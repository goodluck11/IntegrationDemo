# CBQ Logger

A lightweight, structured logging library for Java with field masking, JSON output, and Lombok-style annotations. Perfect for banking, fintech, and any application requiring secure logging.

## Features

- 🎭 **Field Masking**: Automatically mask sensitive data (passwords, card numbers, PINs, etc.)
- 📝 **Structured Logging**: JSON output ready for Splunk, ELK, Datadog
- 🏷️ **Lombok Integration**: Use `@CustomLog` for clean, boilerplate-free logging
- 🔗 **Correlation ID Support**: Track requests across distributed systems
- ⚡ **Exception Utilities**: Log-and-throw, business errors with codes
- 🎨 **Pretty Output**: Colorized console output for development
- ⚙️ **Configurable**: Fluent API, properties, or environment variables

## Quick Start

### 1. Add Dependency

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-logger</artifactId>
    <version>1.0.0</version>
</dependency>
```

### 2. Configure (Optional)

```java
// In your application startup
LoggingConfig.custom()
    .maskFields("password", "cardNumber", "cvv", "pin", "bvn")
    .maskField("cardNumber", 4)       // Show first/last 4: "4111********1111"
    .maskField("cvv", 0)              // Fully masked: "********"
    .excludeFields("internalId", "debugData")
    .maskSymbol('X')
    .defaultVisibleChars(4)
    .outputFormat(LoggingConfig.OutputFormat.JSON)
    .applicationName("payment-service")
    .environment("production")
    .correlationIdKey("X-Correlation-ID")
    .apply();
```

### 3. Add Lombok Config

Copy to your project root as `lombok.config`:

```properties
lombok.log.custom.declaration = com.cbq.logging.core.CbqLog com.cbq.logging.core.CbqLog.getLogger(TYPE)
```

### 4. Use It!

```java
import lombok.CustomLog;

@CustomLog
@Service
public class PaymentService {

    public PaymentResponse processPayment(PaymentRequest request) {
        // Simple logging
        log.info("Processing payment for merchant: {}", request.getMerchantId());
        
        // Structured logging with automatic field masking
        log.structured("payment.received")
           .field("amount", request.getAmount())
           .field("currency", "NGN")
           .field("cardNumber", request.getCardNumber())  // Auto-masked!
           .field("merchantId", request.getMerchantId())
           .log();
        
        try {
            PaymentResponse response = gateway.process(request);
            
            log.structured("payment.success")
               .field("transactionRef", response.getRef())
               .field("amount", request.getAmount())
               .duration(response.getProcessingTime())
               .log();
               
            return response;
            
        } catch (PaymentException e) {
            // Business error with code
            throw log.businessError("PAY_001", "Payment failed: " + e.getMessage(),
                () -> new PaymentFailedException(e));
        }
    }
}
```

## Output Formats

### JSON (Production/Splunk)

```json
{
  "timestamp": "2024-01-15T10:30:45.123Z",
  "level": "INFO",
  "logger": "com.example.PaymentService",
  "thread": "http-nio-8080-exec-1",
  "correlationId": "abc-123-def",
  "application": "payment-service",
  "environment": "production",
  "event": "payment.received",
  "data": {
    "amount": 50000,
    "currency": "NGN",
    "cardNumber": "4111********1111",
    "merchantId": "MERCH001"
  }
}
```

### Pretty (Development)

```
10:30:45.123 INFO  [http-nio-8080-exec-1] c.e.PaymentService : [abc-123-def] Processing payment for merchant: MERCH001
```

## Configuration Reference

### Fluent API

```java
LoggingConfig.custom()
    // Field masking
    .maskFields("password", "cardNumber", "cvv", "pin", "ssn", "iban", "bvn")
    .maskField("cardNumber", 4)              // Show first/last 4 chars
    .fullyMaskField("cvv")                   // Fully masked
    .excludeFields("internalId", "debugData") // Not logged at all
    .maskSymbol('X')                         // Use X instead of *
    .defaultVisibleChars(4)                  // Default visible chars
    .minMaskLength(8)                        // Minimum masked output length
    
    // Output format
    .outputFormat(OutputFormat.JSON)         // JSON, PRETTY, LOGFMT, TEXT
    .prettyPrint(false)                      // Pretty print JSON
    
    // Context
    .includeTimestamp(true)
    .includeLevel(true)
    .includeLogger(true)
    .includeThread(true)
    .includeCorrelationId(true)
    .correlationIdKey("X-Correlation-ID")
    .includeTraceId(true)
    .includeSpanId(true)
    
    // Application metadata
    .applicationName("my-service")
    .applicationVersion("1.0.0")
    .environment("production")
    
    // Exception handling
    .includeStackTrace(true)
    .maxStackTraceDepth(50)
    .includeExceptionCause(true)
    
    // Performance
    .asyncLogging(false)
    .asyncQueueSize(1024)
    
    .apply();
```

### Application Properties (Spring Boot)

```yaml
cbq:
  logging:
    mask-fields:
      - password
      - cardNumber
      - cvv
      - pin
      - bvn
    mask-symbol: "*"
    default-visible-chars: 4
    exclude-fields:
      - internalId
      - debugData
    output-format: JSON
    pretty-print: false
    include-correlation-id: true
    correlation-id-key: X-Correlation-ID
    application-name: payment-service
    environment: production
```

### Environment Variables

```bash
export CBQ_LOGGING_MASK_FIELDS="password,cardNumber,cvv"
export CBQ_LOGGING_APPLICATION_NAME="payment-service"
export CBQ_LOGGING_ENVIRONMENT="production"
```

## Logging Patterns

### Structured Logging

```java
// Basic structured log
log.structured("user.login")
   .field("userId", user.getId())
   .field("email", user.getEmail())
   .log();

// With log level
log.structured("api.call")
   .debug()
   .field("endpoint", "/api/payments")
   .field("method", "POST")
   .log();

// With timing
Instant start = Instant.now();
// ... do work ...
log.structured("operation.complete")
   .durationSince(start)
   .field("recordsProcessed", count)
   .log();

// With request/response
log.structured("api.response")
   .request(request)
   .response(response)
   .duration(processingTime)
   .log();
```

### Exception Handling

```java
// Log and throw
throw log.logAndThrow("Failed to process payment", new PaymentException("..."));

// Log and return custom exception
throw log.errorAndReturn("Database error", cause, 
    () -> new ServiceException("DB_001", "Database unavailable"));

// Business error with code
log.businessError("PAY_002", "Insufficient funds");

// Transaction failure
log.transactionFailure(txnRef, exception);
log.transactionFailure(txnRef, "Card declined", Map.of(
    "responseCode", "05",
    "cardType", "VISA"
));
```

### Correlation ID

```java
// Set correlation ID
log.setCorrelationId("abc-123-def");

// Use with block
log.withCorrelationId("abc-123-def", () -> {
    log.info("This log will include the correlation ID");
    processPayment(request);
});

// Get current
String correlationId = log.getCorrelationId();
```

### Field Masking

```java
// Automatic masking (configured fields)
log.info("Card: {}", cardNumber);  // Outputs: Card: 4111********1111

// Manual masking
String masked = log.mask("cardNumber", cardNumber);

// Object masking
Map<String, Object> maskedData = FieldMasker.maskObject(paymentRequest);

// Annotation-based masking
public class PaymentRequest {
    @MaskSensitive(visibleChars = 4)
    private String cardNumber;
    
    @MaskSensitive(fullyMask = true)
    private String cvv;
    
    @MaskSensitive(exclude = true)
    private String internalDebugData;
}
```

## Logback Configuration

### Development (Pretty Console)

```xml
<configuration>
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder class="com.cbq.logging.encoder.CbqPrettyEncoder">
            <colorEnabled>true</colorEnabled>
            <timestampPattern>HH:mm:ss.SSS</timestampPattern>
        </encoder>
    </appender>
    
    <root level="INFO">
        <appender-ref ref="CONSOLE" />
    </root>
</configuration>
```

### Production (JSON for Splunk)

```xml
<configuration>
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder class="com.cbq.logging.encoder.CbqJsonEncoder">
            <prettyPrint>false</prettyPrint>
            <includeMdc>true</includeMdc>
            <maskSensitiveFields>true</maskSensitiveFields>
        </encoder>
    </appender>
    
    <appender name="ASYNC_CONSOLE" class="ch.qos.logback.classic.AsyncAppender">
        <queueSize>2048</queueSize>
        <neverBlock>true</neverBlock>
        <appender-ref ref="CONSOLE" />
    </appender>
    
    <root level="INFO">
        <appender-ref ref="ASYNC_CONSOLE" />
    </root>
</configuration>
```

## Default Masked Fields

These fields are masked by default (case-insensitive):

- `password`, `passwd`, `pwd`, `secret`
- `token`, `accessToken`, `refreshToken`, `apiKey`
- `cardNumber`, `creditCard`
- `cvv`, `cvc`, `cvv2`, `securityCode`
- `pin`, `pinCode`
- `ssn`, `socialSecurity`
- `iban`, `accountNumber`, `routingNumber`
- `bvn`, `nin` (Nigerian identifiers)
- `privateKey`, `secretKey`

## Spring Boot Integration

```java
@Configuration
public class LoggingConfiguration {
    
    @Bean
    public LoggingConfig cbqLoggingConfig(
            @Value("${spring.application.name}") String appName,
            @Value("${spring.profiles.active:dev}") String environment) {
        
        return LoggingConfig.custom()
            .applicationName(appName)
            .environment(environment)
            .maskFields("password", "cardNumber", "cvv", "pin", "bvn")
            .outputFormat(
                "prod".equals(environment) 
                    ? LoggingConfig.OutputFormat.JSON 
                    : LoggingConfig.OutputFormat.PRETTY
            )
            .apply();
    }
}
```

## Thread Safety

CBQ Logger is fully thread-safe:
- `LoggingConfig` uses thread-safe collections
- `CbqLog` instances can be shared across threads
- `StructuredLogBuilder` is designed for single-thread use (builder pattern)

## Performance

- Minimal overhead (~1-2μs per log call)
- Lazy evaluation of masked fields
- Async logging support for high-throughput scenarios
- Efficient JSON serialization with Jackson

## License

MIT License - See LICENSE file for details.
