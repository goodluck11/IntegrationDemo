package com.cbq.logging.pool.core;

/*
 * @created by 06/02/2026  - 18:03
 * @project cbq-logger
 * @author Goodluck
 */
public final class RequestContextHolder {

   private RequestContextHolder() {
   }

   private static final ThreadLocal<RequestContext> CONTEXT = new ThreadLocal<>();

   public static void set(String requestId, String requestTime) {
      CONTEXT.set(new RequestContext(requestId, requestTime));
   }

   public static void setRequestId(String requestId) {
      set(requestId, null);
   }

   public static RequestContext get() {
      return CONTEXT.get();
   }

   public static String getRequestId() {
      RequestContext ctx = CONTEXT.get();
      return ctx != null ? ctx.requestId() : null;
   }

   public static String getRequestTime() {
      RequestContext ctx = CONTEXT.get();
      return ctx != null ? ctx.requestTime() : null;
   }

   public static void clear() {
      CONTEXT.remove();
   }

   /**
       * Immutable holder for request context extracted from body's requestInfo.
       */
      public record RequestContext(String requestId, String requestTime) {
   }
}
