package com.cbq.logging.pool.jdbc;

import com.cbq.logging.pool.core.RequestContextHolder;
import com.cbq.logging.pool.core.RequestInfo;
import com.cbq.logging.pool.core.RequestInfoExtractor;
import org.slf4j.MDC;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Servlet Filter (javax, for Spring Boot 2.7.x) that automatically extracts
 * {@code requestInfo.requestId} and {@code requestInfo.requestTime} from the
 * JSON request body and sets them in {@link RequestContextHolder} + MDC.
 * <p>
 * Extraction priority:
 * <ol>
 *   <li>Body: {@code requestInfo.requestId} (nested object)</li>
 *   <li>Body: {@code requestId} (top-level field)</li>
 *   <li>Header: {@code X-Request-ID}</li>
 *   <li>Header: {@code X-Correlation-ID}</li>
 *   <li>Auto-generated short UUID</li>
 * </ol>
 * <p>
 * The body is cached and re-readable so downstream controllers still work.
 * Only caches for JSON content types and POST/PUT/PATCH methods.
 */
public class JavaxRequestIdFilter implements Filter {

   private static final int MAX_BODY_CACHE_SIZE = 8192; // 8KB max for extraction

   @Override
   public void init(FilterConfig filterConfig) throws ServletException {
   }

   @Override
   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
           throws IOException, ServletException {
      var httpReq = (HttpServletRequest) request;
      try {
         var info = extractFromRequest(httpReq);
         String requestId;
         String requestTime;

         if (info != null) {
            requestId = info.requestId();
            requestTime = info.requestTime();
            httpReq = new CachedBodyRequestWrapper(httpReq);
         } else {
            requestId = extractFromHeaders(httpReq);
            requestTime = null;
         }

         if (requestId == null || requestId.isEmpty()) {
            requestId = generateShortId();
         }

         RequestContextHolder.set(requestId, requestTime);
         MDC.put("requestId", requestId);
         if (requestTime != null) MDC.put("requestTime", requestTime);

         chain.doFilter(httpReq, response);
      } finally {
         RequestContextHolder.clear();
         MDC.remove("requestId");
         MDC.remove("requestTime");
      }
   }

   @Override
   public void destroy() {
   }

   private RequestInfo extractFromRequest(HttpServletRequest request) {
      if (!isJsonBody(request)) return null;
      String method = request.getMethod();
      if (!"POST".equals(method) && !"PUT".equals(method) && !"PATCH".equals(method)) return null;

      try {
         // Read up to MAX_BODY_CACHE_SIZE bytes
         ServletInputStream input = request.getInputStream();
         byte[] buffer = new byte[MAX_BODY_CACHE_SIZE];
         int totalRead = 0;
         int bytesRead;
         while (totalRead < buffer.length &&
                 (bytesRead = input.read(buffer, totalRead, buffer.length - totalRead)) > 0) {
            totalRead += bytesRead;
         }

         if (totalRead > 0) {
            String body = new String(buffer, 0, totalRead, StandardCharsets.UTF_8);
            return RequestInfoExtractor.extract(body);
         }
      } catch (IOException e) {
         // Silently fall through to header extraction
      }
      return null;
   }

   private String extractFromHeaders(HttpServletRequest request) {
      String id = request.getHeader("X-Request-ID");
      if (id != null && !id.isEmpty()) return id;
      id = request.getHeader("X-Correlation-ID");
      if (id != null && !id.isEmpty()) return id;
      return null;
   }

   private boolean isJsonBody(HttpServletRequest request) {
      String ct = request.getContentType();
      return ct != null && ct.contains("application/json");
   }

   private String generateShortId() {
      return UUID.randomUUID().toString().replace("-", "").substring(0, 12);
   }

   /**
    * Wraps the request to allow the body to be read multiple times.
    * The body is cached in memory (up to MAX_BODY_CACHE_SIZE).
    */
   private static class CachedBodyRequestWrapper extends HttpServletRequestWrapper {
      private byte[] cachedBody;

      CachedBodyRequestWrapper(HttpServletRequest request) throws IOException {
         super(request);
         // Read entire body
         ServletInputStream input = request.getInputStream();
         this.cachedBody = input.readAllBytes();
      }

      @Override
      public ServletInputStream getInputStream() {
         ByteArrayInputStream bais = new ByteArrayInputStream(cachedBody);
         return new ServletInputStream() {
            @Override
            public int read() {
               return bais.read();
            }

            @Override
            public int read(byte[] b, int off, int len) {
               return bais.read(b, off, len);
            }

            @Override
            public boolean isFinished() {
               return bais.available() == 0;
            }

            @Override
            public boolean isReady() {
               return true;
            }

            @Override
            public void setReadListener(ReadListener listener) {
            }
         };
      }

      @Override
      public BufferedReader getReader() {
         return new BufferedReader(new InputStreamReader(
                 new ByteArrayInputStream(cachedBody), StandardCharsets.UTF_8));
      }
   }
}