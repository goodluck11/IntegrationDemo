package com.cbq.logging.pool.core;

/*
 * @created by 06/02/2026  - 18:06
 * @project cbq-logger
 * @author Goodluck
 */
public final class ReactiveRequestContext {

   private ReactiveRequestContext() {
   }

   public static final String REQUEST_ID_KEY = "pool-monitor.request-id";
   public static final String REQUEST_TIME_KEY = "pool-monitor.request-time";
}
