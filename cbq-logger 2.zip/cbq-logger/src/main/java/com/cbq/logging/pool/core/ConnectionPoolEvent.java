package com.cbq.logging.pool.core;

/*
 * @created by 06/02/2026  - 18:01
 * @project cbq-logger
 * @author Goodluck
 */

/**
 * Immutable, lightweight event representing a connection pool action.
 * Uses primitive fields and avoids allocations for maximum performance.
 * <p>
 * {@code poolName} distinguishes events from multiple databases
 * (e.g. "core-banking", "fraud-db", "audit-db").
 */
public final class ConnectionPoolEvent {

   public enum Action {
      ACQUIRED, RELEASED
   }

   private final String requestId;
   private final String requestTime;
   private final Action action;
   private final long durationNanos;
   private final long timestampEpochMillis;
   private final String poolType; // "R2DBC" or "JDBC"
   private final String poolName; // logical database name

   public ConnectionPoolEvent(String requestId, String requestTime, Action action,
                              long durationNanos, long timestampEpochMillis,
                              String poolType, String poolName) {
      this.requestId = requestId;
      this.requestTime = requestTime;
      this.action = action;
      this.durationNanos = durationNanos;
      this.timestampEpochMillis = timestampEpochMillis;
      this.poolType = poolType;
      this.poolName = poolName;
   }

   public String getRequestId()          { return requestId; }
   public String getRequestTime()        { return requestTime; }
   public Action getAction()             { return action; }
   public long getDurationNanos()        { return durationNanos; }
   public long getTimestampEpochMillis() { return timestampEpochMillis; }
   public String getPoolType()           { return poolType; }
   public String getPoolName()           { return poolName; }

   public double getDurationMillis() {
      return durationNanos / 1_000_000.0;
   }

   @Override
   public String toString() {
      return new StringBuilder(160)
              .append("[pool-monitor] requestId=").append(requestId)
              .append(" requestTime=").append(requestTime != null ? requestTime : "-")
              .append(" action=").append(action)
              .append(" pool=").append(poolType).append('/').append(poolName)
              .append(" duration=").append(String.format("%.3fms", getDurationMillis()))
              .toString();
   }
}
