package com.cbq.logging.pool.r2dbc;

import com.cbq.logging.pool.core.ReactiveRequestContext;
import com.cbq.logging.pool.core.RequestInfo;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * WebFlux WebFilter that extracts {@code requestInfo.requestId} and
 * {@code requestInfo.requestTime} from the JSON request body and injects
 * them into the Reactor Context for downstream R2DBC monitoring.
 * <p>
 * Extraction priority:
 * <ol>
 *   <li>Body: {@code requestInfo.requestId} (nested)</li>
 *   <li>Body: {@code requestId} (top-level)</li>
 *   <li>Header: {@code X-Request-ID}</li>
 *   <li>Header: {@code X-Correlation-ID}</li>
 *   <li>Auto-generated UUID</li>
 * </ol>
 * <p>
 * The body is cached and replayed so downstream handlers still read it normally.
 */
public class ReactiveRequestIdWebFilter implements WebFilter {

   private static final int MAX_BODY_BYTES = 8192;

   @Override
   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
      ServerHttpRequest request = exchange.getRequest();

      if (shouldReadBody(request)) {
         return DataBufferUtils.join(request.getBody(), MAX_BODY_BYTES)
                 .defaultIfEmpty(DefaultDataBufferFactory.sharedInstance.allocateBuffer(0))
                 .flatMap(dataBuffer -> {
                    byte[] bytes = new byte[dataBuffer.readableByteCount()];
                    dataBuffer.read(bytes);
                    DataBufferUtils.release(dataBuffer);

                    String body = new String(bytes, StandardCharsets.UTF_8);
                    RequestInfo info = RequestInfoExtractor.extract(body);

                    String requestId;
                    String requestTime;
                    if (info != null && info.requestId() != null) {
                       requestId = info.requestId();
                       requestTime = info.requestTime();
                    } else {
                       requestId = resolveFromHeaders(request);
                       requestTime = null;
                    }

                    // Replay cached body
                    DataBuffer cachedBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
                    ServerHttpRequest mutatedRequest = new ServerHttpRequestDecorator(request) {
                       @Override
                       public Flux<DataBuffer> getBody() {
                          return Flux.just(cachedBuffer);
                       }
                    };
                    ServerWebExchange mutatedExchange = exchange.mutate().request(mutatedRequest).build();

                    return chain.filter(mutatedExchange)
                            .contextWrite(ctx -> {
                               ctx = ctx.put(ReactiveRequestContext.REQUEST_ID_KEY, requestId);
                               if (requestTime != null) {
                                  ctx = ctx.put(ReactiveRequestContext.REQUEST_TIME_KEY, requestTime);
                               }
                               return ctx;
                            });
                 });
      }

      // Non-body requests: use headers only
      String requestId = resolveFromHeaders(request);
      return chain.filter(exchange)
              .contextWrite(ctx -> ctx.put(ReactiveRequestContext.REQUEST_ID_KEY, requestId));
   }

   private boolean shouldReadBody(ServerHttpRequest request) {
      HttpMethod method = request.getMethod();
      if (method != HttpMethod.POST && method != HttpMethod.PUT && method != HttpMethod.PATCH) {
         return false;
      }
      MediaType contentType = request.getHeaders().getContentType();
      return contentType != null && contentType.isCompatibleWith(MediaType.APPLICATION_JSON);
   }

   private String resolveFromHeaders(ServerHttpRequest request) {
      String id = request.getHeaders().getFirst("X-Request-ID");
      if (id != null && !id.isEmpty()) return id;
      id = request.getHeaders().getFirst("X-Correlation-ID");
      if (id != null && !id.isEmpty()) return id;
      return UUID.randomUUID().toString().replace("-", "").substring(0, 12);
   }
}
