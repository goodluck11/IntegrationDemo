package com.cbq.logging.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to automatically log method entry, exit, and exceptions.
 * <p>
 * Usage:
 * <pre>
 * &#64;LogMethod(includeArgs = true, includeResult = true)
 * public PaymentResponse processPayment(PaymentRequest request) {
 *     // Method implementation
 * }
 * </pre>
 * <p>
 * This will automatically log:
 * - Method entry with arguments (if includeArgs = true)
 * - Method exit with result (if includeResult = true)
 * - Any exceptions thrown
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface LogMethod {
    
    /**
     * Log level for method entry/exit. Default is DEBUG.
     */
    String level() default "DEBUG";
    
    /**
     * Include method arguments in the log.
     */
    boolean includeArgs() default true;
    
    /**
     * Include method result in the log.
     */
    boolean includeResult() default true;
    
    /**
     * Include execution time in milliseconds.
     */
    boolean includeExecutionTime() default true;
    
    /**
     * Custom message prefix.
     */
    String message() default "";
}
