package com.cbq.logging.pool.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration properties for CBQ connection pool monitoring.
 * <pre>
 * cbq:
 *   pool-monitor:
 *     enabled: true
 *     log-level: DEBUG
 *     buffer-size: 4096
 *     slow-threshold-ms: 100
 *     default-pool-name: primary
 *     pool-names:                        # Map bean name → logical pool name
 *       coreBankingDataSource: core-banking
 *       fraudDataSource: fraud-db
 *       auditDataSource: audit-db
 *       coreBankingConnectionFactory: core-banking-r2dbc
 * </pre>
 */
@ConfigurationProperties(prefix = "cbq.pool-monitor")
public class PoolMonitorProperties {

   private boolean enabled = true;
   private String logLevel = "DEBUG";
   private int bufferSize = 4096;
   private long slowThresholdMs = 100;
   private String defaultPoolName = "default";

   /**
    * Maps DataSource/ConnectionFactory bean names to logical pool names.
    * If a bean name is not found here, {@code defaultPoolName} is used.
    */
   private Map<String, String> poolNames = new HashMap<>();

   public boolean isEnabled() { return enabled; }
   public void setEnabled(boolean enabled) { this.enabled = enabled; }

   public String getLogLevel() { return logLevel; }
   public void setLogLevel(String logLevel) { this.logLevel = logLevel; }

   public int getBufferSize() { return bufferSize; }
   public void setBufferSize(int bufferSize) { this.bufferSize = bufferSize; }

   public long getSlowThresholdMs() { return slowThresholdMs; }
   public void setSlowThresholdMs(long slowThresholdMs) { this.slowThresholdMs = slowThresholdMs; }

   public String getDefaultPoolName() { return defaultPoolName; }
   public void setDefaultPoolName(String defaultPoolName) { this.defaultPoolName = defaultPoolName; }

   public Map<String, String> getPoolNames() { return poolNames; }
   public void setPoolNames(Map<String, String> poolNames) { this.poolNames = poolNames; }

   /**
    * Resolve the logical pool name for a given bean name.
    */
   public String resolvePoolName(String beanName) {
      return poolNames.getOrDefault(beanName, defaultPoolName);
   }
}