package com.cbq.logging.pool.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Ultra-lightweight, lock-free, asynchronous event dispatcher.
 * <p>
 * Design:
 * <ul>
 *   <li>Bounded MPSC (Multi-Producer Single-Consumer) ring buffer</li>
 *   <li>Zero-allocation on the hot path (event into pre-allocated slot)</li>
 *   <li>Single daemon thread drains the buffer</li>
 *   <li>Back-pressure: buffer full → event dropped + counter incremented</li>
 *   <li>No locks, no synchronized blocks, pure CAS operations</li>
 * </ul>
 */
public final class AsyncEventDispatcher implements AutoCloseable {

   private static final Logger log = LoggerFactory.getLogger(AsyncEventDispatcher.class);

   private static final int DEFAULT_BUFFER_SIZE = 4096;

   private final ConnectionPoolEvent[] ringBuffer;
   private final int mask;
   private final AtomicInteger writeIndex = new AtomicInteger(0);
   private volatile int readIndex = 0;
   private final AtomicBoolean running = new AtomicBoolean(true);
   private final AtomicInteger droppedEvents = new AtomicInteger(0);

   private final List<ConnectionPoolEventListener> listeners = new CopyOnWriteArrayList<>();
   private final Thread drainThread;

   public AsyncEventDispatcher() {
      this(DEFAULT_BUFFER_SIZE);
   }

   public AsyncEventDispatcher(int bufferSize) {
      if (Integer.bitCount(bufferSize) != 1) {
         throw new IllegalArgumentException("bufferSize must be a power of 2, got: " + bufferSize);
      }
      this.ringBuffer = new ConnectionPoolEvent[bufferSize];
      this.mask = bufferSize - 1;

      this.drainThread = new Thread(this::drainLoop, "cbq-pool-monitor-dispatcher");
      this.drainThread.setDaemon(true);
      this.drainThread.setPriority(Thread.MIN_PRIORITY);
      this.drainThread.start();
   }

   /**
    * Publish an event. Non-blocking, lock-free.
    * If the buffer is full, the event is dropped and a counter incremented.
    */
   public void publish(ConnectionPoolEvent event) {
      int currentWrite;
      int nextWrite;
      do {
         currentWrite = writeIndex.get();
         nextWrite = (currentWrite + 1) & mask;
         if (nextWrite == readIndex) {
            droppedEvents.incrementAndGet();
            return;
         }
      } while (!writeIndex.compareAndSet(currentWrite, nextWrite));

      ringBuffer[currentWrite & mask] = event;
   }

   public void addListener(ConnectionPoolEventListener listener) {
      listeners.add(listener);
   }

   public void removeListener(ConnectionPoolEventListener listener) {
      listeners.remove(listener);
   }

   public int getDroppedEventCount() {
      return droppedEvents.get();
   }

   private void drainLoop() {
      while (running.get()) {
         try {
            boolean idle = drain();
            if (idle) {
               Thread.sleep(1);
            }
         } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            break;
         } catch (Exception e) {
            log.warn("[cbq-pool-monitor] Error in drain loop", e);
         }
      }
      drain(); // final drain
   }

   private boolean drain() {
      boolean processed = false;
      int currentRead = readIndex;
      int currentWrite = writeIndex.get();

      while (currentRead != currentWrite) {
         ConnectionPoolEvent event = ringBuffer[currentRead & mask];
         if (event != null) {
            ringBuffer[currentRead & mask] = null;
            dispatchToListeners(event);
            processed = true;
         }
         currentRead = (currentRead + 1) & mask;
      }
      readIndex = currentRead;
      return !processed;
   }

   private void dispatchToListeners(ConnectionPoolEvent event) {
      for (ConnectionPoolEventListener listener : listeners) {
         try {
            listener.onEvent(event);
         } catch (Exception e) {
            log.warn("[cbq-pool-monitor] Listener error for requestId={}", event.getRequestId(), e);
         }
      }
   }

   @Override
   public void close() {
      running.set(false);
      drainThread.interrupt();
      try {
         drainThread.join(2000);
      } catch (InterruptedException e) {
         Thread.currentThread().interrupt();
      }
      int dropped = droppedEvents.get();
      if (dropped > 0) {
         log.info("[cbq-pool-monitor] Total dropped events during lifetime: {}", dropped);
      }
   }
}
