package com.cbq.logging.mask;

import com.cbq.logging.annotation.MaskSensitive;
import com.cbq.logging.config.LoggingConfig;

import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Utility class for masking sensitive field values.
 * <p>
 * Supports:
 * - Field name-based masking (configured via LoggingConfig)
 * - Annotation-based masking (@MaskSensitive)
 * - Object introspection for automatic masking
 */
public final class FieldMasker {
    
    private static final Map<Class<?>, Map<String, MaskSensitive>> ANNOTATION_CACHE = new ConcurrentHashMap<>();
    
    private FieldMasker() {
        // Utility class
    }
    
    /**
     * Mask a value based on field name using global configuration.
     *
     * @param fieldName the field name
     * @param value     the value to mask
     * @return masked value or original if not configured for masking
     */
    public static String mask(String fieldName, Object value) {
        if (value == null) return null;
        
        LoggingConfig config = LoggingConfig.getInstance();
        
        // Check if field should be excluded
        if (config.shouldExcludeField(fieldName)) {
            return "[EXCLUDED]";
        }
        
        // Check if field should be masked
        if (config.shouldMaskField(fieldName)) {
            FieldMaskConfig maskConfig = config.getMaskConfig(fieldName);
            return maskValue(value.toString(), maskConfig);
        }
        
        return value.toString();
    }
    
    /**
     * Mask a value with specific configuration.
     *
     * @param value      the value to mask
     * @param maskConfig the mask configuration
     * @return masked value
     */
    public static String maskValue(String value, FieldMaskConfig maskConfig) {
        if (value == null || value.isEmpty()) return value;
        
        if (maskConfig.exclude()) {
            return "[EXCLUDED]";
        }
        
        if (maskConfig.fullyMask()) {
            return repeatChar(maskConfig.maskSymbol(), 
                Math.max(value.length(), LoggingConfig.getInstance().getMinMaskLength()));
        }
        
        int visibleChars = maskConfig.visibleChars();
        int length = value.length();
        
        // If value is too short, fully mask it
        if (length <= visibleChars * 2) {
            return repeatChar(maskConfig.maskSymbol(), 
                Math.max(length, LoggingConfig.getInstance().getMinMaskLength()));
        }
        
        // Show first and last N characters
        String prefix = value.substring(0, visibleChars);
        String suffix = value.substring(length - visibleChars);
        int maskLength = length - (visibleChars * 2);
        String masked = repeatChar(maskConfig.maskSymbol(), maskLength);
        
        return prefix + masked + suffix;
    }
    
    /**
     * Mask an object by introspecting its fields.
     *
     * @param obj the object to mask
     * @return map of field names to masked values
     */
    public static Map<String, Object> maskObject(Object obj) {
        if (obj == null) return Map.of();
        
        Map<String, Object> result = new LinkedHashMap<>();
        Class<?> clazz = obj.getClass();
        
        // Get cached annotations for this class
        Map<String, MaskSensitive> annotations = getAnnotationCache(clazz);
        
        for (Field field : clazz.getDeclaredFields()) {
            field.setAccessible(true);
            String fieldName = field.getName();
            
            try {
                Object value = field.get(obj);
                
                // Check for annotation first
                MaskSensitive annotation = annotations.get(fieldName);
                if (annotation != null) {
                    if (annotation.exclude()) {
                        // Skip excluded fields
                        continue;
                    }
                    if (value != null) {
                        FieldMaskConfig config = new FieldMaskConfig(
                            annotation.visibleChars(),
                            annotation.maskSymbol(),
                            annotation.fullyMask(),
                            annotation.exclude()
                        );
                        result.put(fieldName, maskValue(value.toString(), config));
                    } else {
                        result.put(fieldName, null);
                    }
                } else {
                    // Use global config
                    result.put(fieldName, mask(fieldName, value));
                }
            } catch (IllegalAccessException e) {
                result.put(fieldName, "[ACCESS_ERROR]");
            }
        }
        
        return result;
    }
    
    /**
     * Mask a map of values.
     *
     * @param data the map to mask
     * @return new map with masked values
     */
    public static Map<String, Object> maskMap(Map<String, Object> data) {
        if (data == null) return Map.of();
        
        Map<String, Object> result = new LinkedHashMap<>();
        LoggingConfig config = LoggingConfig.getInstance();
        
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            
            if (config.shouldExcludeField(key)) {
                continue; // Skip excluded fields
            }
            
            if (value == null) {
                result.put(key, null);
            } else if (value instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> nestedMap = (Map<String, Object>) value;
                result.put(key, maskMap(nestedMap));
            } else if (config.shouldMaskField(key)) {
                FieldMaskConfig maskConfig = config.getMaskConfig(key);
                result.put(key, maskValue(value.toString(), maskConfig));
            } else {
                result.put(key, value);
            }
        }
        
        return result;
    }
    
    /**
     * Mask specific fields in a string (e.g., for log messages).
     * Looks for patterns like fieldName=value or "fieldName": "value"
     *
     * @param message the message to mask
     * @return message with masked field values
     */
    public static String maskMessage(String message) {
        if (message == null || message.isEmpty()) return message;
        
        LoggingConfig config = LoggingConfig.getInstance();
        String result = message;
        
        for (String fieldName : config.getDefaultMaskedFields()) {
            // Match patterns like: password=value, password="value", "password": "value"
            result = maskFieldInString(result, fieldName, config);
        }
        
        for (String fieldName : config.getFieldMaskConfigs().keySet()) {
            result = maskFieldInString(result, fieldName, config);
        }
        
        return result;
    }
    
    private static String maskFieldInString(String message, String fieldName, LoggingConfig config) {
        FieldMaskConfig maskConfig = config.getMaskConfig(fieldName);
        
        // Pattern: fieldName=value (until space or end)
        String pattern1 = "(?i)(" + fieldName + "=)([^\\s,}\"]+)";
        message = message.replaceAll(pattern1, "$1" + getMaskReplacement(maskConfig));
        
        // Pattern: fieldName="value"
        String pattern2 = "(?i)(" + fieldName + "=\")([^\"]*)(\")";
        message = message.replaceAll(pattern2, "$1" + getMaskReplacement(maskConfig) + "$3");
        
        // Pattern: "fieldName": "value"
        String pattern3 = "(?i)(\"" + fieldName + "\"\\s*:\\s*\")([^\"]*)(\")";
        message = message.replaceAll(pattern3, "$1" + getMaskReplacement(maskConfig) + "$3");
        
        // Pattern: "fieldName": value (number or boolean)
        String pattern4 = "(?i)(\"" + fieldName + "\"\\s*:\\s*)([^,}\\s]+)";
        message = message.replaceAll(pattern4, "$1" + getMaskReplacement(maskConfig));
        
        return message;
    }
    
    private static String getMaskReplacement(FieldMaskConfig config) {
        if (config.fullyMask() || config.visibleChars() == 0) {
            return repeatChar(config.maskSymbol(), LoggingConfig.getInstance().getMinMaskLength());
        }
        return repeatChar(config.maskSymbol(), LoggingConfig.getInstance().getMinMaskLength());
    }
    
    private static Map<String, MaskSensitive> getAnnotationCache(Class<?> clazz) {
        return ANNOTATION_CACHE.computeIfAbsent(clazz, c -> {
            Map<String, MaskSensitive> cache = new ConcurrentHashMap<>();
            for (Field field : c.getDeclaredFields()) {
                MaskSensitive annotation = field.getAnnotation(MaskSensitive.class);
                if (annotation != null) {
                    cache.put(field.getName(), annotation);
                }
            }
            return cache;
        });
    }
    
    private static String repeatChar(char c, int count) {
        return String.valueOf(c).repeat(Math.max(0, count));
    }
}
