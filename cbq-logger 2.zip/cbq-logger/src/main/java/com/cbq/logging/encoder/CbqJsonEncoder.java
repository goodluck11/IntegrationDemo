package com.cbq.logging.encoder;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.StackTraceElementProxy;
import ch.qos.logback.core.encoder.EncoderBase;
import com.cbq.logging.config.LoggingConfig;
import com.cbq.logging.mask.FieldMasker;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;

/**
 * Logback encoder that outputs structured JSON logs.
 * <p>
 * This encoder automatically:
 * <ul>
 *     <li>Masks sensitive fields based on LoggingConfig</li>
 *     <li>Includes MDC context (correlation ID, trace ID, etc.)</li>
 *     <li>Formats exceptions with configurable stack trace depth</li>
 *     <li>Outputs Splunk-compatible JSON format</li>
 * </ul>
 * <p>
 * Usage in logback.xml:
 * <pre>
 * &lt;encoder class="com.cbq.logging.encoder.CbqJsonEncoder"&gt;
 *     &lt;prettyPrint&gt;false&lt;/prettyPrint&gt;
 *     &lt;includeContext&gt;true&lt;/includeContext&gt;
 *     &lt;includeMdc&gt;true&lt;/includeMdc&gt;
 * &lt;/encoder&gt;
 * </pre>
 */
public class CbqJsonEncoder extends EncoderBase<ILoggingEvent> {
    
    private static final ObjectMapper OBJECT_MAPPER = createObjectMapper();
    private static final byte[] LINE_SEPARATOR = System.lineSeparator().getBytes(StandardCharsets.UTF_8);
    
    private boolean prettyPrint = false;
    private boolean includeContext = true;
    private boolean includeMdc = true;
    private boolean includeCallerData = false;
    private boolean maskSensitiveFields = true;
    
    private static ObjectMapper createObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return mapper;
    }
    
    @Override
    public byte[] headerBytes() {
        return null;
    }
    
    @Override
    public byte[] encode(ILoggingEvent event) {
        try {
            Map<String, Object> logEntry = buildLogEntry(event);
            String json = prettyPrint ? 
                OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(logEntry) :
                OBJECT_MAPPER.writeValueAsString(logEntry);
            
            byte[] jsonBytes = json.getBytes(StandardCharsets.UTF_8);
            byte[] result = new byte[jsonBytes.length + LINE_SEPARATOR.length];
            System.arraycopy(jsonBytes, 0, result, 0, jsonBytes.length);
            System.arraycopy(LINE_SEPARATOR, 0, result, jsonBytes.length, LINE_SEPARATOR.length);
            
            return result;
        } catch (JsonProcessingException e) {
            return createFallbackEntry(event).getBytes(StandardCharsets.UTF_8);
        }
    }
    
    @Override
    public byte[] footerBytes() {
        return null;
    }
    
    private Map<String, Object> buildLogEntry(ILoggingEvent event) {
        LoggingConfig config = LoggingConfig.getInstance();
        Map<String, Object> entry = new LinkedHashMap<>();
        
        // Timestamp
        entry.put("timestamp", Instant.ofEpochMilli(event.getTimeStamp()).toString());
        
        // Level
        entry.put("level", event.getLevel().toString());
        
        // Logger
        entry.put("logger", event.getLoggerName());
        
        // Thread
        entry.put("thread", event.getThreadName());
        
        // Message (with potential masking)
        String message = event.getFormattedMessage();
        if (maskSensitiveFields) {
            message = FieldMasker.maskMessage(message);
        }
        entry.put("message", message);
        
        // MDC context
        if (includeMdc && event.getMDCPropertyMap() != null && !event.getMDCPropertyMap().isEmpty()) {
            Map<String, String> mdc = new LinkedHashMap<>(event.getMDCPropertyMap());
            
            // Extract known fields
            if (config.isIncludeCorrelationId() && mdc.containsKey(config.getCorrelationIdKey())) {
                entry.put("correlationId", mdc.remove(config.getCorrelationIdKey()));
            }
            if (config.isIncludeTraceId() && mdc.containsKey(config.getTraceIdKey())) {
                entry.put("traceId", mdc.remove(config.getTraceIdKey()));
            }
            if (config.isIncludeSpanId() && mdc.containsKey(config.getSpanIdKey())) {
                entry.put("spanId", mdc.remove(config.getSpanIdKey()));
            }
            
            // Include remaining MDC as context
            if (!mdc.isEmpty()) {
                entry.put("context", mdc);
            }
        }
        
        // Application metadata
        if (config.getApplicationName() != null) {
            entry.put("application", config.getApplicationName());
        }
        if (config.getEnvironment() != null) {
            entry.put("environment", config.getEnvironment());
        }
        
        // Caller data (if enabled)
        if (includeCallerData) {
            StackTraceElement[] callerData = event.getCallerData();
            if (callerData != null && callerData.length > 0) {
                Map<String, Object> caller = new LinkedHashMap<>();
                caller.put("class", callerData[0].getClassName());
                caller.put("method", callerData[0].getMethodName());
                caller.put("file", callerData[0].getFileName());
                caller.put("line", callerData[0].getLineNumber());
                entry.put("caller", caller);
            }
        }
        
        // Exception
        IThrowableProxy throwableProxy = event.getThrowableProxy();
        if (throwableProxy != null) {
            entry.put("exception", formatException(throwableProxy, config));
        }
        
        return entry;
    }
    
    private Map<String, Object> formatException(IThrowableProxy throwable, LoggingConfig config) {
        Map<String, Object> exception = new LinkedHashMap<>();
        exception.put("type", throwable.getClassName());
        exception.put("message", throwable.getMessage());
        
        if (config.isIncludeStackTrace()) {
            StackTraceElementProxy[] stackTrace = throwable.getStackTraceElementProxyArray();
            if (stackTrace != null) {
                int depth = Math.min(stackTrace.length, config.getMaxStackTraceDepth());
                List<String> frames = new ArrayList<>(depth);
                for (int i = 0; i < depth; i++) {
                    frames.add(stackTrace[i].getStackTraceElement().toString());
                }
                exception.put("stackTrace", frames);
            }
        }
        
        if (config.isIncludeExceptionCause() && throwable.getCause() != null) {
            exception.put("cause", formatException(throwable.getCause(), config));
        }
        
        return exception;
    }
    
    private String createFallbackEntry(ILoggingEvent event) {
        return String.format(
            "{\"timestamp\":\"%s\",\"level\":\"%s\",\"logger\":\"%s\",\"message\":\"%s\",\"error\":\"JSON serialization failed\"}%n",
            Instant.ofEpochMilli(event.getTimeStamp()),
            event.getLevel(),
            event.getLoggerName(),
            escapeJson(event.getFormattedMessage())
        );
    }
    
    private String escapeJson(String text) {
        if (text == null) return "";
        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }
    
    // Setters for Logback configuration
    
    public void setPrettyPrint(boolean prettyPrint) {
        this.prettyPrint = prettyPrint;
    }
    
    public void setIncludeContext(boolean includeContext) {
        this.includeContext = includeContext;
    }
    
    public void setIncludeMdc(boolean includeMdc) {
        this.includeMdc = includeMdc;
    }
    
    public void setIncludeCallerData(boolean includeCallerData) {
        this.includeCallerData = includeCallerData;
    }
    
    public void setMaskSensitiveFields(boolean maskSensitiveFields) {
        this.maskSensitiveFields = maskSensitiveFields;
    }
}
