package com.cbq.logging.pool.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Lightweight JSON parser that extracts {@code requestInfo.requestId} and
 * {@code requestInfo.requestTime} from a request body string WITHOUT
 * full JSON deserialization (no Jackson/Gson dependency on hot path).
 * <p>
 * Handles the standard CBQ request body pattern:
 * <pre>
 * {
 *   "someField": "value",
 *   "requestInfo": {
 *     "requestId": "Req-cba52cfc-e888-40ac-8352-b1949e286e59",
 *     "requestTime": "2025-11-11T09:00:00"
 *   }
 * }
 * </pre>
 * <p>
 * Also supports flat body where requestId is at the root level:
 * <pre>
 * {
 *   "requestId": "11223344123",
 *   "aliasValue": "ramz"
 * }
 * </pre>
 * <p>
 * Design: Pure string scanning — no regex, no object allocation beyond the result.
 * Handles escaped quotes, whitespace variations, and nested objects.
 */
public final class RequestInfoExtractor {

   private static final Logger log = LoggerFactory.getLogger(RequestInfoExtractor.class);

   private RequestInfoExtractor() {
   }

   /**
    * Extract requestId and requestTime from a JSON body string.
    * <p>
    * Strategy:
    * <ol>
    *   <li>Look for "requestInfo" object → extract requestId and requestTime from it</li>
    *   <li>Fallback: look for top-level "requestId"</li>
    *   <li>Fallback: look for X-Request-ID style (handled by caller)</li>
    * </ol>
    *
    * @param body the raw JSON body string (may be null/empty)
    * @return extracted info, or null if nothing found
    */
   public static RequestInfo extract(String body) {
      if (body == null || body.isEmpty()) {
         return null;
      }

      try {
         // Strategy 1: Look for "requestInfo" nested object
         String requestId = null;
         String requestTime = null;

         int requestInfoIdx = indexOfKey(body, "requestInfo");
         if (requestInfoIdx >= 0) {
            // Find the opening brace of the requestInfo object
            int braceStart = body.indexOf('{', requestInfoIdx);
            if (braceStart >= 0) {
               int braceEnd = findMatchingBrace(body, braceStart);
               if (braceEnd > braceStart) {
                  String innerBlock = body.substring(braceStart, braceEnd + 1);
                  requestId = extractStringValue(innerBlock, "requestId");
                  requestTime = extractStringValue(innerBlock, "requestTime");
               }
            }
         }

         // Strategy 2: Fallback to top-level requestId
         if (requestId == null) {
            requestId = extractStringValue(body, "requestId");
         }
         if (requestTime == null) {
            requestTime = extractStringValue(body, "requestTime");
         }

         if (requestId != null) {
            return new RequestInfo(requestId, requestTime);
         }
      } catch (Exception e) {
         log.trace("Failed to extract requestInfo from body", e);
      }

      return null;
   }

   /**
    * Find index of a JSON key in the string, handling quotes.
    */
   private static int indexOfKey(String json, String key) {
      String pattern1 = "\"" + key + "\"";
      int idx = json.indexOf(pattern1);
      if (idx >= 0) {
         // Verify it's followed by a colon (with optional whitespace)
         int afterQuote = idx + pattern1.length();
         for (int i = afterQuote; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == ':') return idx;
            if (c != ' ' && c != '\t' && c != '\n' && c != '\r') break;
         }
      }
      return -1;
   }

   /**
    * Extract a string value for a given key from a JSON fragment.
    */
   private static String extractStringValue(String json, String key) {
      String pattern = "\"" + key + "\"";
      int keyIdx = json.indexOf(pattern);
      if (keyIdx < 0) return null;

      // Find colon after key
      int colonIdx = json.indexOf(':', keyIdx + pattern.length());
      if (colonIdx < 0) return null;

      // Find opening quote of value
      int valueStart = -1;
      for (int i = colonIdx + 1; i < json.length(); i++) {
         char c = json.charAt(i);
         if (c == '"') {
            valueStart = i + 1;
            break;
         }
         if (c != ' ' && c != '\t' && c != '\n' && c != '\r') return null; // not a string value
      }
      if (valueStart < 0) return null;

      // Find closing quote (handling escapes)
      StringBuilder sb = new StringBuilder(64);
      for (int i = valueStart; i < json.length(); i++) {
         char c = json.charAt(i);
         if (c == '\\' && i + 1 < json.length()) {
            sb.append(json.charAt(++i));
         } else if (c == '"') {
            return sb.toString();
         } else {
            sb.append(c);
         }
      }
      return null;
   }

   /**
    * Find the matching closing brace for an opening brace.
    */
   private static int findMatchingBrace(String json, int openBrace) {
      int depth = 0;
      boolean inString = false;

      for (int i = openBrace; i < json.length(); i++) {
         char c = json.charAt(i);
         if (c == '\\' && inString) {
            i++; // skip escaped char
            continue;
         }
         if (c == '"') {
            inString = !inString;
         } else if (!inString) {
            if (c == '{') depth++;
            else if (c == '}') {
               depth--;
               if (depth == 0) return i;
            }
         }
      }
      return -1;
   }
}
