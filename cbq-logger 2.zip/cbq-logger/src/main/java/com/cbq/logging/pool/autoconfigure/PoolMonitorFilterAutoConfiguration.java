package com.cbq.logging.pool.autoconfigure;

import com.cbq.logging.pool.jdbc.JakartaRequestIdFilter;
import com.cbq.logging.pool.jdbc.JavaxRequestIdFilter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

/**
 * Auto-registers the appropriate servlet filter (javax or jakarta)
 * for request body extraction of requestInfo.
 */
public class PoolMonitorFilterAutoConfiguration {

   /**
    * Spring Boot 2.7.x (javax.servlet)
    */
   @Configuration
   @ConditionalOnClass(name = "javax.servlet.Filter")
   @ConditionalOnProperty(prefix = "cbq.pool-monitor", name = "enabled", havingValue = "true", matchIfMissing = true)
   public static class JavaxFilterConfig {

      @Bean
      public FilterRegistrationBean<JavaxRequestIdFilter> cbqPoolMonitorJavaxFilter() {
         FilterRegistrationBean<JavaxRequestIdFilter> registration =
                 new FilterRegistrationBean<>();
         registration.setFilter(new JavaxRequestIdFilter());
         registration.addUrlPatterns("/*");
         registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 10);
         registration.setName("cbqPoolMonitorRequestIdFilter");
         return registration;
      }
   }

   /**
    * Spring Boot 3.x (jakarta.servlet)
    */
   @Configuration
   @ConditionalOnClass(name = "jakarta.servlet.Filter")
   @ConditionalOnProperty(prefix = "cbq.pool-monitor", name = "enabled", havingValue = "true", matchIfMissing = true)
   public static class JakartaFilterConfig {

      @Bean
      public FilterRegistrationBean cbqPoolMonitorJakartaFilter() {
         var registration = new FilterRegistrationBean();
         registration.setFilter(new JakartaRequestIdFilter());
         registration.addUrlPatterns("/*");
         registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 10);
         registration.setName("cbqPoolMonitorRequestIdFilter");
         return registration;
      }
   }
}
