package com.cbq.logging.core;

import com.cbq.logging.config.LoggingConfig;
import com.cbq.logging.mask.FieldMasker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.slf4j.Marker;

import java.util.Map;
import java.util.function.Supplier;

/**
 * CBQ Logger - A structured logging wrapper with field masking and exception utilities.
 * <p>
 * This class wraps SLF4J Logger and provides additional functionality:
 * <ul>
 *     <li>Structured logging with JSON output</li>
 *     <li>Automatic field masking for sensitive data</li>
 *     <li>Exception logging helpers</li>
 *     <li>Correlation ID support</li>
 *     <li>Business exception utilities</li>
 * </ul>
 * <p>
 * Usage with Lombok (add to lombok.config):
 * <pre>
 * lombok.log.custom.declaration = com.cbq.logging.core.CbqLog com.cbq.logging.core.CbqLog.getLogger(TYPE)
 * </pre>
 * <p>
 * Then use:
 * <pre>
 * &#64;CustomLog
 * public class MyService {
 *     public void process() {
 *         log.info("Processing started");
 *         log.structured("payment.received")
 *            .field("amount", 100)
 *            .field("cardNumber", "4111111111111111")
 *            .log();
 *     }
 * }
 * </pre>
 * <p>
 * Or use directly:
 * <pre>
 * public class MyService {
 *     private static final CbqLog log = CbqLog.getLogger(MyService.class);
 * }
 * </pre>
 */
public class CbqLog {
    
    private final Logger delegate;
    private final String loggerName;
    
    private CbqLog(Logger delegate) {
        this.delegate = delegate;
        this.loggerName = delegate.getName();
    }
    
    /**
     * Get a CbqLog instance for the specified class.
     * This method is used by Lombok's @CustomLog annotation.
     *
     * @param clazz the class to create logger for
     * @return CbqLog instance
     */
    public static CbqLog getLogger(Class<?> clazz) {
        return new CbqLog(LoggerFactory.getLogger(clazz));
    }
    
    /**
     * Get a CbqLog instance with a custom name.
     *
     * @param name the logger name
     * @return CbqLog instance
     */
    public static CbqLog getLogger(String name) {
        return new CbqLog(LoggerFactory.getLogger(name));
    }
    
    /**
     * Get the underlying SLF4J Logger.
     */
    public Logger getDelegate() {
        return delegate;
    }
    
    /**
     * Get the logger name.
     */
    public String getName() {
        return loggerName;
    }
    
    // ==================== Structured Logging ====================
    
    /**
     * Start building a structured log entry.
     *
     * @param event the event name (e.g., "payment.processed", "user.login")
     * @return StructuredLogBuilder for fluent API
     */
    public StructuredLogBuilder structured(String event) {
        return new StructuredLogBuilder(delegate, event);
    }
    
    /**
     * Start building a structured log entry with a message.
     */
    public StructuredLogBuilder structured(String event, String message) {
        return new StructuredLogBuilder(delegate, event).message(message);
    }
    
    // ==================== Exception Utilities ====================
    
    /**
     * Log an error and throw the exception.
     *
     * @param message the error message
     * @param ex      the exception to throw
     * @param <T>     exception type
     * @throws T always throws the provided exception
     */
    public <T extends RuntimeException> T logAndThrow(String message, T ex) {
        delegate.error(message, ex);
        throw ex;
    }
    
    /**
     * Log an error and return a new RuntimeException.
     *
     * @param message the error message
     * @param cause   the cause
     * @return RuntimeException that can be thrown
     */
    public RuntimeException errorAndReturn(String message, Throwable cause) {
        delegate.error(message, cause);
        return new RuntimeException(message, cause);
    }
    
    /**
     * Log an error and return a custom exception.
     *
     * @param message         the error message
     * @param cause           the cause
     * @param exceptionSupplier supplier to create the exception
     * @param <T>             exception type
     * @return the created exception
     */
    public <T extends Exception> T errorAndReturn(String message, Throwable cause, 
            Supplier<T> exceptionSupplier) {
        delegate.error(message, cause);
        return exceptionSupplier.get();
    }
    
    /**
     * Log a business error with code.
     *
     * @param code    error code (e.g., "PAY_001")
     * @param message error message
     */
    public void businessError(String code, String message) {
        structured("business.error")
            .error()
            .field("errorCode", code)
            .message(message)
            .log();
    }
    
    /**
     * Log a business error with code and return an exception.
     *
     * @param code    error code
     * @param message error message
     * @param exceptionSupplier supplier to create the exception
     * @param <T>     exception type
     * @return the created exception
     */
    public <T extends RuntimeException> T businessError(String code, String message, 
            Supplier<T> exceptionSupplier) {
        businessError(code, message);
        return exceptionSupplier.get();
    }
    
    /**
     * Log a transaction failure.
     *
     * @param txnRef transaction reference
     * @param ex     the exception
     */
    public void transactionFailure(String txnRef, Throwable ex) {
        structured("transaction.failed")
            .error()
            .field("transactionRef", txnRef)
            .exception(ex)
            .log();
    }
    
    /**
     * Log a transaction failure with additional context.
     */
    public void transactionFailure(String txnRef, String reason, Map<String, Object> context) {
        structured("transaction.failed")
            .error()
            .field("transactionRef", txnRef)
            .field("reason", reason)
            .fields(context)
            .log();
    }
    
    // ==================== Context Management ====================
    
    /**
     * Execute a block with a correlation ID set in MDC.
     *
     * @param correlationId the correlation ID
     * @param runnable      the code to execute
     */
    public void withCorrelationId(String correlationId, Runnable runnable) {
        String key = LoggingConfig.getInstance().getCorrelationIdKey();
        String previous = MDC.get(key);
        try {
            MDC.put(key, correlationId);
            runnable.run();
        } finally {
            if (previous != null) {
                MDC.put(key, previous);
            } else {
                MDC.remove(key);
            }
        }
    }
    
    /**
     * Execute a block with a correlation ID set in MDC and return a result.
     *
     * @param correlationId the correlation ID
     * @param supplier      the code to execute
     * @param <T>           return type
     * @return the result
     */
    public <T> T withCorrelationId(String correlationId, Supplier<T> supplier) {
        String key = LoggingConfig.getInstance().getCorrelationIdKey();
        String previous = MDC.get(key);
        try {
            MDC.put(key, correlationId);
            return supplier.get();
        } finally {
            if (previous != null) {
                MDC.put(key, previous);
            } else {
                MDC.remove(key);
            }
        }
    }
    
    /**
     * Set correlation ID in MDC.
     */
    public void setCorrelationId(String correlationId) {
        MDC.put(LoggingConfig.getInstance().getCorrelationIdKey(), correlationId);
    }
    
    /**
     * Get current correlation ID from MDC.
     */
    public String getCorrelationId() {
        return MDC.get(LoggingConfig.getInstance().getCorrelationIdKey());
    }
    
    /**
     * Clear correlation ID from MDC.
     */
    public void clearCorrelationId() {
        MDC.remove(LoggingConfig.getInstance().getCorrelationIdKey());
    }
    
    // ==================== Masking Utilities ====================
    
    /**
     * Mask a value using global configuration.
     *
     * @param fieldName the field name
     * @param value     the value to mask
     * @return masked value
     */
    public String mask(String fieldName, Object value) {
        return FieldMasker.mask(fieldName, value);
    }
    
    /**
     * Mask all sensitive fields in a message string.
     */
    public String maskMessage(String message) {
        return FieldMasker.maskMessage(message);
    }
    
    // ==================== Standard SLF4J Delegation ====================
    
    // TRACE level
    public boolean isTraceEnabled() {
        return delegate.isTraceEnabled();
    }
    
    public void trace(String msg) {
        delegate.trace(msg);
    }
    
    public void trace(String format, Object arg) {
        delegate.trace(format, arg);
    }
    
    public void trace(String format, Object arg1, Object arg2) {
        delegate.trace(format, arg1, arg2);
    }
    
    public void trace(String format, Object... arguments) {
        delegate.trace(format, arguments);
    }
    
    public void trace(String msg, Throwable t) {
        delegate.trace(msg, t);
    }
    
    public void trace(Marker marker, String msg) {
        delegate.trace(marker, msg);
    }
    
    // DEBUG level
    public boolean isDebugEnabled() {
        return delegate.isDebugEnabled();
    }
    
    public void debug(String msg) {
        delegate.debug(msg);
    }
    
    public void debug(String format, Object arg) {
        delegate.debug(format, arg);
    }
    
    public void debug(String format, Object arg1, Object arg2) {
        delegate.debug(format, arg1, arg2);
    }
    
    public void debug(String format, Object... arguments) {
        delegate.debug(format, arguments);
    }
    
    public void debug(String msg, Throwable t) {
        delegate.debug(msg, t);
    }
    
    public void debug(Marker marker, String msg) {
        delegate.debug(marker, msg);
    }
    
    // INFO level
    public boolean isInfoEnabled() {
        return delegate.isInfoEnabled();
    }
    
    public void info(String msg) {
        delegate.info(msg);
    }
    
    public void info(String format, Object arg) {
        delegate.info(format, arg);
    }
    
    public void info(String format, Object arg1, Object arg2) {
        delegate.info(format, arg1, arg2);
    }
    
    public void info(String format, Object... arguments) {
        delegate.info(format, arguments);
    }
    
    public void info(String msg, Throwable t) {
        delegate.info(msg, t);
    }
    
    public void info(Marker marker, String msg) {
        delegate.info(marker, msg);
    }
    
    // WARN level
    public boolean isWarnEnabled() {
        return delegate.isWarnEnabled();
    }
    
    public void warn(String msg) {
        delegate.warn(msg);
    }
    
    public void warn(String format, Object arg) {
        delegate.warn(format, arg);
    }
    
    public void warn(String format, Object arg1, Object arg2) {
        delegate.warn(format, arg1, arg2);
    }
    
    public void warn(String format, Object... arguments) {
        delegate.warn(format, arguments);
    }
    
    public void warn(String msg, Throwable t) {
        delegate.warn(msg, t);
    }
    
    public void warn(Marker marker, String msg) {
        delegate.warn(marker, msg);
    }
    
    // ERROR level
    public boolean isErrorEnabled() {
        return delegate.isErrorEnabled();
    }
    
    public void error(String msg) {
        delegate.error(msg);
    }
    
    public void error(String format, Object arg) {
        delegate.error(format, arg);
    }
    
    public void error(String format, Object arg1, Object arg2) {
        delegate.error(format, arg1, arg2);
    }
    
    public void error(String format, Object... arguments) {
        delegate.error(format, arguments);
    }
    
    public void error(String msg, Throwable t) {
        delegate.error(msg, t);
    }
    
    public void error(Marker marker, String msg) {
        delegate.error(marker, msg);
    }
}
