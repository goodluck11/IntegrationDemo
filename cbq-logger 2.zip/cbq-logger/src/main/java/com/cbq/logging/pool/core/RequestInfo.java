package com.cbq.logging.pool.core;

/*
 * @created by 06/02/2026  - 18:15
 * @project cbq-logger
 * @author Goodluck
 */
public record RequestInfo(String requestId, String requestTime) {
}
