package com.cbq.logging.pool.r2dbc;

import com.cbq.logging.pool.core.AsyncEventDispatcher;
import com.cbq.logging.pool.core.ConnectionPoolEvent;
import io.r2dbc.spi.*;
import org.reactivestreams.Publisher;
import reactor.core.publisher.Mono;

import java.time.Duration;

import static com.cbq.logging.pool.core.ConnectionPoolEvent.Action;

/**
 * R2DBC Connection decorator. All methods are pure delegation except {@link #close()},
 * which emits a RELEASED event with the hold duration.
 */
final class MonitoredConnection implements Connection {

   private final Connection delegate;
   private final String requestId;
   private final String requestTime;
   private final AsyncEventDispatcher dispatcher;
   private final String poolName;
   private final long holdStart;

   MonitoredConnection(Connection delegate, String requestId, String requestTime,
                       AsyncEventDispatcher dispatcher, String poolName) {
      this.delegate = delegate;
      this.requestId = requestId;
      this.requestTime = requestTime;
      this.dispatcher = dispatcher;
      this.poolName = poolName;
      this.holdStart = System.nanoTime();
   }

   @Override
   public Publisher<Void> close() {
      return Mono.from(delegate.close())
              .doFinally(signal -> {
                 long holdDuration = System.nanoTime() - holdStart;
                 dispatcher.publish(new ConnectionPoolEvent(
                         requestId, requestTime, Action.RELEASED, holdDuration,
                         System.currentTimeMillis(), "R2DBC", poolName));
              });
   }

   // ---- Pure delegation ----
   @Override
   public Publisher<Void> beginTransaction() {
      return delegate.beginTransaction();
   }

   @Override
   public Publisher<Void> beginTransaction(TransactionDefinition definition) {
      return delegate.beginTransaction(definition);
   }

   @Override
   public Publisher<Void> commitTransaction() {
      return delegate.commitTransaction();
   }

   @Override
   public Batch createBatch() {
      return delegate.createBatch();
   }

   @Override
   public Publisher<Void> createSavepoint(String name) {
      return delegate.createSavepoint(name);
   }

   @Override
   public Statement createStatement(String sql) {
      return delegate.createStatement(sql);
   }

   @Override
   public boolean isAutoCommit() {
      return delegate.isAutoCommit();
   }

   @Override
   public ConnectionMetadata getMetadata() {
      return delegate.getMetadata();
   }

   @Override
   public IsolationLevel getTransactionIsolationLevel() {
      return delegate.getTransactionIsolationLevel();
   }

   @Override
   public Publisher<Void> releaseSavepoint(String name) {
      return delegate.releaseSavepoint(name);
   }

   @Override
   public Publisher<Void> rollbackTransaction() {
      return delegate.rollbackTransaction();
   }

   @Override
   public Publisher<Void> rollbackTransactionToSavepoint(String name) {
      return delegate.rollbackTransactionToSavepoint(name);
   }

   @Override
   public Publisher<Void> setAutoCommit(boolean autoCommit) {
      return delegate.setAutoCommit(autoCommit);
   }

   @Override
   public Publisher<Void> setTransactionIsolationLevel(IsolationLevel level) {
      return delegate.setTransactionIsolationLevel(level);
   }

   @Override
   public Publisher<Void> setLockWaitTimeout(Duration timeout) {
      return delegate.setLockWaitTimeout(timeout);
   }

   @Override
   public Publisher<Void> setStatementTimeout(Duration timeout) {
      return delegate.setStatementTimeout(timeout);
   }

   @Override
   public Publisher<Boolean> validate(ValidationDepth depth) {
      return delegate.validate(depth);
   }
}
