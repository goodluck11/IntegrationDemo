package com.cbq.logging.pool.autoconfigure;

import com.cbq.logging.pool.core.AsyncEventDispatcher;
import com.cbq.logging.pool.r2dbc.MonitoredConnectionFactory;
import com.cbq.logging.pool.r2dbc.ReactiveRequestIdWebFilter;
import io.r2dbc.spi.ConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.server.WebFilter;

@Configuration
@ConditionalOnClass({ConnectionFactory.class, reactor.core.publisher.Mono.class})
@ConditionalOnProperty(prefix = "cbq.pool-monitor", name = "enabled", havingValue = "true", matchIfMissing = true)
@AutoConfigureAfter(PoolMonitorCoreAutoConfiguration.class)
public class PoolMonitorR2dbcAutoConfiguration {

   private static final Logger log = LoggerFactory.getLogger(PoolMonitorR2dbcAutoConfiguration.class);

   @Bean
   public static BeanPostProcessor cbqConnectionFactoryMonitorPostProcessor(
           AsyncEventDispatcher dispatcher, PoolMonitorProperties props) {
      return new BeanPostProcessor() {
         @Override
         public Object postProcessAfterInitialization(Object bean, String beanName) {
            if (bean instanceof ConnectionFactory cfBean && !(bean instanceof MonitoredConnectionFactory)) {
               String poolName = props.getPoolNames().getOrDefault(beanName, beanName);
               log.info("[cbq-pool-monitor] Wrapping ConnectionFactory bean '{}' as pool '{}'", beanName, poolName);
               return new MonitoredConnectionFactory(cfBean, dispatcher, poolName);
            }
            return bean;
         }
      };
   }

   @Bean
   @ConditionalOnMissingBean(ReactiveRequestIdWebFilter.class)
   @ConditionalOnClass(WebFilter.class)
   public ReactiveRequestIdWebFilter cbqPoolMonitorRequestIdWebFilter() {
      return new ReactiveRequestIdWebFilter();
   }
}