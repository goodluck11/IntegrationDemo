package com.cbq.logging.pool.autoconfigure;

import com.cbq.logging.pool.core.AsyncEventDispatcher;
import com.cbq.logging.pool.jdbc.MonitoredDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * Auto-configuration for JDBC connection pool monitoring.
 * <p>
 * Wraps ALL DataSource beans with monitoring. Each DataSource gets a logical
 * pool name resolved from {@code cbq.pool-monitor.pool-names} mapping.
 * <p>
 * For multiple databases, configure:
 * <pre>
 * cbq:
 *   pool-monitor:
 *     pool-names:
 *       coreBankingDataSource: core-banking
 *       fraudDataSource: fraud-db
 *       auditDataSource: audit-db
 * </pre>
 * <p>
 * If a bean name is not mapped, the bean name itself is used as the pool name.
 */
@Configuration
@ConditionalOnClass(DataSource.class)
@ConditionalOnProperty(prefix = "cbq.pool-monitor", name = "enabled", havingValue = "true", matchIfMissing = true)
@AutoConfigureAfter({DataSourceAutoConfiguration.class, PoolMonitorCoreAutoConfiguration.class})
public class PoolMonitorJdbcAutoConfiguration {

   private static final Logger log = LoggerFactory.getLogger(PoolMonitorJdbcAutoConfiguration.class);

   @Bean
   public static BeanPostProcessor cbqDataSourceMonitorPostProcessor(
           AsyncEventDispatcher dispatcher, PoolMonitorProperties props) {
      return new BeanPostProcessor() {
         @Override
         public Object postProcessAfterInitialization(Object bean, String beanName) {
            if (bean instanceof DataSource && !(bean instanceof MonitoredDataSource)) {
               String poolName = resolvePoolName(beanName, props);
               log.info("[cbq-pool-monitor] Wrapping DataSource bean '{}' as pool '{}'", beanName, poolName);
               return new MonitoredDataSource((DataSource) bean, dispatcher, poolName);
            }
            return bean;
         }
      };
   }

   private static String resolvePoolName(String beanName, PoolMonitorProperties props) {
      String mapped = props.getPoolNames().get(beanName);
      // If not explicitly mapped, use the bean name itself (more useful than "default")
      return mapped != null ? mapped : beanName;
   }
}
