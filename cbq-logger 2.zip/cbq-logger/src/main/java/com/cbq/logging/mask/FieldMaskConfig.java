package com.cbq.logging.mask;

/**
 * Configuration for how a specific field should be masked.
 *
 * @param visibleChars Number of characters to show at start and end
 * @param maskSymbol   Character to use for masking
 * @param fullyMask    If true, entire value is masked
 * @param exclude      If true, field is excluded from logging entirely
 */
public record FieldMaskConfig(
    int visibleChars,
    char maskSymbol,
    boolean fullyMask,
    boolean exclude
) {
    
    /**
     * Create a config for partial masking.
     */
    public static FieldMaskConfig partial(int visibleChars) {
        return new FieldMaskConfig(visibleChars, '*', false, false);
    }
    
    /**
     * Create a config for full masking.
     */
    public static FieldMaskConfig full() {
        return new FieldMaskConfig(0, '*', true, false);
    }
    
    /**
     * Create a config for exclusion.
     */
    public static FieldMaskConfig excluded() {
        return new FieldMaskConfig(0, '*', false, true);
    }
}
