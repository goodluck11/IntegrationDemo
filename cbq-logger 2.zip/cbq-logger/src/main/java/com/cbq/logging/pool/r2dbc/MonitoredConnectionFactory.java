package com.cbq.logging.pool.r2dbc;

import com.cbq.logging.pool.core.AsyncEventDispatcher;
import com.cbq.logging.pool.core.ConnectionPoolEvent;
import com.cbq.logging.pool.core.ReactiveRequestContext;
import io.r2dbc.spi.Connection;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.ConnectionFactoryMetadata;
import lombok.Getter;
import org.reactivestreams.Publisher;
import reactor.core.publisher.Mono;

import static com.cbq.logging.pool.core.ConnectionPoolEvent.Action;

/**
 * R2DBC {@link ConnectionFactory} decorator with named pool for multi-database support.
 * <p>
 * Reads requestId/requestTime from Reactor Context (set by {@link ReactiveRequestIdWebFilter}).
 * <pre>
 * new MonitoredConnectionFactory(coreBankingCf, dispatcher, "core-banking");
 * new MonitoredConnectionFactory(fraudCf, dispatcher, "fraud-db");
 * </pre>
 */
public final class MonitoredConnectionFactory implements ConnectionFactory {

   @Getter
   private final ConnectionFactory delegate;
   private final AsyncEventDispatcher dispatcher;
   private final String poolName;

   public MonitoredConnectionFactory(ConnectionFactory delegate, AsyncEventDispatcher dispatcher, String poolName) {
      this.delegate = delegate;
      this.dispatcher = dispatcher;
      this.poolName = poolName;
   }

   @Override
   public Publisher<? extends Connection> create() {
      return Mono.deferContextual(ctx -> {
         String requestId = ctx.getOrDefault(ReactiveRequestContext.REQUEST_ID_KEY, "no-request-id");
         String requestTime = ctx.getOrDefault(ReactiveRequestContext.REQUEST_TIME_KEY, null);
         long acquireStart = System.nanoTime();

         return Mono.from(delegate.create())
                 .doOnNext(conn -> {
                    long acquireDuration = System.nanoTime() - acquireStart;
                    dispatcher.publish(new ConnectionPoolEvent(
                            requestId, requestTime, Action.ACQUIRED, acquireDuration,
                            System.currentTimeMillis(), "R2DBC", poolName));
                 })
                 .map(conn -> new MonitoredConnection(conn, requestId, requestTime, dispatcher, poolName));
      });
   }

   @Override
   public ConnectionFactoryMetadata getMetadata() {
      return delegate.getMetadata();
   }

}