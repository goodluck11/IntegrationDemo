package com.cbq.logging.pool.jdbc;

import com.cbq.logging.pool.core.AsyncEventDispatcher;
import com.cbq.logging.pool.core.ConnectionPoolEvent;
import com.cbq.logging.pool.core.RequestContextHolder;
import lombok.Getter;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;

import static com.cbq.logging.pool.core.ConnectionPoolEvent.Action;

/**
 * Lightweight DataSource decorator that monitors connection acquire and release.
 * <p>
 * Each instance has a {@code poolName} to distinguish multiple databases:
 * <pre>
 * new MonitoredDataSource(coreBankingDs, dispatcher, "core-banking");
 * new MonitoredDataSource(fraudDs, dispatcher, "fraud-db");
 * new MonitoredDataSource(auditDs, dispatcher, "audit-db");
 * </pre>
 * <p>
 * Reads requestId/requestTime from {@link RequestContextHolder} (set by the servlet filter).
 */
public final class MonitoredDataSource implements DataSource {

   /**
    * -- GETTER --
    * Access the original unwrapped DataSource.
    */
   @Getter
   private final DataSource delegate;
   private final AsyncEventDispatcher dispatcher;
   private final String poolName;

   public MonitoredDataSource(DataSource delegate, AsyncEventDispatcher dispatcher, String poolName) {
      this.delegate = delegate;
      this.dispatcher = dispatcher;
      this.poolName = poolName;
   }

   @Override
   public Connection getConnection() throws SQLException {
      String requestId = resolveRequestId();
      String requestTime = RequestContextHolder.getRequestTime();
      long acquireStart = System.nanoTime();

      Connection realConnection = delegate.getConnection();

      long acquireDuration = System.nanoTime() - acquireStart;
      dispatcher.publish(new ConnectionPoolEvent(
              requestId, requestTime, Action.ACQUIRED, acquireDuration,
              System.currentTimeMillis(), "JDBC", poolName));

      return proxyConnection(realConnection, requestId, requestTime);
   }

   @Override
   public Connection getConnection(String username, String password) throws SQLException {
      String requestId = resolveRequestId();
      String requestTime = RequestContextHolder.getRequestTime();
      long acquireStart = System.nanoTime();

      Connection realConnection = delegate.getConnection(username, password);

      long acquireDuration = System.nanoTime() - acquireStart;
      dispatcher.publish(new ConnectionPoolEvent(
              requestId, requestTime, Action.ACQUIRED, acquireDuration,
              System.currentTimeMillis(), "JDBC", poolName));

      return proxyConnection(realConnection, requestId, requestTime);
   }

   private Connection proxyConnection(Connection real, String requestId, String requestTime) {
      long holdStart = System.nanoTime();
      return (Connection) Proxy.newProxyInstance(
              real.getClass().getClassLoader(),
              new Class<?>[]{Connection.class},
              new ConnectionHandler(real, requestId, requestTime, holdStart));
   }

   private String resolveRequestId() {
      String id = RequestContextHolder.getRequestId();
      return id != null ? id : "no-request-id";
   }

   /**
    * JDK dynamic proxy — intercepts ONLY close(). All other methods are zero-overhead delegation.
    */
   private final class ConnectionHandler implements InvocationHandler {
      private final Connection delegate;
      private final String requestId;
      private final String requestTime;
      private final long holdStart;

      ConnectionHandler(Connection delegate, String requestId, String requestTime, long holdStart) {
         this.delegate = delegate;
         this.requestId = requestId;
         this.requestTime = requestTime;
         this.holdStart = holdStart;
      }

      @Override
      public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
         if ("close".equals(method.getName()) && (args == null || args.length == 0)) {
            long holdDuration = System.nanoTime() - holdStart;
            try {
               return method.invoke(delegate, args);
            } finally {
               dispatcher.publish(new ConnectionPoolEvent(
                       requestId, requestTime, Action.RELEASED, holdDuration,
                       System.currentTimeMillis(), "JDBC", poolName));
            }
         }
         return method.invoke(delegate, args);
      }
   }

   // ---- Delegate pass-through ----
   @Override
   public PrintWriter getLogWriter() throws SQLException {
      return delegate.getLogWriter();
   }

   @Override
   public void setLogWriter(PrintWriter out) throws SQLException {
      delegate.setLogWriter(out);
   }

   @Override
   public void setLoginTimeout(int seconds) throws SQLException {
      delegate.setLoginTimeout(seconds);
   }

   @Override
   public int getLoginTimeout() throws SQLException {
      return delegate.getLoginTimeout();
   }

   @Override
   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
      return delegate.getParentLogger();
   }

   @Override
   public <T> T unwrap(Class<T> iface) throws SQLException {
      return delegate.unwrap(iface);
   }

   @Override
   public boolean isWrapperFor(Class<?> iface) throws SQLException {
      return delegate.isWrapperFor(iface);
   }

}