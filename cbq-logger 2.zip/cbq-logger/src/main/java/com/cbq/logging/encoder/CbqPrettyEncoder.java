package com.cbq.logging.encoder;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.StackTraceElementProxy;
import ch.qos.logback.core.encoder.EncoderBase;
import com.cbq.logging.config.LoggingConfig;
import com.cbq.logging.mask.FieldMasker;
import lombok.Setter;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Map;

/**
 * Pretty text encoder for development and debugging.
 * <p>
 * Outputs human-readable formatted logs with colors (when supported).
 * <p>
 * Usage in logback.xml:
 * <pre>
 * &lt;encoder class="com.cbq.logging.encoder.CbqPrettyEncoder"&gt;
 *     &lt;colorEnabled&gt;true&lt;/colorEnabled&gt;
 *     &lt;timestampPattern&gt;HH:mm:ss.SSS&lt;/timestampPattern&gt;
 * &lt;/encoder&gt;
 * </pre>
 */
public class CbqPrettyEncoder extends EncoderBase<ILoggingEvent> {
    
    private static final String LINE_SEPARATOR = System.lineSeparator();
    
    // ANSI colors
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String BLUE = "\u001B[34m";
    private static final String MAGENTA = "\u001B[35m";
    private static final String CYAN = "\u001B[36m";
    private static final String WHITE = "\u001B[37m";
    private static final String GRAY = "\u001B[90m";
    private static final String BOLD = "\u001B[1m";
    
    @Setter
    private boolean colorEnabled = true;
    @Setter
    private String timestampPattern = "yyyy-MM-dd HH:mm:ss.SSS";
    @Setter
    private boolean showThread = true;
    @Setter
    private boolean showLogger = true;
    @Setter
    private boolean maskSensitiveFields = true;
    
    private DateTimeFormatter formatter;
    
    @Override
    public void start() {
        super.start();
        formatter = DateTimeFormatter.ofPattern(timestampPattern)
            .withZone(ZoneId.systemDefault());
    }
    
    @Override
    public byte[] headerBytes() {
        return null;
    }
    
    @Override
    public byte[] encode(ILoggingEvent event) {
        StringBuilder sb = new StringBuilder();
        
        // Timestamp
        String timestamp = formatter.format(Instant.ofEpochMilli(event.getTimeStamp()));
        sb.append(colorize(GRAY, timestamp)).append(" ");
        
        // Level with color
        String level = String.format("%-5s", event.getLevel().toString());
        sb.append(colorize(getLevelColor(event.getLevel().toString()), level)).append(" ");
        
        // Thread
        if (showThread) {
            sb.append(colorize(MAGENTA, "[" + event.getThreadName() + "]")).append(" ");
        }
        
        // Logger (shortened)
        if (showLogger) {
            String loggerName = shortenLoggerName(event.getLoggerName());
            sb.append(colorize(CYAN, loggerName)).append(" : ");
        }
        
        // Correlation ID from MDC
        LoggingConfig config = LoggingConfig.getInstance();
        Map<String, String> mdc = event.getMDCPropertyMap();
        if (mdc != null) {
            String correlationId = mdc.get(config.getCorrelationIdKey());
            if (correlationId != null) {
                sb.append(colorize(BLUE, "[" + correlationId + "]")).append(" ");
            }
        }
        
        // Message
        String message = event.getFormattedMessage();
        if (maskSensitiveFields) {
            message = FieldMasker.maskMessage(message);
        }
        sb.append(message);
        
        sb.append(LINE_SEPARATOR);
        
        // Exception
        IThrowableProxy throwableProxy = event.getThrowableProxy();
        if (throwableProxy != null) {
            formatException(sb, throwableProxy, config, "");
        }
        
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }
    
    @Override
    public byte[] footerBytes() {
        return null;
    }
    
    private void formatException(StringBuilder sb, IThrowableProxy throwable, 
            LoggingConfig config, String indent) {
        // Exception type and message
        sb.append(indent)
          .append(colorize(RED, throwable.getClassName()))
          .append(": ")
          .append(throwable.getMessage())
          .append(LINE_SEPARATOR);
        
        // Stack trace
        if (config.isIncludeStackTrace()) {
            StackTraceElementProxy[] stackTrace = throwable.getStackTraceElementProxyArray();
            if (stackTrace != null) {
                int depth = Math.min(stackTrace.length, config.getMaxStackTraceDepth());
                for (int i = 0; i < depth; i++) {
                    sb.append(indent)
                      .append(colorize(GRAY, "\tat " + stackTrace[i].getStackTraceElement().toString()))
                      .append(LINE_SEPARATOR);
                }
                if (depth < stackTrace.length) {
                    sb.append(indent)
                      .append(colorize(GRAY, "\t... " + (stackTrace.length - depth) + " more"))
                      .append(LINE_SEPARATOR);
                }
            }
        }
        
        // Cause
        if (config.isIncludeExceptionCause() && throwable.getCause() != null) {
            sb.append(indent).append(colorize(YELLOW, "Caused by: "));
            formatException(sb, throwable.getCause(), config, indent);
        }
    }
    
    private String getLevelColor(String level) {
        return switch (level) {
            case "ERROR" -> RED + BOLD;
            case "WARN" -> YELLOW;
            case "INFO" -> GREEN;
            case "DEBUG" -> BLUE;
            case "TRACE" -> GRAY;
            default -> WHITE;
        };
    }
    
    private String colorize(String color, String text) {
        if (!colorEnabled) return text;
        return color + text + RESET;
    }
    
    private String shortenLoggerName(String loggerName) {
        if (loggerName == null) return "";
        
        String[] parts = loggerName.split("\\.");
        if (parts.length <= 2) return loggerName;
        
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length - 1; i++) {
            sb.append(parts[i].charAt(0)).append(".");
        }
        sb.append(parts[parts.length - 1]);
        return sb.toString();
    }
    
    // Setters for Logback configuration

}
