package com.cbq.logging.pool.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * Listener that logs a WARN when connection acquire/release duration
 * exceeds a configurable threshold. Critical for detecting pool exhaustion
 * or connection leaks in production banking systems.
 */
public final class SlowConnectionListener implements ConnectionPoolEventListener {

   private static final Logger log = LoggerFactory.getLogger("com.cbq.poolmonitor.slow");

   private final long thresholdNanos;

   public SlowConnectionListener(long thresholdMillis) {
      this.thresholdNanos = thresholdMillis * 1_000_000L;
   }

   @Override
   public void onEvent(ConnectionPoolEvent event) {
      if (event.getDurationNanos() > thresholdNanos) {
         String previousId = MDC.get("requestId");
         try {
            MDC.put("requestId", event.getRequestId());
            log.warn("SLOW pool.connection.{} | requestId={} | pool={}/{} | duration={}ms (threshold={}ms)",
                    event.getAction().name().toLowerCase(),
                    event.getRequestId(),
                    event.getPoolType(), event.getPoolName(),
                    String.format("%.3f", event.getDurationMillis()),
                    thresholdNanos / 1_000_000L);
         } finally {
            if (previousId != null) MDC.put("requestId", previousId);
            else MDC.remove("requestId");
         }
      }
   }
}

