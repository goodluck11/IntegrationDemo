package com.cbq.logging.pool.core;

/*
 * @created by 06/02/2026  - 18:02
 * @project cbq-logger
 * @author Goodluck
 */
@FunctionalInterface
public interface ConnectionPoolEventListener {

   void onEvent(ConnectionPoolEvent event);
}