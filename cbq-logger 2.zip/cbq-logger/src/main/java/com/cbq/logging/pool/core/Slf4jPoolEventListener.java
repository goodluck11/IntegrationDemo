package com.cbq.logging.pool.core;

/*
 * @created by 06/02/2026  - 18:08
 * @project cbq-logger
 * @author Goodluck
 */
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * Default listener that logs pool events via SLF4J with MDC integration.
 * <p>
 * Automatically sets {@code requestId} and {@code requestTime} in MDC before logging,
 * so they flow through to your logback pattern / CbqJsonEncoder / Splunk.
 * <p>
 * Configure log level:
 * <pre>
 * logging.level.com.cbq.poolmonitor.events=DEBUG
 * </pre>
 */
public final class Slf4jPoolEventListener implements ConnectionPoolEventListener {

   private static final Logger log = LoggerFactory.getLogger("com.cbq.poolmonitor.events");

   public enum LogLevel {
      TRACE, DEBUG, INFO
   }

   private final LogLevel level;

   public Slf4jPoolEventListener() {
      this(LogLevel.DEBUG);
   }

   public Slf4jPoolEventListener(LogLevel level) {
      this.level = level;
   }

   @Override
   public void onEvent(ConnectionPoolEvent event) {
      // Push into MDC so cbq-logger / logback patterns pick it up
      String previousId = MDC.get("requestId");
      String previousTime = MDC.get("requestTime");
      try {
         MDC.put("requestId", event.getRequestId());
         if (event.getRequestTime() != null) {
            MDC.put("requestTime", event.getRequestTime());
         }
         MDC.put("poolName", event.getPoolName());
         MDC.put("poolType", event.getPoolType());

         String msg = formatMessage(event);
         switch (level) {
            case TRACE:
               if (log.isTraceEnabled()) log.trace(msg);
               break;
            case DEBUG:
               if (log.isDebugEnabled()) log.debug(msg);
               break;
            case INFO:
               if (log.isInfoEnabled()) log.info(msg);
               break;
         }
      } finally {
         // Restore previous MDC values
         restoreMdc("requestId", previousId);
         restoreMdc("requestTime", previousTime);
         MDC.remove("poolName");
         MDC.remove("poolType");
      }
   }

   private String formatMessage(ConnectionPoolEvent event) {
      return new StringBuilder(128)
              .append("pool.connection.").append(event.getAction().name().toLowerCase())
              .append(" | requestId=").append(event.getRequestId())
              .append(" | pool=").append(event.getPoolType()).append('/').append(event.getPoolName())
              .append(" | duration=").append(String.format("%.3fms", event.getDurationMillis()))
              .toString();
   }

   private void restoreMdc(String key, String previousValue) {
      if (previousValue != null) {
         MDC.put(key, previousValue);
      } else {
         MDC.remove(key);
      }
   }
}
