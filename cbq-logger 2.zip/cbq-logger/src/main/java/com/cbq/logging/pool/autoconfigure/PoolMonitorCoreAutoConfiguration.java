package com.cbq.logging.pool.autoconfigure;

import com.cbq.logging.pool.core.AsyncEventDispatcher;
import com.cbq.logging.pool.core.ConnectionPoolEventListener;
import com.cbq.logging.pool.core.Slf4jPoolEventListener;
import com.cbq.logging.pool.core.SlowConnectionListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
@ConditionalOnProperty(prefix = "cbq.pool-monitor", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(PoolMonitorProperties.class)
public class PoolMonitorCoreAutoConfiguration {

   @Bean
   @ConditionalOnMissingBean
   public AsyncEventDispatcher cbqPoolMonitorDispatcher(PoolMonitorProperties props,
                                                        List<ConnectionPoolEventListener> listeners) {
      AsyncEventDispatcher dispatcher = new AsyncEventDispatcher(props.getBufferSize());
      listeners.forEach(dispatcher::addListener);
      return dispatcher;
   }

   @Bean
   @ConditionalOnMissingBean(Slf4jPoolEventListener.class)
   public Slf4jPoolEventListener cbqPoolMonitorSlf4jListener(PoolMonitorProperties props) {
      Slf4jPoolEventListener.LogLevel level;
      try {
         level = Slf4jPoolEventListener.LogLevel.valueOf(props.getLogLevel().toUpperCase());
      } catch (IllegalArgumentException e) {
         level = Slf4jPoolEventListener.LogLevel.DEBUG;
      }
      return new Slf4jPoolEventListener(level);
   }

   @Bean
   @ConditionalOnMissingBean(SlowConnectionListener.class)
   public SlowConnectionListener cbqPoolMonitorSlowListener(PoolMonitorProperties props) {
      return new SlowConnectionListener(props.getSlowThresholdMs());
   }
}
