# CBQ REST Client Comprehensive Guide

Welcome to the CBQ REST Client guide. This library is a high-performance, fully reactive wrapper around Spring's `WebClient`, designed to simplify complex service orchestrations, handle context propagation (like correlation IDs) automatically, and provide robust resilience patterns.

## 1. Core Philosophy

*   **Fully Reactive**: Built on Project Reactor. Everything is non-blocking.
*   **Context Aware**: Automatically manages and propagates Tracing and Correlation IDs across asynchronous boundaries.
*   **Resilience First**: Integrated Circuit Breaker, Rate Limiter, Retry, and Bulkhead.
*   **Workflow Engine**: Specialized DSL for mixing blocking (synchronous) and non-blocking (reactive) tasks without killing threads or losing context.

---

## 2. Client Configuration

Use the `CBQRestClientBuilder` to configure your client. You can set up base URLs, timeouts, logging, and resilience defaults globally.

```java
CBQRestClient client = CBQRestClientBuilder.builder("order-service")
    .baseUrl("https://api.orders.example.com")
    .timeout(timeouts -> timeouts
        .connection(Duration.ofSeconds(2))
        .read(Duration.ofSeconds(5))
        .response(Duration.ofSeconds(10)))
    .logging(logging -> logging
        .enabled(true)
        .level(LoggingConfig.Level.FULL)
        .logBody(true))
    .resilience(resilience -> resilience
        .retry(retry -> retry.maxAttempts(3).backoff(Duration.ofMillis(500)))
        .circuitBreaker(cb -> cb.failureThreshold(5).resetTime(Duration.ofMinutes(1))))
    .build();
```

---

## 3. Basic Requests

The client supports all standard HTTP methods with a fluent API.

### Single Response (Mono)
```java
Mono<CBQResponse<User>> userMono = client.get()
    .uri("/users/{}", userId)
    .retrieve(User.class);
```

### Stream of Responses (Flux)
```java
Flux<Product> productFlux = client.get()
    .uri("/products")
    .retrieveFlux(Product.class);
```

### Per-Request Overrides
You can override global settings for specific requests:
```java
client.post()
    .uri("/critical-operation")
    .bodyValue(payload)
    .override(o -> o
        .responseTimeout(Duration.ofSeconds(30))
        .disableRetry())
    .retrieve(Result.class);
```

---

## 4. Advanced Parallel Execution

The `parallel` API allows you to execute multiple requests concurrently with different strategies.

### Strategies:
1.  **Wait All (Default)**: Completes when all requests complete. If one fails, the whole block fails.
2.  **Fail Fast**: Completes as soon as the first failure occurs.
3.  **Partial Success**: Collects both successful responses and errors without failing the entire operation.

```java
Mono<CBQParallelResult<Object>> results = client.parallel(
    client.get().uri("/service-a").retrieve(Object.class),
    client.get().uri("/service-b").retrieve(Object.class),
    client.get().uri("/service-c").retrieve(Object.class)
)
.partialSuccess() // Don't fail if one service is down
.execute();
```

---

## 5. CBQWorkflow: Orchestrating Complex Logic

`CBQWorkflow` is the crown jewel of this library. It allows you to chain multiple steps, including blocking database calls, manage background tasks safely, and even nest workflows.

### Chaining Blocking and Non-Blocking Steps
The workflow ensures that synchronous calls are executed on a dedicated scheduler to prevent blocking the reactive event loop.

```java
PostingResult result = CBQWorkflow
    .startWith(() -> client.get().uri("/validate/{}").retrieve(Status.class))
    
    // Non-blocking step
    .step(status -> client.post().uri("/process").bodyValue(status).retrieve(PostingResult.class))
    
    // Synchronous/Blocking DB call (safely handled)
    .stepSync(res -> {
        repository.save(res); // Traditional blocking JPA/JDBC call
        return res;
    })
    
    // Execute and block to get result (or use executeAsync())
    .execute();
```

### Advanced Mix & Match (Nested Flows)
You can nest workflows within steps for complex conditional logic.

```java
CBQWorkflow.startWith(client.get().uri("/user/config").retrieve(Config.class))
    .step(config -> {
        if (config.isPremium()) {
            // Nested workflow for premium users
            return CBQWorkflow.startWith(client.get().uri("/premium/data").retrieve(Data.class))
                .step(data -> client.post().uri("/premium/process").bodyValue(data).retrieve(Result.class))
                .executeAsync(); // Return Mono for the outer step
        }
        return client.get().uri("/standard/data").retrieve(Result.class).map(CBQResponse::getBody);
    })
    .execute();
```

### Error Handling & Fallbacks
```java
CBQWorkflow.startWith(client.get().uri("/data").retrieve(Data.class))
    .step(data -> client.post().uri("/update").bodyValue(data).retrieve(Result.class))
    .onFailure(error -> {
        log.error("Workflow failed: " + error.getMessage());
        return client.post().uri("/rollback").retrieve(Void.class).then();
    })
    .execute();
```

### Background Tasks (Fire-and-Forget)
Trigger side-effects that don't need to block the main response. These tasks automatically inherit the parent's correlation ID and context.

```java
CBQWorkflow.startWith(client.post().uri("/order").retrieve(Order.class))
    .fireAndForget(
        () -> client.post().uri("/notify/email").retrieve(Void.class),
        () -> client.post().uri("/audit/log").retrieve(Void.class)
    )
    .fireAndForgetSync(() -> legacyAuditSystem.log("Order Created"))
    .execute();
```

---

## 6. Sequence Builder
For simpler sequential chains that don't require the full workflow engine, use `client.sequence()`. It passes the body of one response as the input to the next call.

```java
Mono<Order[]> orders = client.sequence()
    .then(() -> client.get().uri("/users/1").retrieve(User.class))
    .then((User user) -> client.get()
        .uri("/orders?userId=" + user.getId())
        .retrieve(Order[].class))
    .execute();
```

---

## 7. Email Notifications on Error
The client can automatically send emails when a request fails. This works for individual requests, parallel execution, and workflows.

### Individual Request
```java
client.post()
    .uri("/payments")
    .bodyValue(payment)
    .onErrorNotify(mail -> mail
        .to("alerts@company.com")
        .subject("Payment Critical Failure"))
    .retrieve(Result.class);
```

### In Parallel Execution
```java
client.parallel(
    client.get().uri("/s1").onErrorNotify(m -> m.to("devs@cbq.com")).retrieve(Object.class),
    client.get().uri("/s2").onErrorNotify(m -> m.to("devs@cbq.com")).retrieve(Object.class)
).execute();
```

### In Workflows
```java
CBQWorkflow.startWith(() -> client.get()
        .uri("/data")
        .onErrorNotify(m -> m.subject("Workflow Step 1 Failed"))
        .retrieve(Data.class))
    .step(data -> client.post()
        .uri("/process")
        .onErrorNotify(m -> m.subject("Workflow Step 2 Failed"))
        .retrieve(Result.class))
    .execute();
```

---

## 8. Custom Request Info & Payload-Driven Correlation IDs

Banks often require a `requestInfo` object with a `requestId` and `requestTime` in every request body. Additionally, you may need to use a `requestId` provided in the user's payload as the `correlationId` for the entire request chain.

### Mandatory Bank Request Pattern
This filter captures the `requestId` from the user's payload and promotes it to the `correlationId`, while also injecting it into the `requestInfo` block of all downstream requests.

```java
public class BankRequestFilter implements RequestFilter {
    @Override
    public Mono<RequestContext> filter(RequestContext ctx) {
        Object body = ctx.getBody();
        
        if (body instanceof MyBaseRequest) {
            MyBaseRequest payload = (MyBaseRequest) body;
            
            // 1. If the payload has a requestId, use it as the source of truth for correlation
            String payloadId = payload.getRequestId();
            if (payloadId != null && !payloadId.isEmpty()) {
                // This will be used by the client for the X-Correlation-Id header
                ctx.addHeader("X-Correlation-Id", payloadId); 
            }

            // 2. Ensure every request has the required requestInfo block
            if (payload.getRequestInfo() == null) {
                payload.setRequestInfo(new RequestInfo());
            }
            
            // Use the client-generated requestId (or the one we just promoted)
            payload.getRequestInfo().setRequestId(ctx.getRequestId());
            payload.getRequestInfo().setRequestTime(OffsetDateTime.now().toString());
        }
        return Mono.just(ctx);
    }
}
```

### Registering Globally
```java
CBQRestClient client = CBQRestClientBuilder.builder("bank-client")
    .addRequestFilter(new BankRequestFilter())
    .build();
```

Once registered, the IDs are automatically synchronized between the payload and the headers for **Basic Requests**, **Parallel Requests**, and **Workflows**.

---

## 9. CBQWorkflow: Advanced Orchestration & Mix-and-Match

`CBQWorkflow` is a powerful engine for chaining complex operations. Below are "Grade A" examples showcasing its full potential.

### The "Kitchen Sink" Example (Mix & Match)
This example demonstrates nearly every method in a single flow, combining reactive calls, blocking DB operations, and background tasks. It uses the `PostingResult` model (see Sample Data Models) to capture transaction details.

```java
PostingResult finalResult = CBQWorkflow
    // Start with a reactive call
    .startWith(() -> client.get().uri("/init").retrieve(InitData.class))
    
    // Standard reactive step
    .step(init -> client.post().uri("/validate").bodyValue(init).retrieve(Status.class))
    
    // Blocking/Synchronous step (safely offloaded to ASYNC_SCHEDULER)
    .stepSync(status -> {
        User user = userRepository.findById(status.getUserId()); // JPA/JDBC
        return user;
    })
    
    // Step returning a plain Mono (not necessarily an HTTP call)
    .stepMono(user -> cacheService.putAsync(user.getId(), user).thenReturn(user))
    
    // Continue even if this optional step fails
    .stepContinueOnError(
        user -> client.get().uri("/enrich/{}", user.getId()).retrieve(EnrichedData.class),
        error -> log.warn("Enrichment failed, but continuing workflow...")
    )
    
    // Fire-and-forget: Reactive (multiple)
    .fireAndForget(
        () -> client.post().uri("/audit").retrieve(Void.class),
        () -> client.post().uri("/metrics").retrieve(Void.class)
    )
    
    // Fire-and-forget: Mono based
    .fireAndForgetMono(() -> messageQueue.sendAsync("User processed"))
    
    // Fire-and-forget: Blocking/Synchronous tasks
    .fireAndForgetSync(
        () -> legacyLogger.log("Workflow reached milestone"),
        () -> diskService.writeLocalBackup(userData)
    )
    
    // Advanced: Handle errors specifically for fire-and-forget tasks
    .onFireAndForgetError(err -> notifyDevOps("Background task failed: " + err.getMessage()))
    
    // Global workflow failure handler (Rollback logic)
    .onFailure(error -> {
        log.error("Main workflow failed at some point. Rolling back...");
        return client.post().uri("/rollback").bodyValue(error.getMessage()).retrieve(Void.class).then();
    })
    
    // Blocking execution to wait for the final result
    .execute();
```

### Nested Flows & Advanced Scoping
You can nest workflows and even place `onFailure` handlers inside background tasks using `fireAndForgetWith`.

```java
CBQWorkflow.startWith(client.get().uri("/orders/123").retrieve(Order.class))
    .fireAndForgetWith(order -> {
        // A nested workflow inside fire-and-forget with its own rollback logic
        return CBQWorkflow.startWith(client.post().uri("/internal/sync").bodyValue(order).retrieve(Void.class))
            .onFailure(err -> {
                log.error("Nested sync failed, performing internal rollback");
                return internalDb.rollbackAsync(order.getId());
            })
            .executeAsync(); // Important: must return a Mono
    })
    .executeAsync() // Run the whole thing asynchronously
    .subscribe();
```

### Specialized Error Handlers (Sync & Nested)
If you need to perform blocking operations during a failure (like writing to a local emergency file or calling a legacy cleanup tool), use `onFailureSync`.

```java
CBQWorkflow.startWith(client.post().uri("/critical").retrieve(Void.class))
    // Failure handler for the main chain (Blocking)
    .onFailureSync(error -> {
        emergencyCleanupTool.run(error.getMessage());
        log.error("Sync failure cleanup done.");
    })
    
    // You can also nest failure handlers inside fire-and-forget tasks
    .fireAndForgetWith(data -> {
        return CBQWorkflow.startWith(client.post().uri("/side-effect").retrieve(Void.class))
            .onFailureSync(err -> {
                 log.error("Side-effect failed, performing sync nested cleanup");
                 legacyAuditSystem.logFailure(err);
            })
            .executeAsync();
    })
    .executeAsync();
```

---

## 10. Robust Response Handling

### CBQResponse Capabilities
The `CBQResponse<T>` wrapper provides rich metadata and utility methods.

```java
CBQResponse<User> resp = client.get().uri("/user/1").retrieve(User.class).block();

if (resp.isSuccessful()) {
    User body = resp.getBody(); // The typed body
    int code = resp.getStatusCode(); // e.g., 200
    long time = resp.getDurationMs(); // Response time
    String reqId = resp.getRequestId(); // Internal trace ID
} else if (resp.is4xxClientError()) {
    log.error("Client error: " + resp.getStatusCode());
}
```

### CBQParallelResult: Mastering Concurrent Calls
When using `.parallel()`, the `CBQParallelResult` helps you manage bulk outcomes.

```java
CBQParallelResult<Object> result = client.parallel(call1, call2, call3)
    .partialSuccess()
    .execute()
    .block();

// High-level stats
int successes = result.successCount();
int failures = result.errorCount();
boolean allOk = result.allSuccessful();

// Extract all successful bodies at once
List<Object> allBodies = result.getBodies();

// Targeted extraction
if (result.getError(0) != null) {
    Throwable error = result.getError(0); // Error from first call
} else {
    CBQResponse<Object> resp = result.getResponse(0); // Success from first call
}
```

---

## 11. Context Propagation & Correlation IDs

Correlation IDs are critical for distributed tracing. This client makes it seamless.

### How it works:
1.  **Automatic Generation**: If no ID exists, a new UUID is generated for the request.
2.  **Header Propagation**: The client looks for `X-Correlation-Id` (configurable) in incoming headers.
3.  **Downstream Forwarding**: Every downstream HTTP call automatically includes this ID in its headers.
4.  **Workflow Support**: Background tasks (`fireAndForget`) and asynchronous steps preserve this context.

### Example: Controller to Service
```java
@GetMapping("/process")
public Mono<Result> handleRequest(@RequestHeader HttpHeaders headers) {
    // The client will pick up 'X-Correlation-Id' from headers if present
    return client.get()
        .uri("/service-1")
        .headers(h -> h.addAll(headers)) 
        .retrieve(Result.class)
        .flatMap(res -> {
            // Even in a flatMap, the ID is preserved and sent to service-2
            return client.get().uri("/service-2").retrieve(Result.class);
        });
}
```

### 4. Application Shutdown
Always call `client.shutdown()` and `CBQWorkflow.shutdown()` during application shutdown to clean up thread pools. There are three common ways to handle this in Spring:

**Way 1: Using `@Bean(destroyMethod = "shutdown")`**
```java
@Bean(destroyMethod = "shutdown")
public CBQRestClient cbqRestClient() {
    return CBQRestClientBuilder.builder("my-client").build();
}
```

**Way 2: Implementing `DisposableBean`**
```java
@Component
public class MyService implements DisposableBean {
    private final CBQRestClient client;
    
    @Override
    public void destroy() {
        client.shutdown();
        CBQWorkflow.shutdown();
    }
}
```

**Way 3: Using `@PreDestroy`**
```java
@Component
public class MyService {
    @PreDestroy
    public void cleanup() {
        client.shutdown();
        CBQWorkflow.shutdown();
    }
}
```

---

## 10. Multi-Client & Dynamic Configuration

In many enterprise scenarios, you need to connect to multiple external APIs with different requirements (SSL, timeouts, auth).

### Multiple Named Clients
Configure separate beans for different services:
```java
@Bean
public CBQRestClient bankAClient() {
    return CBQRestClientBuilder.builder("bank-a")
        .baseUrl("https://api.bank-a.com")
        .build();
}

@Bean
public CBQRestClient internalServiceClient() {
    return CBQRestClientBuilder.builder("internal")
        .baseUrl("http://internal-svc")
        .ssl(SslConfig.disabled()) // Disable SSL for internal calls
        .build();
}
```

### Dynamic Clients & Agent-based Config
Use `CBQRestClientPool` to manage clients dynamically. For example, getting credentials from a Map based on the `User-Agent`:

```java
public class DynamicService {
    private final CBQRestClientPool pool;
    private final Map<String, String[]> agentCreds = Map.of(
        "Mobile-App", new String[]{"mob_user", "mob_pass"},
        "Web-Portal", new String[]{"web_user", "web_pass"}
    );

    public Mono<String> callService(String userAgent) {
        String[] creds = agentCreds.getOrDefault(userAgent, new String[]{"def", "def"});
        
        // Get or create a client with a specific timeout profile
        CBQRestClient client = pool.getOrCreate(userAgent, CBQRestClientPool.DEFAULT_PROFILE);
        
        return client.get()
            .uri("/data")
            .header("User-Agent", userAgent)
            .header("X-Auth-User", creds[0])
            .header("X-Auth-Pass", creds[1])
            .retrieveBody(String.class);
    }
}
```

---

## 11. Client Pooling with `CBQRestClientPool`

`CBQRestClientPool` is a high-level manager for multiple `CBQRestClient` instances. It allows you to share common configurations while using different `TimeoutProfiles`.

### Pre-defined Profiles:
- `FAST_PROFILE`: 2s connect, 5s read (Low latency)
- `DEFAULT_PROFILE`: 5s connect, 30s read (Standard)
- `SLOW_PROFILE`: 10s connect, 2m read (Heavy processing)
- `BATCH_PROFILE`: 10s connect, 10m read (Background jobs)

### Usage Example:
```java
CBQRestClientPool pool = CBQRestClientPool.builder()
    .baseUrl("https://api.global.com")
    .logging(LoggingConfig.enabled())
    .resilience(ResilienceConfig.defaults())
    .build();

// Use different profiles for different tasks
CBQRestClient fastClient = pool.getFast();
CBQRestClient batchClient = pool.getBatch();
```

---

## 12. Advanced ID Management

### Using `requestId` as `correlationId`
Sometimes you want to force the `requestId` (unique per call) to be the `correlationId` for downstream services. You can do this with a global `RequestFilter`:

```java
CBQRestClient client = CBQRestClientBuilder.builder("custom-id-client")
    .addRequestFilter(context -> {
        // Overwrite correlation ID with request ID
        context.getHeaders().set("X-Correlation-Id", context.getRequestId());
        return Mono.just(context);
    })
    .build();
```

---

## 13. Best Practices

### 1. Never `block()` inside a Reactive Chain
If you are already in a reactive flow (e.g., inside a `flatMap`), do not call `.block()`. Use `CBQWorkflow` or `flatMap` to chain operations.

### 2. Handling Blocking Code
When you must call a blocking library (JDBC, File IO, Legacy SDKs), always use `.stepSync()` or `.fireAndForgetSync()` within a `CBQWorkflow`. This offloads the work to the `ASYNC_SCHEDULER`.

### 3. Context in Background Tasks
Use `.fireAndForget()` instead of manually calling `.subscribe()`. Manual subscriptions often lose the Reactive Context (MDC, Tracing), whereas `CBQWorkflow` preserves it.

---

## 14. Real-World Use Cases

Below are practical scenarios mixing different library capabilities to solve complex business requirements.

### Use Case 1: Transactional Flow with Reversal
**Scenario**: Check status -> Fetch card details -> Check balance -> Make posting. If any step fails after the posting attempt or due to business logic, trigger a reversal.

```java
final String[] txnIdHolder = new String[1];

PostingResult result = CBQWorkflow
    .startWith(() -> client.get().uri("/card/status/1234").retrieve(Status.class))
    .step(status -> {
        if (!status.isActive()) return Mono.error(new RuntimeException("Card Inactive"));
        return client.post().uri("/card/details").bodyValue(new CardRequest("1234")).retrieve(CardDetails.class);
    })
    .step(details -> client.post().uri("/card/balance").bodyValue(details).retrieve(Balance.class))
    .step(balance -> {
        if (balance.getAvailable() < 100) return Mono.error(new RuntimeException("Low Balance"));
        return client.post().uri("/card/posting").bodyValue(new PostingRequest(100.0)).retrieve(PostingResult.class);
    })
    .stepMono(res -> {
        txnIdHolder[0] = res.getTransactionId(); // Capture ID for potential reversal
        return Mono.just(res);
    })
    .onFailure(error -> {
        if (txnIdHolder[0] != null) {
            return client.post().uri("/card/reversal").bodyValue(new ReversalRequest(txnIdHolder[0])).retrieve(Void.class).then();
        }
        return Mono.empty();
    })
    .execute();
```

### Use Case 2: Resilience with Async Side-Effects
**Scenario**: Make posting -> Call secondary service. If secondary fails, don't stop the successful posting result. Finally, update a database count asynchronously.

```java
PostingResult result = CBQWorkflow
    .startWith(() -> client.post().uri("/posting").bodyValue(req).retrieve(PostingResult.class))
    .stepContinueOnError(
        res -> client.post().uri("/secondary").bodyValue(res).retrieve(Void.class),
        error -> log.warn("Secondary service failed, but posting is valid")
    )
    .fireAndForgetMono(() -> repository.incrementCountAsync(req.getCardNumber()))
    .execute();
```

### Use Case 3: Comprehensive Bank Card Workflow
**Scenario**: Check app status -> Get card details -> Check card status -> Check eligibility -> Account posting -> On failure: log to DB, trigger reversal, and send alert email.

```java
final String[] txnId = new String[1];

PostingResult flow = CBQWorkflow
    .startWith(() -> client.get().uri("/app/status").retrieve(Status.class))
    .step(app -> client.get().uri("/card/details/{}").retrieve(CardDetails.class))
    .step(details -> client.get().uri("/card/status/{}").retrieve(Status.class))
    .step(status -> {
        if (!status.isEligible()) return Mono.error(new RuntimeException("Ineligible"));
        return client.post().uri("/account/posting").retrieve(PostingResult.class);
    })
    .stepMono(res -> { txnId[0] = res.getTransactionId(); return Mono.just(res); })
    .onFailure(error -> {
        // Multi-step failure handling
        return Mono.zip(
            repository.logFailureAsync(error.getMessage()),
            txnId[0] != null ? client.post().uri("/reversal").bodyValue(txnId[0]).retrieve(Void.class) : Mono.empty()
        ).then();
    })
    .fireAndForget(() -> client.post().uri("/notify/email").bodyValue("Workflow Failed").retrieve(Void.class))
    .execute();
```

### Use Case 4: Conditional Data Return & Cleanup
**Scenario**: Make first API call -> Use result for second call. If second fails, it should still return the first result but without the reference returned from the first call. Finally, fire and forget a database call.

```java
TransferResult result = CBQWorkflow
    .startWith(() -> client.get().uri("/first-call").retrieve(TransferResult.class))
    .step(first -> 
        client.get().uri("/second-call/{}", first.getId())
            .retrieve(SecondResult.class)
            .map(second -> first) // Success: return original
            .onErrorResume(err -> {
                first.setReference(null); // Failure: strip reference
                return Mono.just(first);
            })
    )
    .fireAndForgetSync(() -> db.cleanup(id))
    .execute();
```

### Use Case 5: Direct Reactor Integration (Mono.zip)
**Scenario**: When you need to combine results from multiple independent reactive calls triggered by a previous step. This example shows how to use the client directly with standard Reactor operators.

```java
public Mono<TransferResponse> processTransfer(TransferRequest request) {
    return client.post()
        .uri("/transfers")
        .bodyValue(request)
        .retrieveBody(TransferResult.class)
        .flatMap(transfer -> {
            // Trigger two calls in parallel that depend on the first result
            Mono<String> receiptIdMono = client.post()
                    .uri("/receipts")
                    .bodyValue(new ReceiptRequest(transfer.getId()))
                    .retrieveBody(Receipt.class)
                    .map(Receipt::getId)
                    .onErrorResume(error -> {
                        log.warn("Receipt generation failed: {}", error.getMessage());
                        return Mono.just(""); // Graceful degradation
                    });

            Mono<TransferResult> completedTransferMono = client.post()
                    .uri("/transfers/complete")
                    .bodyValue(new CompleteRequest(transfer.getId()))
                    .retrieveBody(TransferResult.class);

            // Wait for both to complete
            return Mono.zip(completedTransferMono, receiptIdMono);
        })
        .map(tuple -> {
            TransferResult result = tuple.getT1();
            String receiptId = tuple.getT2();
            return new TransferResponse(result.getId(), result.getAmount(), receiptId);
        });
}
```

---

## 15. Sample Data Models

To keep the examples concise, the following data models are used throughout this guide.

```java
// Common response for posting operations
@Data
public class PostingResult {
    private String transactionId;
    private String status;
    private Double processedAmount;
}

// Status check response
@Data
public class Status {
    private String code;
    private boolean active;
    private boolean eligible;
}

// Card details
@Data
public class CardDetails {
    private String cardNumber;
    private String type;
    private Double limit;
}

// Financial balance
@Data
public class Balance {
    private Double available;
    private Double ledger;
}

// Transfer models
@Data
public class TransferResult {
    private String id;
    private String reference;
    private Double amount;
    
    public void setReference(String ref) { this.reference = ref; }
}

@Data
@AllArgsConstructor
public class TransferResponse {
    private String transferId;
    private Double amount;
    private String receiptId;
}

@Data
public class Receipt {
    private String id;
}

@Data
@AllArgsConstructor
public class CardRequest {
    private String cardNumber;
}

@Data
@AllArgsConstructor
public class PostingRequest {
    private Double amount;
}

@Data
@AllArgsConstructor
public class ReversalRequest {
    private String transactionId;
}
```
