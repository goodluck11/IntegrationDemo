package com.cbq.restclient.v2;

import io.micrometer.core.instrument.MeterRegistry;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.SneakyThrows;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import java.io.FileInputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public class WebClientFactoryV2 {
   @SneakyThrows
   public static WebClient create(
           String baseUrl,
           TimeoutConfigV2 timeout,
           SslConfigV2 ssl,
           LoggingConfigV2 logging,
           ObservabilityConfigV2 observability
   ) {
      HttpClient httpClient = HttpClient.create();

      if (ssl.isEnabled()) {
         if (ssl.getCertificatePath() == null) {
            httpClient = httpClient.secure(s ->
                    s.sslContext(SslContextBuilder.forClient()
                            .trustManager(InsecureTrustManagerFactory.INSTANCE)));
         } else {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate)
                    cf.generateCertificate(new FileInputStream(ssl.getCertificatePath()));
            httpClient = httpClient.secure(s ->
                    s.sslContext(SslContextBuilder.forClient().trustManager(cert)));
         }
      }

      WebClient.Builder builder = WebClient.builder()
              .baseUrl(baseUrl == null ? "" : baseUrl)
              .clientConnector(new ReactorClientHttpConnector(httpClient));

      if (logging.isEnabled()) {
         builder.filter(new StructuredLoggingFilterV2(logging));
      }

      if (observability.isEnabled() && observability.getMeterRegistry() != null) {
         MeterRegistry registry = observability.getMeterRegistry();
         builder.filter((req, next) ->
                 next.exchange(req)
                         .doOnSuccess(res ->
                                 registry.counter("cbq.http.requests",
                                         "client", observability.getClientName(),
                                         "status", String.valueOf(res.rawStatusCode())
                                 ).increment()
                         )
         );
      }

      builder.filter((req, next) ->
              Mono.deferContextual(ctx -> {
                 String correlationId = req.headers().getFirst("X-Correlation-Id");
                 if (correlationId == null) {
                    correlationId = ctx.<String>getOrEmpty("correlationId").orElse(java.util.UUID.randomUUID().toString());
                 }
                 return next.exchange(
                         ClientRequest.from(req)
                                 .header("X-Correlation-Id", correlationId)
                                 .build()
                 );
              })
      );

      return builder.build();
   }
}
