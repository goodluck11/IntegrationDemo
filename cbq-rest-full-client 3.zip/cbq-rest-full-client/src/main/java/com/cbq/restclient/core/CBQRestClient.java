package com.cbq.restclient.core;

import com.cbq.restclient.config.CBQRestClientConfig;
import com.cbq.restclient.config.RequestOverride;
import com.cbq.restclient.email.EmailNotifier;
import com.cbq.restclient.filter.ErrorMapper;
import com.cbq.restclient.filter.RequestFilter;
import com.cbq.restclient.logging.LoggingService;
import com.cbq.restclient.model.CBQParallelResult;
import com.cbq.restclient.model.CBQResponse;
import com.cbq.restclient.model.EmailNotification;
import com.cbq.restclient.resilience.ResilienceManager;
import com.cbq.restclient.tracing.TracingService;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.time.Duration;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class CBQRestClient {
   private static final Logger log = LoggerFactory.getLogger(CBQRestClient.class);

   @Getter
   private final CBQRestClientConfig config;
   private final WebClient webClient;
   @Getter
   private final ResilienceManager resilienceManager;
   private final LoggingService loggingService;
   private final EmailNotifier emailNotifier;
   private final TracingService tracingService;
   private final Scheduler parallelScheduler;

   CBQRestClient(CBQRestClientConfig config, WebClient webClient,
                 ResilienceManager resilienceManager, LoggingService loggingService,
                 EmailNotifier emailNotifier, TracingService tracingService) {
      this.config = config;
      this.webClient = webClient;
      this.resilienceManager = resilienceManager;
      this.loggingService = loggingService;
      this.emailNotifier = emailNotifier;
      this.tracingService = tracingService;
      this.parallelScheduler = Schedulers.newBoundedElastic(
              10, 100, "cbq-parallel-" + config.getName());
   }

   public RequestSpec get() {
      return new RequestSpec(this, HttpMethod.GET);
   }

   public RequestSpec post() {
      return new RequestSpec(this, HttpMethod.POST);
   }

   public RequestSpec put() {
      return new RequestSpec(this, HttpMethod.PUT);
   }

   public RequestSpec delete() {
      return new RequestSpec(this, HttpMethod.DELETE);
   }

   public RequestSpec patch() {
      return new RequestSpec(this, HttpMethod.PATCH);
   }

   public RequestSpec head() {
      return new RequestSpec(this, HttpMethod.HEAD);
   }

   public RequestSpec options() {
      return new RequestSpec(this, HttpMethod.OPTIONS);
   }

   @SafeVarargs
   public final <T> ParallelBuilder<T> parallel(Mono<CBQResponse<T>>... requests) {
      return new ParallelBuilder<>(this, Arrays.asList(requests));
   }

   public SequenceBuilder sequence() {
      return new SequenceBuilder();
   }

   public static class RequestSpec {
      private final CBQRestClient client;
      private final HttpMethod method;
      private String uri = "";
      private final HttpHeaders headers = new HttpHeaders();
      private Object body;
      private MediaType contentType = MediaType.APPLICATION_JSON;
      private RequestOverride override;
      private EmailNotification emailNotification;
      private final List<ErrorMapper> errorMappers = new ArrayList<>();

      RequestSpec(CBQRestClient client, HttpMethod method) {
         this.client = client;
         this.method = method;
      }

      public RequestSpec uri(String uri) {
         this.uri = uri;
         return this;
      }

      public RequestSpec uri(String template, Object... vars) {
         this.uri = String.format(template.replace("{}", "%s"), vars);
         return this;
      }

      public RequestSpec header(String name, String value) {
         this.headers.add(name, value);
         return this;
      }

      public RequestSpec headers(Consumer<HttpHeaders> consumer) {
         consumer.accept(this.headers);
         return this;
      }

      public RequestSpec bodyValue(Object body) {
         this.body = body;
         return this;
      }

      public RequestSpec contentType(MediaType contentType) {
         this.contentType = contentType;
         return this;
      }

      public RequestSpec override(Consumer<RequestOverride> configurer) {
         this.override = RequestOverride.create();
         configurer.accept(this.override);
         return this;
      }

      public RequestSpec onStatus(Predicate<HttpStatus> predicate,
                                  Function<ErrorMapper.ErrorContext, Throwable> mapper) {
         this.errorMappers.add(ErrorMapper.onStatus(predicate, mapper));
         return this;
      }

      public RequestSpec onErrorNotify(Consumer<EmailNotification> configurer) {
         this.emailNotification = EmailNotification.create();
         configurer.accept(this.emailNotification);
         return this;
      }

      public <T> Mono<CBQResponse<T>> retrieve(Class<T> responseType) {
         return client.execute(this, responseType);
      }

      public Mono<CBQResponse<String>> retrieve() {
         return client.execute(this, String.class);
      }

      public <T> Mono<T> retrieveBody(Class<T> responseType) {
         return retrieve(responseType).map(CBQResponse::getBody);
      }

      public <T> Flux<T> retrieveFlux(Class<T> responseType) {
         return client.executeFlux(this, responseType);
      }

      HttpMethod getMethod() {
         return method;
      }

      String getUri() {
         return uri;
      }

      HttpHeaders getHeaders() {
         return headers;
      }

      Object getBody() {
         return body;
      }

      MediaType getContentType() {
         return contentType;
      }

      RequestOverride getOverride() {
         return override;
      }

      EmailNotification getEmailNotification() {
         return emailNotification;
      }

      List<ErrorMapper> getErrorMappers() {
         return errorMappers;
      }
   }

   <T> Mono<CBQResponse<T>> execute(RequestSpec spec, Class<T> responseType) {
      String requestId = tracingService.generateRequestId();
      long startTime = System.currentTimeMillis();
      String fullUrl = buildFullUrl(spec.getUri());

      log.info("Executing CBQ response {}", fullUrl);

      HttpHeaders mergedHeaders = new HttpHeaders();
      config.getDefaultHeaders().forEach(mergedHeaders::add);
      mergedHeaders.putAll(spec.getHeaders());

      RequestFilter.RequestContext reqCtx = new RequestFilter.RequestContext(
              requestId, spec.getMethod(), spec.getUri(), mergedHeaders,
              spec.getBody(), new HashMap<>());

      return Mono.deferContextual(ctx -> {
         Mono<RequestFilter.RequestContext> filterChain = Mono.just(reqCtx);
         for (RequestFilter filter : config.getRequestFilters()) {
            filterChain = filterChain.flatMap(filter::filter);
         }

         String cid = tracingService.getOrCreateCId(mergedHeaders, ctx);
         return filterChain.flatMap(fCtx -> {

            tracingService.addTracingHeaders(fCtx.getHeaders(), cid);

            Mono<Void> logRequestMono = loggingService.logRequestAsync(requestId, cid, fCtx.getMethod().name(), fullUrl,
                    fCtx.getHeaders(), fCtx.getBody(),
                    spec.getContentType() != null ? spec.getContentType().toString() : null);

            WebClient.RequestBodySpec requestSpec = webClient
                    .method(fCtx.getMethod())
                    .uri(fCtx.getUri());

            fCtx.getHeaders().forEach((name, values) ->
                    values.forEach(v -> requestSpec.header(name, v)));

            WebClient.RequestHeadersSpec<?> headersSpec;
            if (fCtx.getBody() != null) {
               headersSpec = requestSpec
                       .contentType(spec.getContentType())
                       .body(BodyInserters.fromValue(fCtx.getBody()));
            } else {
               headersSpec = requestSpec;
            }

            Duration responseTimeout = getEffectiveTimeout(spec.getOverride());
            Mono<CBQResponse<T>> responseMono = headersSpec
                    .exchangeToMono(clientResponse ->
                            handleResponse(clientResponse, responseType, requestId, cid, spec, fullUrl, startTime))
                    .timeout(responseTimeout);

            responseMono = resilienceManager.applyResilience(
                    responseMono, spec.getOverride(), requestId, fullUrl, spec.getMethod().name());

            responseMono = responseMono.doOnError(error -> {
               long duration = System.currentTimeMillis() - startTime;
               loggingService.logError(requestId, spec.getMethod().name(), fullUrl, error, duration);

               if (spec.getEmailNotification() != null && emailNotifier != null) {
                  emailNotifier.notify(
                          new EmailNotifier.ErrorEvent(requestId, cid, spec.getMethod().name(), spec.getUri(), error, duration),
                          spec.getEmailNotification());
               }
            });

            return responseMono.doFirst(logRequestMono::subscribe);
         });
      });
   }

   private <T> Mono<CBQResponse<T>> handleResponse(ClientResponse clientResponse,
                                                   Class<T> responseType,
                                                   String requestId,
                                                   String correlationId,
                                                   RequestSpec spec,
                                                   String url,
                                                   long startTime) {
      HttpStatus status = clientResponse.statusCode();
      HttpHeaders headers = clientResponse.headers().asHttpHeaders();

      List<ErrorMapper> mappers = new ArrayList<>(config.getErrorMappers());
      mappers.addAll(spec.getErrorMappers());

      for (ErrorMapper mapper : mappers) {
         if (mapper.matches(status)) {
            return clientResponse.bodyToMono(String.class)
                    .defaultIfEmpty("")
                    .flatMap(body -> {
                       ErrorMapper.ErrorContext ctx = new ErrorMapper.ErrorContext(
                               requestId, status, spec.getMethod().name(), url, body, headers);
                       return Mono.error(mapper.mapError(ctx));
                    });
         }
      }

      return clientResponse.bodyToMono(responseType)
              .defaultIfEmpty(createEmptyResponse(responseType))
              .flatMap(body -> {
                 long duration = System.currentTimeMillis() - startTime;
                 Mono<Void> responseAsync = loggingService.logResponseAsync(
                         requestId,
                         correlationId,
                         spec.getUri(),
                         status.value(),
                         headers,
                         body != null ? body.toString() : null,
                         duration,
                         headers.getFirst(HttpHeaders.CONTENT_TYPE)
                 );

                 return Mono.just(CBQResponse.<T>builder()
                                 .body(body)
                                 .status(status)
                                 .headers(headers)
                                 .durationMs(duration)
                                 .requestId(requestId)
                                 .correlationId(correlationId)
                                 .build())
                         .doFirst(responseAsync::subscribe);
              });
   }

   <T> Flux<T> executeFlux(RequestSpec spec, Class<T> responseType) {
      return Flux.deferContextual(ctx -> {
         String requestId = tracingService.generateRequestId();
         long startTime = System.currentTimeMillis();
         String fullUrl = buildFullUrl(spec.getUri());

         HttpHeaders mergedHeaders = new HttpHeaders();
         config.getDefaultHeaders().forEach(mergedHeaders::add);
         mergedHeaders.putAll(spec.getHeaders());

         RequestFilter.RequestContext reqCtx = new RequestFilter.RequestContext(
                 requestId, spec.getMethod(), spec.getUri(), mergedHeaders,
                 spec.getBody(), new HashMap<>());

         Mono<RequestFilter.RequestContext> filterChain = Mono.just(reqCtx);
         for (RequestFilter filter : config.getRequestFilters()) {
            filterChain = filterChain.flatMap(filter::filter);
         }

         String cid = tracingService.getOrCreateCId(mergedHeaders, ctx);
         return filterChain.flatMapMany(fCtx -> {
            tracingService.addTracingHeaders(fCtx.getHeaders(), cid);

            Mono<Void> logRequestMono = loggingService.logRequestAsync(requestId, cid, fCtx.getMethod().name(), fullUrl,
                    fCtx.getHeaders(), fCtx.getBody(),
                    spec.getContentType() != null ? spec.getContentType().toString() : null);

            WebClient.RequestBodySpec requestSpec = webClient
                    .method(fCtx.getMethod())
                    .uri(fCtx.getUri());

            fCtx.getHeaders().forEach((name, values) ->
                    values.forEach(v -> requestSpec.header(name, v)));

            WebClient.RequestHeadersSpec<?> headersSpec;
            if (fCtx.getBody() != null) {
               headersSpec = requestSpec
                       .contentType(spec.getContentType())
                       .body(BodyInserters.fromValue(fCtx.getBody()));
            } else {
               headersSpec = requestSpec;
            }

            return logRequestMono.thenMany(headersSpec.retrieve()
                    .onStatus(HttpStatus::isError, clientResponse ->
                            handleResponse(clientResponse, String.class, requestId, cid, spec, fullUrl, startTime)
                                    .flatMap(resp -> Mono.error(new RuntimeException("Error in flux: " + resp.getStatus()))))
                    .bodyToFlux(responseType)
                    .doOnError(error -> {
                       loggingService.logError(requestId, spec.getMethod().name(), fullUrl, error,
                               System.currentTimeMillis() - startTime);
                    }));
         });
      });
   }

   private Duration getEffectiveTimeout(RequestOverride override) {
      if (override != null && override.getResponseTimeout() != null) {
         return override.getResponseTimeout();
      }
      return config.getTimeouts().getResponseTimeout();
   }

   private String buildFullUrl(String uri) {
      String baseUrl = config.getBaseUrl();
      if (baseUrl != null && !baseUrl.isEmpty()) {
         return uri.startsWith("/") ? baseUrl + uri : baseUrl + "/" + uri;
      }
      return uri;
   }

   @SuppressWarnings("unchecked")
   private <T> T createEmptyResponse(Class<T> type) {
      if (type == String.class) return (T) "";
      if (type == Void.class) return null;
      try {
         return type.getDeclaredConstructor().newInstance();
      } catch (Exception e) {
         return null;
      }
   }

   public static class ParallelBuilder<T> {
      private final CBQRestClient client;
      private final List<Mono<CBQResponse<T>>> requests;
      private CBQParallelResult.ParallelStrategy strategy = CBQParallelResult.ParallelStrategy.WAIT_ALL;

      ParallelBuilder(CBQRestClient client, List<Mono<CBQResponse<T>>> requests) {
         this.client = client;
         this.requests = requests;
      }

      public ParallelBuilder<T> waitAll() {
         this.strategy = CBQParallelResult.ParallelStrategy.WAIT_ALL;
         return this;
      }

      public ParallelBuilder<T> failFast() {
         this.strategy = CBQParallelResult.ParallelStrategy.FAIL_FAST;
         return this;
      }

      public ParallelBuilder<T> partialSuccess() {
         this.strategy = CBQParallelResult.ParallelStrategy.PARTIAL_SUCCESS;
         return this;
      }

      public Mono<CBQParallelResult<T>> execute() {
         long startTime = System.currentTimeMillis();

         return Mono.deferContextual(ctx -> {
            List<Mono<CBQResponse<T>>> contextualRequests = new ArrayList<>();
            for (Mono<CBQResponse<T>> req : requests) {
               contextualRequests.add(req.contextWrite(ctx));
            }

            Mono<CBQParallelResult<T>> result;
            switch (strategy) {
               case FAIL_FAST:
                  result = executeFailFast(contextualRequests, startTime);
                  break;
               case PARTIAL_SUCCESS:
                  result = executePartialSuccess(contextualRequests, startTime);
                  break;
               case WAIT_ALL:
               default:
                  result = executeWaitAll(contextualRequests, startTime);
                  break;
            }
            return result.contextWrite(ctx);
         });
      }

      private Mono<CBQParallelResult<T>> executeWaitAll(List<Mono<CBQResponse<T>>> contextualRequests, long startTime) {
         return Mono.zip(contextualRequests, objects -> {
                    List<CBQResponse<T>> responses = new ArrayList<>();
                    for (Object obj : objects) {
                       responses.add((CBQResponse<T>) obj);
                    }
                    return responses;
                 })
                 .map(responses ->
                         CBQParallelResult.<T>builder()
                                 .responses(responses)
                                 .totalDurationMs(System.currentTimeMillis() - startTime)
                                 .strategy(strategy)
                                 .build()
                 ).subscribeOn(client.parallelScheduler);
      }

      private Mono<CBQParallelResult<T>> executeFailFast(List<Mono<CBQResponse<T>>> contextualRequests, long startTime) {
         return Flux.merge(contextualRequests)
                 .collectList()
                 .map(list -> CBQParallelResult.<T>builder()
                         .responses(list)
                         .totalDurationMs(System.currentTimeMillis() - startTime)
                         .strategy(strategy)
                         .build())
                 .subscribeOn(client.parallelScheduler);
      }

      private Mono<CBQParallelResult<T>> executePartialSuccess(List<Mono<CBQResponse<T>>> contextualRequests, long startTime) {
         return Flux.fromIterable(contextualRequests)
                 .flatMap(mono -> mono
                         .map(resp -> Tuples.of(true, (Object) resp))
                         .onErrorResume(e -> Mono.just(Tuples.of(false, (Object) e)))
                 )
                 .collectList()
                 .map(results -> {
                    List<CBQResponse<T>> responses = new ArrayList<>();
                    Map<Integer, Throwable> errors = new HashMap<>();
                    for (int i = 0; i < results.size(); i++) {
                       Tuple2<Boolean, Object> result = results.get(i);
                       if (result.getT1()) {
                          responses.add((CBQResponse<T>) result.getT2());
                       } else {
                          errors.put(i, (Throwable) result.getT2());
                       }
                    }
                    return CBQParallelResult.<T>builder()
                            .responses(responses)
                            .errors(errors)
                            .totalDurationMs(System.currentTimeMillis() - startTime)
                            .strategy(strategy)
                            .build();
                 })
                 .subscribeOn(client.parallelScheduler);
      }
   }

   public static class SequenceBuilder {
      private final List<Function<Object, Mono<?>>> steps = new ArrayList<>();

      public <T> SequenceBuilder then(Supplier<Mono<CBQResponse<T>>> step) {
         steps.add(prev -> step.get());
         return this;
      }

      public <I, O> SequenceBuilder then(Function<I, Mono<CBQResponse<O>>> step) {
         steps.add(prev -> step.apply((I) prev));
         return this;
      }

      @SuppressWarnings("unchecked")
      public <T> Mono<T> execute() {
         if (steps.isEmpty()) return Mono.empty();

         Mono<Object> chain = steps.get(0).apply(null)
                 .map(resp -> ((CBQResponse<?>) resp).getBody());

         for (int i = 1; i < steps.size(); i++) {
            final int idx = i;
            chain = chain.flatMap(prev ->
                    (Mono<Object>) steps.get(idx).apply(prev)
                            .map(resp -> ((CBQResponse<?>) resp).getBody()));
         }

         return (Mono<T>) chain;
      }
   }

   public void shutdown() {
      if (loggingService != null) loggingService.shutdown();
      if (parallelScheduler != null) parallelScheduler.dispose();
   }

}
