package com.cbq.restclient.config;

import com.cbq.restclient.filter.ErrorMapper;
import com.cbq.restclient.filter.RequestFilter;
import com.cbq.restclient.filter.ResponseFilter;
import lombok.Getter;

import java.util.*;
import java.util.function.Consumer;

public class CBQRestClientConfig {

    private String name;
    @Getter
    private String baseUrl;
    @Getter
    private Map<String, String> defaultHeaders = new LinkedHashMap<>();

    @Getter
    private TimeoutConfig timeouts = TimeoutConfig.defaults();
    @Getter
    private SslConfig ssl = SslConfig.disabled();
    @Getter
    private ResilienceConfig resilience = ResilienceConfig.disabled();
    @Getter
    private LoggingConfig logging = LoggingConfig.disabled();
    @Getter
    private EmailNotifierConfig emailNotifier = EmailNotifierConfig.disabled();
    @Getter
    private TracingConfig tracing = TracingConfig.defaults();
    @Getter
    private MetricsConfig metrics = MetricsConfig.disabled();

    @Getter
    private List<RequestFilter> requestFilters = new ArrayList<>();
    @Getter
    private List<ResponseFilter> responseFilters = new ArrayList<>();
    @Getter
    private List<ErrorMapper> errorMappers = new ArrayList<>();

    private CBQRestClientConfig() {}

    public static CBQRestClientConfig create() {
        return new CBQRestClientConfig();
    }

    public static CBQRestClientConfig create(String name) {
        CBQRestClientConfig config = new CBQRestClientConfig();
        config.name = name;
        return config;
    }

    public CBQRestClientConfig name(String name) {
        this.name = name;
        return this;
    }

    public CBQRestClientConfig baseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
        return this;
    }

    public CBQRestClientConfig header(String name, String value) {
        this.defaultHeaders.put(name, value);
        return this;
    }

    public CBQRestClientConfig headers(Consumer<Map<String, String>> headersConsumer) {
        headersConsumer.accept(this.defaultHeaders);
        return this;
    }

    public CBQRestClientConfig timeouts(TimeoutConfig config) {
        this.timeouts = config;
        return this;
    }

    public CBQRestClientConfig timeouts(Consumer<TimeoutConfig> configurer) {
        configurer.accept(this.timeouts);
        return this;
    }

    public CBQRestClientConfig ssl(SslConfig config) {
        this.ssl = config;
        return this;
    }

    public CBQRestClientConfig resilience(ResilienceConfig config) {
        this.resilience = config;
        return this;
    }

    public CBQRestClientConfig logging(LoggingConfig config) {
        this.logging = config;
        return this;
    }

    public CBQRestClientConfig emailNotifier(EmailNotifierConfig config) {
        this.emailNotifier = config;
        return this;
    }

    public CBQRestClientConfig tracing(TracingConfig config) {
        this.tracing = config;
        return this;
    }

    public CBQRestClientConfig metrics(MetricsConfig config) {
        this.metrics = config;
        return this;
    }

    public CBQRestClientConfig metricsEnabled(boolean enabled) {
        this.metrics = enabled ? MetricsConfig.defaults() : MetricsConfig.disabled();
        return this;
    }

    public CBQRestClientConfig tracingEnabled(boolean enabled) {
        this.tracing = enabled ? TracingConfig.defaults() : TracingConfig.disabled();
        return this;
    }

    public CBQRestClientConfig addRequestFilter(RequestFilter filter) {
        this.requestFilters.add(filter);
        return this;
    }

    public CBQRestClientConfig addResponseFilter(ResponseFilter filter) {
        this.responseFilters.add(filter);
        return this;
    }

    public CBQRestClientConfig addErrorMapper(ErrorMapper mapper) {
        this.errorMappers.add(mapper);
        return this;
    }

    public String getName() { return name != null ? name : "cbq-client-" + UUID.randomUUID().toString().substring(0, 8); }

    public CBQRestClientConfig copy() {
        CBQRestClientConfig copy = new CBQRestClientConfig();
        copy.name = this.name;
        copy.baseUrl = this.baseUrl;
        copy.defaultHeaders = new LinkedHashMap<>(this.defaultHeaders);
        copy.timeouts = this.timeouts.copy();
        copy.ssl = this.ssl;
        copy.resilience = this.resilience;
        copy.logging = this.logging;
        copy.emailNotifier = this.emailNotifier;
        copy.tracing = this.tracing;
        copy.metrics = this.metrics;
        copy.requestFilters = new ArrayList<>(this.requestFilters);
        copy.responseFilters = new ArrayList<>(this.responseFilters);
        copy.errorMappers = new ArrayList<>(this.errorMappers);
        return copy;
    }
}
