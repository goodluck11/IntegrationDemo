package com.cbq.restclient.v2;

@FunctionalInterface
public interface FallbackV2<T> {
   T apply(Throwable t);
}
