package com.cbq.restclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CbqRestClientApplication {

   public static void main(String[] args) {
      SpringApplication.run(CbqRestClientApplication.class, args);
   }
}
