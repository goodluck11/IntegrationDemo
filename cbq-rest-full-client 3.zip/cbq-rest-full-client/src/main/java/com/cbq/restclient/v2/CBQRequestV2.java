package com.cbq.restclient.v2;

import com.cbq.restclient.config.RequestOverride;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ServerErrorException;
import reactor.core.publisher.Mono;

import java.util.function.Consumer;

@RequiredArgsConstructor
public class CBQRequestV2 {
   private final CBQRestClientV2 client;
   private final WebClient.RequestBodySpec spec;

   private RequestOverrideV2 override = RequestOverrideV2.none();
   private FallbackV2<?> fallback;

   public static CBQRequestV2 create(CBQRestClientV2 client, HttpMethod method) {
      return new CBQRequestV2(client, client.getWebClient().method(method));
   }


   public CBQRequestV2 header(String k, String v) {
      spec.header(k, v);
      return this;
   }

   public CBQRequestV2 bodyValue(Object body) {
      spec.bodyValue(body);
      return this;
   }

   public CBQRequestV2 override(Consumer<RequestOverrideV2.RequestOverrideV2Builder> c) {
      RequestOverrideV2.RequestOverrideV2Builder b = RequestOverrideV2.builder();
      c.accept(b);
      this.override = b.build();
      return this;
   }

   public <T> CBQRequestV2 fallback(FallbackV2<T> fallback) {
      this.fallback = fallback;
      return this;
   }

   public <T> Mono<T> retrieve(Class<T> type) {
      return Mono.deferContextual(ctx -> {
         Mono<T> mono =
                 spec.retrieve()
                         .onStatus(
                                 HttpStatus::is4xxClientError,
                                 r -> r.bodyToMono(String.class)
                                         .map(b -> new ClientErrorExceptionV2(r.rawStatusCode(), b))
                         )
                         .onStatus(
                                 HttpStatus::is5xxServerError,
                                 r -> r.bodyToMono(String.class)
                                         .map(b -> new ServerErrorExceptionV2(r.rawStatusCode(), b))
                         )
                         .bodyToMono(type);

         Mono<T> resilient =
                 ResiliencePipelineV2.decorate(
                         mono,
                         client.getResilienceConfig(),
                         override
                 );

         if (fallback != null) {
            resilient = resilient.onErrorResume(t -> Mono.just((T) fallback.apply(t)));
         }

         return resilient;
      });
   }
}
