package com.cbq.restclient.ssl;

import com.cbq.restclient.config.SslConfig;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public final class SslContextFactory {
   private static final Logger log = LoggerFactory.getLogger(SslContextFactory.class);

   private SslContextFactory() {
   }

   public static SslContext create(SslConfig config) {
      if (!config.isEnabled()) return null;

      try {
         if (config.isInsecure()) {
            log.warn("Creating INSECURE SSL context - DO NOT USE IN PRODUCTION");
            return SslContextBuilder.forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE)
                    .build();
         }

         if (config.getCertificatePath() != null) {
            return createFromCertificate(config.getCertificatePath());
         }

         if (config.getKeystorePath() != null) {
            return createFromKeystore(config.getKeystorePath(),
                    config.getKeystorePassword(), config.getKeystoreType());
         }

         return SslContextBuilder.forClient().build();

      } catch (Exception e) {
         log.error("Failed to create SSL context", e);
         throw new RuntimeException("SSL configuration failed", e);
      }
   }

   private static SslContext createFromCertificate(String certPath) throws CertificateException, IOException {
      CertificateFactory cf = CertificateFactory.getInstance("X.509");
      try (InputStream is = new FileInputStream(certPath)) {
         X509Certificate cert = (X509Certificate) cf.generateCertificate(is);
         return SslContextBuilder.forClient()
                 .trustManager(cert)
                 .build();
      }
   }

   private static SslContext createFromKeystore(String keystorePath,
                                                String password,
                                                String type) throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException {
      KeyStore keyStore = KeyStore.getInstance(type);
      try (InputStream is = new FileInputStream(keystorePath)) {
         keyStore.load(is, password != null ? password.toCharArray() : null);
      }

      TrustManagerFactory tmf = TrustManagerFactory.getInstance(
              TrustManagerFactory.getDefaultAlgorithm());
      tmf.init(keyStore);

      return SslContextBuilder.forClient()
              .trustManager(tmf)
              .build();
   }
}
