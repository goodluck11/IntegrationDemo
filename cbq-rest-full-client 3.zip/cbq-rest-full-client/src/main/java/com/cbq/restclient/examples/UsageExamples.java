package com.cbq.restclient.examples;

import com.cbq.restclient.config.*;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQRestClientBuilder;
import com.cbq.restclient.filter.*;
import com.cbq.restclient.model.*;

import java.time.Duration;

public class UsageExamples {

    public static CBQRestClient createProductionClient() {
        return CBQRestClientBuilder.builder("payment-service")
                .baseUrl("https://api.service.com")
                .timeouts(TimeoutConfig.defaults()
                        .connection(Duration.ofSeconds(3))
                        .read(Duration.ofSeconds(5))
                        .write(Duration.ofSeconds(5))
                        .response(Duration.ofSeconds(10)))
                .headers(h -> {
                    h.put("X-App", "cbq");
                    h.put("X-Env", "prod");
                })
                .ssl(SslConfig.custom()
                        .certificatePath("/certs/service.pem")
                        .handshakeTimeout(Duration.ofSeconds(10)))
                .resilience(ResilienceConfig.custom()
                        .retry(ResilienceConfig.RetryConfig.custom()
                                .maxAttempts(3)
                                .backoff(ResilienceConfig.BackoffStrategy.EXPONENTIAL_WITH_JITTER))
                        .circuitBreaker(ResilienceConfig.CircuitBreakerConfig.custom()
                                .windowSize(50)
                                .minCalls(10)
                                .failureRate(50)
                                .openStateWait(Duration.ofSeconds(30)))
                        .rateLimiter(ResilienceConfig.RateLimiterConfig.custom()
                                .limitForPeriod(100)
                                .refreshPeriod(Duration.ofSeconds(1)))
                        .bulkhead(ResilienceConfig.BulkheadConfig.custom()
                                .maxConcurrentCalls(50)))
                .logging(LoggingConfig.custom()
                        .logAll()
                        .maskFields("password", "token")
                        .maxBodySize(10_000))
                .emailNotifier(EmailNotifierConfig.custom()
                        .async(true)
                        .rateLimit(5, Duration.ofMinutes(1)))
                .metricsEnabled(true)
                .tracingEnabled(true)
                .build();
    }

    public static void requestOverrides(CBQRestClient client) {

        client.post()
                .uri("/slow-endpoint")
                .override(o -> o
                        .responseTimeout(Duration.ofMinutes(2))
                        .disableRetry())
                .retrieve(String.class)
                .block();

        client.get()
                .uri("/health")
                .override(RequestOverride::disableAllResilience)
                .retrieve(String.class)
                .block();
    }

    public static void errorMapping(CBQRestClient client) {
        client.get()
                .uri("/users/123")
                .onStatus(status -> status.value() == 404,
                        ctx -> new RuntimeException("Not found: " + ctx.getUri()))
                .onStatus(status -> status.is5xxServerError(),
                        ctx -> new RuntimeException("Server error"))
                .retrieve(Object.class)
                .block();
    }

    public static void emailOnError(CBQRestClient client) {
        client.post()
                .uri("/payments")
                .bodyValue("{}")
                .override(o -> o.disableRetry())
                .onErrorNotify(mail -> mail
                        .to("ops@company.com")
                        .subject("Payment Failed")
                        .addContext("time", System.currentTimeMillis()))
                .retrieve(Object.class)
                .block();
    }

    public static void parallelExecution(CBQRestClient client) {

        CBQParallelResult<Object> result = client.parallel(
                client.get().uri("/a").retrieve(Object.class),
                client.get().uri("/b").retrieve(Object.class)
        ).waitAll().execute().block();

        CBQParallelResult<Object> partial = client.parallel(
                client.get().uri("/ok").retrieve(Object.class),
                client.get().uri("/fail").retrieve(Object.class)
        ).partialSuccess().execute().block();
    }

    public static void sequentialChaining(CBQRestClient client) {
        client.sequence()
                .then(() -> client.get().uri("/step1").retrieve(String.class))
                .then((String prev) -> client.get().uri("/step2?data=" + prev).retrieve(String.class))
                .<String>execute()
                .block();
    }

    public static CBQRestClient clientWithFilters() {
        return CBQRestClientBuilder.builder()
                .baseUrl("https://api.example.com")
                .addRequestFilter(Filters.bearerToken("token"))
                .addRequestFilter(Filters.auditLog("my-app"))
                .addResponseFilter(Filters.slowResponseLog(1000))
                .addResponseFilter(Filters.errorLog())
                .build();
    }
}
