package com.cbq.restclient.v2;

import io.github.resilience4j.bulkhead.Bulkhead;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class BulkheadConfigV2 {
   Bulkhead bulkhead;
   boolean isolateScheduler;
   int schedulerThreads;

   public static BulkheadConfigV2 disabled() {
      return BulkheadConfigV2.builder().build();
   }
}
