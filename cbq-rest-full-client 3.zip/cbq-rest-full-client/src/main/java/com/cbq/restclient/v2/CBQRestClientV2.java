package com.cbq.restclient.v2;

import lombok.Getter;
import org.springframework.http.HttpMethod;
import org.springframework.web.reactive.function.client.WebClient;

@Getter
public final class CBQRestClientV2 {

   private final WebClient webClient;
   private final TimeoutConfigV2 timeoutConfig;
   private final ResilienceConfigV2 resilienceConfig;
   private final LoggingConfigV2 loggingConfig;
   private final EmailConfigV2 emailConfig;
   private final ObservabilityConfigV2 observabilityConfig;

   CBQRestClientV2(
           WebClient webClient,
           TimeoutConfigV2 timeoutConfig,
           ResilienceConfigV2 resilienceConfig,
           LoggingConfigV2 loggingConfig,
           EmailConfigV2 emailConfig,
           ObservabilityConfigV2 observabilityConfig
   ) {
      this.webClient = webClient;
      this.timeoutConfig = timeoutConfig;
      this.resilienceConfig = resilienceConfig;
      this.loggingConfig = loggingConfig;
      this.emailConfig = emailConfig;
      this.observabilityConfig = observabilityConfig;
   }

   public static CBQRestClientBuilderV2 builder() {
      return new CBQRestClientBuilderV2();
   }

   public CBQRequestV2 get() {
      return CBQRequestV2.create(this, HttpMethod.GET);
   }

   public CBQRequestV2 post() {
      return CBQRequestV2.create(this, HttpMethod.POST);
   }

   public CBQRequestV2 put() {
      return CBQRequestV2.create(this, HttpMethod.PUT);
   }

   public CBQRequestV2 delete() {
      return CBQRequestV2.create(this, HttpMethod.DELETE);
   }

   public static CBQParallelV2 parallel(CBQRequestV2... requests) {
      return CBQParallelV2.of(requests);
   }

   public CBQSequenceV2 sequence() {
      return new CBQSequenceV2();
   }
}
