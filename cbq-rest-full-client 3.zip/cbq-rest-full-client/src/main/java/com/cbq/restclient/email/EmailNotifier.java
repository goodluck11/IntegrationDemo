package com.cbq.restclient.email;

import com.cbq.restclient.config.EmailNotifierConfig;
import com.cbq.restclient.model.EmailNotification;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.TaskExecutor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import javax.mail.internet.MimeMessage;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class EmailNotifier {
   private static final Logger log = LoggerFactory.getLogger(EmailNotifier.class);

   private final EmailNotifierConfig config;
   private final JavaMailSender mailSender;
   private final Scheduler emailScheduler;

   private final ConcurrentLinkedQueue<Instant> emailTimestamps = new ConcurrentLinkedQueue<>();

   private final AtomicInteger consecutiveFailures = new AtomicInteger(0);
   private final AtomicLong circuitOpenedAt = new AtomicLong(0);

   public EmailNotifier(EmailNotifierConfig config,
                        JavaMailSender springMailSender,
                        TaskExecutor taskExecutor) {
      this.config = config;

      if (springMailSender != null) {
         log.info("Using Spring-configured JavaMailSender for email notifications");
         this.mailSender = springMailSender;
      } else if (config.getHost() != null) {
         log.info("Creating JavaMailSender from EmailNotifierConfig");
         this.mailSender = createMailSender();
      } else {
         this.mailSender = null;
      }

      if (taskExecutor != null) {
         this.emailScheduler = Schedulers.fromExecutor(taskExecutor);
      } else {
         this.emailScheduler = Schedulers.newBoundedElastic(4, 100, "cbq-email-fallback");
      }
   }

   public void notify(ErrorEvent event, EmailNotification notification) {
      if (!config.isEnabled() || mailSender == null) {
         log.debug("Email notifications disabled, skipping");
         return;
      }

      sendNotificationMono(event, notification)
              .subscribeOn(emailScheduler)
              .subscribe(
                      null,
                      error -> log.error("Failed to send error notification email for requestId={}: {}",
                              event.getRequestId(), error.getMessage())
              );
   }

   private Mono<Void> sendNotificationMono(ErrorEvent event, EmailNotification notification) {
      return Mono.defer(() -> {
                 if (isCircuitOpen()) {
                    return Mono.error(new RuntimeException("Email circuit breaker is open"));
                 }

                 if (isRateLimited()) {
                    return Mono.error(new RuntimeException("Email rate limit exceeded"));
                 }

                 return Mono.fromCallable(() -> {
                    MimeMessage message = mailSender.createMimeMessage();
                    MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

                    String from = notification.getFrom() != null
                            ? notification.getFrom()
                            : config.getDefaultFrom();
                    if (from != null) helper.setFrom(from);

                    List<String> to = notification.getTo().isEmpty()
                            ? config.getDefaultTo()
                            : notification.getTo();
                    if (to.isEmpty()) {
                       log.warn("No email recipients configured, skipping notification");
                       return null;
                    }
                    helper.setTo(to.toArray(new String[0]));

                    String subject = notification.getSubject() != null
                            ? notification.getSubject()
                            : config.getDefaultSubject();
                    helper.setSubject(subject);

                    String body = notification.getBody() != null
                            ? notification.getBody()
                            : formatErrorBody(event, notification.getContext());
                    helper.setText(body, notification.isHtml());

                    helper.setSentDate(new Date());

                    mailSender.send(message);
                    return message;
                 });
              })
              .subscribeOn(emailScheduler)
              .retryWhen(reactor.util.retry.Retry.backoff(2, Duration.ofSeconds(1))
                      .filter(throwable -> !(throwable instanceof RuntimeException &&
                              (throwable.getMessage().contains("circuit breaker") ||
                                      throwable.getMessage().contains("rate limit"))))
                      .doBeforeRetry(retrySignal -> log.warn("Retrying email notification send for requestId={}, attempt={}",
                              event.getRequestId(), retrySignal.totalRetries() + 1))
              )
              .doOnSuccess(msg -> {
                 if (msg != null) {
                    recordEmailSent();
                    consecutiveFailures.set(0);
                    log.info("Error notification email sent for requestId={}", event.getRequestId());
                 }
              })
              .doOnError(error -> {
                 if (!(error instanceof RuntimeException &&
                         (error.getMessage().contains("circuit breaker") ||
                                 error.getMessage().contains("rate limit")))) {
                    handleSendFailure();
                 }
              })
              .then();
   }

   private boolean isRateLimited() {

      Instant cutoff = Instant.now().minus(config.getRateLimitWindow());
      while (!emailTimestamps.isEmpty() && emailTimestamps.peek().isBefore(cutoff)) {
         emailTimestamps.poll();
      }

      return emailTimestamps.size() >= config.getMaxEmailsPerWindow();
   }

   private void recordEmailSent() {
      emailTimestamps.offer(Instant.now());
   }

   private boolean isCircuitOpen() {
      if (!config.isCircuitBreakerEnabled()) return false;

      long openedAt = circuitOpenedAt.get();
      if (openedAt == 0) return false;

      Duration sinceOpened = Duration.between(Instant.ofEpochMilli(openedAt), Instant.now());
      if (sinceOpened.compareTo(config.getCircuitBreakerResetTime()) > 0) {

         circuitOpenedAt.set(0);
         log.info("Email circuit breaker transitioning to half-open");
         return false;
      }

      return true;
   }

   private void handleSendFailure() {
      if (!config.isCircuitBreakerEnabled()) return;

      int failures = consecutiveFailures.incrementAndGet();
      if (failures >= config.getCircuitBreakerThreshold()) {
         circuitOpenedAt.set(System.currentTimeMillis());
         log.warn("Email circuit breaker opened after {} consecutive failures", failures);
      }
   }

   private String formatErrorBody(ErrorEvent event, Map<String, Object> context) {
      StringBuilder sb = new StringBuilder();
      sb.append("═══════════════════════════════════════════════════════════════\n");
      sb.append("CBQ REST CLIENT ERROR NOTIFICATION\n");
      sb.append("═══════════════════════════════════════════════════════════════\n\n");

      sb.append("Request Details:\n");
      sb.append("───────────────────────────────────────────────────────────────\n");
      sb.append("Request ID: ").append(event.getRequestId()).append("\n");
      sb.append("Correlation ID: ").append(event.getCorrelationId()).append("\n");
      sb.append("Method: ").append(event.getMethod()).append("\n");
      sb.append("URI: ").append(event.getUri()).append("\n");
      sb.append("Timestamp: ").append(new Date()).append("\n\n");

      sb.append("Error Details:\n");
      sb.append("───────────────────────────────────────────────────────────────\n");
      sb.append("Exception: ").append(event.getError().getClass().getName()).append("\n");
      sb.append("Message: ").append(event.getError().getMessage()).append("\n\n");

      if (context != null && !context.isEmpty()) {
         sb.append("Context:\n");
         sb.append("───────────────────────────────────────────────────────────────\n");
         context.forEach((k, v) -> sb.append(k).append(": ").append(v).append("\n"));
      }

      return sb.toString();
   }

   private JavaMailSender createMailSender() {
      JavaMailSenderImpl sender = new JavaMailSenderImpl();
      sender.setHost(config.getHost());
      sender.setPort(config.getPort());
      sender.setUsername(config.getUsername());
      sender.setPassword(config.getPassword());

      Properties props = sender.getJavaMailProperties();
      props.put("mail.transport.protocol", "smtp");
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.connectiontimeout", "5000");
      props.put("mail.smtp.timeout", "5000");

      if (config.isStartTls()) {
         props.put("mail.smtp.starttls.enable", "true");
      }
      if (config.isSsl()) {
         props.put("mail.smtp.ssl.enable", "true");
      }

      return sender;
   }

   @Getter
   public static class ErrorEvent {
      private final String requestId;
      private final String correlationId;
      private final String method;
      private final String uri;
      private final Throwable error;
      private final long durationMs;

      public ErrorEvent(String requestId, String correlationId, String method,
                        String uri, Throwable error, long durationMs) {
         this.requestId = requestId;
         this.correlationId = correlationId;
         this.method = method;
         this.uri = uri;
         this.error = error;
         this.durationMs = durationMs;
      }

   }
}
