package com.cbq.restclient.examples;

import com.cbq.restclient.config.SslConfig;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQRestClientBuilder;
import com.cbq.restclient.core.CBQRestClientPool;
import com.cbq.restclient.filter.RequestFilter;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;

import javax.annotation.PreDestroy;
import java.util.HashMap;
import java.util.Map;

/**
 * Examples for advanced configuration, multi-client setup, and dynamic client management.
 */
public class AdvancedConfigurationExamples {

    // --- 1. Shutdown Patterns ---

    @Configuration
    public static class ShutdownConfig {

        // Way 1: @Bean(destroyMethod = "shutdown")
        @Bean(destroyMethod = "shutdown")
        public CBQRestClient clientWithDestroyMethod() {
            return CBQRestClientBuilder.builder("destroy-method-client")
                    .baseUrl("https://api.example.com")
                    .build();
        }

        // Way 2: implements DisposableBean
        @Bean
        public ClientWrapper disposableClientWrapper(@org.springframework.beans.factory.annotation.Qualifier("bankAClient") CBQRestClient client) {
            return new ClientWrapper(client);
        }

        public static class ClientWrapper implements DisposableBean {
            private final CBQRestClient client;
            public ClientWrapper(CBQRestClient client) { this.client = client; }
            @Override
            public void destroy() {
                client.shutdown();
            }
        }

        // Way 3: @PreDestroy
        @Bean
        public PreDestroyClient preDestroyClient() {
            return new PreDestroyClient();
        }

        public static class PreDestroyClient {
            private final CBQRestClient client = CBQRestClientBuilder.builder("pre-destroy-client").build();
            @PreDestroy
            public void cleanUp() {
                client.shutdown();
            }
        }
    }

    // --- 2. Multiple Clients Configuration ---

    @Configuration
    public static class MultiClientConfig {
        @Bean
        public CBQRestClient bankAClient() {
            return CBQRestClientBuilder.builder("bank-a")
                    .baseUrl("https://api.banka.com")
                    .build();
        }

        @Bean
        public CBQRestClient bankBClient() {
            return CBQRestClientBuilder.builder("bank-b")
                    .baseUrl("https://api.bankb.com")
                    .ssl(SslConfig.disabled()) // Disable SSL for internal Bank B
                    .build();
        }
    }

    // --- 3. Dynamic Client Management (Agent-based) ---

    public static class DynamicClientManager {
        private final Map<String, String[]> credentialsMap = new HashMap<>(); // agent -> [user, pass]
        private final CBQRestClientPool pool;

        public DynamicClientManager(CBQRestClientPool pool) {
            this.pool = pool;
            credentialsMap.put("Mobile-App", new String[]{"mob_user", "mob_pass"});
            credentialsMap.put("Web-Portal", new String[]{"web_user", "web_pass"});
        }

        public Mono<String> performActionForAgent(String userAgent) {
            String[] creds = credentialsMap.getOrDefault(userAgent, new String[]{"default", "default"});
            
            // Get or create a client from the pool with custom settings for this agent
            CBQRestClient client = pool.getOrCreate(userAgent, CBQRestClientPool.DEFAULT_PROFILE);

            return client.get()
                    .uri("/action")
                    .header("User-Agent", userAgent)
                    .header("X-Auth-User", creds[0])
                    .header("X-Auth-Pass", creds[1])
                    .retrieve(String.class)
                    .map(com.cbq.restclient.model.CBQResponse::getBody);
        }
    }

    // --- 4. RequestId as CorrelationId ---

    public static void requestIdAsCorrelationId(CBQRestClient client) {
        client.get()
                .uri("/users/123")
                // A RequestFilter can be used to set the correlationId header to the requestId
                .headers(h -> {
                    // This is usually done in a RequestFilter globally
                })
                .retrieve(String.class);
    }
    
    public static RequestFilter requestIdToCorrelationFilter() {
        return context -> {
            // Set X-Correlation-Id header to the current requestId
            context.getHeaders().set("X-Correlation-Id", context.getRequestId());
            return Mono.just(context);
        };
    }
}
