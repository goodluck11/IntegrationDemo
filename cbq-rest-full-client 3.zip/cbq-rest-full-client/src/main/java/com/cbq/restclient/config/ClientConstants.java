package com.cbq.restclient.config;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/*
 * @created by 31/01/2026  - 10:23
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ClientConstants {
   public static final String REQUEST_ID_HEADER = "X-Correlation-Id";
   public static final String CID_KEY = "cid";
   public static final String RID_KEY = "rid";
}
