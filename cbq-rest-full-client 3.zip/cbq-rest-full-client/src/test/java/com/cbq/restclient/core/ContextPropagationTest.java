package com.cbq.restclient.core;

import com.cbq.restclient.model.CBQParallelResult;
import com.cbq.restclient.model.CBQResponse;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.context.Context;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ContextPropagationTest {

    @Test
    void testContextPropagationInParallel() {
        CBQRestClient client = CBQRestClientBuilder.builder()
                .baseUrl("https://httpbin.org")
                .tracingEnabled(true)
                .build();

        String correlationId = "test-correlation-id";

        Mono<CBQParallelResult<String>> parallelMono = Mono.defer(() -> 
            client.parallel(
                client.get()
                        .uri("/get")
                        .retrieve(String.class),
                client.get().uri("/get").retrieve(String.class)
            ).waitAll().execute()
        );

        StepVerifier.create(parallelMono.contextWrite(Context.of("cid", correlationId)))
                .assertNext(result -> {
                    assertNotNull(result);
                    assertEquals(2, result.size());
                    for (CBQResponse<String> response : result.getResponses()) {
                        System.out.println("[DEBUG_LOG] Parallel Response Correlation ID: " + response.getCorrelationId());
                        assertEquals(correlationId, response.getCorrelationId(), "Correlation ID should be propagated from Reactor Context in Parallel");
                    }
                })
                .verifyComplete();
    }

    @Test
    void testContextPropagationInWorkflow() {
        CBQRestClient client = CBQRestClientBuilder.builder()
                .baseUrl("https://httpbin.org")
                .tracingEnabled(true)
                .build();

        String correlationId = "workflow-correlation-id";

        // Step 1 sets the correlation ID header
        // Step 2 should have it automatically
        Mono<CBQResponse<String>> workflowMono = Mono.defer(() ->
            CBQWorkflow.startWith(() -> client.get()
                            .uri("/get")
                            .header("X-Correlation-ID", correlationId)
                            .retrieve(String.class))
                    .stepMono(prev -> client.get()
                            .uri("/get")
                            .retrieve(String.class))
                    .executeAsync()
                    .contextWrite(Context.of("cid", correlationId))
        );

        StepVerifier.create(workflowMono)
                .assertNext(response -> {
                    assertNotNull(response);
                    System.out.println("[DEBUG_LOG] Workflow Step 2 Correlation ID: " + response.getCorrelationId());
                    System.out.println("[DEBUG_LOG] Workflow Step 2 Request ID: " + response.getRequestId());
                    assertEquals(correlationId, response.getCorrelationId(), "Correlation ID should be propagated from Step 1 to Step 2");
                })
                .verifyComplete();
    }
}
