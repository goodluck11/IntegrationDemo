# Running CBQ Rest Client as a SpringBoot Application

## Quick Start

### Run the Application
```bash
mvn spring-boot:run
```

Or build and run the JAR:
```bash
mvn clean package
java -jar target/cbq-rest-client-2.0.0.jar
```

## Available Endpoints

Once running on `http://localhost:8080`:

### 1. Health Check
```bash
curl http://localhost:8080/api/demo/health
```

### 2. Simple Request
```bash
curl http://localhost:8080/api/demo/simple
```

### 3. Workflow Example (demonstrates correlation ID propagation)
```bash
# Auto-generated correlation ID
curl http://localhost:8080/api/demo/workflow

# Custom correlation ID
curl "http://localhost:8080/api/demo/workflow?correlationId=my-custom-id-123"
```

### 4. Workflow with Fire-and-Forget
```bash
curl http://localhost:8080/api/demo/workflow-with-fire-and-forget
```

## Testing Correlation ID Propagation

To verify correlation IDs are propagating correctly:

```bash
# Make a request with a custom correlation ID
curl "http://localhost:8080/api/demo/workflow?correlationId=test-correlation-xyz"

# Check application logs to see the same correlation ID used across all steps
```

## Configuration

Edit `src/main/resources/application.properties` to customize:
- Server port
- Logging levels
- Other Spring Boot settings

Edit `CBQRestClientAutoConfiguration.java` to customize the CBQRestClient:
- Base URL
- Retry settings
- Circuit breaker
- Tracing
- Metrics

## Main Classes

- **Application**: `com.cbq.restclient.CbqRestClientApplication`
- **Controller**: `com.cbq.restclient.controller.DemoController`
- **Configuration**: `com.cbq.restclient.autoconfigure.CBQRestClientAutoConfiguration`

## What This Demonstrates

1. **Simple HTTP requests** using CBQRestClient
2. **Workflow chaining** with multiple sequential steps
3. **Correlation ID propagation** across workflow steps
4. **Fire-and-forget tasks** in workflows
5. **Spring Boot integration** with auto-configuration
