package io.reactive.me.playground.repository;

import io.r2dbc.spi.Row;
import io.r2dbc.spi.RowMetadata;
import io.reactive.me.playground.model.Page;
import io.reactive.me.playground.model.Post;
import lombok.RequiredArgsConstructor;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Objects;

/*
 * @created by 06/02/2026  - 05:26
 * @project ReactivePlayground
 * @author Goodluck
 */

@Repository
@RequiredArgsConstructor
public class PostRepository {
   private final DatabaseClient databaseClient;

   public Flux<Post> findAll() {
      return databaseClient
              .sql("SELECT * FROM posts")
              .map(this::mapRowToPost)
              .all();
   }

   public Mono<Page<Post>> getPosts(int size, Long cursor) {
      var limit = size > 0 ? size : 10;
      var fetchLimit = limit + 1;
      var hasCursor = cursor != null && cursor > 0;
      var query = hasCursor ?
              "SELECT * FROM posts WHERE id > :cursor ORDER BY id ASC LIMIT :limit"
              : "SELECT * FROM posts ORDER BY id LIMIT :limit";

      var executeSpec = databaseClient.sql(query)
              .bind("limit", fetchLimit);

      if (hasCursor) {
         executeSpec = executeSpec.bind("cursor", cursor);
      }

      var all = executeSpec.map(this::mapRowToPost).all();

      return all.collectList()
              .map(posts -> {
                 var hasMore = posts.size() > limit;
                 var pageItems = hasMore ? posts.subList(0, limit) : posts;
                 var nextCursor = pageItems.isEmpty() ? null : pageItems.get(pageItems.size() - 1).id();
                 return new Page<>(nextCursor, hasMore, posts);
              });
   }

   public Mono<Long> count() {
      return databaseClient
              .sql("SELECT COUNT(*) FROM posts")
              .map(row -> Objects.requireNonNull(row.get(0, Long.class)))
              .one()
              .defaultIfEmpty(0L);
   }

   public Mono<Long> deleteAll() {
      return databaseClient.sql("DELETE FROM posts")
              .fetch()
              .rowsUpdated();
   }

   private Post mapRowToPost(Row row, RowMetadata metadata) {
      return new Post(
              row.get("id", Long.class),
              row.get("user_id", Long.class),
              row.get("title", String.class),
              row.get("body", String.class)
      );
   }
}
