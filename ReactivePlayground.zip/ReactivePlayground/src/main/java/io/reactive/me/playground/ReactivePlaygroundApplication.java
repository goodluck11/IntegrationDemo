package io.reactive.me.playground;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactivePlaygroundApplication {
   public static void main(String[] args) {
      SpringApplication.run(ReactivePlaygroundApplication.class, args);
   }

}
