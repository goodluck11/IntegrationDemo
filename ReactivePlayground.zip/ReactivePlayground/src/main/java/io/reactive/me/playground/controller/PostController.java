package io.reactive.me.playground.controller;

import io.reactive.me.playground.model.Page;
import io.reactive.me.playground.model.Post;
import io.reactive.me.playground.service.PostService;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/*
 * @created by 06/02/2026 - 06:01
 * @project ReactivePlayground
 * @author Goodluck
 */
@RestController
@RequestMapping("/")
@RequiredArgsConstructor
public class PostController {
   private final PostService postService;

   @PostConstruct
   public void init() {
      System.out.println("✅ PostController LOADED!");
   }

   @GetMapping("/posts")
   public Mono<Page<Post>> getPosts(
           @RequestParam(required = false) Long cursor,
           @RequestParam(defaultValue = "10") int limit) {
      return postService.findAll(limit, cursor);
   }

   @GetMapping("/posts/all")
   public Flux<Post> findAll() {
      return postService.findAll();
   }

   @DeleteMapping("/posts/delete-all")
   public Mono<Long> deleteAll() {
      return postService.deleteAll();
   }
}
