package io.reactive.me.playground.helper;

import io.r2dbc.spi.ConnectionFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.r2dbc.connection.init.ConnectionFactoryInitializer;
import org.springframework.r2dbc.connection.init.ResourceDatabasePopulator;

/*
 * @created by 06/02/2026  - 05:35
 * @project ReactivePlayground
 * @author Goodluck
 */
//@Configuration
public class DatabaseConfig {
//   @Bean
   public ConnectionFactoryInitializer initializer(ConnectionFactory connectionFactory) {
      var initializer = new ConnectionFactoryInitializer();
      initializer.setConnectionFactory(connectionFactory);

      var populator = new ResourceDatabasePopulator();
      populator.addScript(new ClassPathResource("schema.sql"));

      initializer.setDatabasePopulator(populator);
      return initializer;
   }
}
