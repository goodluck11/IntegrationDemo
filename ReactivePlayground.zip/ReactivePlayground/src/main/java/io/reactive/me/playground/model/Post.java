package io.reactive.me.playground.model;

/*
 * @created by 06/02/2026  - 05:21
 * @project ReactivePlayground
 * @author Goodluck
 */
public record Post(Long id, Long userId, String title, String body) {
}
