package io.reactive.me.playground.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

/*
 * @created by 06/02/2026  - 06:55
 * @project ReactivePlayground
 * @author Goodluck
 */
@Component
@Slf4j
public class LoggingWebFilter implements WebFilter {
   @Override
   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
      long startTime = System.currentTimeMillis();
      String path = exchange.getRequest().getPath().value();
      String method = exchange.getRequest().getMethod().name();

      return chain.filter(exchange)
              .doOnSuccess(aVoid -> {
                 long duration = System.currentTimeMillis() - startTime;
                 int status = exchange.getResponse().getStatusCode().value();
                 log.info("{} {} - {} ({}ms)", method, path, status, duration);
              })
              .doOnError(error ->
                      log.error("{} {} - Error: {}", method, path, error.getMessage())
              );
   }
}
