package io.reactive.me.playground.config;

import io.r2dbc.spi.ConnectionFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.r2dbc.core.DatabaseClient;

/*
 * @created by 06/02/2026  - 06:04
 * @project ReactivePlayground
 * @author Goodluck
 */
@Configuration
@Slf4j
public class DbConfig {
   @Bean
   public DatabaseClient databaseClient(ConnectionFactory connectionFactory) {
      return DatabaseClient.builder()
              .connectionFactory(connectionFactory)
              .build();
   }
}
