CREATE TABLE IF NOT EXISTS posts
(
    id         serial not null primary key,
    user_id    integer,
    title      varchar(255),
    body       TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON posts(user_id);
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at);