package com.cbq.logging;

import com.cbq.logging.config.LoggingConfig;
import com.cbq.logging.core.CbqLog;
import com.cbq.logging.mask.FieldMasker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class CbqLoggerTest {

    @BeforeEach
    void setUp() {
        LoggingConfig.reset();
    }

    @Test
    void shouldMaskCardNumberWithDefaultConfig() {
        LoggingConfig.custom()
            .maskField("cardNumber", 4)
            .apply();

        String masked = FieldMasker.mask("cardNumber", "4111111111111111");
        
        assertThat(masked).isEqualTo("4111********1111");
    }

    @Test
    void shouldFullyMaskCvv() {
        LoggingConfig.custom()
            .fullyMaskField("cvv")
            .apply();

        String masked = FieldMasker.mask("cvv", "123");
        
        assertThat(masked).startsWith("*");
        assertThat(masked).doesNotContain("1", "2", "3");
    }

    @Test
    void shouldExcludeFields() {
        LoggingConfig.custom()
            .excludeFields("debugData")
            .apply();

        String masked = FieldMasker.mask("debugData", "sensitive info");
        
        assertThat(masked).isEqualTo("[EXCLUDED]");
    }

    @Test
    void shouldUseCustomMaskSymbol() {
        LoggingConfig.custom()
            .maskSymbol('X')
            .maskField("password", 0)
            .apply();

        String masked = FieldMasker.mask("password", "secret123");
        
        assertThat(masked).contains("X");
        assertThat(masked).doesNotContain("*");
    }

    @Test
    void shouldMaskMapValues() {
        LoggingConfig.custom()
            .maskField("password", 0)
            .maskField("cardNumber", 4)
            .apply();

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("username", "john");
        data.put("password", "secret123");
        data.put("cardNumber", "4111111111111111");

        Map<String, Object> masked = FieldMasker.maskMap(data);

        assertThat(masked.get("username")).isEqualTo("john");
        assertThat(masked.get("password").toString()).doesNotContain("secret");
        assertThat(masked.get("cardNumber").toString()).startsWith("4111");
        assertThat(masked.get("cardNumber").toString()).endsWith("1111");
    }

    @Test
    void shouldMaskFieldsCaseInsensitive() {
        LoggingConfig.custom()
            .maskField("cardnumber", 4)
            .apply();

        // Different cases should all be masked
        assertThat(FieldMasker.mask("cardNumber", "4111111111111111")).contains("****");
        assertThat(FieldMasker.mask("CARDNUMBER", "4111111111111111")).contains("****");
        assertThat(FieldMasker.mask("CardNumber", "4111111111111111")).contains("****");
    }

    @Test
    void shouldMaskFieldsWithUnderscoresAndDashes() {
        LoggingConfig.custom()
            .maskField("cardnumber", 4)
            .apply();

        assertThat(FieldMasker.mask("card_number", "4111111111111111")).contains("****");
        assertThat(FieldMasker.mask("card-number", "4111111111111111")).contains("****");
    }

    @Test
    void shouldMaskDefaultSensitiveFields() {
        // Default config includes common sensitive fields
        LoggingConfig.custom().apply();

        assertThat(FieldMasker.mask("password", "secret")).doesNotContain("secret");
        assertThat(FieldMasker.mask("token", "abc123token")).doesNotContain("abc123");
        assertThat(FieldMasker.mask("apikey", "sk-12345")).doesNotContain("sk-12345");
    }

    @Test
    void shouldNotMaskNonSensitiveFields() {
        LoggingConfig.custom()
            .clearDefaultMaskedFields()
            .maskField("password", 0)
            .apply();

        assertThat(FieldMasker.mask("username", "john")).isEqualTo("john");
        assertThat(FieldMasker.mask("email", "john@example.com")).isEqualTo("john@example.com");
    }

    @Test
    void shouldMaskMessagePatterns() {
        LoggingConfig.custom()
            .maskField("password", 0)
            .apply();

        String message = "Login attempt with password=secret123 failed";
        String masked = FieldMasker.maskMessage(message);

        assertThat(masked).doesNotContain("secret123");
        assertThat(masked).contains("password=");
    }

    @Test
    void shouldMaskJsonPatterns() {
        LoggingConfig.custom()
            .maskField("password", 0)
            .apply();

        String json = "{\"username\": \"john\", \"password\": \"secret123\"}";
        String masked = FieldMasker.maskMessage(json);

        assertThat(masked).doesNotContain("secret123");
        assertThat(masked).contains("\"password\":");
    }

    @Test
    void shouldCreateLoggerInstance() {
        CbqLog log = CbqLog.getLogger(CbqLoggerTest.class);

        assertThat(log).isNotNull();
        assertThat(log.getName()).isEqualTo(CbqLoggerTest.class.getName());
    }

    @Test
    void shouldBuildStructuredLog() {
        CbqLog log = CbqLog.getLogger(CbqLoggerTest.class);
        LoggingConfig.custom()
            .maskField("cardNumber", 4)
            .includeTimestamp(true)
            .includeLevel(true)
            .apply();

        Map<String, Object> entry = log.structured("payment.test")
            .field("amount", 100)
            .field("cardNumber", "4111111111111111")
            .build();

        assertThat(entry).containsKey("timestamp");
        assertThat(entry).containsKey("level");
        assertThat(entry).containsEntry("event", "payment.test");
        
        @SuppressWarnings("unchecked")
        Map<String, Object> data = (Map<String, Object>) entry.get("data");
        assertThat(data).containsEntry("amount", 100);
        assertThat(data.get("cardNumber").toString()).contains("****");
    }

    @Test
    void shouldHandleNullValues() {
        assertThat(FieldMasker.mask("password", null)).isNull();
        assertThat(FieldMasker.maskMessage(null)).isNull();
        assertThat(FieldMasker.maskMap(null)).isEmpty();
    }

    @Test
    void shouldHandleEmptyValues() {
        assertThat(FieldMasker.mask("password", "")).isEqualTo("");
        assertThat(FieldMasker.maskMessage("")).isEqualTo("");
        assertThat(FieldMasker.maskMap(Map.of())).isEmpty();
    }

    @Test
    void shouldConfigureFromBuilder() {
        LoggingConfig config = LoggingConfig.custom()
            .maskFields("field1", "field2")
            .excludeFields("excluded1")
            .maskSymbol('X')
            .defaultVisibleChars(2)
            .outputFormat(LoggingConfig.OutputFormat.JSON)
            .applicationName("test-app")
            .environment("test")
            .includeCorrelationId(true)
            .correlationIdKey("X-Request-ID")
            .build();

        assertThat(config.getMaskSymbol()).isEqualTo('X');
        assertThat(config.getDefaultVisibleChars()).isEqualTo(2);
        assertThat(config.getOutputFormat()).isEqualTo(LoggingConfig.OutputFormat.JSON);
        assertThat(config.getApplicationName()).isEqualTo("test-app");
        assertThat(config.getEnvironment()).isEqualTo("test");
        assertThat(config.isIncludeCorrelationId()).isTrue();
        assertThat(config.getCorrelationIdKey()).isEqualTo("X-Request-ID");
    }
}
