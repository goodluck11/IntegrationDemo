package com.cbq.logging.config;

import com.cbq.logging.mask.FieldMaskConfig;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Main configuration class for CBQ Logger.
 * <p>
 * Usage:
 * <pre>
 * LoggingConfig.custom()
 *     .maskFields("password", "cardNumber", "cvv", "pin", "ssn", "iban")
 *     .maskField("cardNumber", 4)
 *     .maskField("cvv", 0)
 *     .excludeFields("internalId", "debugData")
 *     .maskSymbol('X')
 *     .defaultVisibleChars(4)
 *     .outputFormat(OutputFormat.JSON)
 *     .prettyPrint(false)
 *     .includeTimestamp(true)
 *     .includeLevel(true)
 *     .includeLogger(true)
 *     .includeThread(true)
 *     .includeCorrelationId(true)
 *     .correlationIdKey("X-Correlation-ID")
 *     .apply();
 * </pre>
 */
public class LoggingConfig {
    
    private static volatile LoggingConfig INSTANCE;
    private static final Object LOCK = new Object();
    
    // Field masking configuration
    private final Map<String, FieldMaskConfig> fieldMaskConfigs = new ConcurrentHashMap<>();
    private final Set<String> excludedFields = ConcurrentHashMap.newKeySet();
    private final Set<String> defaultMaskedFields = ConcurrentHashMap.newKeySet();
    
    // Masking defaults
    private char maskSymbol = '*';
    private int defaultVisibleChars = 4;
    private int minMaskLength = 8;
    
    // Output format
    private OutputFormat outputFormat = OutputFormat.JSON;
    private boolean prettyPrint = false;
    
    // Structured log fields
    private boolean includeTimestamp = true;
    private boolean includeLevel = true;
    private boolean includeLogger = true;
    private boolean includeThread = true;
    private boolean includeCorrelationId = true;
    private boolean includeSpanId = false;
    private boolean includeTraceId = false;
    
    // Context keys
    private String correlationIdKey = "X-Correlation-ID";
    private String spanIdKey = "X-Span-ID";
    private String traceIdKey = "X-Trace-ID";
    
    // Application metadata
    private String applicationName;
    private String applicationVersion;
    private String environment;
    
    // Exception handling
    private boolean includeStackTrace = true;
    private int maxStackTraceDepth = 50;
    private boolean includeExceptionCause = true;
    
    // Performance
    private boolean asyncLogging = false;
    private int asyncQueueSize = 1024;
    
    private LoggingConfig() {
        // Initialize with common sensitive field patterns
        initializeDefaultMaskedFields();
    }
    
    private void initializeDefaultMaskedFields() {
        // Common sensitive fields that should be masked by default
        defaultMaskedFields.addAll(Arrays.asList(
            "password", "passwd", "pwd", "secret",
            "token", "accesstoken", "refreshtoken", "apikey", "api_key",
            "authorization", "auth", "bearer",
            "cardnumber", "card_number", "creditcard", "credit_card",
            "cvv", "cvc", "cvv2", "securitycode", "security_code",
            "pin", "pincode", "pin_code",
            "ssn", "socialsecurity", "social_security",
            "iban", "accountnumber", "account_number", "routingnumber", "routing_number",
            "bvn", "nin", // Nigerian identifiers
            "privatekey", "private_key", "secretkey", "secret_key"
        ));
    }
    
    /**
     * Get the singleton instance.
     */
    public static LoggingConfig getInstance() {
        if (INSTANCE == null) {
            synchronized (LOCK) {
                if (INSTANCE == null) {
                    INSTANCE = new LoggingConfig();
                }
            }
        }
        return INSTANCE;
    }

    public static Builder custom() {
        return new Builder();
    }

    public static void reset() {
        synchronized (LOCK) {
            INSTANCE = new LoggingConfig();
        }
    }
    
    // Getters
    public Map<String, FieldMaskConfig> getFieldMaskConfigs() {
        return Collections.unmodifiableMap(fieldMaskConfigs);
    }
    
    public Set<String> getExcludedFields() {
        return Collections.unmodifiableSet(excludedFields);
    }
    
    public Set<String> getDefaultMaskedFields() {
        return Collections.unmodifiableSet(defaultMaskedFields);
    }

    public char getMaskSymbol() {
        return maskSymbol;
    }

    public int getDefaultVisibleChars() {
        return defaultVisibleChars;
    }
    
    public int getMinMaskLength() {
        return minMaskLength;
    }
    
    public OutputFormat getOutputFormat() {
        return outputFormat;
    }
    
    public boolean isPrettyPrint() {
        return prettyPrint;
    }
    
    public boolean isIncludeTimestamp() {
        return includeTimestamp;
    }
    
    public boolean isIncludeLevel() {
        return includeLevel;
    }
    
    public boolean isIncludeLogger() {
        return includeLogger;
    }
    
    public boolean isIncludeThread() {
        return includeThread;
    }
    
    public boolean isIncludeCorrelationId() {
        return includeCorrelationId;
    }
    
    public boolean isIncludeSpanId() {
        return includeSpanId;
    }
    
    public boolean isIncludeTraceId() {
        return includeTraceId;
    }
    
    public String getCorrelationIdKey() {
        return correlationIdKey;
    }
    
    public String getSpanIdKey() {
        return spanIdKey;
    }
    
    public String getTraceIdKey() {
        return traceIdKey;
    }
    
    public String getApplicationName() {
        return applicationName;
    }
    
    public String getApplicationVersion() {
        return applicationVersion;
    }
    
    public String getEnvironment() {
        return environment;
    }
    
    public boolean isIncludeStackTrace() {
        return includeStackTrace;
    }
    
    public int getMaxStackTraceDepth() {
        return maxStackTraceDepth;
    }
    
    public boolean isIncludeExceptionCause() {
        return includeExceptionCause;
    }
    
    public boolean isAsyncLogging() {
        return asyncLogging;
    }
    
    public int getAsyncQueueSize() {
        return asyncQueueSize;
    }
    
    /**
     * Check if a field should be masked.
     */
    public boolean shouldMaskField(String fieldName) {
        if (fieldName == null) return false;
        String normalizedName = fieldName.toLowerCase().replaceAll("[_-]", "");
        return fieldMaskConfigs.containsKey(normalizedName) || 
               defaultMaskedFields.contains(normalizedName);
    }
    
    /**
     * Check if a field should be excluded.
     */
    public boolean shouldExcludeField(String fieldName) {
        if (fieldName == null) return false;
        String normalizedName = fieldName.toLowerCase().replaceAll("[_-]", "");
        return excludedFields.contains(normalizedName);
    }
    
    /**
     * Get mask configuration for a specific field.
     */
    public FieldMaskConfig getMaskConfig(String fieldName) {
        if (fieldName == null) return getDefaultMaskConfig();
        String normalizedName = fieldName.toLowerCase().replaceAll("[_-]", "");
        return fieldMaskConfigs.getOrDefault(normalizedName, getDefaultMaskConfig());
    }
    
    private FieldMaskConfig getDefaultMaskConfig() {
        return new FieldMaskConfig(defaultVisibleChars, maskSymbol, false, false);
    }
    
    /**
     * Output format enumeration.
     */
    public enum OutputFormat {
        JSON,       // Compact JSON for Splunk/ELK
        PRETTY,     // Pretty-printed JSON for development
        LOGFMT,     // key=value format
        TEXT        // Traditional text format
    }
    
    /**
     * Builder class for fluent configuration.
     */
    public static class Builder {
        private final LoggingConfig config;
        
        private Builder() {
            this.config = new LoggingConfig();
        }
        
        /**
         * Add fields to mask with default settings (case-insensitive, partial match).
         */
        public Builder maskFields(String... fieldNames) {
            for (String fieldName : fieldNames) {
                String normalized = fieldName.toLowerCase().replaceAll("[_-]", "");
                config.fieldMaskConfigs.put(normalized, 
                    new FieldMaskConfig(config.defaultVisibleChars, config.maskSymbol, false, false));
            }
            return this;
        }
        
        /**
         * Configure masking for a specific field with custom visible characters.
         */
        public Builder maskField(String fieldName, int visibleChars) {
            String normalized = fieldName.toLowerCase().replaceAll("[_-]", "");
            config.fieldMaskConfigs.put(normalized, 
                new FieldMaskConfig(visibleChars, config.maskSymbol, false, false));
            return this;
        }
        
        /**
         * Configure a fully masked field (no visible characters).
         */
        public Builder fullyMaskField(String fieldName) {
            String normalized = fieldName.toLowerCase().replaceAll("[_-]", "");
            config.fieldMaskConfigs.put(normalized, 
                new FieldMaskConfig(0, config.maskSymbol, true, false));
            return this;
        }
        
        /**
         * Exclude fields entirely from logging.
         */
        public Builder excludeFields(String... fieldNames) {
            for (String fieldName : fieldNames) {
                String normalized = fieldName.toLowerCase().replaceAll("[_-]", "");
                config.excludedFields.add(normalized);
            }
            return this;
        }

        public Builder maskSymbol(char symbol) {
            config.maskSymbol = symbol;
            // Update existing configs with new symbol
            config.fieldMaskConfigs.replaceAll((k, v) -> 
                new FieldMaskConfig(v.visibleChars(), symbol, v.fullyMask(), v.exclude()));
            return this;
        }
        
        /**
         * Set default visible characters for masking (default: 4).
         */
        public Builder defaultVisibleChars(int chars) {
            config.defaultVisibleChars = chars;
            return this;
        }
        
        /**
         * Set minimum mask length (default: 8).
         */
        public Builder minMaskLength(int length) {
            config.minMaskLength = length;
            return this;
        }
        
        /**
         * Set output format.
         */
        public Builder outputFormat(OutputFormat format) {
            config.outputFormat = format;
            return this;
        }
        
        /**
         * Enable JSON output format.
         */
        public Builder jsonFormat() {
            config.outputFormat = OutputFormat.JSON;
            return this;
        }
        
        /**
         * Enable pretty print for development.
         */
        public Builder prettyPrint(boolean enabled) {
            config.prettyPrint = enabled;
            if (enabled) {
                config.outputFormat = OutputFormat.PRETTY;
            }
            return this;
        }
        
        /**
         * Include timestamp in structured log.
         */
        public Builder includeTimestamp(boolean include) {
            config.includeTimestamp = include;
            return this;
        }
        
        /**
         * Include log level in structured log.
         */
        public Builder includeLevel(boolean include) {
            config.includeLevel = include;
            return this;
        }
        
        /**
         * Include logger name in structured log.
         */
        public Builder includeLogger(boolean include) {
            config.includeLogger = include;
            return this;
        }
        
        /**
         * Include thread name in structured log.
         */
        public Builder includeThread(boolean include) {
            config.includeThread = include;
            return this;
        }
        
        /**
         * Include correlation ID in structured log.
         */
        public Builder includeCorrelationId(boolean include) {
            config.includeCorrelationId = include;
            return this;
        }
        
        /**
         * Include span ID for distributed tracing.
         */
        public Builder includeSpanId(boolean include) {
            config.includeSpanId = include;
            return this;
        }
        
        /**
         * Include trace ID for distributed tracing.
         */
        public Builder includeTraceId(boolean include) {
            config.includeTraceId = include;
            return this;
        }
        
        /**
         * Set the MDC key for correlation ID.
         */
        public Builder correlationIdKey(String key) {
            config.correlationIdKey = key;
            return this;
        }
        
        /**
         * Set the MDC key for span ID.
         */
        public Builder spanIdKey(String key) {
            config.spanIdKey = key;
            return this;
        }
        
        /**
         * Set the MDC key for trace ID.
         */
        public Builder traceIdKey(String key) {
            config.traceIdKey = key;
            return this;
        }
        
        /**
         * Set application name for logs.
         */
        public Builder applicationName(String name) {
            config.applicationName = name;
            return this;
        }
        
        /**
         * Set application version for logs.
         */
        public Builder applicationVersion(String version) {
            config.applicationVersion = version;
            return this;
        }
        
        /**
         * Set environment (dev, staging, prod).
         */
        public Builder environment(String env) {
            config.environment = env;
            return this;
        }
        
        /**
         * Include stack trace in exception logging.
         */
        public Builder includeStackTrace(boolean include) {
            config.includeStackTrace = include;
            return this;
        }
        
        /**
         * Set maximum stack trace depth.
         */
        public Builder maxStackTraceDepth(int depth) {
            config.maxStackTraceDepth = depth;
            return this;
        }
        
        /**
         * Include exception cause chain.
         */
        public Builder includeExceptionCause(boolean include) {
            config.includeExceptionCause = include;
            return this;
        }
        
        /**
         * Enable async logging.
         */
        public Builder asyncLogging(boolean enabled) {
            config.asyncLogging = enabled;
            return this;
        }
        
        /**
         * Set async queue size.
         */
        public Builder asyncQueueSize(int size) {
            config.asyncQueueSize = size;
            return this;
        }
        
        /**
         * Clear default masked fields (password, cardNumber, etc.).
         */
        public Builder clearDefaultMaskedFields() {
            config.defaultMaskedFields.clear();
            return this;
        }
        
        /**
         * Add to default masked fields.
         */
        public Builder addDefaultMaskedFields(String... fieldNames) {
            for (String fieldName : fieldNames) {
                String normalized = fieldName.toLowerCase().replaceAll("[_-]", "");
                config.defaultMaskedFields.add(normalized);
            }
            return this;
        }
        
        /**
         * Apply the configuration globally.
         */
        public LoggingConfig apply() {
            synchronized (LOCK) {
                INSTANCE = this.config;
            }
            return this.config;
        }

        public LoggingConfig build() {
            return this.config;
        }
    }
}
