package com.cbq.logging.filter;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.filter.Filter;
import ch.qos.logback.core.spi.FilterReply;
import com.cbq.logging.config.LoggingConfig;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

/**
 * Logback filter to exclude logs from specific loggers or containing specific patterns.
 * <p>
 * Usage in logback.xml:
 * <pre>
 * &lt;filter class="com.cbq.logging.filter.CbqLoggingFilter"&gt;
 *     &lt;excludeLogger&gt;org.hibernate.SQL&lt;/excludeLogger&gt;
 *     &lt;excludeLogger&gt;org.apache.http&lt;/excludeLogger&gt;
 *     &lt;excludePattern&gt;heartbeat&lt;/excludePattern&gt;
 * &lt;/filter&gt;
 * </pre>
 */
public class CbqLoggingFilter extends Filter<ILoggingEvent> {
    
    private final Set<String> excludedLoggers = new HashSet<>();
    private final Set<String> excludedPatterns = new HashSet<>();
    private final Set<String> includedLoggers = new HashSet<>();
    @Setter
    private String minLevel = null;
    
    @Override
    public FilterReply decide(ILoggingEvent event) {
        // Check excluded loggers
        String loggerName = event.getLoggerName();
        for (String excluded : excludedLoggers) {
            if (loggerName.startsWith(excluded)) {
                return FilterReply.DENY;
            }
        }
        
        // Check included loggers (if specified, only these are allowed)
        if (!includedLoggers.isEmpty()) {
            boolean included = false;
            for (String include : includedLoggers) {
                if (loggerName.startsWith(include)) {
                    included = true;
                    break;
                }
            }
            if (!included) {
                return FilterReply.DENY;
            }
        }
        
        // Check excluded patterns in message
        String message = event.getFormattedMessage();
        if (message != null) {
            for (String pattern : excludedPatterns) {
                if (message.toLowerCase().contains(pattern.toLowerCase())) {
                    return FilterReply.DENY;
                }
            }
        }
        
        // Check minimum level
        if (minLevel != null) {
            int eventLevel = event.getLevel().toInt();
            int minLevelInt = ch.qos.logback.classic.Level.toLevel(minLevel).toInt();
            if (eventLevel < minLevelInt) {
                return FilterReply.DENY;
            }
        }
        
        return FilterReply.NEUTRAL;
    }
    
    // Configuration methods for Logback
    
    public void addExcludeLogger(String logger) {
        excludedLoggers.add(logger);
    }
    
    public void addExcludePattern(String pattern) {
        excludedPatterns.add(pattern);
    }
    
    public void addIncludeLogger(String logger) {
        includedLoggers.add(logger);
    }

}
