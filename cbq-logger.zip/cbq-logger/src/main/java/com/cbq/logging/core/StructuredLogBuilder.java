package com.cbq.logging.core;

import com.cbq.logging.config.LoggingConfig;
import com.cbq.logging.mask.FieldMasker;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.slf4j.Logger;
import org.slf4j.MDC;
import org.slf4j.event.Level;

import java.time.Instant;
import java.util.*;

/**
 * Builder for structured log entries with fluent API.
 * <p>
 * Usage:
 * <pre>
 * log.structured("payment.processed")
 *    .field("amount", 100.00)
 *    .field("currency", "NGN")
 *    .field("cardNumber", "4111111111111111") // Will be masked automatically
 *    .fields(paymentRequest) // Add all fields from object
 *    .exception(ex)
 *    .log();
 * </pre>
 */
public class StructuredLogBuilder {
    
    private static final ObjectMapper OBJECT_MAPPER = createObjectMapper();
    
    private final Logger delegate;
    private final String event;
    private Level level = Level.INFO;
    private final Map<String, Object> fields = new LinkedHashMap<>();
    private Throwable exception;
    private String message;
    private boolean maskFields = true;
    
    StructuredLogBuilder(Logger delegate, String event) {
        this.delegate = delegate;
        this.event = event;
    }
    
    private static ObjectMapper createObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return mapper;
    }
    
    /**
     * Set log level to DEBUG.
     */
    public StructuredLogBuilder debug() {
        this.level = Level.DEBUG;
        return this;
    }
    
    /**
     * Set log level to INFO.
     */
    public StructuredLogBuilder info() {
        this.level = Level.INFO;
        return this;
    }
    
    /**
     * Set log level to WARN.
     */
    public StructuredLogBuilder warn() {
        this.level = Level.WARN;
        return this;
    }
    
    /**
     * Set log level to ERROR.
     */
    public StructuredLogBuilder error() {
        this.level = Level.ERROR;
        return this;
    }
    
    /**
     * Set log level to TRACE.
     */
    public StructuredLogBuilder trace() {
        this.level = Level.TRACE;
        return this;
    }
    
    /**
     * Set log level.
     */
    public StructuredLogBuilder level(Level level) {
        this.level = level;
        return this;
    }
    
    /**
     * Add a field to the structured log.
     *
     * @param name  field name
     * @param value field value (will be masked if configured)
     */
    public StructuredLogBuilder field(String name, Object value) {
        if (name != null) {
            fields.put(name, value);
        }
        return this;
    }
    
    /**
     * Add a field only if the value is not null.
     */
    public StructuredLogBuilder fieldIfPresent(String name, Object value) {
        if (name != null && value != null) {
            fields.put(name, value);
        }
        return this;
    }
    
    /**
     * Add multiple fields from a map.
     */
    public StructuredLogBuilder fields(Map<String, Object> data) {
        if (data != null) {
            fields.putAll(data);
        }
        return this;
    }
    
    /**
     * Add all fields from an object (introspects the object).
     */
    public StructuredLogBuilder fields(Object obj) {
        if (obj != null) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Object> objectFields = OBJECT_MAPPER.convertValue(obj, Map.class);
                fields.putAll(objectFields);
            } catch (Exception e) {
                fields.put("_objectConversionError", e.getMessage());
            }
        }
        return this;
    }
    
    /**
     * Add an exception to the log entry.
     */
    public StructuredLogBuilder exception(Throwable t) {
        this.exception = t;
        return this;
    }
    
    /**
     * Add a human-readable message.
     */
    public StructuredLogBuilder message(String msg) {
        this.message = msg;
        return this;
    }
    
    /**
     * Add a formatted message.
     */
    public StructuredLogBuilder message(String format, Object... args) {
        this.message = String.format(format, args);
        return this;
    }
    
    /**
     * Disable automatic field masking for this log entry.
     */
    public StructuredLogBuilder noMasking() {
        this.maskFields = false;
        return this;
    }
    
    /**
     * Add timing information.
     */
    public StructuredLogBuilder duration(long millis) {
        fields.put("duration_ms", millis);
        return this;
    }
    
    /**
     * Add timing information with start time.
     */
    public StructuredLogBuilder durationSince(Instant start) {
        if (start != null) {
            long duration = Instant.now().toEpochMilli() - start.toEpochMilli();
            fields.put("duration_ms", duration);
        }
        return this;
    }
    
    /**
     * Add request/response pair information.
     */
    public StructuredLogBuilder request(Object request) {
        if (request != null) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Object> requestFields = OBJECT_MAPPER.convertValue(request, Map.class);
                fields.put("request", requestFields);
            } catch (Exception e) {
                fields.put("request", request.toString());
            }
        }
        return this;
    }
    
    /**
     * Add response information.
     */
    public StructuredLogBuilder response(Object response) {
        if (response != null) {
            try {
                @SuppressWarnings("unchecked")
                Map<String, Object> responseFields = OBJECT_MAPPER.convertValue(response, Map.class);
                fields.put("response", responseFields);
            } catch (Exception e) {
                fields.put("response", response.toString());
            }
        }
        return this;
    }
    
    /**
     * Execute the log operation.
     */
    public void log() {
        Map<String, Object> logEntry = buildLogEntry();
        String jsonMessage = toJson(logEntry);
        
        switch (level) {
            case TRACE -> {
                if (exception != null) delegate.trace(jsonMessage, exception);
                else delegate.trace(jsonMessage);
            }
            case DEBUG -> {
                if (exception != null) delegate.debug(jsonMessage, exception);
                else delegate.debug(jsonMessage);
            }
            case INFO -> {
                if (exception != null) delegate.info(jsonMessage, exception);
                else delegate.info(jsonMessage);
            }
            case WARN -> {
                if (exception != null) delegate.warn(jsonMessage, exception);
                else delegate.warn(jsonMessage);
            }
            case ERROR -> {
                if (exception != null) delegate.error(jsonMessage, exception);
                else delegate.error(jsonMessage);
            }
        }
    }
    
    /**
     * Build and return the log entry without logging.
     */
    public Map<String, Object> build() {
        return buildLogEntry();
    }
    
    /**
     * Build and return the JSON string without logging.
     */
    public String toJsonString() {
        return toJson(buildLogEntry());
    }
    
    private Map<String, Object> buildLogEntry() {
        LoggingConfig config = LoggingConfig.getInstance();
        Map<String, Object> entry = new LinkedHashMap<>();
        
        // Standard fields
        if (config.isIncludeTimestamp()) {
            entry.put("timestamp", Instant.now().toString());
        }
        
        if (config.isIncludeLevel()) {
            entry.put("level", level.name());
        }
        
        if (config.isIncludeLogger()) {
            entry.put("logger", delegate.getName());
        }
        
        if (config.isIncludeThread()) {
            entry.put("thread", Thread.currentThread().getName());
        }
        
        // Tracing fields from MDC
        if (config.isIncludeCorrelationId()) {
            String correlationId = MDC.get(config.getCorrelationIdKey());
            if (correlationId != null) {
                entry.put("correlationId", correlationId);
            }
        }
        
        if (config.isIncludeTraceId()) {
            String traceId = MDC.get(config.getTraceIdKey());
            if (traceId != null) {
                entry.put("traceId", traceId);
            }
        }
        
        if (config.isIncludeSpanId()) {
            String spanId = MDC.get(config.getSpanIdKey());
            if (spanId != null) {
                entry.put("spanId", spanId);
            }
        }
        
        // Application metadata
        if (config.getApplicationName() != null) {
            entry.put("application", config.getApplicationName());
        }
        
        if (config.getEnvironment() != null) {
            entry.put("environment", config.getEnvironment());
        }
        
        // Event name
        entry.put("event", event);
        
        // Human-readable message
        if (message != null) {
            entry.put("message", message);
        }
        
        // Custom fields (masked if necessary)
        Map<String, Object> maskedFields = maskFields ? 
            FieldMasker.maskMap(fields) : fields;
        entry.put("data", maskedFields);
        
        // Exception handling
        if (exception != null) {
            entry.put("exception", formatException(exception, config));
        }
        
        return entry;
    }
    
    private Map<String, Object> formatException(Throwable t, LoggingConfig config) {
        Map<String, Object> exceptionData = new LinkedHashMap<>();
        exceptionData.put("type", t.getClass().getName());
        exceptionData.put("message", t.getMessage());
        
        if (config.isIncludeStackTrace()) {
            StackTraceElement[] stackTrace = t.getStackTrace();
            int depth = Math.min(stackTrace.length, config.getMaxStackTraceDepth());
            List<String> frames = new ArrayList<>(depth);
            for (int i = 0; i < depth; i++) {
                frames.add(stackTrace[i].toString());
            }
            exceptionData.put("stackTrace", frames);
        }
        
        if (config.isIncludeExceptionCause() && t.getCause() != null) {
            exceptionData.put("cause", formatException(t.getCause(), config));
        }
        
        return exceptionData;
    }
    
    private String toJson(Map<String, Object> entry) {
        LoggingConfig config = LoggingConfig.getInstance();
        try {
            if (config.isPrettyPrint() || config.getOutputFormat() == LoggingConfig.OutputFormat.PRETTY) {
                return OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(entry);
            }
            return OBJECT_MAPPER.writeValueAsString(entry);
        } catch (JsonProcessingException e) {
            return "{\"error\":\"Failed to serialize log entry\",\"event\":\"" + event + "\"}";
        }
    }
}
