package com.cbq.logging.aspect;

import com.cbq.logging.annotation.LogMethod;
import com.cbq.logging.annotation.MaskSensitive;
import com.cbq.logging.core.CbqLog;
import com.cbq.logging.mask.FieldMasker;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * AOP Aspect that implements automatic method logging for @LogMethod annotation.
 * <p>
 * To enable this aspect in Spring Boot, add the following dependency:
 * <pre>
 * &lt;dependency&gt;
 *     &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
 *     &lt;artifactId&gt;spring-boot-starter-aop&lt;/artifactId&gt;
 * &lt;/dependency&gt;
 * </pre>
 * <p>
 * Then register the aspect as a bean:
 * <pre>
 * &#64;Configuration
 * &#64;EnableAspectJAutoProxy
 * public class LoggingAspectConfig {
 *     &#64;Bean
 *     public LogMethodAspect logMethodAspect() {
 *         return new LogMethodAspect();
 *     }
 * }
 * </pre>
 * <p>
 * Or simply annotate your Spring Boot application:
 * <pre>
 * &#64;SpringBootApplication
 * &#64;EnableAspectJAutoProxy
 * public class Application { }
 * </pre>
 * And register as a component:
 * <pre>
 * &#64;Component
 * public class LogMethodAspect extends com.cbq.logging.aspect.LogMethodAspect { }
 * </pre>
 */
@Aspect
public class LogMethodAspect {

   @Around("@annotation(logMethod)")
   public Object logMethodExecution(ProceedingJoinPoint joinPoint, LogMethod logMethod) throws Throwable {

      MethodSignature signature = (MethodSignature) joinPoint.getSignature();
      Method method = signature.getMethod();
      String className = joinPoint.getTarget().getClass().getSimpleName();
      String methodName = method.getName();

      CbqLog log = CbqLog.getLogger(joinPoint.getTarget().getClass());

      String messagePrefix = logMethod.message().isEmpty()
              ? className + "." + methodName
              : logMethod.message();

      // Build entry log
      Map<String, Object> entryData = new LinkedHashMap<>();
      entryData.put("class", className);
      entryData.put("method", methodName);

      if (logMethod.includeArgs()) {
         entryData.put("args", buildArgsMap(joinPoint, method));
      }

      // Log method entry
      logAtLevel(log, logMethod.level(), "method.entry", messagePrefix + " - ENTRY", entryData, null);

      Instant start = Instant.now();

      try {
         // Execute the method
         Object result = joinPoint.proceed();

         long duration = Instant.now().toEpochMilli() - start.toEpochMilli();

         // Build exit log
         Map<String, Object> exitData = new LinkedHashMap<>();
         exitData.put("class", className);
         exitData.put("method", methodName);

         if (logMethod.includeExecutionTime()) {
            exitData.put("duration_ms", duration);
         }

         if (logMethod.includeResult() && result != null) {
            exitData.put("result", maskResult(result));
         }

         // Log method exit
         logAtLevel(log, logMethod.level(), "method.exit", messagePrefix + " - EXIT", exitData, null);

         return result;

      } catch (Throwable ex) {
         long duration = Instant.now().toEpochMilli() - start.toEpochMilli();

         // Build error log
         Map<String, Object> errorData = new LinkedHashMap<>();
         errorData.put("class", className);
         errorData.put("method", methodName);
         errorData.put("duration_ms", duration);
         errorData.put("exceptionType", ex.getClass().getName());
         errorData.put("exceptionMessage", ex.getMessage());

         // Always log exceptions at ERROR level
         log.structured("method.exception")
                 .error()
                 .message(messagePrefix + " - EXCEPTION")
                 .fields(errorData)
                 .exception(ex)
                 .log();

         throw ex;
      }
   }

   private Map<String, Object> buildArgsMap(ProceedingJoinPoint joinPoint, Method method) {
      Map<String, Object> argsMap = new LinkedHashMap<>();
      Object[] args = joinPoint.getArgs();
      Parameter[] parameters = method.getParameters();

      for (int i = 0; i < args.length; i++) {
         String paramName = parameters[i].getName();
         Object argValue = args[i];

         // Check for @MaskSensitive on parameter
         MaskSensitive maskAnnotation = parameters[i].getAnnotation(MaskSensitive.class);

         if (maskAnnotation != null) {
            if (maskAnnotation.exclude()) {
               continue; // Skip excluded parameters
            }
            argsMap.put(paramName, maskParameter(argValue, maskAnnotation));
         } else if (argValue != null) {
            // Check if it's a complex object with @MaskSensitive fields
            if (isComplexObject(argValue)) {
               argsMap.put(paramName, FieldMasker.maskObject(argValue));
            } else {
               argsMap.put(paramName, FieldMasker.mask(paramName, argValue));
            }
         } else {
            argsMap.put(paramName, null);
         }
      }

      return argsMap;
   }

   private Object maskParameter(Object value, MaskSensitive annotation) {
      if (value == null) return null;

      if (annotation.fullyMask()) {
         return repeatChar(annotation.maskSymbol(), 8);
      }

      String strValue = value.toString();
      int visible = annotation.visibleChars();

      if (strValue.length() <= visible * 2) {
         return repeatChar(annotation.maskSymbol(), strValue.length());
      }

      String prefix = strValue.substring(0, visible);
      String suffix = strValue.substring(strValue.length() - visible);
      String masked = repeatChar(annotation.maskSymbol(), strValue.length() - visible * 2);

      return prefix + masked + suffix;
   }

   private Object maskResult(Object result) {
      if (result == null) return null;

      if (isComplexObject(result)) {
         return FieldMasker.maskObject(result);
      }

      return result.toString();
   }

   private boolean isComplexObject(Object obj) {
      if (obj == null) return false;
      Class<?> clazz = obj.getClass();
      return !clazz.isPrimitive()
              && !clazz.getName().startsWith("java.lang")
              && !clazz.getName().startsWith("java.math")
              && !clazz.isEnum()
              && !(obj instanceof CharSequence)
              && !(obj instanceof Number);
   }

   private void logAtLevel(CbqLog log, String level, String event, String message,
                           Map<String, Object> data, Throwable ex) {
      var builder = log.structured(event)
              .message(message)
              .fields(data);

      if (ex != null) {
         builder.exception(ex);
      }

      switch (level.toUpperCase()) {
         case "TRACE" -> builder.trace().log();
         case "INFO" -> builder.info().log();
         case "WARN" -> builder.warn().log();
         case "ERROR" -> builder.error().log();
         default -> builder.debug().log();
      }
   }

   private String repeatChar(char c, int count) {
      return String.valueOf(c).repeat(Math.max(0, count));
   }
}
