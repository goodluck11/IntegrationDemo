package com.cbq.logging.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Lombok-style annotation that generates a CbqLog instance for the annotated class.
 * <p>
 * Usage:
 * <pre>
 * &#64;CbqLogger
 * public class MyService {
 *     public void doSomething() {
 *         log.info("Processing request");
 *         log.structured("payment.processed")
 *            .field("amount", 100.00)
 *            .field("currency", "NGN")
 *            .log();
 *     }
 * }
 * </pre>
 * <p>
 * This annotation generates the equivalent of:
 * <pre>
 * private static final CbqLog log = CbqLog.getLogger(MyService.class);
 * </pre>
 * <p>
 * To use this annotation, add to your {@code lombok.config}:
 * <pre>
 * lombok.log.custom.declaration = com.cbq.logging.core.CbqLog com.cbq.logging.core.CbqLog.getLogger(TYPE)
 * </pre>
 *
 * @see com.cbq.logging.core.CbqLog
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface CbqLogger {
}
