package com.cbq.logging.config;

import java.util.ArrayList;
import java.util.List;

/**
 * Configuration properties for CBQ Logger (Spring Boot style).
 * <p>
 * Can be used with Spring Boot's @ConfigurationProperties:
 * <pre>
 * &#64;Configuration
 * &#64;ConfigurationProperties(prefix = "cbq.logging")
 * public class CbqLoggingProperties extends CbqLoggingConfigProperties {
 * }
 * </pre>
 * <p>
 * Then in application.yml:
 * <pre>
 * cbq:
 *   logging:
 *     mask-fields:
 *       - password
 *       - cardNumber
 *     mask-symbol: "*"
 *     default-visible-chars: 4
 *     output-format: JSON
 * </pre>
 */
public class CbqLoggingConfigProperties {
    
    /**
     * Fields to mask in logs.
     */
    private List<String> maskFields = new ArrayList<>();
    
    /**
     * Fields to exclude entirely from logs.
     */
    private List<String> excludeFields = new ArrayList<>();
    
    /**
     * Symbol used for masking (default: *).
     */
    private String maskSymbol = "*";
    
    /**
     * Number of characters to show at start/end of masked values (default: 4).
     */
    private int defaultVisibleChars = 4;
    
    /**
     * Minimum length of masked output (default: 8).
     */
    private int minMaskLength = 8;
    
    /**
     * Output format: JSON, PRETTY, LOGFMT, TEXT.
     */
    private String outputFormat = "JSON";
    
    /**
     * Enable pretty printing for development.
     */
    private boolean prettyPrint = false;
    
    /**
     * Include correlation ID in logs.
     */
    private boolean includeCorrelationId = true;
    
    /**
     * MDC key for correlation ID.
     */
    private String correlationIdKey = "X-Correlation-ID";
    
    /**
     * Include trace ID in logs.
     */
    private boolean includeTraceId = false;
    
    /**
     * MDC key for trace ID.
     */
    private String traceIdKey = "X-Trace-ID";
    
    /**
     * Include span ID in logs.
     */
    private boolean includeSpanId = false;
    
    /**
     * MDC key for span ID.
     */
    private String spanIdKey = "X-Span-ID";
    
    /**
     * Application name for logs.
     */
    private String applicationName;
    
    /**
     * Application version for logs.
     */
    private String applicationVersion;
    
    /**
     * Environment (dev, staging, prod).
     */
    private String environment;
    
    /**
     * Include stack traces in exception logging.
     */
    private boolean includeStackTrace = true;
    
    /**
     * Maximum stack trace depth.
     */
    private int maxStackTraceDepth = 50;
    
    /**
     * Include exception cause chain.
     */
    private boolean includeExceptionCause = true;
    
    /**
     * Enable async logging.
     */
    private boolean asyncLogging = false;
    
    /**
     * Async logging queue size.
     */
    private int asyncQueueSize = 1024;
    
    // Getters and Setters
    
    public List<String> getMaskFields() {
        return maskFields;
    }
    
    public void setMaskFields(List<String> maskFields) {
        this.maskFields = maskFields;
    }
    
    public List<String> getExcludeFields() {
        return excludeFields;
    }
    
    public void setExcludeFields(List<String> excludeFields) {
        this.excludeFields = excludeFields;
    }
    
    public String getMaskSymbol() {
        return maskSymbol;
    }
    
    public void setMaskSymbol(String maskSymbol) {
        this.maskSymbol = maskSymbol;
    }
    
    public int getDefaultVisibleChars() {
        return defaultVisibleChars;
    }
    
    public void setDefaultVisibleChars(int defaultVisibleChars) {
        this.defaultVisibleChars = defaultVisibleChars;
    }
    
    public int getMinMaskLength() {
        return minMaskLength;
    }
    
    public void setMinMaskLength(int minMaskLength) {
        this.minMaskLength = minMaskLength;
    }
    
    public String getOutputFormat() {
        return outputFormat;
    }
    
    public void setOutputFormat(String outputFormat) {
        this.outputFormat = outputFormat;
    }
    
    public boolean isPrettyPrint() {
        return prettyPrint;
    }
    
    public void setPrettyPrint(boolean prettyPrint) {
        this.prettyPrint = prettyPrint;
    }
    
    public boolean isIncludeCorrelationId() {
        return includeCorrelationId;
    }
    
    public void setIncludeCorrelationId(boolean includeCorrelationId) {
        this.includeCorrelationId = includeCorrelationId;
    }
    
    public String getCorrelationIdKey() {
        return correlationIdKey;
    }
    
    public void setCorrelationIdKey(String correlationIdKey) {
        this.correlationIdKey = correlationIdKey;
    }
    
    public boolean isIncludeTraceId() {
        return includeTraceId;
    }
    
    public void setIncludeTraceId(boolean includeTraceId) {
        this.includeTraceId = includeTraceId;
    }
    
    public String getTraceIdKey() {
        return traceIdKey;
    }
    
    public void setTraceIdKey(String traceIdKey) {
        this.traceIdKey = traceIdKey;
    }
    
    public boolean isIncludeSpanId() {
        return includeSpanId;
    }
    
    public void setIncludeSpanId(boolean includeSpanId) {
        this.includeSpanId = includeSpanId;
    }
    
    public String getSpanIdKey() {
        return spanIdKey;
    }
    
    public void setSpanIdKey(String spanIdKey) {
        this.spanIdKey = spanIdKey;
    }
    
    public String getApplicationName() {
        return applicationName;
    }
    
    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }
    
    public String getApplicationVersion() {
        return applicationVersion;
    }
    
    public void setApplicationVersion(String applicationVersion) {
        this.applicationVersion = applicationVersion;
    }
    
    public String getEnvironment() {
        return environment;
    }
    
    public void setEnvironment(String environment) {
        this.environment = environment;
    }
    
    public boolean isIncludeStackTrace() {
        return includeStackTrace;
    }
    
    public void setIncludeStackTrace(boolean includeStackTrace) {
        this.includeStackTrace = includeStackTrace;
    }
    
    public int getMaxStackTraceDepth() {
        return maxStackTraceDepth;
    }
    
    public void setMaxStackTraceDepth(int maxStackTraceDepth) {
        this.maxStackTraceDepth = maxStackTraceDepth;
    }
    
    public boolean isIncludeExceptionCause() {
        return includeExceptionCause;
    }
    
    public void setIncludeExceptionCause(boolean includeExceptionCause) {
        this.includeExceptionCause = includeExceptionCause;
    }
    
    public boolean isAsyncLogging() {
        return asyncLogging;
    }
    
    public void setAsyncLogging(boolean asyncLogging) {
        this.asyncLogging = asyncLogging;
    }
    
    public int getAsyncQueueSize() {
        return asyncQueueSize;
    }
    
    public void setAsyncQueueSize(int asyncQueueSize) {
        this.asyncQueueSize = asyncQueueSize;
    }
    
    /**
     * Apply these properties to the global LoggingConfig.
     */
    public void apply() {
        LoggingConfig.Builder builder = LoggingConfig.custom();
        
        if (!maskFields.isEmpty()) {
            builder.maskFields(maskFields.toArray(new String[0]));
        }
        
        if (!excludeFields.isEmpty()) {
            builder.excludeFields(excludeFields.toArray(new String[0]));
        }
        
        if (maskSymbol != null && !maskSymbol.isEmpty()) {
            builder.maskSymbol(maskSymbol.charAt(0));
        }
        
        builder.defaultVisibleChars(defaultVisibleChars)
               .minMaskLength(minMaskLength)
               .prettyPrint(prettyPrint)
               .includeCorrelationId(includeCorrelationId)
               .correlationIdKey(correlationIdKey)
               .includeTraceId(includeTraceId)
               .traceIdKey(traceIdKey)
               .includeSpanId(includeSpanId)
               .spanIdKey(spanIdKey)
               .includeStackTrace(includeStackTrace)
               .maxStackTraceDepth(maxStackTraceDepth)
               .includeExceptionCause(includeExceptionCause)
               .asyncLogging(asyncLogging)
               .asyncQueueSize(asyncQueueSize);
        
        if (outputFormat != null) {
            try {
                builder.outputFormat(LoggingConfig.OutputFormat.valueOf(outputFormat.toUpperCase()));
            } catch (IllegalArgumentException ignored) {
                // Keep default
            }
        }
        
        if (applicationName != null) {
            builder.applicationName(applicationName);
        }
        
        if (applicationVersion != null) {
            builder.applicationVersion(applicationVersion);
        }
        
        if (environment != null) {
            builder.environment(environment);
        }
        
        builder.apply();
    }
}
