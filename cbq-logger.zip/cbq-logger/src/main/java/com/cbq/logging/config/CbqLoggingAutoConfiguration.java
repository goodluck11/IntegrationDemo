package com.cbq.logging.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Properties;

/**
 * Auto-configuration for CBQ Logger that reads from application properties.
 * <p>
 * Supported properties:
 * <pre>
 * cbq.logging.mask-fields=password,cardNumber,cvv,pin
 * cbq.logging.mask-symbol=*
 * cbq.logging.default-visible-chars=4
 * cbq.logging.exclude-fields=internalId,debugData
 * cbq.logging.output-format=JSON
 * cbq.logging.pretty-print=false
 * cbq.logging.include-correlation-id=true
 * cbq.logging.correlation-id-key=X-Correlation-ID
 * cbq.logging.application-name=my-app
 * cbq.logging.environment=production
 * </pre>
 * <p>
 * For Spring Boot, you can use @ConfigurationProperties or call this
 * from your configuration class.
 */
public class CbqLoggingAutoConfiguration {
    
    private static final Logger logger = LoggerFactory.getLogger(CbqLoggingAutoConfiguration.class);
    private static final String PREFIX = "cbq.logging.";
    
    /**
     * Configure CBQ Logger from properties.
     */
    public static void configure(Properties properties) {
        LoggingConfig.Builder builder = LoggingConfig.custom();
        
        // Mask fields
        String maskFields = properties.getProperty(PREFIX + "mask-fields");
        if (maskFields != null && !maskFields.isBlank()) {
            builder.maskFields(maskFields.split(","));
        }
        
        // Mask symbol
        String maskSymbol = properties.getProperty(PREFIX + "mask-symbol");
        if (maskSymbol != null && !maskSymbol.isEmpty()) {
            builder.maskSymbol(maskSymbol.charAt(0));
        }
        
        // Default visible chars
        String visibleChars = properties.getProperty(PREFIX + "default-visible-chars");
        if (visibleChars != null) {
            try {
                builder.defaultVisibleChars(Integer.parseInt(visibleChars));
            } catch (NumberFormatException e) {
                logger.warn("Invalid default-visible-chars value: {}", visibleChars);
            }
        }
        
        // Exclude fields
        String excludeFields = properties.getProperty(PREFIX + "exclude-fields");
        if (excludeFields != null && !excludeFields.isBlank()) {
            builder.excludeFields(excludeFields.split(","));
        }
        
        // Output format
        String outputFormat = properties.getProperty(PREFIX + "output-format");
        if (outputFormat != null) {
            try {
                builder.outputFormat(LoggingConfig.OutputFormat.valueOf(outputFormat.toUpperCase()));
            } catch (IllegalArgumentException e) {
                logger.warn("Invalid output-format value: {}", outputFormat);
            }
        }
        
        // Pretty print
        String prettyPrint = properties.getProperty(PREFIX + "pretty-print");
        if (prettyPrint != null) {
            builder.prettyPrint(Boolean.parseBoolean(prettyPrint));
        }
        
        // Include correlation ID
        String includeCorrelationId = properties.getProperty(PREFIX + "include-correlation-id");
        if (includeCorrelationId != null) {
            builder.includeCorrelationId(Boolean.parseBoolean(includeCorrelationId));
        }
        
        // Correlation ID key
        String correlationIdKey = properties.getProperty(PREFIX + "correlation-id-key");
        if (correlationIdKey != null && !correlationIdKey.isBlank()) {
            builder.correlationIdKey(correlationIdKey);
        }
        
        // Include trace ID
        String includeTraceId = properties.getProperty(PREFIX + "include-trace-id");
        if (includeTraceId != null) {
            builder.includeTraceId(Boolean.parseBoolean(includeTraceId));
        }
        
        // Include span ID
        String includeSpanId = properties.getProperty(PREFIX + "include-span-id");
        if (includeSpanId != null) {
            builder.includeSpanId(Boolean.parseBoolean(includeSpanId));
        }
        
        // Application name
        String applicationName = properties.getProperty(PREFIX + "application-name");
        if (applicationName != null && !applicationName.isBlank()) {
            builder.applicationName(applicationName);
        }
        
        // Application version
        String applicationVersion = properties.getProperty(PREFIX + "application-version");
        if (applicationVersion != null && !applicationVersion.isBlank()) {
            builder.applicationVersion(applicationVersion);
        }
        
        // Environment
        String environment = properties.getProperty(PREFIX + "environment");
        if (environment != null && !environment.isBlank()) {
            builder.environment(environment);
        }
        
        // Include stack trace
        String includeStackTrace = properties.getProperty(PREFIX + "include-stack-trace");
        if (includeStackTrace != null) {
            builder.includeStackTrace(Boolean.parseBoolean(includeStackTrace));
        }
        
        // Max stack trace depth
        String maxStackTraceDepth = properties.getProperty(PREFIX + "max-stack-trace-depth");
        if (maxStackTraceDepth != null) {
            try {
                builder.maxStackTraceDepth(Integer.parseInt(maxStackTraceDepth));
            } catch (NumberFormatException e) {
                logger.warn("Invalid max-stack-trace-depth value: {}", maxStackTraceDepth);
            }
        }
        
        builder.apply();
        logger.info("CBQ Logger configured from properties");
    }
    
    /**
     * Configure CBQ Logger from a Map (useful for Spring @ConfigurationProperties).
     */
    public static void configure(Map<String, String> config) {
        Properties properties = new Properties();
        config.forEach((key, value) -> properties.setProperty(PREFIX + key, value));
        configure(properties);
    }
    
    /**
     * Configure CBQ Logger from environment variables.
     * Looks for variables like CBQ_LOGGING_MASK_FIELDS, CBQ_LOGGING_MASK_SYMBOL, etc.
     */
    public static void configureFromEnvironment() {
        Properties properties = new Properties();
        Map<String, String> env = System.getenv();
        
        env.forEach((key, value) -> {
            if (key.startsWith("CBQ_LOGGING_")) {
                // Convert CBQ_LOGGING_MASK_FIELDS to cbq.logging.mask-fields
                String propKey = key.toLowerCase()
                    .replace("_", ".")
                    .replace("cbq.logging.", PREFIX);
                // Handle the kebab-case conversion
                propKey = propKey.replaceAll("\\.([a-z])", "-$1");
                properties.setProperty(propKey, value);
            }
        });
        
        if (!properties.isEmpty()) {
            configure(properties);
        }
    }
}
