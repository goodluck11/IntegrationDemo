package com.cbq.logging.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a field as sensitive for automatic masking during logging.
 * <p>
 * Usage:
 * <pre>
 * public class PaymentRequest {
 *     &#64;MaskSensitive(visibleChars = 4)
 *     private String cardNumber;
 *     
 *     &#64;MaskSensitive(fullyMask = true)
 *     private String cvv;
 *     
 *     &#64;MaskSensitive(exclude = true)
 *     private String internalDebugData;
 * }
 * </pre>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.PARAMETER})
public @interface MaskSensitive {
    
    /**
     * Number of characters to show at start and end of the value.
     * Default is 4 (e.g., "4111********1111").
     */
    int visibleChars() default 4;
    
    /**
     * If true, the entire value is masked with no visible characters.
     */
    boolean fullyMask() default false;
    
    /**
     * If true, the field is completely excluded from logging.
     */
    boolean exclude() default false;
    
    /**
     * Custom mask symbol to use (default uses global config).
     */
    char maskSymbol() default '*';
}
