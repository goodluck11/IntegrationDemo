package com.cbq.restclient.v2;

import lombok.Builder;
import lombok.Value;

/*
 * @created by 24/01/2026  - 21:51
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Value
@Builder
public class RequestOverrideV2 {
   Boolean disableRetry;
   Boolean disableCircuitBreaker;
   Boolean disableRateLimiter;
   Boolean disableBulkhead;
   Boolean disableLogging;
   Boolean disableObservability;
   TimeoutConfigV2 timeoutOverride;

   public static RequestOverrideV2 none() {
      return RequestOverrideV2.builder().build();
   }
}
