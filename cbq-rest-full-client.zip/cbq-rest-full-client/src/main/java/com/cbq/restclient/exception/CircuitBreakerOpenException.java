package com.cbq.restclient.exception;

/**
 * Thrown when circuit breaker is open and rejects requests
 */
public class CircuitBreakerOpenException extends CBQRestClientException {
    private final String circuitBreakerName;
    
    public CircuitBreakerOpenException(String circuitBreakerName, String requestId, String uri, String method) {
        super("Circuit breaker '" + circuitBreakerName + "' is open", requestId, uri, method);
        this.circuitBreakerName = circuitBreakerName;
    }
    
    public String getCircuitBreakerName() { return circuitBreakerName; }
}
