package com.cbq.restclient.core;

import com.cbq.restclient.config.*;
import com.cbq.restclient.email.EmailNotifier;
import com.cbq.restclient.filter.*;
import com.cbq.restclient.logging.LoggingService;
import com.cbq.restclient.resilience.ResilienceManager;
import com.cbq.restclient.ssl.SslContextFactory;
import com.cbq.restclient.tracing.TracingService;
import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Builder for creating CBQRestClient instances.
 * 
 * <pre>{@code
 * CBQRestClient client = CBQRestClient.builder()
 *     .baseUrl("https://api.service.com")
 *     .timeouts(TimeoutConfig.defaults()
 *         .connection(Duration.ofSeconds(3))
 *         .read(Duration.ofSeconds(5))
 *         .response(Duration.ofSeconds(10)))
 *     .ssl(SslConfig.custom()
 *         .certificatePath("/certs/service.pem"))
 *     .resilience(ResilienceConfig.custom()
 *         .retry(RetryConfig.custom().maxAttempts(3))
 *         .circuitBreaker(CircuitBreakerConfig.custom().failureRate(50))
 *         .bulkhead(BulkheadConfig.custom().maxConcurrentCalls(50)))
 *     .logging(LoggingConfig.custom()
 *         .logAll()
 *         .maskFields("password", "token")
 *         .maxBodySize(10000))
 *     .metricsEnabled(true)
 *     .tracingEnabled(true)
 *     .build();
 * }</pre>
 */
public class CBQRestClientBuilder {

    private final CBQRestClientConfig config;
    
    // Spring integration (optional)
    private JavaMailSender javaMailSender;
    private TaskExecutor taskExecutor;

    private CBQRestClientBuilder() {
        this.config = CBQRestClientConfig.create();
    }

    private CBQRestClientBuilder(String name) {
        this.config = CBQRestClientConfig.create(name);
    }

    public static CBQRestClientBuilder builder() {
        return new CBQRestClientBuilder();
    }

    public static CBQRestClientBuilder builder(String name) {
        return new CBQRestClientBuilder(name);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Configuration Methods
    // ═══════════════════════════════════════════════════════════════════════════

    public CBQRestClientBuilder baseUrl(String baseUrl) {
        config.baseUrl(baseUrl);
        return this;
    }

    public CBQRestClientBuilder header(String name, String value) {
        config.header(name, value);
        return this;
    }

    public CBQRestClientBuilder headers(Consumer<Map<String, String>> consumer) {
        config.headers(consumer);
        return this;
    }

    public CBQRestClientBuilder timeouts(TimeoutConfig timeouts) {
        config.timeouts(timeouts);
        return this;
    }

    public CBQRestClientBuilder ssl(SslConfig ssl) {
        config.ssl(ssl);
        return this;
    }

    public CBQRestClientBuilder resilience(ResilienceConfig resilience) {
        config.resilience(resilience);
        return this;
    }

    public CBQRestClientBuilder logging(LoggingConfig logging) {
        config.logging(logging);
        return this;
    }

    public CBQRestClientBuilder emailNotifier(EmailNotifierConfig emailNotifier) {
        config.emailNotifier(emailNotifier);
        return this;
    }

    public CBQRestClientBuilder tracing(TracingConfig tracing) {
        config.tracing(tracing);
        return this;
    }

    public CBQRestClientBuilder metrics(MetricsConfig metrics) {
        config.metrics(metrics);
        return this;
    }

    public CBQRestClientBuilder metricsEnabled(boolean enabled) {
        config.metricsEnabled(enabled);
        return this;
    }

    public CBQRestClientBuilder tracingEnabled(boolean enabled) {
        config.tracingEnabled(enabled);
        return this;
    }

    public CBQRestClientBuilder addRequestFilter(RequestFilter filter) {
        config.addRequestFilter(filter);
        return this;
    }

    public CBQRestClientBuilder addResponseFilter(ResponseFilter filter) {
        config.addResponseFilter(filter);
        return this;
    }

    public CBQRestClientBuilder addErrorMapper(ErrorMapper mapper) {
        config.addErrorMapper(mapper);
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Spring Integration (Optional)
    // ═══════════════════════════════════════════════════════════════════════════

    public CBQRestClientBuilder withSpringMailSender(JavaMailSender mailSender) {
        this.javaMailSender = mailSender;
        return this;
    }

    public CBQRestClientBuilder withSpringTaskExecutor(TaskExecutor taskExecutor) {
        this.taskExecutor = taskExecutor;
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Build
    // ═══════════════════════════════════════════════════════════════════════════

    public CBQRestClient build() {
        // Create WebClient
        WebClient webClient = createWebClient();
        
        // Create services
        ResilienceManager resilienceManager = new ResilienceManager(
                config.getName(), config.getResilience());
        
        LoggingService loggingService = new LoggingService(config.getLogging());
        
        TracingService tracingService = new TracingService(config.getTracing());
        
        // Create email notifier with Spring integration if available
        TaskExecutor executor = taskExecutor != null ? taskExecutor : createDefaultTaskExecutor();
        EmailNotifier emailNotifier = new EmailNotifier(
                config.getEmailNotifier(), javaMailSender, executor);
        
        return new CBQRestClient(config, webClient, resilienceManager, 
                loggingService, emailNotifier, tracingService);
    }

    private WebClient createWebClient() {
        TimeoutConfig timeouts = config.getTimeouts();
        
        HttpClient httpClient = HttpClient.create()
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 
                        (int) timeouts.getConnectionTimeout().toMillis())
                .doOnConnected(conn -> conn
                        .addHandlerLast(new ReadTimeoutHandler(
                                timeouts.getReadTimeout().toMillis(), TimeUnit.MILLISECONDS))
                        .addHandlerLast(new WriteTimeoutHandler(
                                timeouts.getWriteTimeout().toMillis(), TimeUnit.MILLISECONDS)));

        // Configure SSL
        SslConfig sslConfig = config.getSsl();
        if (sslConfig.isEnabled()) {
            SslContext sslContext = SslContextFactory.create(sslConfig);
            if (sslContext != null) {
                httpClient = httpClient.secure(spec -> spec.sslContext(sslContext)
                        .handshakeTimeout(sslConfig.getHandshakeTimeout()));
            }
        }

        // Build WebClient
        WebClient.Builder builder = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer -> configurer.defaultCodecs()
                                .maxInMemorySize(16 * 1024 * 1024))
                        .build());

        if (config.getBaseUrl() != null && !config.getBaseUrl().isEmpty()) {
            builder.baseUrl(config.getBaseUrl());
        }

        if (!config.getDefaultHeaders().isEmpty()) {
            builder.defaultHeaders(headers -> 
                    config.getDefaultHeaders().forEach(headers::add));
        }

        builder.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        return builder.build();
    }

    private TaskExecutor createDefaultTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(4);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("cbq-async-");
        executor.setDaemon(true);
        executor.initialize();
        return executor;
    }
}
