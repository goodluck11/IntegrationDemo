package com.cbq.restclient.exception;

import lombok.Getter;

/**
 * Thrown when rate limit is exceeded
 */
@Getter
public class RateLimitExceededException extends CBQRestClientException {
    private final String rateLimiterName;
    
    public RateLimitExceededException(String rateLimiterName, String requestId, String uri, String method) {
        super("Rate limit exceeded for '" + rateLimiterName + "'", requestId, uri, method);
        this.rateLimiterName = rateLimiterName;
    }

}
