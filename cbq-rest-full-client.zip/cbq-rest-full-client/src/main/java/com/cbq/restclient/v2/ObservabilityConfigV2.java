package com.cbq.restclient.v2;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.Builder;
import lombok.Value;

/*
 * @created by 24/01/2026  - 21:39
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Value
@Builder
public class ObservabilityConfigV2 {
   boolean enabled;
   MeterRegistry meterRegistry;
   String clientName;

   public static ObservabilityConfigV2 disabled() {
      return ObservabilityConfigV2.builder().enabled(false).build();
   }
}
