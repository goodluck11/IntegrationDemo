package com.cbq.restclient.resilience;

import com.cbq.restclient.config.ResilienceConfig;
import com.cbq.restclient.config.ResilienceConfig.*;
import com.cbq.restclient.config.RequestOverride;
import com.cbq.restclient.exception.*;
import io.github.resilience4j.bulkhead.Bulkhead;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.ratelimiter.RateLimiterRegistry;
import io.github.resilience4j.reactor.bulkhead.operator.BulkheadOperator;
import io.github.resilience4j.reactor.circuitbreaker.operator.CircuitBreakerOperator;
import io.github.resilience4j.reactor.ratelimiter.operator.RateLimiterOperator;
import io.github.resilience4j.reactor.retry.RetryOperator;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.ConnectException;
import java.time.Duration;
import java.util.concurrent.TimeoutException;

/**
 * Manages Resilience4j patterns: Retry, Circuit Breaker, Rate Limiter, Bulkhead.
 */
public class ResilienceManager {
    private static final Logger log = LoggerFactory.getLogger(ResilienceManager.class);

    private final String name;
    private final ResilienceConfig config;

   // Getters for metrics/monitoring
   @Getter
   private final Retry retry;
    @Getter
    private final CircuitBreaker circuitBreaker;
    @Getter
    private final RateLimiter rateLimiter;
    @Getter
    private final Bulkhead bulkhead;

    public ResilienceManager(String name, ResilienceConfig config) {
        this.name = name;
        this.config = config;
        
        this.retry = createRetry(config.getRetryConfig());
        this.circuitBreaker = createCircuitBreaker(config.getCircuitBreakerConfig());
        this.rateLimiter = createRateLimiter(config.getRateLimiterConfig());
        this.bulkhead = createBulkhead(config.getBulkheadConfig());
        
        registerEventListeners();
    }

    /**
     * Applies resilience patterns to a Mono with optional per-request overrides
     */
    public <T> Mono<T> applyResilience(Mono<T> mono, RequestOverride override, 
                                        String requestId, String uri, String method) {
        // Apply in order: Bulkhead -> RateLimiter -> CircuitBreaker -> Retry
        // (innermost to outermost)
        
        // Retry (innermost - retries happen first)
        if (isRetryEnabled(override)) {
            mono = mono.transformDeferred(RetryOperator.of(retry))
                    .onErrorMap(io.github.resilience4j.retry.MaxRetriesExceededException.class,
                            e -> new CBQRestClientException("Max retries exceeded", e, requestId, uri, method));
        }
        
        // Circuit Breaker
        if (isCircuitBreakerEnabled(override)) {
            mono = mono.transformDeferred(CircuitBreakerOperator.of(circuitBreaker))
                    .onErrorMap(io.github.resilience4j.circuitbreaker.CallNotPermittedException.class,
                            e -> new CircuitBreakerOpenException(name, requestId, uri, method));
        }
        
        // Rate Limiter
        if (isRateLimiterEnabled(override)) {
            mono = mono.transformDeferred(RateLimiterOperator.of(rateLimiter))
                    .onErrorMap(io.github.resilience4j.ratelimiter.RequestNotPermitted.class,
                            e -> new RateLimitExceededException(name, requestId, uri, method));
        }
        
        // Bulkhead (outermost - controls concurrency)
        if (isBulkheadEnabled(override)) {
            mono = mono.transformDeferred(BulkheadOperator.of(bulkhead))
                    .onErrorMap(io.github.resilience4j.bulkhead.BulkheadFullException.class,
                            e -> new BulkheadFullException(name, requestId, uri, method));
        }
        
        return mono;
    }

    private boolean isRetryEnabled(RequestOverride override) {
        if (override != null && override.getRetryEnabled() != null) {
            return override.getRetryEnabled();
        }
        return config.getRetryConfig().isEnabled();
    }

    private boolean isCircuitBreakerEnabled(RequestOverride override) {
        if (override != null && override.getCircuitBreakerEnabled() != null) {
            return override.getCircuitBreakerEnabled();
        }
        return config.getCircuitBreakerConfig().isEnabled();
    }

    private boolean isRateLimiterEnabled(RequestOverride override) {
        if (override != null && override.getRateLimiterEnabled() != null) {
            return override.getRateLimiterEnabled();
        }
        return config.getRateLimiterConfig().isEnabled();
    }

    private boolean isBulkheadEnabled(RequestOverride override) {
        if (override != null && override.getBulkheadEnabled() != null) {
            return override.getBulkheadEnabled();
        }
        return config.getBulkheadConfig().isEnabled();
    }

    private Retry createRetry(ResilienceConfig.RetryConfig cfg) {
        if (!cfg.isEnabled()) return null;

        io.github.resilience4j.retry.RetryConfig.Builder builder = 
            io.github.resilience4j.retry.RetryConfig.custom()
                .maxAttempts(cfg.getMaxAttempts())
                .waitDuration(cfg.getWaitDuration());

        // Configure backoff strategy
        switch (cfg.getBackoffStrategy()) {
            case EXPONENTIAL:
                builder.intervalFunction(io.github.resilience4j.core.IntervalFunction
                        .ofExponentialBackoff(cfg.getWaitDuration(), cfg.getBackoffMultiplier()));
                break;
            case EXPONENTIAL_WITH_JITTER:
                builder.intervalFunction(io.github.resilience4j.core.IntervalFunction
                        .ofExponentialRandomBackoff(cfg.getWaitDuration(), cfg.getBackoffMultiplier()));
                break;
            case FIXED:
            default:
                // Default fixed interval
                break;
        }

        // Configure retry predicate
        builder.retryOnException(ex -> {
           if (cfg.isRetryOnConnectionTimeout() && isConnectionTimeout((Throwable) ex)) return true;
           if (cfg.isRetryOnReadTimeout() && isReadTimeout((Throwable) ex)) return true;
           for (Class<? extends Throwable> retryEx : cfg.getRetryExceptions()) {
              if (retryEx.isInstance(ex)) return true;
           }
           return false;
        });

        // Configure ignore exceptions
        if (!cfg.getIgnoreExceptions().isEmpty()) {
            builder.ignoreExceptions(cfg.getIgnoreExceptions().toArray(new Class[0]));
        }

        return RetryRegistry.of(builder.build()).retry(name);
    }

    private CircuitBreaker createCircuitBreaker(ResilienceConfig.CircuitBreakerConfig cfg) {
        if (!cfg.isEnabled()) return null;

        io.github.resilience4j.circuitbreaker.CircuitBreakerConfig cbConfig = 
            io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.custom()
                .slidingWindowSize(cfg.getWindowSize())
                .minimumNumberOfCalls(cfg.getMinCalls())
                .permittedNumberOfCallsInHalfOpenState(cfg.getHalfOpenCalls())
                .failureRateThreshold(cfg.getFailureRate())
                .slowCallRateThreshold(cfg.getSlowCallRate())
                .slowCallDurationThreshold(cfg.getSlowCallDuration())
                .waitDurationInOpenState(cfg.getOpenStateWait())
                .automaticTransitionFromOpenToHalfOpenEnabled(cfg.isAutoTransition())
                .build();

        return CircuitBreakerRegistry.of(cbConfig).circuitBreaker(name);
    }

    private RateLimiter createRateLimiter(ResilienceConfig.RateLimiterConfig cfg) {
        if (!cfg.isEnabled()) return null;

        io.github.resilience4j.ratelimiter.RateLimiterConfig rlConfig = 
            io.github.resilience4j.ratelimiter.RateLimiterConfig.custom()
                .limitForPeriod(cfg.getLimitForPeriod())
                .limitRefreshPeriod(cfg.getRefreshPeriod())
                .timeoutDuration(cfg.getTimeout())
                .build();

        return RateLimiterRegistry.of(rlConfig).rateLimiter(name);
    }

    private Bulkhead createBulkhead(ResilienceConfig.BulkheadConfig cfg) {
        if (!cfg.isEnabled()) return null;

        io.github.resilience4j.bulkhead.BulkheadConfig bhConfig = 
            io.github.resilience4j.bulkhead.BulkheadConfig.custom()
                .maxConcurrentCalls(cfg.getMaxConcurrentCalls())
                .maxWaitDuration(cfg.getMaxWait())
                .build();

        return BulkheadRegistry.of(bhConfig).bulkhead(name);
    }

    private void registerEventListeners() {
        if (circuitBreaker != null) {
            circuitBreaker.getEventPublisher()
                .onStateTransition(event -> 
                    log.info("Circuit breaker '{}' state changed: {} -> {}", 
                        name, event.getStateTransition().getFromState(), 
                        event.getStateTransition().getToState()));
        }
        
        if (retry != null) {
            retry.getEventPublisher()
                .onRetry(event -> 
                    log.debug("Retry attempt {} for '{}': {}", 
                        event.getNumberOfRetryAttempts(), name, event.getLastThrowable().getMessage()));
        }
    }

    private boolean isConnectionTimeout(Throwable ex) {
        return ex instanceof ConnectException ||
               (ex.getCause() != null && ex.getCause() instanceof ConnectException) ||
               (ex.getMessage() != null && ex.getMessage().toLowerCase().contains("connection timed out"));
    }

    private boolean isReadTimeout(Throwable ex) {
        return ex instanceof java.net.SocketTimeoutException ||
               ex instanceof TimeoutException ||
               (ex.getMessage() != null && ex.getMessage().toLowerCase().contains("read timed out"));
    }

}
