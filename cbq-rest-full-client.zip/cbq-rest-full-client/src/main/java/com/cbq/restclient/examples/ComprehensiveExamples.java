package com.cbq.restclient.examples;

import com.cbq.restclient.config.*;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQRestClientBuilder;
import com.cbq.restclient.exception.*;
import com.cbq.restclient.filter.*;
import com.cbq.restclient.model.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import static java.lang.System.err;
import static java.lang.System.out;

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * CBQ REST CLIENT v2.0 - COMPREHENSIVE EXAMPLES (ALL FEATURES)
 * ═══════════════════════════════════════════════════════════════════════════════
 */
public class ComprehensiveExamples {

   // ═══════════════════════════════════════════════════════════════════════════
   // MODELS (Using Lombok)
   // ═══════════════════════════════════════════════════════════════════════════

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class User {
      private Long id;
      private String name;
      private String email;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class Order {
      private Long id;
      private Long userId;
      private String status;
      private Double amount;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class Product {
      private Long id;
      private String name;
      private Double price;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class PaymentRequest {
      private Long orderId;
      private Double amount;
      private String currency;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class PaymentResult {
      private String transactionId;
      private String status;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class CreateUserRequest {
      private String name;
      private String email;
   }

   // Custom Exceptions
   static class UserNotFoundException extends RuntimeException {
      public UserNotFoundException(String message) {
         super(message);
      }
   }

   static class OrderNotFoundException extends RuntimeException {
      public OrderNotFoundException(String message) {
         super(message);
      }
   }

   static class ServiceUnavailableException extends RuntimeException {
      public ServiceUnavailableException(String message) {
         super(message);
      }
   }

   static class UnauthorizedException extends RuntimeException {
      public UnauthorizedException(String message) {
         super(message);
      }
   }

   static class RateLimitException extends RuntimeException {
      public RateLimitException(String message) {
         super(message);
      }
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 1. FULL CLIENT CONFIGURATION
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Production-ready client with all features enabled
    */
   public static CBQRestClient createFullyConfiguredClient() {
      return CBQRestClientBuilder.builder("user-service")
              .baseUrl("https://api.example.com/v1")

              // ─────────────────────────────────────────────────────────────────
              // TIMEOUTS (All 4 types)
              // ─────────────────────────────────────────────────────────────────
              .timeouts(TimeoutConfig.custom()
                      .connection(Duration.ofSeconds(3))   // TCP connection
                      .read(Duration.ofSeconds(10))        // Between data packets
                      .write(Duration.ofSeconds(10))       // Write operation
                      .response(Duration.ofSeconds(30)))   // Total response time

              // ─────────────────────────────────────────────────────────────────
              // DEFAULT HEADERS
              // ─────────────────────────────────────────────────────────────────
              .headers(h -> {
                 h.put("X-Application", "my-app");
                 h.put("X-Environment", "production");
                 h.put("Accept-Language", "en-US");
              })

              // ─────────────────────────────────────────────────────────────────
              // SSL CONFIGURATION
              // ─────────────────────────────────────────────────────────────────
              .ssl(SslConfig.custom()
                      .certificatePath("/etc/ssl/certs/api-cert.pem")
                      .handshakeTimeout(Duration.ofSeconds(10)))

              // ─────────────────────────────────────────────────────────────────
              // RESILIENCE (Retry, Circuit Breaker, Rate Limiter, Bulkhead)
              // ─────────────────────────────────────────────────────────────────
              .resilience(ResilienceConfig.custom()
                      // Retry Configuration
                      .retry(ResilienceConfig.RetryConfig.custom()
                              .maxAttempts(3)
                              .waitDuration(Duration.ofMillis(500))
                              .backoff(ResilienceConfig.BackoffStrategy.EXPONENTIAL_WITH_JITTER)
                              .backoffMultiplier(2.0)
                              .maxBackoff(Duration.ofSeconds(10))
                              .retryOnConnectionTimeout(true)
                              .retryOnReadTimeout(true)
                              .retryOnExceptions(IOException.class))

                      // Circuit Breaker Configuration
                      .circuitBreaker(ResilienceConfig.CircuitBreakerConfig.custom()
                              .windowSize(100)
                              .minCalls(10)
                              .failureRate(50)
                              .slowCallRate(80)
                              .slowCallDuration(Duration.ofSeconds(2))
                              .openStateWait(Duration.ofSeconds(60))
                              .halfOpenCalls(5)
                              .autoTransition(true))

                      // Rate Limiter Configuration
                      .rateLimiter(ResilienceConfig.RateLimiterConfig.custom()
                              .limitForPeriod(100)           // 100 requests
                              .refreshPeriod(Duration.ofSeconds(1))  // per second
                              .timeout(Duration.ofMillis(500)))      // wait up to 500ms

                      // Bulkhead Configuration (Thread Isolation)
                      .bulkhead(ResilienceConfig.BulkheadConfig.custom()
                              .maxConcurrentCalls(25)        // Max 25 concurrent calls
                              .maxWait(Duration.ofMillis(100))))  // Wait up to 100ms

              // ─────────────────────────────────────────────────────────────────
              // LOGGING (Safe: max body size, async, content-type aware)
              // ─────────────────────────────────────────────────────────────────
              .logging(LoggingConfig.custom()
                      .logAll()                              // Log request + response + headers
                      .maskFields("password", "token", "apiKey", "secret", "authorization")
                      .maskField("creditCard", 4)            // Show last 4 chars
                      .excludeFields("internalId")           // Never log this field
                      .maskSymbol('*')
                      .maxBodySize(10_000))                  // Max 10KB body logged

              // ─────────────────────────────────────────────────────────────────
              // EMAIL NOTIFICATIONS (Rate limited, Circuit Breaker protected)
              // ─────────────────────────────────────────────────────────────────
              .emailNotifier(EmailNotifierConfig.custom()
                      .async(true)                           // Never block HTTP threads
                      .rateLimit(5, Duration.ofMinutes(1))   // Max 5 emails per minute
                      .circuitBreaker(true)
                      .circuitBreakerThreshold(3)            // Open after 3 failures
                      .circuitBreakerResetTime(Duration.ofMinutes(5))
                      .host("smtp.company.com")
                      .port(587)
                      .credentials("alerts@company.com", "password")
                      .startTls(true)
                      .defaultFrom("noreply@company.com")
                      .defaultTo("ops-team@company.com", "dev-team@company.com")
                      .defaultSubject("API Error Alert"))

              // ─────────────────────────────────────────────────────────────────
              // TRACING (Correlation ID, OpenTelemetry)
              // ─────────────────────────────────────────────────────────────────
              .tracing(TracingConfig.custom()
                      .correlationId(true)
                      .correlationIdHeader("X-Correlation-Id")
                      .generateCorrelationIdIfMissing(true)
                      .openTelemetry(true)
                      .propagateHeaders("X-Request-Id", "X-Session-Id"))

              // ─────────────────────────────────────────────────────────────────
              // METRICS (Micrometer)
              // ─────────────────────────────────────────────────────────────────
              .metrics(MetricsConfig.custom()
                      .metricPrefix("cbq.http.client")
                      .commonTag("service", "user-service")
                      .normalizeUri(true)                    // Prevent high cardinality
                      .maxUriSegments(5))

              // ─────────────────────────────────────────────────────────────────
              // REQUEST FILTERS
              // ─────────────────────────────────────────────────────────────────
              .addRequestFilter(Filters.bearerToken(() -> getAuthToken()))
              .addRequestFilter(Filters.timestamp("X-Request-Timestamp"))
              .addRequestFilter(Filters.auditLog("user-service"))

              // ─────────────────────────────────────────────────────────────────
              // RESPONSE FILTERS
              // ─────────────────────────────────────────────────────────────────
              .addResponseFilter(Filters.slowResponseLog(2000))  // Log if > 2s
              .addResponseFilter(Filters.errorLog())

              // ─────────────────────────────────────────────────────────────────
              // GLOBAL ERROR MAPPERS
              // ─────────────────────────────────────────────────────────────────
              .addErrorMapper(ErrorMapper.on401(ctx ->
                      new UnauthorizedException("Auth failed: " + ctx.getUri())))
              .addErrorMapper(ErrorMapper.on429(ctx ->
                      new RateLimitException("Rate limited: " + ctx.getUri())))

              .build();
   }

   private static String getAuthToken() {
      // In real app, get from auth service or cache
      return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 2. ERROR HANDLING (onStatus THROWS exceptions via Mono.error)
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * onStatus() THROWS the exception - it's converted to Mono.error()
    */
   public static void errorHandlingExamples(CBQRestClient client) {

      // ─────────────────────────────────────────────────────────────────
      // Example 2.1: Basic error mapping - THROWS UserNotFoundException
      // ─────────────────────────────────────────────────────────────────
      try {
         CBQResponse<User> block = client.get()
                 .uri("/users/999")  // Non-existent user
                 .onStatus(
                         status -> status.value() == 404,
                         ctx -> new UserNotFoundException("User not found: " + ctx.getUri())
                 )
                 .retrieve(User.class)
                 .block();
      } catch (UserNotFoundException e) {
         err.println("Caught: " + e.getMessage());
         // Output: Caught: User not found: /users/999
      }

      // ─────────────────────────────────────────────────────────────────
      // Example 2.2: Multiple error mappers
      // ─────────────────────────────────────────────────────────────────
      try {
         CBQResponse<User> block = client.get()
                 .uri("/users/123")
                 .onStatus(status -> status.value() == 404,
                         ctx -> new UserNotFoundException("User " + extractId(ctx.getUri()) + " not found"))
                 .onStatus(status -> status.value() == 401,
                         ctx -> new UnauthorizedException("Not authorized to access user"))
                 .onStatus(status -> status.value() == 403,
                         ctx -> new SecurityException("Forbidden: " + ctx.getResponseBody()))
                 .onStatus(HttpStatus::is5xxServerError,
                         ctx -> new ServiceUnavailableException("Service error: " + ctx.getStatusCode()))
                 .retrieve(User.class)
                 .block();
      } catch (UserNotFoundException | UnauthorizedException | ServiceUnavailableException e) {
         err.println("Error: " + e.getClass().getSimpleName() + " - " + e.getMessage());
      }

      // ─────────────────────────────────────────────────────────────────
      // Example 2.3: Using ErrorMapper helpers
      // ─────────────────────────────────────────────────────────────────
      try {
         CBQResponse<Order> orderNotFound = client.get()
                 .uri("/orders/456")
                 .onStatus(status -> status.value() == 404,
                         ctx -> new OrderNotFoundException("Order not found"))
                 .onStatus(status -> status.value() == 400,
                         ErrorMapper.ErrorContext::toException)  // Uses built-in exception
                 .retrieve(Order.class)
                 .block();
      } catch (OrderNotFoundException e) {
         // Handle not found
      } catch (CBQRestClientException e) {
         // Handle other errors
         err.println("Request failed: " + e.getRequestId());
      }

      // ─────────────────────────────────────────────────────────────────
      // Example 2.4: Reactive error handling (non-blocking)
      // ─────────────────────────────────────────────────────────────────
      client.get()
              .uri("/users/123")
              .onStatus(status -> status.value() == 404,
                      ctx -> new UserNotFoundException("Not found"))
              .retrieve(User.class)
              .doOnNext(user -> out.println("Got user: " + user.getBody().getName()))
              .doOnError(UserNotFoundException.class, e ->
                      err.println("User not found!"))
              .doOnError(CBQRestClientException.class, e ->
                      err.println("Request error: " + e.getMessage()))
              .onErrorResume(UserNotFoundException.class, e ->
                      Mono.just(CBQResponse.<User>builder()
                              .body(new User(0L, "Unknown", "unknown@example.com"))
                              .build())
              )
              .subscribe(
                      user -> out.println("Final user: " + user.getBody().getName()),
                      error -> err.println("Unhandled error: " + error.getMessage())
              );
   }

   private static String extractId(String uri) {
      String[] parts = uri.split("/");
      return parts[parts.length - 1];
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 3. ALL OVERRIDE EXAMPLES
   // ═══════════════════════════════════════════════════════════════════════════

   public static void allOverrideExamples(CBQRestClient client) {

      // ─────────────────────────────────────────────────────────────────
      // Example 3.1: Timeout Override - Read Timeout Only
      // ─────────────────────────────────────────────────────────────────
      CBQResponse<byte[]> largeFile = client.get()
              .uri("/files/large-report.pdf")
              .override(o -> o
                      .timeouts(t -> t.read(Duration.ofMinutes(5))))  // Only override read
              .retrieve(byte[].class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.2: Timeout Override - All Timeouts
      // ─────────────────────────────────────────────────────────────────
      CBQResponse<String> slowEndpoint = client.get()
              .uri("/reports/generate")
              .override(o -> o
                      .timeouts(t -> t
                              .connection(Duration.ofSeconds(10))
                              .read(Duration.ofMinutes(2))
                              .write(Duration.ofSeconds(30))
                              .response(Duration.ofMinutes(3))))
              .retrieve(String.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.3: Disable Retry Only
      // ─────────────────────────────────────────────────────────────────
      // Use for non-idempotent operations like payments
      CBQResponse<PaymentResult> payment = client.post()
              .uri("/payments/process")
              .bodyValue(new PaymentRequest(123L, 99.99, "USD"))
              .override(o -> o.disableRetry())  // Don't retry payments!
              .retrieve(PaymentResult.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.4: Disable Circuit Breaker Only
      // ─────────────────────────────────────────────────────────────────
      // For critical health checks that should always attempt
      CBQResponse<String> health = client.get()
              .uri("/health")
              .override(o -> o.disableCircuitBreaker())
              .retrieve(String.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.5: Disable Rate Limiter Only
      // ─────────────────────────────────────────────────────────────────
      // For admin/priority operations
      CBQResponse<String> adminOp = client.post()
              .uri("/admin/critical-operation")
              .override(o -> o.disableRateLimiter())
              .retrieve(String.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.6: Disable Bulkhead Only
      // ─────────────────────────────────────────────────────────────────
      CBQResponse<String> urgent = client.get()
              .uri("/urgent/request")
              .override(o -> o.disableBulkhead())
              .retrieve(String.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.7: Disable ALL Resilience
      // ─────────────────────────────────────────────────────────────────
      // For testing or when you need raw behavior
      CBQResponse<String> raw = client.get()
              .uri("/test/endpoint")
              .override(RequestOverride::disableAllResilience)
              .retrieve()
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.8: Custom Retry Settings
      // ─────────────────────────────────────────────────────────────────
      CBQResponse<String> customRetry = client.get()
              .uri("/flaky/endpoint")
              .override(o -> o
                      .maxAttempts(5)
                      .waitDuration(Duration.ofSeconds(2)))
              .retrieve(String.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.9: Combined Overrides
      // ─────────────────────────────────────────────────────────────────
      CBQResponse<String> combined = client.post()
              .uri("/complex/operation")
              .bodyValue(Map.of("key", "value"))
              .override(o -> o
                      .disableRetry()              // Non-idempotent
                      .disableCircuitBreaker()     // Critical operation
                      .timeouts(t -> t
                              .read(Duration.ofMinutes(1))
                              .response(Duration.ofMinutes(2))))
              .retrieve(String.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 3.10: Timeout Override with Disable
      // ─────────────────────────────────────────────────────────────────
      CBQResponse<String> longRunning = client.post()
              .uri("/batch/process")
              .bodyValue(List.of(1, 2, 3, 4, 5))
              .override(o -> o
                      .disableRetry()                          // Don't retry batch
                      .disableCircuitBreaker()                 // Batch is expected to be slow
                      .timeouts(t -> t.read(Duration.ofMinutes(10))))  // Long read timeout
              .retrieve(String.class)
              .block();
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 4. PARALLEL CALLS - WAIT FOR ALL
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Parallel execution with waitAll() - uses Mono.zip under the hood
    * All requests must succeed, or the entire operation fails
    */
   public static void parallelWaitForAll(CBQRestClient client) {

      // Execute 3 requests in parallel
      CBQParallelResult<Object> result = client.parallel(
              client.get().uri("/users/1").retrieve(Object.class),
              client.get().uri("/orders/100").retrieve(Object.class),
              client.get().uri("/products/50").retrieve(Object.class)
      ).waitAll().execute().block();

      // ─────────────────────────────────────────────────────────────────
      // How the response looks and is used:
      // ─────────────────────────────────────────────────────────────────
      if (result != null) {
         // Check overall result
         out.println("All successful: " + result.allSuccessful());  // true
         out.println("Total duration: " + result.getTotalDurationMs() + "ms");
         out.println("Response count: " + result.size());  // 3
         out.println("Success count: " + result.successCount());  // 3
         out.println("Error count: " + result.errorCount());  // 0

         // Get individual responses by index
         CBQResponse<Object> userResponse = result.getResponse(0);
         CBQResponse<Object> orderResponse = result.getResponse(1);
         CBQResponse<Object> productResponse = result.getResponse(2);

         // Access bodies (need to cast)
         User user = userResponse.bodyAs(User.class);
         Order order = orderResponse.bodyAs(Order.class);
         Product product = productResponse.bodyAs(Product.class);

         out.println("User: " + user.getName());
         out.println("Order: " + order.getStatus());
         out.println("Product: " + product.getName());

         // Access response metadata
         out.println("User request ID: " + userResponse.getRequestId());
         out.println("User status: " + userResponse.getStatusCode());
         out.println("User duration: " + userResponse.getDurationMs() + "ms");
         out.println("User correlation ID: " + userResponse.getCorrelationId());

         // Get all bodies as list
         List<Object> allBodies = result.getBodies();
         out.println("All bodies: " + allBodies.size());

         // Get all successful responses
         List<CBQResponse<Object>> successfulResponses = result.getSuccessfulResponses();
      }

      // ─────────────────────────────────────────────────────────────────
      // Type-safe parallel (same type)
      // ─────────────────────────────────────────────────────────────────
      CBQParallelResult<User> usersResult = client.parallel(
              client.get().uri("/users/1").retrieve(User.class),
              client.get().uri("/users/2").retrieve(User.class),
              client.get().uri("/users/3").retrieve(User.class)
      ).waitAll().execute().block();

      // Direct access without casting
      List<User> users = usersResult.getBodies();
      users.forEach(u -> out.println("User: " + u.getName()));
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 5. PARALLEL CALLS - FAIL FAST
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Parallel execution with failFast() - uses Flux.merge
    * Fails immediately on first error, cancels remaining requests
    */
   public static void parallelFailFast(CBQRestClient client) {

      try {
         CBQParallelResult<User> result = client.parallel(
                 client.get().uri("/users/1").retrieve(User.class),
                 client.get().uri("/users/999").retrieve(User.class),  // This will 404
                 client.get().uri("/users/3").retrieve(User.class)
         ).failFast().execute().block();

         // This won't be reached if any request fails
         out.println("All succeeded: " + result.successCount());

      } catch (CBQRestClientException e) {
         // Catch the first failure
         err.println("Fail fast triggered!");
         err.println("Error: " + e.getMessage());
         err.println("Request ID: " + e.getRequestId());
         err.println("URI: " + e.getUri());
      }

      // ─────────────────────────────────────────────────────────────────
      // With error mapping
      // ─────────────────────────────────────────────────────────────────
      try {
         client.parallel(
                 client.get().uri("/users/1")
                         .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException("User 1 not found"))
                         .retrieve(User.class),
                 client.get().uri("/users/999")
                         .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException("User 999 not found"))
                         .retrieve(User.class)
         ).failFast().execute().block();

      } catch (UserNotFoundException e) {
         err.println("User not found: " + e.getMessage());
      }
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 6. PARALLEL CALLS - PARTIAL SUCCESS
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Parallel execution with partialSuccess() - continues on errors
    * Collects all successful responses and all errors separately
    */
   public static void parallelPartialSuccess(CBQRestClient client) {

      CBQParallelResult<User> result = client.parallel(
              client.get().uri("/users/1").retrieve(User.class),      // OK
              client.get().uri("/users/999").retrieve(User.class),    // 404
              client.get().uri("/users/3").retrieve(User.class),      // OK
              client.get().uri("/users/888").retrieve(User.class)     // 404
      ).partialSuccess().execute().block();

      // ─────────────────────────────────────────────────────────────────
      // How to use the response:
      // ─────────────────────────────────────────────────────────────────

      out.println("Has errors: " + result.hasErrors());     // true
      out.println("Success count: " + result.successCount());  // 2
      out.println("Error count: " + result.errorCount());      // 2
      out.println("Total: " + result.size());                  // 4

      // Get successful responses
      List<CBQResponse<User>> successful = result.getSuccessfulResponses();
      out.println("Successful users:");
      for (CBQResponse<User> resp : successful) {
         out.println("  - " + resp.getBody().getName() + " (id=" + resp.getBody().getId() + ")");
      }

      // Get errors by index
      Map<Integer, Throwable> errors = result.getErrors();
      out.println("Errors:");
      errors.forEach((index, error) -> {
         out.println("  - Index " + index + ": " + error.getMessage());
      });

      // Check specific index
      if (result.getError(1) != null) {
         out.println("Request at index 1 failed: " + result.getError(1).getMessage());
      }

      // Get all bodies (only from successful)
      List<User> users = result.getBodies();
      out.println("Got " + users.size() + " users successfully");
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 7. SEQUENTIAL CALLS - DEPENDENT CHAIN
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Sequential chaining - each step depends on previous result
    */
   public static void sequentialChainExamples(CBQRestClient client) {

      // ─────────────────────────────────────────────────────────────────
      // Example 7.1: Basic chain WITHOUT overrides
      // ─────────────────────────────────────────────────────────────────
      // Get user -> Get user's orders -> Get first order's product
      Product product = client.sequence()
              // Step 1: Get user
              .then(() -> client.get()
                      .uri("/users/123")
                      .retrieve(User.class))
              // Step 2: Use user ID to get their orders
              .then((User user) -> client.get()
                      .uri("/orders?userId=" + user.getId())
                      .retrieve(Order[].class))
              // Step 3: Use first order to get product
              .then((Order[] orders) -> client.get()
                      .uri("/products/" + orders[0].getId())
                      .retrieve(Product.class))
              .<Product>execute()
              .block();

      out.println("Final product: " + product.getName());

      // ─────────────────────────────────────────────────────────────────
      // Example 7.2: Chain WITH overrides at each step
      // ─────────────────────────────────────────────────────────────────
      PaymentResult paymentResult = client.sequence()
              // Step 1: Get user (with custom timeout)
              .then(() -> client.get()
                      .uri("/users/123")
                      .override(o -> o.timeouts(t -> t.read(Duration.ofSeconds(5))))
                      .retrieve(User.class))
              // Step 2: Create order (disable retry - not idempotent)
              .then((User user) -> client.post()
                      .uri("/orders")
                      .bodyValue(Map.of("userId", user.getId(), "items", List.of(1, 2, 3)))
                      .override(o -> o.disableRetry())
                      .retrieve(Order.class))
              // Step 3: Process payment (disable all resilience - critical)
              .then((Order order) -> client.post()
                      .uri("/payments/process")
                      .bodyValue(new PaymentRequest(order.getId(), order.getAmount(), "USD"))
                      .override(o -> o
                              .disableRetry()
                              .disableCircuitBreaker()
                              .timeouts(t -> t.response(Duration.ofMinutes(1))))
                      .onErrorNotify(mail -> mail
                              .subject("Payment Failed!")
                              .addContext("orderId", order.getId()))
                      .retrieve(PaymentResult.class))
              .<PaymentResult>execute()
              .block();

      out.println("Payment transaction: " + paymentResult.getTransactionId());

      // ─────────────────────────────────────────────────────────────────
      // Example 7.3: Chain with error handling at each step
      // ─────────────────────────────────────────────────────────────────
      try {
         String result = client.sequence()
                 .then(() -> client.get()
                         .uri("/users/123")
                         .onStatus(s -> s.value() == 404,
                                 ctx -> new UserNotFoundException("User not found"))
                         .retrieve(User.class))
                 .then((User user) -> client.get()
                         .uri("/orders?userId=" + user.getId())
                         .onStatus(s -> s.value() == 404,
                                 ctx -> new OrderNotFoundException("No orders for user"))
                         .retrieve(Order[].class))
                 .<Order[]>execute()
                 .map(orders -> "Found " + orders.length + " orders")
                 .block();

         out.println(result);

      } catch (UserNotFoundException e) {
         err.println("User error: " + e.getMessage());
      } catch (OrderNotFoundException e) {
         err.println("Order error: " + e.getMessage());
      }
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 8. DISABLE LOGGING + METRICS FOR ONE CALL
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Note: Logging and metrics are client-level, but you can create
    * a separate client for specific calls, or filter in your logging config
    */
   public static void disableLoggingAndMetrics() {

      // ─────────────────────────────────────────────────────────────────
      // Option 1: Create a separate "silent" client
      // ─────────────────────────────────────────────────────────────────
      CBQRestClient silentClient = CBQRestClientBuilder.builder("silent-client")
              .baseUrl("https://api.example.com")
              .logging(LoggingConfig.disabled())      // No logging
              .metrics(MetricsConfig.disabled())      // No metrics
              .tracing(TracingConfig.disabled())      // No tracing
              .resilience(ResilienceConfig.disabled()) // No resilience
              .build();

      // Use for health checks, internal calls, etc.
      silentClient.get()
              .uri("/internal/health")
              .retrieve(String.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Option 2: Minimal client for specific use case
      // ─────────────────────────────────────────────────────────────────
      CBQRestClient minimalClient = CBQRestClientBuilder.builder("minimal")
              .baseUrl("https://api.example.com")
              .timeouts(TimeoutConfig.defaults()
                      .connection(Duration.ofSeconds(2))
                      .response(Duration.ofSeconds(5)))
              // Everything else disabled by default
              .build();

      minimalClient.get()
              .uri("/quick/check")
              .retrieve(String.class)
              .block();
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 9. CORRELATION ID PROPAGATION
   // ═══════════════════════════════════════════════════════════════════════════

   public static void correlationIdExamples(CBQRestClient client) {

      // ─────────────────────────────────────────────────────────────────
      // Example 9.1: Auto-generated correlation ID
      // ─────────────────────────────────────────────────────────────────
      // If no X-Correlation-Id is passed, one is generated automatically
      CBQResponse<User> response = client.get()
              .uri("/users/123")
              .retrieve(User.class)
              .block();

      // Access the correlation ID from response
      if (response != null) {
         out.println("Correlation ID: " + response.getCorrelationId());
      }
      out.println("Request ID: " + (response != null ? response.getRequestId() : null));

      // ─────────────────────────────────────────────────────────────────
      // Example 9.2: Pass existing correlation ID
      // ─────────────────────────────────────────────────────────────────
      String incomingCorrelationId = "abc-123-def-456";  // From incoming request

      CBQResponse<User> response2 = client.get()
              .uri("/users/123")
              .header("X-Correlation-Id", incomingCorrelationId)  // Propagate
              .retrieve(User.class)
              .block();

      // Same correlation ID is used
      if (response2 != null) {
         out.println("Propagated ID: " + response2.getCorrelationId());
      }

      // ─────────────────────────────────────────────────────────────────
      // Example 9.3: Chain with correlation ID
      // ─────────────────────────────────────────────────────────────────
      // Correlation ID is automatically propagated through the chain
      client.sequence()
              .then(() -> client.get().uri("/users/1").retrieve(User.class))
              .then((User user) -> client.get()
                      .uri("/orders?userId=" + user.getId())
                      .retrieve(Order[].class))
              .execute()
              .block();
      // All requests in the chain share the same correlation ID

      // ─────────────────────────────────────────────────────────────────
      // Example 9.4: Parallel with correlation ID
      // ─────────────────────────────────────────────────────────────────
      CBQParallelResult<Object> parallelResult = client.parallel(
              client.get().uri("/users/1").retrieve(Object.class),
              client.get().uri("/orders/1").retrieve(Object.class)
      ).waitAll().execute().block();

      // Each parallel request may have its own correlation ID
      String userId1CorrelationId = parallelResult.getResponse(0).getCorrelationId();
      String orderId1CorrelationId = parallelResult.getResponse(1).getCorrelationId();
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 10. RATE LIMITING REJECTION HANDLING
   // ═══════════════════════════════════════════════════════════════════════════

   public static void rateLimitingExamples(CBQRestClient client) {

      // ─────────────────────────────────────────────────────────────────
      // Example 10.1: Handle rate limit exception
      // ─────────────────────────────────────────────────────────────────
      try {
         // If rate limit is exceeded, RateLimitExceededException is thrown
         for (int i = 0; i < 200; i++) {
            client.get()
                    .uri("/users/" + i)
                    .retrieve(User.class)
                    .block();
         }
      } catch (RateLimitExceededException e) {
         err.println("Rate limit exceeded!");
         err.println("Rate limiter: " + e.getRateLimiterName());
         err.println("Request ID: " + e.getRequestId());
         err.println("URI: " + e.getUri());

         // Implement backoff
         try {
            Thread.sleep(1000);  // Wait 1 second
         } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
         }
      }

      // ─────────────────────────────────────────────────────────────────
      // Example 10.2: Reactive rate limit handling
      // ─────────────────────────────────────────────────────────────────
      client.get()
              .uri("/users/123")
              .retrieve(User.class)
              .doOnError(RateLimitExceededException.class, e -> err.println("Rate limited! Will retry after delay..."))
              .retryWhen(Retry.backoff(3, Duration.ofSeconds(1))
                      .filter(RateLimitExceededException.class::isInstance))
              .subscribe(
                      user -> out.println("Got user: " + user.getBody().getName()),
                      error -> err.println("Failed after retries: " + error.getMessage())
              );

      // ─────────────────────────────────────────────────────────────────
      // Example 10.3: Bypass rate limiter for specific request
      // ─────────────────────────────────────────────────────────────────
      // For admin/priority operations
      client.get()
              .uri("/admin/critical")
              .override(RequestOverride::disableRateLimiter)
              .retrieve(String.class)
              .block();

      // ─────────────────────────────────────────────────────────────────
      // Example 10.4: Handle server-side 429 response
      // ─────────────────────────────────────────────────────────────────
      try {
         client.get()
                 .uri("/external-api/data")
                 .onStatus(status -> status.value() == 429, ctx -> {
                    // Extract retry-after header if present
                    String retryAfter = ctx.getHeaders().getFirst("Retry-After");
                    return new RateLimitException(
                            "Server rate limit. Retry after: " + retryAfter);
                 })
                 .retrieve(String.class)
                 .block();
      } catch (RateLimitException e) {
         err.println(e.getMessage());
      }
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 11. EMAIL USE CASES - ALL
   // ═══════════════════════════════════════════════════════════════════════════

   public static void emailUseCases(CBQRestClient client) {

      // ─────────────────────────────────────────────────────────────────
      // Example 11.1: Basic email notification on error
      // ─────────────────────────────────────────────────────────────────
      client.post()
              .uri("/payments/process")
              .bodyValue(new PaymentRequest(100L, 99.99, "USD"))
              .onErrorNotify(mail -> mail
                      .to("payments@company.com")
                      .subject("Payment Processing Failed"))
              .retrieve(PaymentResult.class)
              .subscribe();  // Email sent async if error occurs

      // ─────────────────────────────────────────────────────────────────
      // Example 11.2: Email with full context
      // ─────────────────────────────────────────────────────────────────
      PaymentRequest paymentRequest = new PaymentRequest(200L, 149.99, "EUR");

      client.post()
              .uri("/payments/process")
              .bodyValue(paymentRequest)
              .onErrorNotify(mail -> mail
                      .from("alerts@company.com")
                      .to("payments@company.com", "oncall@company.com")
                      .subject("CRITICAL: Payment Failed - Order #" + paymentRequest.getOrderId())
                      .addContext("orderId", paymentRequest.getOrderId())
                      .addContext("amount", paymentRequest.getAmount())
                      .addContext("currency", paymentRequest.getCurrency())
                      .addContext("timestamp", System.currentTimeMillis())
                      .addContext("environment", "production")
                      .html(false))  // Plain text email
              .retrieve(PaymentResult.class)
              .subscribe();

      // ─────────────────────────────────────────────────────────────────
      // Example 11.3: HTML email
      // ─────────────────────────────────────────────────────────────────
      client.post()
              .uri("/orders/create")
              .bodyValue(Map.of("items", List.of(1, 2, 3)))
              .onErrorNotify(mail -> mail
                      .to("orders@company.com")
                      .subject("Order Creation Failed")
                      .body("<html><body>" +
                              "<h1>Order Creation Failed</h1>" +
                              "<p>Please check the order service.</p>" +
                              "</body></html>")
                      .html(true))
              .retrieve(Order.class)
              .subscribe();

      // ─────────────────────────────────────────────────────────────────
      // Example 11.4: Email with dynamic recipients
      // ─────────────────────────────────────────────────────────────────
      String serviceOwner = getServiceOwner("payment-service");
      String oncallEngineer = getOncallEngineer();

      client.post()
              .uri("/payments/process")
              .bodyValue(paymentRequest)
              .onErrorNotify(mail -> mail
                      .to(serviceOwner, oncallEngineer)
                      .subject("Payment Service Error"))
              .retrieve(PaymentResult.class)
              .subscribe();

      // ─────────────────────────────────────────────────────────────────
      // Example 11.5: Email in sequential chain
      // ─────────────────────────────────────────────────────────────────
      client.sequence()
              .then(() -> client.get()
                      .uri("/users/123")
                      .onErrorNotify(mail -> mail
                              .to("user-service@company.com")
                              .subject("User Lookup Failed"))
                      .retrieve(User.class))
              .then((User user) -> client.post()
                      .uri("/notifications/send")
                      .bodyValue(Map.of("userId", user.getId(), "message", "Welcome!"))
                      .onErrorNotify(mail -> mail
                              .to("notification-service@company.com")
                              .subject("Notification Send Failed")
                              .addContext("userId", user.getId()))
                      .retrieve(String.class))
              .execute()
              .subscribe();

      // ─────────────────────────────────────────────────────────────────
      // Example 11.6: Email only for specific errors
      // ─────────────────────────────────────────────────────────────────
      client.post()
              .uri("/orders/process")
              .bodyValue(Map.of("id", 123))
              .retrieve(Order.class)
              .doOnError(error -> {
                 // Only send email for 5xx errors
                 if (error instanceof CBQRestClientException) {
                    CBQRestClientException e = (CBQRestClientException) error;
                    if (e.getStatusCode() != null && e.getStatusCode() >= 500) {
                       // Manually trigger email (via your email service)
                       sendCriticalAlert(e);
                    }
                 }
              })
              .subscribe();

      // ─────────────────────────────────────────────────────────────────
      // Example 11.7: Rate limiting prevents email storms
      // ─────────────────────────────────────────────────────────────────
      // The email notifier is configured with rate limiting:
      // .rateLimit(5, Duration.ofMinutes(1))
      //
      // This means:
      // - Max 5 emails per minute
      // - After 5 emails, subsequent errors won't trigger emails
      // - After 1 minute, the window resets
      //
      // Also circuit breaker protected:
      // .circuitBreakerThreshold(3)
      // - After 3 consecutive email send failures, stops trying
      // - Prevents blocking on SMTP issues

      // ─────────────────────────────────────────────────────────────────
      // Example 11.8: Conditional email (in chain)
      // ─────────────────────────────────────────────────────────────────
      client.post()
              .uri("/critical/operation")
              .bodyValue(Map.of("important", true))
              .override(o -> o.disableRetry())  // Critical, non-idempotent
              .onErrorNotify(mail -> mail
                      .to("critical-alerts@company.com")
                      .subject("URGENT: Critical Operation Failed")
                      .addContext("severity", "HIGH")
                      .addContext("requiresImmediate", true))
              .retrieve(String.class)
              .subscribe();
   }

   private static String getServiceOwner(String service) {
      return "owner-" + service + "@company.com";
   }

   private static String getOncallEngineer() {
      return "oncall@company.com";
   }

   private static void sendCriticalAlert(CBQRestClientException e) {
      err.println("Sending critical alert for: " + e.getMessage());
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 12. BULKHEAD REJECTION HANDLING
   // ═══════════════════════════════════════════════════════════════════════════

   public static void bulkheadExamples(CBQRestClient client) {

      // ─────────────────────────────────────────────────────────────────
      // Example 12.1: Handle bulkhead full exception
      // ─────────────────────────────────────────────────────────────────
      try {
         client.get()
                 .uri("/users/123")
                 .retrieve(User.class)
                 .block();
      } catch (BulkheadFullException e) {
         err.println("Bulkhead is full!");
         err.println("Bulkhead: " + e.getBulkheadName());
         err.println("Max concurrent calls reached");
      }

      // ─────────────────────────────────────────────────────────────────
      // Example 12.2: Bypass bulkhead for priority requests
      // ─────────────────────────────────────────────────────────────────
      client.get()
              .uri("/priority/request")
              .override(RequestOverride::disableBulkhead)
              .retrieve(String.class)
              .block();
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // 13. CIRCUIT BREAKER HANDLING
   // ═══════════════════════════════════════════════════════════════════════════

   public static void circuitBreakerExamples(CBQRestClient client) {

      // ─────────────────────────────────────────────────────────────────
      // Example 13.1: Handle circuit breaker open
      // ─────────────────────────────────────────────────────────────────
      try {
         client.get()
                 .uri("/flaky/service")
                 .retrieve(String.class)
                 .block();
      } catch (CircuitBreakerOpenException e) {
         err.println("Circuit breaker is OPEN!");
         err.println("Circuit breaker: " + e.getCircuitBreakerName());
         err.println("Service is temporarily unavailable");

         // Return fallback or cached data
         // return cachedData;
      }

      // ─────────────────────────────────────────────────────────────────
      // Example 13.2: Bypass circuit breaker for health checks
      // ─────────────────────────────────────────────────────────────────
      client.get()
              .uri("/health")
              .override(RequestOverride::disableCircuitBreaker)
              .retrieve(String.class)
              .block();
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // MAIN
   // ═══════════════════════════════════════════════════════════════════════════

   public static void main(String[] args) {
      CBQRestClient client = createFullyConfiguredClient();

      out.println("=== CBQ REST Client v2.0 Examples ===\n");

      // Run examples (uncomment as needed)
      // errorHandlingExamples(client);
      // allOverrideExamples(client);
      // parallelWaitForAll(client);
      // parallelFailFast(client);
      // parallelPartialSuccess(client);
      // sequentialChainExamples(client);
      // correlationIdExamples(client);
      // rateLimitingExamples(client);
      // emailUseCases(client);

      client.shutdown();
   }
}
