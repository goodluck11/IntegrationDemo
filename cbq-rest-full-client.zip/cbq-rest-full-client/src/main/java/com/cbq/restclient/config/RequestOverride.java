package com.cbq.restclient.config;

import lombok.Getter;

import java.time.Duration;
import java.util.function.Consumer;

/**
 * Per-request override configuration.
 * 
 * <p>Precedence: Request Override > Client Config > Defaults</p>
 * 
 * <pre>{@code
 * client.get()
 *     .uri("/slow-endpoint")
 *     .override(o -> o
 *         .disableRetry()
 *         .disableCircuitBreaker()
 *         .timeouts(t -> t.read(Duration.ofMinutes(2))))
 *     .retrieve(Response.class);
 * }</pre>
 */
@Getter
public class RequestOverride {

    // Resilience overrides
    private Boolean retryEnabled;
    private Boolean circuitBreakerEnabled;
    private Boolean rateLimiterEnabled;
    private Boolean bulkheadEnabled;
    
    // Retry overrides
    private Integer maxAttempts;
    private Duration waitDuration;

    // Timeout overrides
    private Duration connectionTimeout;
    private Duration readTimeout;
    private Duration writeTimeout;
    private Duration responseTimeout;

    private RequestOverride() {}

    public static RequestOverride create() {
        return new RequestOverride();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // RESILIENCE OVERRIDES
    // ═══════════════════════════════════════════════════════════════════════════

    public RequestOverride disableRetry() {
        this.retryEnabled = false;
        return this;
    }

    public RequestOverride enableRetry() {
        this.retryEnabled = true;
        return this;
    }

    public RequestOverride disableCircuitBreaker() {
        this.circuitBreakerEnabled = false;
        return this;
    }

    public RequestOverride enableCircuitBreaker() {
        this.circuitBreakerEnabled = true;
        return this;
    }

    public RequestOverride disableRateLimiter() {
        this.rateLimiterEnabled = false;
        return this;
    }

    public RequestOverride enableRateLimiter() {
        this.rateLimiterEnabled = true;
        return this;
    }

    public RequestOverride disableBulkhead() {
        this.bulkheadEnabled = false;
        return this;
    }

    public RequestOverride enableBulkhead() {
        this.bulkheadEnabled = true;
        return this;
    }

    public RequestOverride disableAllResilience() {
        this.retryEnabled = false;
        this.circuitBreakerEnabled = false;
        this.rateLimiterEnabled = false;
        this.bulkheadEnabled = false;
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // RETRY OVERRIDES
    // ═══════════════════════════════════════════════════════════════════════════

    public RequestOverride maxAttempts(int attempts) {
        this.maxAttempts = attempts;
        return this;
    }

    public RequestOverride waitDuration(Duration duration) {
        this.waitDuration = duration;
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // TIMEOUT OVERRIDES
    // ═══════════════════════════════════════════════════════════════════════════

    public RequestOverride timeouts(Consumer<TimeoutOverride> configurer) {
        TimeoutOverride override = new TimeoutOverride(this);
        configurer.accept(override);
        return this;
    }

    public RequestOverride connectionTimeout(Duration timeout) {
        this.connectionTimeout = timeout;
        return this;
    }

    public RequestOverride readTimeout(Duration timeout) {
        this.readTimeout = timeout;
        return this;
    }

    public RequestOverride writeTimeout(Duration timeout) {
        this.writeTimeout = timeout;
        return this;
    }

    public RequestOverride responseTimeout(Duration timeout) {
        this.responseTimeout = timeout;
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GETTERS
    // ═══════════════════════════════════════════════════════════════════════════

   /**
     * Timeout override helper
     */
    public static class TimeoutOverride {
        private final RequestOverride parent;

        private TimeoutOverride(RequestOverride parent) {
            this.parent = parent;
        }

        public TimeoutOverride connection(Duration timeout) {
            parent.connectionTimeout = timeout;
            return this;
        }

        public TimeoutOverride read(Duration timeout) {
            parent.readTimeout = timeout;
            return this;
        }

        public TimeoutOverride write(Duration timeout) {
            parent.writeTimeout = timeout;
            return this;
        }

        public TimeoutOverride response(Duration timeout) {
            parent.responseTimeout = timeout;
            return this;
        }
    }
}
