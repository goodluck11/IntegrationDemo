package com.cbq.restclient.v2;

import lombok.Builder;
import lombok.Value;

import java.util.Set;

/*
 * @created by 24/01/2026  - 21:42
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Value
@Builder
public class LoggingConfigV2 {
   boolean enabled;
   boolean logHeaders;
   boolean logRequest;
   boolean logResponse;

   Set<String> fieldsToMask;
   Set<String> fieldsToExclude;
   char maskSymbol;
   int maxFieldLength;
   int maxBodySize;

   public static LoggingConfigV2 disabled() {
      return LoggingConfigV2.builder().enabled(false).build();
   }
}
