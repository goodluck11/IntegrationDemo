package com.cbq.restclient.model;

import lombok.Getter;

import java.util.*;

/**
 * Result of parallel request execution.
 */
@Getter
public class CBQParallelResult<T> {

    private final List<CBQResponse<T>> responses;
    private final Map<Integer, Throwable> errors;
    private final long totalDurationMs;
    private final ParallelStrategy strategy;

    private CBQParallelResult(Builder<T> builder) {
        this.responses = Collections.unmodifiableList(builder.responses);
        this.errors = Collections.unmodifiableMap(builder.errors);
        this.totalDurationMs = builder.totalDurationMs;
        this.strategy = builder.strategy;
    }

   public CBQResponse<T> getResponse(int index) {
        return index >= 0 && index < responses.size() ? responses.get(index) : null;
    }

    public Throwable getError(int index) {
        return errors.get(index);
    }

    public int size() { return responses.size(); }
    public int successCount() { return responses.size() - errors.size(); }
    public int errorCount() { return errors.size(); }
    public boolean hasErrors() { return !errors.isEmpty(); }
    public boolean allSuccessful() { return errors.isEmpty(); }

    /**
     * Gets all successful responses
     */
    public List<CBQResponse<T>> getSuccessfulResponses() {
        List<CBQResponse<T>> successful = new ArrayList<>();
        for (int i = 0; i < responses.size(); i++) {
            if (!errors.containsKey(i) && responses.get(i) != null) {
                successful.add(responses.get(i));
            }
        }
        return successful;
    }

    public List<T> getBodies() {
        List<T> bodies = new ArrayList<>();
        for (CBQResponse<T> response : getSuccessfulResponses()) {
            if (response.getBody() != null) {
                bodies.add(response.getBody());
            }
        }
        return bodies;
    }

   public <T> T getBody(int index, Class<T> type) {
      CBQResponse<?> response = getResponse(index);
      if (response == null || response.getBody() == null) {
         return null;
      }
      return type.cast(response.getBody());
   }

    public static <T> Builder<T> builder() {
        return new Builder<>();
    }

    public static class Builder<T> {
        private List<CBQResponse<T>> responses = new ArrayList<>();
        private Map<Integer, Throwable> errors = new HashMap<>();
        private long totalDurationMs;
        private ParallelStrategy strategy = ParallelStrategy.WAIT_ALL;

        public Builder<T> addResponse(CBQResponse<T> response) {
            this.responses.add(response);
            return this;
        }

        public Builder<T> responses(List<CBQResponse<T>> responses) {
            this.responses = new ArrayList<>(responses);
            return this;
        }

        public Builder<T> addError(int index, Throwable error) {
            this.errors.put(index, error);
            return this;
        }

        public Builder<T> errors(Map<Integer, Throwable> errors) {
            this.errors = new HashMap<>(errors);
            return this;
        }

        public Builder<T> totalDurationMs(long durationMs) {
            this.totalDurationMs = durationMs;
            return this;
        }

        public Builder<T> strategy(ParallelStrategy strategy) {
            this.strategy = strategy;
            return this;
        }

        public CBQParallelResult<T> build() {
            return new CBQParallelResult<>(this);
        }
    }

    /**
     * Strategy for parallel execution
     */
    public enum ParallelStrategy {
        /** Wait for all requests to complete (Mono.zip) */
        WAIT_ALL,
        /** Fail fast on first error */
        FAIL_FAST,
        /** Collect partial results even on errors (Flux.merge with onErrorContinue) */
        PARTIAL_SUCCESS
    }
}
