package com.cbq.restclient.v2;

import lombok.Getter;

/*
 * @created by 24/01/2026  - 21:51
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Getter
public class CBQHttpExceptionV2 extends RuntimeException {
   private final int status;

   protected CBQHttpExceptionV2(int status, String msg) {
      super(msg);
      this.status = status;
   }
}
