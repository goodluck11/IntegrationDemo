package com.cbq.restclient.v2;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

/*
 * @created by 24/01/2026  - 21:46
 * @project cbq-rest-full-client
 * @author Goodluck
 */

@RequiredArgsConstructor
@Slf4j
public final class StructuredLoggingFilterV2 implements ExchangeFilterFunction {
   private final LoggingConfigV2 config;
   private final ObjectMapper mapper = new ObjectMapper();

   @Override
   public Mono<ClientResponse> filter(ClientRequest request, ExchangeFunction next) {
      if (!config.isEnabled()) return next.exchange(request);

      logRequest(request);
      return next.exchange(request)
              .doOnNext(this::logResponse);
   }

   @SneakyThrows
   private void logRequest(ClientRequest request) {
      Map<String, Object> logInfo = new HashMap<>();
      logInfo.put("type", "request");
      logInfo.put("method", request.method().name());
      logInfo.put("url", request.url().toString());

      if (config.isLogHeaders()) {
         logInfo.put("headers", mask(request.headers().toSingleValueMap()));
      }

      log.info(mapper.writeValueAsString(logInfo));
   }

   @SneakyThrows
   private void logResponse(ClientResponse response) {
      Map<String, Object> logInfo = new HashMap<>();
      logInfo.put("type", "response");
      logInfo.put("status", response.rawStatusCode());

      if (config.isLogHeaders()) {
         logInfo.put("headers", mask(response.headers().asHttpHeaders().toSingleValueMap()));
      }

      log.info(mapper.writeValueAsString(logInfo));
   }

   private Map<String, Object> mask(Map<String, String> input) {
      Map<String, Object> masked = new HashMap<>();
      input.forEach((k, v) -> {
         if (config.getFieldsToExclude() != null && config.getFieldsToExclude().contains(k)) {
            return;
         }
         if (config.getFieldsToMask() != null && config.getFieldsToMask().contains(k)) {
            masked.put(k, String.valueOf(config.getMaskSymbol()).repeat(
                    Math.min(v.length(), config.getMaxFieldLength())
            ));
         } else {
            masked.put(k, truncate(v));
         }
      });
      return masked;
   }

   private String truncate(String value) {
      if (value.length() > config.getMaxFieldLength()) {
         return value.substring(0, config.getMaxFieldLength()) + "...";
      }
      return value;
   }
}
