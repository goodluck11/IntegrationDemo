package com.cbq.restclient.v2;

/*
 * @created by 24/01/2026  - 21:52
 * @project cbq-rest-full-client
 * @author Goodluck
 */
public class ClientErrorExceptionV2 extends CBQHttpExceptionV2 {
   public ClientErrorExceptionV2(int status, String msg) {
      super(status, msg);
   }
}
