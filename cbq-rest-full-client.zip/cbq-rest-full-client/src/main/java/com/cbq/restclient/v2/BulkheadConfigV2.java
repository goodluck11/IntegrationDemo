package com.cbq.restclient.v2;

import io.github.resilience4j.bulkhead.Bulkhead;
import lombok.Builder;
import lombok.Value;

/*
 * @created by 24/01/2026  - 21:44
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Value
@Builder
public class BulkheadConfigV2 {
   Bulkhead bulkhead;
   boolean isolateScheduler;
   int schedulerThreads;

   public static BulkheadConfigV2 disabled() {
      return BulkheadConfigV2.builder().build();
   }
}
