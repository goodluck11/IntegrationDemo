package com.cbq.restclient.config;

import java.time.Duration;
import java.util.*;

/**
 * Email notification configuration with production safeguards.
 * 
 * <p>Safety features to prevent email storms:</p>
 * <ul>
 *   <li><b>Rate limiting</b> - Max emails per time window</li>
 *   <li><b>Circuit breaker</b> - Stops notifications during persistent failures</li>
 *   <li><b>Async execution</b> - Never blocks HTTP client threads</li>
 *   <li><b>Event-driven</b> - Decoupled from request flow</li>
 * </ul>
 */
public class EmailNotifierConfig {

    private boolean enabled = false;
    private boolean async = true;
    
    // Rate limiting (prevent email storms)
    private int maxEmailsPerWindow = 5;
    private Duration rateLimitWindow = Duration.ofMinutes(1);
    
    // Circuit breaker for email sending
    private boolean circuitBreakerEnabled = true;
    private int circuitBreakerThreshold = 3; // failures before opening
    private Duration circuitBreakerResetTime = Duration.ofMinutes(5);
    
    // SMTP Configuration (fallback if Spring Mail not configured)
    private String host;
    private int port = 587;
    private String username;
    private String password;
    private boolean startTls = true;
    private boolean ssl = false;
    
    // Default email settings
    private String defaultFrom;
    private List<String> defaultTo = new ArrayList<>();
    private String defaultSubject = "CBQ Rest Client Error Notification";

    private EmailNotifierConfig() {}

    public static EmailNotifierConfig disabled() {
        return new EmailNotifierConfig();
    }

    public static EmailNotifierConfig custom() {
        return new EmailNotifierConfig().enabled(true);
    }

    public EmailNotifierConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public EmailNotifierConfig async(boolean async) {
        this.async = async;
        return this;
    }

    /**
     * Sets rate limiting for email notifications
     * @param maxEmails Maximum emails allowed in the window
     * @param window Time window for rate limiting
     */
    public EmailNotifierConfig rateLimit(int maxEmails, Duration window) {
        this.maxEmailsPerWindow = maxEmails;
        this.rateLimitWindow = window;
        return this;
    }

    public EmailNotifierConfig circuitBreaker(boolean enabled) {
        this.circuitBreakerEnabled = enabled;
        return this;
    }

    public EmailNotifierConfig circuitBreakerThreshold(int failures) {
        this.circuitBreakerThreshold = failures;
        return this;
    }

    public EmailNotifierConfig circuitBreakerResetTime(Duration duration) {
        this.circuitBreakerResetTime = duration;
        return this;
    }

    // SMTP Configuration
    public EmailNotifierConfig host(String host) {
        this.host = host;
        return this;
    }

    public EmailNotifierConfig port(int port) {
        this.port = port;
        return this;
    }

    public EmailNotifierConfig credentials(String username, String password) {
        this.username = username;
        this.password = password;
        return this;
    }

    public EmailNotifierConfig startTls(boolean startTls) {
        this.startTls = startTls;
        return this;
    }

    public EmailNotifierConfig ssl(boolean ssl) {
        this.ssl = ssl;
        return this;
    }

    // Default email settings
    public EmailNotifierConfig defaultFrom(String from) {
        this.defaultFrom = from;
        return this;
    }

    public EmailNotifierConfig defaultTo(String... recipients) {
        this.defaultTo.addAll(Arrays.asList(recipients));
        return this;
    }

    public EmailNotifierConfig defaultSubject(String subject) {
        this.defaultSubject = subject;
        return this;
    }

    // Getters
    public boolean isEnabled() { return enabled; }
    public boolean isAsync() { return async; }
    public int getMaxEmailsPerWindow() { return maxEmailsPerWindow; }
    public Duration getRateLimitWindow() { return rateLimitWindow; }
    public boolean isCircuitBreakerEnabled() { return circuitBreakerEnabled; }
    public int getCircuitBreakerThreshold() { return circuitBreakerThreshold; }
    public Duration getCircuitBreakerResetTime() { return circuitBreakerResetTime; }
    public String getHost() { return host; }
    public int getPort() { return port; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public boolean isStartTls() { return startTls; }
    public boolean isSsl() { return ssl; }
    public String getDefaultFrom() { return defaultFrom; }
    public List<String> getDefaultTo() { return defaultTo; }
    public String getDefaultSubject() { return defaultSubject; }
}
