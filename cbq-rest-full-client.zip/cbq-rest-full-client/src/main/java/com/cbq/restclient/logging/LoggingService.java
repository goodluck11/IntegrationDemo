package com.cbq.restclient.logging;

import com.cbq.restclient.config.LoggingConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Production-safe logging service with:
 * - Max body size limits
 * - Async logging (never blocks Netty)
 * - Content-type aware (skips binary)
 * - Field masking for sensitive data
 */
public class LoggingService {
    private static final Logger log = LoggerFactory.getLogger(LoggingService.class);
    
    private final LoggingConfig config;
    private final ObjectMapper objectMapper;
    private final Scheduler loggingScheduler;
    
    // Pattern for masking in non-JSON content
    private final Map<String, Pattern> maskPatterns = new HashMap<>();

    public LoggingService(LoggingConfig config) {
        this.config = config;
        this.objectMapper = new ObjectMapper();
        // Bounded scheduler to prevent memory issues
        this.loggingScheduler = Schedulers.newBoundedElastic(2, 100, "cbq-logging");
        
        // Build mask patterns for each sensitive field
        for (String field : config.getFieldsToMask()) {
            String pattern = String.format("(?i)(\"%s\"\\s*:\\s*\")[^\"]*(\"|$)", field);
            maskPatterns.put(field, Pattern.compile(pattern));
        }
    }

    /**
     * Logs request asynchronously (never blocks Netty)
     */
    public Mono<Void> logRequestAsync(String requestId, String method, String uri,
                                       HttpHeaders headers, Object body, String contentType) {
        if (!config.isEnabled() || !config.isLogRequest()) {
            return Mono.empty();
        }
        
        return Mono.fromRunnable(() -> logRequest(requestId, method, uri, headers, body, contentType))
                .subscribeOn(loggingScheduler)
                .then();
    }

    /**
     * Logs response asynchronously (never blocks Netty)
     */
    public Mono<Void> logResponseAsync(String requestId, int status, HttpHeaders headers,
                                        String body, long durationMs, String contentType) {
        if (!config.isEnabled() || !config.isLogResponse()) {
            return Mono.empty();
        }
        
        return Mono.fromRunnable(() -> logResponse(requestId, status, headers, body, durationMs, contentType))
                .subscribeOn(loggingScheduler)
                .then();
    }

    private void logRequest(String requestId, String method, String uri,
                           HttpHeaders headers, Object body, String contentType) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════════════════════════╗\n");
        sb.append("║ CBQ HTTP REQUEST\n");
        sb.append("╠══════════════════════════════════════════════════════════════════╣\n");
        sb.append("║ Request ID: ").append(requestId).append("\n");
        sb.append("║ Method: ").append(method).append("\n");
        sb.append("║ URI: ").append(uri).append("\n");
        
        if (config.isLogHeaders() && headers != null) {
            sb.append("║ Headers:\n");
            headers.forEach((name, values) -> {
                if (!config.getFieldsToExclude().contains(name.toLowerCase())) {
                    String value = String.join(", ", values);
                    value = maskHeaderValue(name, value);
                    sb.append("║   ").append(name).append(": ").append(value).append("\n");
                }
            });
        }
        
        if (body != null && shouldLogBody(contentType)) {
            String bodyStr = formatBody(body, contentType);
            sb.append("║ Body:\n").append(bodyStr).append("\n");
        } else if (body != null) {
            sb.append("║ Body: [").append(contentType).append(" - not logged]\n");
        }
        
        sb.append("╚══════════════════════════════════════════════════════════════════╝");
        
        log.info("{}", sb);
    }

    private void logResponse(String requestId, int status, HttpHeaders headers,
                            String body, long durationMs, String contentType) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════════════════════════╗\n");
        sb.append("║ CBQ HTTP RESPONSE\n");
        sb.append("╠══════════════════════════════════════════════════════════════════╣\n");
        sb.append("║ Request ID: ").append(requestId).append("\n");
        sb.append("║ Status: ").append(status).append("\n");
        sb.append("║ Duration: ").append(durationMs).append("ms\n");
        
        if (config.isLogHeaders() && headers != null) {
            sb.append("║ Headers:\n");
            headers.forEach((name, values) -> {
                if (!config.getFieldsToExclude().contains(name.toLowerCase())) {
                    String value = String.join(", ", values);
                    sb.append("║   ").append(name).append(": ").append(value).append("\n");
                }
            });
        }
        
        if (body != null && shouldLogBody(contentType)) {
            String maskedBody = maskBody(body);
            String truncatedBody = truncateBody(maskedBody);
            sb.append("║ Body:\n").append(truncatedBody).append("\n");
        } else if (body != null) {
            sb.append("║ Body: [").append(contentType).append(" - not logged]\n");
        }
        
        sb.append("╚══════════════════════════════════════════════════════════════════╝");

        log.info("{}", sb);
    }

    /**
     * Checks if body should be logged based on content type
     */
    private boolean shouldLogBody(String contentType) {
        return LoggingConfig.shouldLogContentType(contentType);
    }

    /**
     * Formats body for logging with masking
     */
    private String formatBody(Object body, String contentType) {
        if (body == null) return "";
        
        String bodyStr;
        if (body instanceof String) {
            bodyStr = (String) body;
        } else {
            try {
                bodyStr = objectMapper.writeValueAsString(body);
            } catch (JsonProcessingException e) {
                bodyStr = body.toString();
            }
        }
        
        return truncateBody(maskBody(bodyStr));
    }

    /**
     * Masks sensitive fields in body
     */
    private String maskBody(String body) {
        if (body == null || body.isEmpty()) return body;
        
        // Try JSON masking first
        if (body.trim().startsWith("{") || body.trim().startsWith("[")) {
            try {
                JsonNode node = objectMapper.readTree(body);
                maskJsonNode(node);
                return objectMapper.writeValueAsString(node);
            } catch (Exception e) {
                // Fall through to pattern masking
            }
        }
        
        // Pattern-based masking for non-JSON
        String masked = body;
        for (Map.Entry<String, Pattern> entry : maskPatterns.entrySet()) {
            Matcher matcher = entry.getValue().matcher(masked);
            int visibleChars = config.getFieldMaskLengths().getOrDefault(
                    entry.getKey().toLowerCase(), config.getDefaultVisibleChars());
            masked = matcher.replaceAll("$1" + generateMask(visibleChars) + "$2");
        }
        
        return masked;
    }

    /**
     * Recursively masks sensitive fields in JSON
     */
    private void maskJsonNode(JsonNode node) {
        if (node == null) return;
        
        if (node.isObject()) {
            ObjectNode objNode = (ObjectNode) node;
            Iterator<String> fieldNames = objNode.fieldNames();
            List<String> names = new ArrayList<>();
            fieldNames.forEachRemaining(names::add);
            
            for (String fieldName : names) {
                if (config.getFieldsToExclude().contains(fieldName.toLowerCase())) {
                    objNode.remove(fieldName);
                } else if (config.getFieldsToMask().contains(fieldName.toLowerCase())) {
                    int visibleChars = config.getFieldMaskLengths().getOrDefault(
                            fieldName.toLowerCase(), config.getDefaultVisibleChars());
                    JsonNode valueNode = objNode.get(fieldName);
                    if (valueNode != null && valueNode.isTextual()) {
                        String value = valueNode.asText();
                        objNode.put(fieldName, maskValue(value, visibleChars));
                    } else {
                        objNode.put(fieldName, generateMask(0));
                    }
                } else {
                    maskJsonNode(objNode.get(fieldName));
                }
            }
        } else if (node.isArray()) {
            for (JsonNode element : node) {
                maskJsonNode(element);
            }
        }
    }

    /**
     * Masks a value showing only first/last N characters
     */
    private String maskValue(String value, int visibleChars) {
        if (value == null || value.length() <= visibleChars * 2) {
            return generateMask(0);
        }
        
        String mask = String.valueOf(config.getMaskSymbol()).repeat(
                Math.min(8, value.length() - visibleChars * 2));
        
        if (visibleChars > 0) {
            return value.substring(0, visibleChars) + mask + 
                   value.substring(value.length() - visibleChars);
        }
        return mask;
    }

    private String generateMask(int visibleChars) {
        return String.valueOf(config.getMaskSymbol()).repeat(8);
    }

    /**
     * Masks header values
     */
    private String maskHeaderValue(String headerName, String value) {
        String lowerName = headerName.toLowerCase();
        if (config.getFieldsToMask().contains(lowerName) || 
            lowerName.contains("authorization") || 
            lowerName.contains("token") ||
            lowerName.contains("api-key") ||
            lowerName.contains("apikey")) {
            int visibleChars = config.getFieldMaskLengths().getOrDefault(
                    lowerName, config.getDefaultVisibleChars());
            return maskValue(value, visibleChars);
        }
        return value;
    }

    /**
     * Truncates body to max size
     */
    private String truncateBody(String body) {
        if (body == null) return "";
        
        int maxSize = config.getMaxBodySize();
        if (body.length() <= maxSize) {
            return body;
        }
        
        return body.substring(0, maxSize) + "\n... [TRUNCATED - " + 
               (body.length() - maxSize) + " more bytes]";
    }

    /**
     * Logs an error
     */
    public void logError(String requestId, String method, String uri, 
                        Throwable error, long durationMs) {
        log.error("Request {} {} failed after {}ms: {}", 
                method, uri, durationMs, error.getMessage(), error);
    }

    public void shutdown() {
        loggingScheduler.dispose();
    }
}
