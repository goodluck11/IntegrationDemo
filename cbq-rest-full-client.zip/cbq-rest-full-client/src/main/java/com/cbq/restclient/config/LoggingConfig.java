package com.cbq.restclient.config;

import java.util.*;

/**
 * Logging configuration with production safeguards.
 * 
 * <p>Safety features:</p>
 * <ul>
 *   <li><b>Max body size</b> - Truncates large bodies (default 10KB)</li>
 *   <li><b>Content-Type filtering</b> - Never logs binary content</li>
 *   <li><b>Async logging</b> - Never blocks Netty threads</li>
 *   <li><b>Field masking</b> - Protects sensitive data</li>
 * </ul>
 * 
 * <p>Content types NEVER logged:</p>
 * <ul>
 *   <li>multipart/form-data</li>
 *   <li>application/octet-stream</li>
 *   <li>image/*, video/*, audio/*</li>
 * </ul>
 */
public class LoggingConfig {

    private boolean enabled = false;
    private boolean logHeaders = false;
    private boolean logRequest = false;
    private boolean logResponse = false;
    
    // Safety: Max body size to log (default 10KB)
    private int maxBodySize = 10_000;
    
    // Field masking
    private Set<String> fieldsToMask = new HashSet<>(Arrays.asList(
            "password", "passwd", "pwd", "secret", "token", "apikey", "api_key",
            "authorization", "bearer", "credential", "credit_card", "creditcard",
            "cvv", "cvc", "ssn", "social_security", "pin"
    ));
    private Set<String> fieldsToExclude = new HashSet<>();
    private Map<String, Integer> fieldMaskLengths = new HashMap<>();
    private char maskSymbol = '*';
    private int defaultVisibleChars = 4;

    // Content types to never log (binary)
    private static final Set<String> NEVER_LOG_CONTENT_TYPES = Set.of(
            "multipart/form-data",
            "application/octet-stream",
            "application/pdf",
            "application/zip",
            "application/gzip",
            "application/x-tar"
    );
    
    private static final Set<String> NEVER_LOG_CONTENT_TYPE_PREFIXES = Set.of(
            "image/", "video/", "audio/", "application/x-binary"
    );

    private LoggingConfig() {}

    public static LoggingConfig disabled() {
        return new LoggingConfig();
    }

    public static LoggingConfig custom() {
        return new LoggingConfig().enabled(true);
    }

    public LoggingConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public LoggingConfig logHeaders() {
        this.logHeaders = true;
        this.enabled = true;
        return this;
    }

    public LoggingConfig logRequest() {
        this.logRequest = true;
        this.enabled = true;
        return this;
    }

    public LoggingConfig logResponse() {
        this.logResponse = true;
        this.enabled = true;
        return this;
    }

    public LoggingConfig logAll() {
        this.logHeaders = true;
        this.logRequest = true;
        this.logResponse = true;
        this.enabled = true;
        return this;
    }

    public LoggingConfig maxBodySize(int maxBytes) {
        this.maxBodySize = maxBytes;
        return this;
    }

    public LoggingConfig maskFields(String... fields) {
        this.fieldsToMask.addAll(Arrays.asList(fields));
        return this;
    }

    public LoggingConfig maskField(String field, int visibleChars) {
        this.fieldsToMask.add(field);
        this.fieldMaskLengths.put(field.toLowerCase(), visibleChars);
        return this;
    }

    public LoggingConfig excludeFields(String... fields) {
        this.fieldsToExclude.addAll(Arrays.asList(fields));
        return this;
    }

    public LoggingConfig maskSymbol(char symbol) {
        this.maskSymbol = symbol;
        return this;
    }

    public LoggingConfig defaultVisibleChars(int chars) {
        this.defaultVisibleChars = chars;
        return this;
    }

    // Getters
    public boolean isEnabled() { return enabled; }
    public boolean isLogHeaders() { return logHeaders; }
    public boolean isLogRequest() { return logRequest; }
    public boolean isLogResponse() { return logResponse; }
    public int getMaxBodySize() { return maxBodySize; }
    public Set<String> getFieldsToMask() { return fieldsToMask; }
    public Set<String> getFieldsToExclude() { return fieldsToExclude; }
    public Map<String, Integer> getFieldMaskLengths() { return fieldMaskLengths; }
    public char getMaskSymbol() { return maskSymbol; }
    public int getDefaultVisibleChars() { return defaultVisibleChars; }

    /**
     * Checks if a content type should be logged
     */
    public static boolean shouldLogContentType(String contentType) {
        if (contentType == null) return true;
        
        String ct = contentType.toLowerCase();
        
        // Check exact matches
        for (String blocked : NEVER_LOG_CONTENT_TYPES) {
            if (ct.startsWith(blocked)) return false;
        }
        
        // Check prefixes
        for (String prefix : NEVER_LOG_CONTENT_TYPE_PREFIXES) {
            if (ct.startsWith(prefix)) return false;
        }
        
        return true;
    }
}
