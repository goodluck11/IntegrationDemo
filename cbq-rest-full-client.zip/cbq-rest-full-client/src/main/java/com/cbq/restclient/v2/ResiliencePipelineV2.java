package com.cbq.restclient.v2;

import io.github.resilience4j.reactor.bulkhead.operator.BulkheadOperator;
import io.github.resilience4j.reactor.circuitbreaker.operator.CircuitBreakerOperator;
import io.github.resilience4j.reactor.ratelimiter.operator.RateLimiterOperator;
import io.github.resilience4j.reactor.retry.RetryOperator;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/*
 * @created by 24/01/2026  - 21:38
 * @project cbq-rest-full-client
 * @author Goodluck
 */
public class ResiliencePipelineV2 {
   public static <T> Mono<T> decorate(Mono<T> mono, ResilienceConfigV2 cfg, RequestOverrideV2 o) {
      Mono<T> result = mono;

      if (cfg.getBulkhead() != null && !Boolean.TRUE.equals(o.getDisableBulkhead())) {
         result = result.transformDeferred(
                 BulkheadOperator.of(cfg.getBulkhead().getBulkhead())
         );

         if (cfg.getBulkhead().isIsolateScheduler()) {
            result = result.publishOn(
                    Schedulers.newBoundedElastic(
                            cfg.getBulkhead().getSchedulerThreads(),
                            Integer.MAX_VALUE,
                            "cbq-bulkhead"
                    )
            );
         }
      }

      if (cfg.getRetry() != null && !Boolean.TRUE.equals(o.getDisableRetry())) {
         result = result.transformDeferred(RetryOperator.of(cfg.getRetry()));
      }

      if (cfg.getRateLimiter() != null && !Boolean.TRUE.equals(o.getDisableRateLimiter())) {
         result = result.transformDeferred(RateLimiterOperator.of(cfg.getRateLimiter()));
      }

      if (cfg.getCircuitBreaker() != null && !Boolean.TRUE.equals(o.getDisableCircuitBreaker())) {
         result = result.transformDeferred(CircuitBreakerOperator.of(cfg.getCircuitBreaker()));
      }

      return result;
   }
}
