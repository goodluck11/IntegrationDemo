package com.cbq.restclient.core;

import com.cbq.restclient.model.CBQResponse;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Advanced execution patterns for complex workflows.
 *
 * <p>Supports:</p>
 * <ul>
 *   <li>Sequential then fire-and-forget parallel</li>
 *   <li>Sequential with rollback on failure</li>
 *   <li>Mixed sync/async database calls</li>
 *   <li>Fire-and-forget with error handling</li>
 *   <li>Compensating transactions</li>
 * </ul>
 *
 * <h2>Usage:</h2>
 * <pre>{@code
 * CBQWorkflow.start()
 *     .step(() -> client.get().uri("/status").retrieve(Status.class))
 *     .step(status -> client.post().uri("/process").bodyValue(status).retrieve(Result.class))
 *     .onSuccess(result -> fireAndForget(
 *         () -> client.post().uri("/notify").retrieve(Void.class),
 *         () -> client.post().uri("/audit").retrieve(Void.class)
 *     ))
 *     .onFailure(error -> client.post().uri("/rollback").retrieve(Void.class))
 *     .execute();
 * }</pre>
 */
@Slf4j
public class CBQWorkflow<T> {

   private static final Scheduler ASYNC_SCHEDULER = Schedulers.newBoundedElastic(
           10, 1000, "cbq-workflow-async");

   private Mono<T> chain;
   private final List<Mono<?>> fireAndForgetTasks = new ArrayList<>();
   private Function<Throwable, Mono<?>> failureHandler;
   private Consumer<Throwable> fireAndForgetErrorHandler = error ->
           log.error("Fire-and-forget task failed: {}", error.getMessage());

   private CBQWorkflow(Mono<T> initial) {
      this.chain = initial;
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // FACTORY METHODS
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Start a new workflow
    */
   public static CBQWorkflow<Void> start() {
      return new CBQWorkflow<>(Mono.empty());
   }

   /**
    * Start workflow with initial value
    */
   public static <T> CBQWorkflow<T> startWith(T value) {
      return new CBQWorkflow<>(Mono.just(value));
   }

   /**
    * Start workflow with initial Mono
    */
   public static <T> CBQWorkflow<T> startWith(Mono<T> mono) {
      return new CBQWorkflow<>(mono);
   }

   /**
    * Start workflow with HTTP call
    */
   public static <T> CBQWorkflow<T> startWith(Supplier<Mono<CBQResponse<T>>> httpCall) {
      return new CBQWorkflow<>(httpCall.get().map(CBQResponse::getBody));
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // SEQUENTIAL STEPS
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Add a sequential HTTP step (waits for completion)
    */
   public <R> CBQWorkflow<R> step(Supplier<Mono<CBQResponse<R>>> httpCall) {
      Mono<R> newChain = this.chain.then(httpCall.get().map(CBQResponse::getBody));
      return new CBQWorkflow<>(newChain);
   }

   /**
    * Add a sequential HTTP step that uses previous result
    */
   public <R> CBQWorkflow<R> step(Function<T, Mono<CBQResponse<R>>> httpCall) {
      Mono<R> newChain = this.chain.flatMap(prev -> httpCall.apply(prev).map(CBQResponse::getBody));
      CBQWorkflow<R> workflow = new CBQWorkflow<>(newChain);
      workflow.fireAndForgetTasks.addAll(this.fireAndForgetTasks);
      workflow.failureHandler = (Function<Throwable, Mono<?>>) (Object) this.failureHandler;
      workflow.fireAndForgetErrorHandler = this.fireAndForgetErrorHandler;
      return workflow;
   }

   /**
    * Add a sequential step with raw Mono (for DB calls, etc.)
    */
   public <R> CBQWorkflow<R> stepMono(Supplier<Mono<R>> monoCall) {
      Mono<R> newChain = this.chain.then(monoCall.get());
      return new CBQWorkflow<>(newChain);
   }

   /**
    * Add a sequential step with raw Mono that uses previous result
    */
   public <R> CBQWorkflow<R> stepMono(Function<T, Mono<R>> monoCall) {
      Mono<R> newChain = this.chain.flatMap(monoCall);
      CBQWorkflow<R> workflow = new CBQWorkflow<>(newChain);
      workflow.fireAndForgetTasks.addAll(this.fireAndForgetTasks);
      workflow.failureHandler = (Function<Throwable, Mono<?>>) (Object) this.failureHandler;
      workflow.fireAndForgetErrorHandler = this.fireAndForgetErrorHandler;
      return workflow;
   }

   /**
    * Add a SYNC blocking step (e.g., sync DB call) - runs on bounded elastic
    */
   public <R> CBQWorkflow<R> stepSync(Supplier<R> syncCall) {
      Mono<R> newChain = this.chain.then(
              Mono.fromCallable(syncCall::get).subscribeOn(Schedulers.boundedElastic())
      );
      return new CBQWorkflow<>(newChain);
   }

   /**
    * Add a SYNC blocking step that uses previous result
    */
   public <R> CBQWorkflow<R> stepSync(Function<T, R> syncCall) {
      Mono<R> newChain = this.chain.flatMap(prev ->
              Mono.fromCallable(() -> syncCall.apply(prev)).subscribeOn(Schedulers.boundedElastic())
      );
      CBQWorkflow<R> workflow = new CBQWorkflow<>(newChain);
      workflow.fireAndForgetTasks.addAll(this.fireAndForgetTasks);
      workflow.failureHandler = (Function<Throwable, Mono<?>>) (Object) this.failureHandler;
      workflow.fireAndForgetErrorHandler = this.fireAndForgetErrorHandler;
      return workflow;
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // STEP THAT CONTINUES ON ERROR
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Add a step that continues even if it fails (error is logged but doesn't stop workflow)
    */
   public <R> CBQWorkflow<T> stepContinueOnError(Function<T, Mono<CBQResponse<R>>> httpCall) {
      Mono<T> newChain = this.chain.flatMap(prev ->
              httpCall.apply(prev)
                      .map(CBQResponse::getBody)
                      .doOnError(e -> log.warn("Step failed but continuing: {}", e.getMessage()))
                      .onErrorResume(e -> Mono.empty())
                      .then(Mono.just(prev))
      );
      CBQWorkflow<T> workflow = new CBQWorkflow<>(newChain);
      workflow.fireAndForgetTasks.addAll(this.fireAndForgetTasks);
      workflow.failureHandler = this.failureHandler;
      workflow.fireAndForgetErrorHandler = this.fireAndForgetErrorHandler;
      return workflow;
   }

   /**
    * Add a step that continues on error and executes a fallback
    */
   public <R> CBQWorkflow<T> stepContinueOnError(
           Function<T, Mono<CBQResponse<R>>> httpCall,
           Consumer<Throwable> onError) {
      Mono<T> newChain = this.chain.flatMap(prev ->
              httpCall.apply(prev)
                      .map(CBQResponse::getBody)
                      .doOnError(onError)
                      .onErrorResume(e -> Mono.empty())
                      .then(Mono.just(prev))
      );
      CBQWorkflow<T> workflow = new CBQWorkflow<>(newChain);
      workflow.fireAndForgetTasks.addAll(this.fireAndForgetTasks);
      workflow.failureHandler = this.failureHandler;
      workflow.fireAndForgetErrorHandler = this.fireAndForgetErrorHandler;
      return workflow;
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // FIRE AND FORGET
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Add fire-and-forget HTTP calls to execute after success (non-blocking)
    */
   @SafeVarargs
   public final CBQWorkflow<T> fireAndForget(Supplier<? extends Mono<? extends CBQResponse<?>>>... httpCalls) {
      for (Supplier<? extends Mono<? extends CBQResponse<?>>> call : httpCalls) {
         fireAndForgetTasks.add(call.get().then());
      }
      return this;
   }

   /**
    * Add fire-and-forget Monos (for DB calls, notifications, etc.)
    */
   @SafeVarargs
   public final CBQWorkflow<T> fireAndForgetMono(Supplier<? extends Mono<?>>... monoCalls) {
      for (Supplier<? extends Mono<?>> call : monoCalls) {
         fireAndForgetTasks.add(call.get().then());
      }
      return this;
   }

   /**
    * Add fire-and-forget sync calls (run on bounded elastic scheduler)
    */
   public CBQWorkflow<T> fireAndForgetSync(Runnable... syncCalls) {
      for (Runnable call : syncCalls) {
         fireAndForgetTasks.add(Mono.fromRunnable(call).subscribeOn(ASYNC_SCHEDULER));
      }
      return this;
   }

   /**
    * Add fire-and-forget that uses the result
    */
   public CBQWorkflow<T> fireAndForgetWith(Function<T, Mono<?>> task) {
      // Store for later execution with result
      Mono<T> newChain = this.chain.doOnNext(result ->
              task.apply(result)
                      .subscribeOn(ASYNC_SCHEDULER)
                      .doOnError(fireAndForgetErrorHandler)
                      .onErrorResume(e -> Mono.empty())
                      .subscribe()
      );
      return new CBQWorkflow<>(newChain);
   }

   /**
    * Set custom error handler for fire-and-forget tasks
    */
   public CBQWorkflow<T> onFireAndForgetError(Consumer<Throwable> handler) {
      this.fireAndForgetErrorHandler = handler;
      return this;
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // ERROR HANDLING / ROLLBACK
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Set failure handler (rollback, compensation, etc.)
    */
   public CBQWorkflow<T> onFailure(Function<Throwable, Mono<?>> handler) {
      this.failureHandler = handler;
      return this;
   }

   /**
    * Set failure handler with HTTP call
    */
   public CBQWorkflow<T> onFailure(Supplier<? extends Mono<? extends CBQResponse<?>>> httpCall) {
      this.failureHandler = error -> httpCall.get().then();
      return this;
   }

   /**
    * Set sync failure handler (e.g., DB update)
    */
   public CBQWorkflow<T> onFailureSync(Consumer<Throwable> handler) {
      this.failureHandler = error -> Mono.fromRunnable(() -> handler.accept(error))
              .subscribeOn(Schedulers.boundedElastic())
              .then();
      return this;
   }

   // ═══════════════════════════════════════════════════════════════════════════
   // EXECUTION
   // ═══════════════════════════════════════════════════════════════════════════

   /**
    * Execute the workflow and block for result
    */
   public T execute() {
      return executeAsync().block();
   }

   /**
    * Execute the workflow and block with timeout
    */
   public T execute(Duration timeout) {
      return executeAsync().block(timeout);
   }

   /**
    * Execute the workflow asynchronously
    */
   public Mono<T> executeAsync() {
      Mono<T> workflow = chain;

      // Add failure handler
      if (failureHandler != null) {
         workflow = workflow.onErrorResume(error -> {
            log.error("Workflow failed, executing failure handler: {}", error.getMessage());
            return failureHandler.apply(error)
                    .then(Mono.error(error));  // Re-throw after handling
         });
      }

      // Trigger fire-and-forget tasks on success
      if (!fireAndForgetTasks.isEmpty()) {
         workflow = workflow.doOnSuccess(result -> {
            log.debug("Triggering {} fire-and-forget tasks", fireAndForgetTasks.size());
            Flux.merge(fireAndForgetTasks)
                    .subscribeOn(ASYNC_SCHEDULER)
                    .doOnError(fireAndForgetErrorHandler)
                    .onErrorResume(e -> Mono.empty())
                    .subscribe();
         });
      }

      return workflow;
   }

   /**
    * Execute and ignore result (for workflows that only have side effects)
    */
   public void executeAndForget() {
      executeAsync()
              .doOnError(e -> log.error("Workflow failed: {}", e.getMessage()))
              .onErrorResume(e -> Mono.empty())
              .subscribe();
   }
}