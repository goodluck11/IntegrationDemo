package com.cbq.restclient.tracing;

import com.cbq.restclient.config.TracingConfig;
import org.springframework.http.HttpHeaders;
import reactor.util.context.Context;

import java.util.UUID;

/**
 * Manages request tracing: correlation IDs, trace propagation.
 */
public class TracingService {

    private final TracingConfig config;

    public TracingService(TracingConfig config) {
        this.config = config;
    }

    /**
     * Extracts or generates a correlation ID from headers
     */
    public String getOrCreateCorrelationId(HttpHeaders headers) {
        if (!config.isEnabled() || !config.isCorrelationIdEnabled()) {
            return null;
        }

        String correlationId = headers.getFirst(config.getCorrelationIdHeader());
        
        if (correlationId == null && config.isGenerateIfMissing()) {
            correlationId = generateCorrelationId();
        }
        
        return correlationId;
    }

    /**
     * Adds tracing headers to outgoing request
     */
    public void addTracingHeaders(HttpHeaders headers, String correlationId) {
        if (!config.isEnabled()) return;

        // Add correlation ID
        if (config.isCorrelationIdEnabled() && correlationId != null) {
            headers.set(config.getCorrelationIdHeader(), correlationId);
        }

        // Propagate OpenTelemetry/B3 headers from reactor context if available
        if (config.isOpenTelemetryEnabled()) {
            // These would typically come from the current span context
            // For now, we just ensure headers are propagated if present
        }
    }

    /**
     * Propagates headers from incoming context to outgoing request
     */
    public void propagateHeaders(HttpHeaders source, HttpHeaders target) {
        if (!config.isEnabled()) return;

        for (String header : config.getAllPropagationHeaders()) {
            String value = source.getFirst(header);
            if (value != null) {
                target.set(header, value);
            }
        }
    }

    public Context createTracingContext(String correlationId, String requestId) {
        Context ctx = Context.empty();
        
        if (correlationId != null) {
            ctx = ctx.put("correlationId", correlationId);
        }
        if (requestId != null) {
            ctx = ctx.put("requestId", requestId);
        }
        
        return ctx;
    }

    public String generateCorrelationId() {
        return UUID.randomUUID().toString();
    }

    public String generateRequestId() {
        return UUID.randomUUID().toString().substring(0, 8);
    }
}
