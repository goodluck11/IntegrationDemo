package com.cbq.restclient.v2;

import reactor.core.publisher.Mono;

import java.util.function.Function;
import java.util.function.Supplier;

/*
 * @created by 24/01/2026  - 21:37
 * @project cbq-rest-full-client
 * @author Goodluck
 */
public class CBQSequenceV2 {
   private Mono<?> chain = Mono.empty();

   public <T> CBQSequenceV2 then(Supplier<Mono<T>> step) {
      chain = chain.then(step.get());
      return this;
   }

   public <I, O> CBQSequenceV2 then(Function<I, Mono<O>> step) {
      chain = chain.flatMap(v -> step.apply((I) v));
      return this;
   }

   public <T> Mono<T> execute() {
      return (Mono<T>) chain;
   }
}
