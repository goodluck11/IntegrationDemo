package com.cbq.restclient.exception;

import lombok.Getter;

/**
 * Base exception for all CBQ REST Client errors.
 */
@Getter
public class CBQRestClientException extends RuntimeException {
    
    private final String requestId;
    private final String uri;
    private final String method;
    private final Integer statusCode;

    public CBQRestClientException(String message) {
        super(message);
        this.requestId = null;
        this.uri = null;
        this.method = null;
        this.statusCode = null;
    }

    public CBQRestClientException(String message, Throwable cause) {
        super(message, cause);
        this.requestId = null;
        this.uri = null;
        this.method = null;
        this.statusCode = null;
    }

    public CBQRestClientException(String message, String requestId, String uri, String method) {
        super(message);
        this.requestId = requestId;
        this.uri = uri;
        this.method = method;
        this.statusCode = null;
    }

    public CBQRestClientException(String message, String requestId, String uri, String method, Integer statusCode) {
        super(message);
        this.requestId = requestId;
        this.uri = uri;
        this.method = method;
        this.statusCode = statusCode;
    }

    public CBQRestClientException(String message, Throwable cause, String requestId, String uri, String method) {
        super(message, cause);
        this.requestId = requestId;
        this.uri = uri;
        this.method = method;
        this.statusCode = null;
    }

   @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(getClass().getSimpleName());
        sb.append(": ").append(getMessage());
        if (requestId != null) sb.append(" [requestId=").append(requestId).append("]");
        if (method != null && uri != null) sb.append(" [").append(method).append(" ").append(uri).append("]");
        if (statusCode != null) sb.append(" [status=").append(statusCode).append("]");
        return sb.toString();
    }
}
