package com.cbq.restclient.v2;

import lombok.Builder;
import lombok.Value;

/*
 * @created by 24/01/2026  - 21:43
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Value
@Builder
public class EmailConfigV2 {
   boolean enabled;

   public static EmailConfigV2 disabled() {
      return EmailConfigV2.builder().enabled(false).build();
   }
}
