package com.cbq.restclient.v2;

/*
 * @created by 24/01/2026  - 21:53
 * @project cbq-rest-full-client
 * @author Goodluck
 */
public class ServerErrorExceptionV2 extends CBQHttpExceptionV2 {
   public ServerErrorExceptionV2(int status, String msg) {
      super(status, msg);
   }
}
