package com.cbq.restclient.config;

import lombok.Getter;

import java.time.Duration;

/**
 * Timeout configuration supporting all Netty timeout types.
 * 
 * <ul>
 *   <li><b>Connection timeout</b> - Time to establish TCP connection</li>
 *   <li><b>Read timeout</b> - Time between data packets when reading</li>
 *   <li><b>Write timeout</b> - Time between data packets when writing</li>
 *   <li><b>Response timeout</b> - Total time for entire response</li>
 * </ul>
 */
@Getter
public class TimeoutConfig {
    
    private Duration connectionTimeout = Duration.ofSeconds(10);
    private Duration readTimeout = Duration.ofSeconds(30);
    private Duration writeTimeout = Duration.ofSeconds(30);
    private Duration responseTimeout = Duration.ofSeconds(60);

    private TimeoutConfig() {}

    public static TimeoutConfig defaults() {
        return new TimeoutConfig();
    }

    public static TimeoutConfig custom() {
        return new TimeoutConfig();
    }

    public TimeoutConfig connection(Duration timeout) {
        this.connectionTimeout = timeout;
        return this;
    }

    public TimeoutConfig read(Duration timeout) {
        this.readTimeout = timeout;
        return this;
    }

    public TimeoutConfig write(Duration timeout) {
        this.writeTimeout = timeout;
        return this;
    }

    public TimeoutConfig response(Duration timeout) {
        this.responseTimeout = timeout;
        return this;
    }

   public TimeoutConfig copy() {
        return new TimeoutConfig()
                .connection(this.connectionTimeout)
                .read(this.readTimeout)
                .write(this.writeTimeout)
                .response(this.responseTimeout);
    }
}
