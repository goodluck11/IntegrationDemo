package com.cbq.restclient.v2;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.retry.Retry;
import lombok.Builder;
import lombok.Value;

/*
 * @created by 24/01/2026  - 21:41
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Value
@Builder
public class ResilienceConfigV2 {
   Retry retry;
   CircuitBreaker circuitBreaker;
   RateLimiter rateLimiter;
   BulkheadConfigV2 bulkhead;

   public boolean isEnabled() {
      return retry != null || circuitBreaker != null || rateLimiter != null || bulkhead != null;
   }

   public static ResilienceConfigV2 disabled() {
      return ResilienceConfigV2.builder().build();
   }
}
