package com.cbq.restclient.v2;

import lombok.Builder;
import lombok.Value;

import java.time.Duration;

/*
 * @created by 24/01/2026  - 21:41
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Value
@Builder
public class SslConfigV2 {
   boolean enabled;
   String certificatePath;
   Duration handshakeTimeout;

   public static SslConfigV2 disabled() {
      return SslConfigV2.builder().enabled(false).build();
   }
}
