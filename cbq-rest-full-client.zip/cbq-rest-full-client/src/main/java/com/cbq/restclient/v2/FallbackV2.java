package com.cbq.restclient.v2;

/*
 * @created by 24/01/2026  - 21:53
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@FunctionalInterface
public interface FallbackV2<T> {
   T apply(Throwable t);
}
