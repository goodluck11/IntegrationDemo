package com.cbq.restclient.filter;

import com.cbq.restclient.exception.*;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Error mapper for transforming HTTP errors to domain exceptions.
 * 
 * <p>Usage:</p>
 * <pre>{@code
 * client.get()
 *     .uri("/users/1")
 *     .onStatus(HttpStatus::is4xxClientError, resp -> new UserNotFoundException())
 *     .onStatus(HttpStatus::is5xxServerError, resp -> new ServiceUnavailableException())
 *     .retrieve(User.class);
 * }</pre>
 */
public class ErrorMapper {

    private final Predicate<HttpStatus> statusPredicate;
    private final Function<ErrorContext, Throwable> exceptionMapper;

    private ErrorMapper(Predicate<HttpStatus> statusPredicate, 
                       Function<ErrorContext, Throwable> exceptionMapper) {
        this.statusPredicate = statusPredicate;
        this.exceptionMapper = exceptionMapper;
    }

    /**
     * Creates an error mapper for specific status codes
     */
    public static ErrorMapper onStatus(Predicate<HttpStatus> statusPredicate,
                                       Function<ErrorContext, Throwable> exceptionMapper) {
        return new ErrorMapper(statusPredicate, exceptionMapper);
    }

    /**
     * Creates an error mapper for 4xx client errors
     */
    public static ErrorMapper on4xx(Function<ErrorContext, Throwable> exceptionMapper) {
        return new ErrorMapper(HttpStatus::is4xxClientError, exceptionMapper);
    }

    /**
     * Creates an error mapper for 5xx server errors
     */
    public static ErrorMapper on5xx(Function<ErrorContext, Throwable> exceptionMapper) {
        return new ErrorMapper(HttpStatus::is5xxServerError, exceptionMapper);
    }

    /**
     * Creates an error mapper for a specific status code
     */
    public static ErrorMapper onStatusCode(int code, Function<ErrorContext, Throwable> exceptionMapper) {
        return new ErrorMapper(status -> status.value() == code, exceptionMapper);
    }

    /**
     * Creates an error mapper for 404 Not Found
     */
    public static ErrorMapper on404(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(404, exceptionMapper);
    }

    /**
     * Creates an error mapper for 401 Unauthorized
     */
    public static ErrorMapper on401(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(401, exceptionMapper);
    }

    /**
     * Creates an error mapper for 403 Forbidden
     */
    public static ErrorMapper on403(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(403, exceptionMapper);
    }

    /**
     * Creates an error mapper for 429 Too Many Requests
     */
    public static ErrorMapper on429(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(429, exceptionMapper);
    }

    /**
     * Creates an error mapper for 503 Service Unavailable
     */
    public static ErrorMapper on503(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(503, exceptionMapper);
    }

    public boolean matches(HttpStatus status) {
        return statusPredicate.test(status);
    }

    public Throwable mapError(ErrorContext context) {
        return exceptionMapper.apply(context);
    }

    /**
     * Context available when mapping errors
     */
    public static class ErrorContext {
        private final String requestId;
        private final HttpStatus status;
        private final String method;
        private final String uri;
        private final String responseBody;
        private final org.springframework.http.HttpHeaders headers;

        public ErrorContext(String requestId, HttpStatus status, String method, String uri,
                          String responseBody, org.springframework.http.HttpHeaders headers) {
            this.requestId = requestId;
            this.status = status;
            this.method = method;
            this.uri = uri;
            this.responseBody = responseBody;
            this.headers = headers;
        }

        public String getRequestId() { return requestId; }
        public HttpStatus getStatus() { return status; }
        public int getStatusCode() { return status.value(); }
        public String getMethod() { return method; }
        public String getUri() { return uri; }
        public String getResponseBody() { return responseBody; }
        public org.springframework.http.HttpHeaders getHeaders() { return headers; }

        /**
         * Creates a standard CBQRestClientException from this context
         */
        public CBQRestClientException toException() {
            return new CBQRestClientException(
                    "HTTP " + status.value() + " " + status.getReasonPhrase(),
                    requestId, uri, method, status.value()
            );
        }

        /**
         * Creates a standard CBQRestClientException with a custom message
         */
        public CBQRestClientException toException(String message) {
            return new CBQRestClientException(message, requestId, uri, method, status.value());
        }
    }
}
