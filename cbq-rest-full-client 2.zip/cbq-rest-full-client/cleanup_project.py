import re
import sys
import os

def remove_comments(text):
    # Regex to match strings, line comments, and block comments
    # Also handles XML comments <!-- ... -->
    # And shell/yaml style comments starting with #
    pattern = r'("(?:\\.|[^"\\])*?"|\'(?:\\.|[^\'\\])*?\'|//.*?$|/\*.*?\*/|<!--.*?-->|^[ \t]*#.*?$)'
    
    def replacer(match):
        s = match.group(0)
        if s.startswith('/') or s.startswith('<!--') or s.strip().startswith('#'):
            return "" # it's a comment
        else:
            return s # it's a string

    return re.sub(pattern, replacer, text, flags=re.DOTALL | re.MULTILINE)

def process_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        cleaned_content = remove_comments(content)
        
        # Remove excessive blank lines created by comment removal
        # Also remove trailing spaces
        lines = [line.rstrip() for line in cleaned_content.splitlines()]
        # Remove empty lines if multiple in a row
        new_lines = []
        last_empty = False
        for line in lines:
            if not line:
                if not last_empty:
                    new_lines.append(line)
                    last_empty = True
            else:
                new_lines.append(line)
                last_empty = False
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("\n".join(new_lines).strip() + '\n')
        print(f"Processed: {filepath}")
    except Exception as e:
        print(f"Error processing {filepath}: {e}")

if __name__ == "__main__":
    # Process all Java, XML, Properties, and YAML files in src
    for root, dirs, files in os.walk('src'):
        for file in files:
            if file.endswith(('.java', '.xml', '.properties', '.yml', '.yaml')):
                process_file(os.path.join(root, file))
    
    # Process root build files
    for file in os.listdir('.'):
        if file in ('pom.xml', 'build.gradle', 'settings.gradle'):
            process_file(file)
