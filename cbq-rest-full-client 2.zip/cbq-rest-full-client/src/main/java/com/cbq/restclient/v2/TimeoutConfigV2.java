package com.cbq.restclient.v2;

import lombok.Builder;
import lombok.Value;

import java.time.Duration;

@Value
@Builder
public class TimeoutConfigV2 {
   Duration connection;
   Duration read;
   Duration write;
   Duration response;

   public static TimeoutConfigV2 defaults() {
      return TimeoutConfigV2.builder()
              .connection(Duration.ofSeconds(3))
              .read(Duration.ofSeconds(5))
              .write(Duration.ofSeconds(5))
              .response(Duration.ofSeconds(6))
              .build();
   }
}
