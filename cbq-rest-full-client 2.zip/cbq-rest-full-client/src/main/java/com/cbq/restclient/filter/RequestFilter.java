package com.cbq.restclient.filter;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.util.Map;

@FunctionalInterface
public interface RequestFilter {

    Mono<RequestContext> filter(RequestContext context);

    @Getter
    class RequestContext {
        private final String requestId;
        private final HttpMethod method;
        @Setter
        private String uri;
        private final HttpHeaders headers;
        @Setter
        private Object body;
        private final Map<String, Object> attributes;

        public RequestContext(String requestId, HttpMethod method, String uri,
                            HttpHeaders headers, Object body, Map<String, Object> attributes) {
            this.requestId = requestId;
            this.method = method;
            this.uri = uri;
            this.headers = headers;
            this.body = body;
            this.attributes = attributes;
        }

       public void addHeader(String name, String value) {
            headers.add(name, value);
        }

        public void setAttribute(String key, Object value) {
            attributes.put(key, value);
        }

        @SuppressWarnings("unchecked")
        public <T> T getAttribute(String key) {
            return (T) attributes.get(key);
        }
    }
}
