package com.cbq.restclient.v2;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ObservabilityConfigV2 {
   boolean enabled;
   MeterRegistry meterRegistry;
   String clientName;

   public static ObservabilityConfigV2 disabled() {
      return ObservabilityConfigV2.builder().enabled(false).build();
   }
}
