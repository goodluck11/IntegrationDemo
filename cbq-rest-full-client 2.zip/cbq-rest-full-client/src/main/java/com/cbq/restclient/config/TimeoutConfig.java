package com.cbq.restclient.config;

import lombok.Getter;

import java.time.Duration;

@Getter
public class TimeoutConfig {

    private Duration connectionTimeout = Duration.ofSeconds(10);
    private Duration readTimeout = Duration.ofSeconds(30);
    private Duration writeTimeout = Duration.ofSeconds(30);
    private Duration responseTimeout = Duration.ofSeconds(60);

    private TimeoutConfig() {}

    public static TimeoutConfig defaults() {
        return new TimeoutConfig();
    }

    public static TimeoutConfig custom() {
        return new TimeoutConfig();
    }

    public TimeoutConfig connection(Duration timeout) {
        this.connectionTimeout = timeout;
        return this;
    }

    public TimeoutConfig read(Duration timeout) {
        this.readTimeout = timeout;
        return this;
    }

    public TimeoutConfig write(Duration timeout) {
        this.writeTimeout = timeout;
        return this;
    }

    public TimeoutConfig response(Duration timeout) {
        this.responseTimeout = timeout;
        return this;
    }

   public TimeoutConfig copy() {
        return new TimeoutConfig()
                .connection(this.connectionTimeout)
                .read(this.readTimeout)
                .write(this.writeTimeout)
                .response(this.responseTimeout);
    }
}
