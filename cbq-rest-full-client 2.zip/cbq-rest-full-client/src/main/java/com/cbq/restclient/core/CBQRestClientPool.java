package com.cbq.restclient.core;

import com.cbq.restclient.config.*;
import lombok.Getter;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class CBQRestClientPool {
   private final String baseUrl;
   private final ResilienceConfig resilience;
   private final LoggingConfig logging;
   private final EmailNotifierConfig emailNotifier;
   private final TracingConfig tracing;
   private final MetricsConfig metrics;
   private final SslConfig ssl;
   private final Map<String, String> defaultHeaders;

   private final Map<String, CBQRestClient> clients = new ConcurrentHashMap<>();

   public static final TimeoutProfile FAST_PROFILE = TimeoutProfile.builder()
           .connection(Duration.ofSeconds(2))
           .read(Duration.ofSeconds(5))
           .write(Duration.ofSeconds(5))
           .response(Duration.ofSeconds(10))
           .build();

   public static final TimeoutProfile DEFAULT_PROFILE = TimeoutProfile.builder()
           .connection(Duration.ofSeconds(5))
           .read(Duration.ofSeconds(30))
           .write(Duration.ofSeconds(30))
           .response(Duration.ofSeconds(60))
           .build();

   public static final TimeoutProfile SLOW_PROFILE = TimeoutProfile.builder()
           .connection(Duration.ofSeconds(10))
           .read(Duration.ofMinutes(2))
           .write(Duration.ofMinutes(2))
           .response(Duration.ofMinutes(5))
           .build();

   public static final TimeoutProfile BATCH_PROFILE = TimeoutProfile.builder()
           .connection(Duration.ofSeconds(10))
           .read(Duration.ofMinutes(10))
           .write(Duration.ofMinutes(10))
           .response(Duration.ofMinutes(30))
           .build();

   private CBQRestClientPool(Builder builder) {
      this.baseUrl = builder.baseUrl;
      this.resilience = builder.resilience;
      this.logging = builder.logging;
      this.emailNotifier = builder.emailNotifier;
      this.tracing = builder.tracing;
      this.metrics = builder.metrics;
      this.ssl = builder.ssl;
      this.defaultHeaders = builder.defaultHeaders;
   }

   public CBQRestClient getDefault() {
      return getOrCreate("default", DEFAULT_PROFILE);
   }

   public CBQRestClient getFast() {
      return getOrCreate("fast", FAST_PROFILE);
   }

   public CBQRestClient getSlow() {
      return getOrCreate("slow", SLOW_PROFILE);
   }

   public CBQRestClient getBatch() {
      return getOrCreate("batch", BATCH_PROFILE);
   }

   public CBQRestClient getOrCreate(String name, TimeoutProfile profile) {
      return clients.computeIfAbsent(name, n -> createClient(n, profile));
   }

   public CBQRestClient get(String name) {
      CBQRestClient client = clients.get(name);
      if (client == null) {
         throw new IllegalArgumentException("No client with name: " + name +
                 ". Use getOrCreate() to create it first.");
      }
      return client;
   }

   private CBQRestClient createClient(String name, TimeoutProfile profile) {
      CBQRestClientBuilder builder = CBQRestClientBuilder.builder(name)
              .baseUrl(baseUrl)
              .timeouts(TimeoutConfig.custom()
                      .connection(profile.getConnection())
                      .read(profile.getRead())
                      .write(profile.getWrite())
                      .response(profile.getResponse()));

      if (resilience != null) builder.resilience(resilience);
      if (logging != null) builder.logging(logging);
      if (emailNotifier != null) builder.emailNotifier(emailNotifier);
      if (tracing != null) builder.tracing(tracing);
      if (metrics != null) builder.metrics(metrics);
      if (ssl != null) builder.ssl(ssl);
      if (defaultHeaders != null) {
         builder.headers(h -> h.putAll(defaultHeaders));
      }

      return builder.build();
   }

   public void shutdown() {
      clients.values().forEach(CBQRestClient::shutdown);
      clients.clear();
   }

   public static Builder builder() {
      return new Builder();
   }

   @Getter
   @lombok.Builder
   public static class TimeoutProfile {
      private final Duration connection;
      private final Duration read;
      private final Duration write;
      private final Duration response;
   }

   public static class Builder {
      private String baseUrl;
      private ResilienceConfig resilience;
      private LoggingConfig logging;
      private EmailNotifierConfig emailNotifier;
      private TracingConfig tracing;
      private MetricsConfig metrics;
      private SslConfig ssl;
      private Map<String, String> defaultHeaders;

      public Builder baseUrl(String baseUrl) {
         this.baseUrl = baseUrl;
         return this;
      }

      public Builder resilience(ResilienceConfig resilience) {
         this.resilience = resilience;
         return this;
      }

      public Builder logging(LoggingConfig logging) {
         this.logging = logging;
         return this;
      }

      public Builder emailNotifier(EmailNotifierConfig emailNotifier) {
         this.emailNotifier = emailNotifier;
         return this;
      }

      public Builder tracing(TracingConfig tracing) {
         this.tracing = tracing;
         return this;
      }

      public Builder metrics(MetricsConfig metrics) {
         this.metrics = metrics;
         return this;
      }

      public Builder ssl(SslConfig ssl) {
         this.ssl = ssl;
         return this;
      }

      public Builder defaultHeaders(Map<String, String> headers) {
         this.defaultHeaders = headers;
         return this;
      }

      public CBQRestClientPool build() {
         return new CBQRestClientPool(this);
      }
   }
}
