package com.cbq.restclient.core;

import com.cbq.restclient.model.CBQResponse;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

@Slf4j
public class CBQWorkflow<T> {
   private static final Scheduler ASYNC_SCHEDULER = Schedulers.newBoundedElastic(
           Runtime.getRuntime().availableProcessors() * 2,
           10_000,
           "cbq-workflow-async",
           60,
           true
   );

   private final Mono<T> chain;

   private final List<Supplier<Mono<?>>> fireAndForgetTaskSuppliers;
   private final Function<Throwable, Mono<?>> failureHandler;
   private final Consumer<Throwable> fireAndForgetErrorHandler;
   private final int maxConcurrentFireAndForget;

   private CBQWorkflow(
           Mono<T> chain,
           List<Supplier<Mono<?>>> fireAndForgetTaskSuppliers,
           Function<Throwable, Mono<?>> failureHandler,
           Consumer<Throwable> fireAndForgetErrorHandler,
           int maxConcurrentFireAndForget
   ) {
      this.chain = chain;
      this.fireAndForgetTaskSuppliers = fireAndForgetTaskSuppliers;
      this.failureHandler = failureHandler;
      this.fireAndForgetErrorHandler = fireAndForgetErrorHandler;
      this.maxConcurrentFireAndForget = maxConcurrentFireAndForget;
   }

   private CBQWorkflow(Mono<T> initial) {
      this(
              initial,
              new CopyOnWriteArrayList<>(),
              null,
              error -> log.error("Fire-and-forget task failed: {}", error.getMessage()),
              16
      );
   }

   public static CBQWorkflow<Void> start() {
      return new CBQWorkflow<>(Mono.empty());
   }

   public static <T> CBQWorkflow<T> startWith(T value) {
      return new CBQWorkflow<>(Mono.just(value));
   }

   public static <T> CBQWorkflow<T> startWith(Mono<T> mono) {
      return new CBQWorkflow<>(mono);
   }

   public static <T> CBQWorkflow<T> startWith(Supplier<Mono<CBQResponse<T>>> httpCall) {

      return new CBQWorkflow<>(Mono.defer(() -> httpCall.get().map(CBQResponse::getBody)));
   }

   private <R> CBQWorkflow<R> next(Mono<R> newChain) {
      return new CBQWorkflow<>(
              newChain,
              new CopyOnWriteArrayList<>(this.fireAndForgetTaskSuppliers),
              this.failureHandler,
              this.fireAndForgetErrorHandler,
              this.maxConcurrentFireAndForget
      );
   }

   private CBQWorkflow<T> copy() {
      return new CBQWorkflow<>(
              this.chain,
              new CopyOnWriteArrayList<>(this.fireAndForgetTaskSuppliers),
              this.failureHandler,
              this.fireAndForgetErrorHandler,
              this.maxConcurrentFireAndForget
      );
   }

   public <R> CBQWorkflow<R> step(Supplier<Mono<CBQResponse<R>>> httpCall) {
      Mono<R> newChain = this.chain.flatMap(prev ->
              Mono.defer(httpCall::get).map(CBQResponse::getBody)
      );
      return next(newChain);
   }

   public <R> CBQWorkflow<R> step(Function<T, Mono<CBQResponse<R>>> httpCall) {
      Mono<R> newChain = this.chain.flatMap(prev -> httpCall.apply(prev).map(CBQResponse::getBody));
      return next(newChain);
   }

   public <R> CBQWorkflow<R> stepMono(Supplier<Mono<R>> monoCall) {
      Mono<R> newChain = this.chain.flatMap(prev -> Mono.defer(monoCall::get));
      return next(newChain);
   }

   public <R> CBQWorkflow<R> stepMono(Function<T, Mono<R>> monoCall) {
      Mono<R> newChain = this.chain.flatMap(monoCall);
      return next(newChain);
   }

   public <R> CBQWorkflow<R> stepSync(Supplier<R> syncCall) {
      Mono<R> newChain = this.chain.flatMap(prev ->
              Mono.fromCallable(syncCall::get)
                      .subscribeOn(ASYNC_SCHEDULER)
      );
      return next(newChain);
   }

   public <R> CBQWorkflow<R> stepSync(Function<T, R> syncCall) {
      Mono<R> newChain = this.chain.flatMap(prev ->
              Mono.fromCallable(() -> syncCall.apply(prev)).subscribeOn(ASYNC_SCHEDULER)
      );
      return next(newChain);
   }

   public <R> CBQWorkflow<R> stepWithTimeout(
           Function<T, Mono<CBQResponse<R>>> httpCall,
           Duration timeout
   ) {
      Mono<R> newChain = this.chain.flatMap(prev ->
              httpCall.apply(prev)
                      .map(CBQResponse::getBody)
                      .timeout(timeout)
      );
      return next(newChain);
   }

   public <R> CBQWorkflow<T> stepContinueOnError(Function<T, Mono<CBQResponse<R>>> httpCall) {
      Mono<T> newChain = this.chain.flatMap(prev ->
              httpCall.apply(prev)
                      .map(CBQResponse::getBody)
                      .doOnError(e -> log.warn("Step failed but continuing: {}", e.getMessage()))
                      .onErrorResume(e -> Mono.empty())
                      .then(Mono.just(prev))
      );
      return next(newChain);
   }

   public <R> CBQWorkflow<T> stepContinueOnError(
           Function<T, Mono<R>> call,
           Consumer<R> onSuccess,
           Consumer<Throwable> onError
   ) {
      Mono<T> newChain = this.chain.flatMap(prev ->
              call.apply(prev)
                      .doOnNext(onSuccess)
                      .doOnError(onError)
                      .onErrorResume(e -> Mono.empty())
                      .then(Mono.just(prev))
      );
      return next(newChain);
   }

   public <R> CBQWorkflow<T> stepContinueOnError(
           Function<T, Mono<R>> call,
           Consumer<Throwable> onError
   ) {
      return stepContinueOnError(call, r -> {
      }, onError);
   }

   @SafeVarargs
   public final CBQWorkflow<T> fireAndForget(Supplier<? extends Mono<? extends CBQResponse<?>>>... httpCalls) {
      CBQWorkflow<T> result = copy();
      for (Supplier<? extends Mono<? extends CBQResponse<?>>> call : httpCalls) {
         result.fireAndForgetTaskSuppliers.add(() -> call.get().then());
      }
      return result;
   }

   @SafeVarargs
   public final CBQWorkflow<T> fireAndForgetMono(Supplier<? extends Mono<?>>... monoCalls) {
      CBQWorkflow<T> result = copy();
      for (Supplier<? extends Mono<?>> call : monoCalls) {
         result.fireAndForgetTaskSuppliers.add(() -> call.get().then());
      }
      return result;
   }

   public CBQWorkflow<T> fireAndForgetSync(Runnable... syncCalls) {
      CBQWorkflow<T> result = copy();
      for (Runnable call : syncCalls) {
         result.fireAndForgetTaskSuppliers.add(() ->
                 Mono.fromRunnable(call).subscribeOn(ASYNC_SCHEDULER)
         );
      }
      return result;
   }

   public CBQWorkflow<T> fireAndForgetWith(Function<T, Mono<?>> task) {
      CBQWorkflow<T> result = copy();

      Mono<T> newChain = chain.flatMap(value -> {
         Mono.deferContextual(context ->
                         Mono.defer(() -> task.apply(value))
                                 .subscribeOn(ASYNC_SCHEDULER)
                                 .doOnError(error -> {
                                    log.error("Fire-and-forget-with task failed: {}", error.getMessage());
                                    result.fireAndForgetErrorHandler.accept(error);
                                 })
                                 .onErrorResume(e -> Mono.empty())
                                 .contextWrite(context)
                 ).subscribe();
         return Mono.just(value);
      });
      return new CBQWorkflow<>(
              newChain,
              result.fireAndForgetTaskSuppliers,
              result.failureHandler,
              result.fireAndForgetErrorHandler,
              result.maxConcurrentFireAndForget
      );
   }

   public CBQWorkflow<T> onFireAndForgetError(Consumer<Throwable> handler) {
      return new CBQWorkflow<>(
              this.chain,
              new CopyOnWriteArrayList<>(this.fireAndForgetTaskSuppliers),
              this.failureHandler,
              handler,
              this.maxConcurrentFireAndForget
      );
   }

   public CBQWorkflow<T> withMaxConcurrentFireAndForget(int max) {
      return new CBQWorkflow<>(
              this.chain,
              new CopyOnWriteArrayList<>(this.fireAndForgetTaskSuppliers),
              this.failureHandler,
              this.fireAndForgetErrorHandler,
              max
      );
   }

   public CBQWorkflow<T> onFailure(Function<Throwable, Mono<?>> handler) {
      return new CBQWorkflow<>(
              this.chain,
              new CopyOnWriteArrayList<>(this.fireAndForgetTaskSuppliers),
              handler,
              this.fireAndForgetErrorHandler,
              this.maxConcurrentFireAndForget
      );
   }

   public CBQWorkflow<T> onFailure(Supplier<? extends Mono<? extends CBQResponse<?>>> httpCall) {
      return onFailure(error -> httpCall.get().then());
   }

   public CBQWorkflow<T> onFailureSync(Consumer<Throwable> handler) {
      return onFailure(error ->
              Mono.fromRunnable(() -> handler.accept(error))
                      .subscribeOn(ASYNC_SCHEDULER)
                      .then()
      );
   }

   public T execute() {
      return executeAsync().block();
   }

   public T execute(Duration timeout) {
      return executeAsync().block(timeout);
   }

   public Mono<T> executeAsync() {
      return Mono.deferContextual(context -> {
         Mono<T> workflow = chain;

         if (failureHandler != null) {
            workflow = workflow.onErrorResume(error -> {
               log.error("Workflow failed, executing failure handler: {}", error.getMessage());
               return failureHandler.apply(error)
                       .contextWrite(context)
                       .then(Mono.error(error));
            });
         }

         if (!fireAndForgetTaskSuppliers.isEmpty()) {
            workflow = workflow.flatMap(result -> {
               log.debug("Triggering {} fire-and-forget tasks", fireAndForgetTaskSuppliers.size());

               Flux.fromIterable(new ArrayList<>(fireAndForgetTaskSuppliers))
                       .flatMap(
                               supplier -> Mono.defer(supplier)
                                       .contextWrite(context)
                                       .doOnError(error -> {
                                           log.error("Fire-and-forget task failed: {}", error.getMessage());
                                           fireAndForgetErrorHandler.accept(error);
                                       })
                                       .onErrorResume(e -> Mono.empty()),
                               maxConcurrentFireAndForget
                       )
                       .subscribeOn(ASYNC_SCHEDULER)
                       .subscribe();

               return Mono.just(result);
            });
         }

         return workflow;
      });
   }

   public Mono<T> executeAsync(Duration timeout) {
      return executeAsync().timeout(timeout);
   }

   public void executeAndForget() {
      executeAsync()
              .doOnError(e -> log.error("Workflow failed: {}", e.getMessage()))
              .onErrorResume(e -> Mono.empty())
              .subscribeOn(ASYNC_SCHEDULER)
              .subscribe();
   }

   public static void shutdown() {
      ASYNC_SCHEDULER.dispose();
   }
}
