package com.cbq.restclient.exception;

public class ReadTimeoutException extends CBQRestClientException {
    public ReadTimeoutException(String message, String requestId, String uri, String method) {
        super(message, requestId, uri, method);
    }
    public ReadTimeoutException(String message, Throwable cause, String requestId, String uri, String method) {
        super(message, cause, requestId, uri, method);
    }
}
