package com.cbq.restclient.v2;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class EmailConfigV2 {
   boolean enabled;

   public static EmailConfigV2 disabled() {
      return EmailConfigV2.builder().enabled(false).build();
   }
}
