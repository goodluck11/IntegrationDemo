package com.cbq.restclient.tracing;

import com.cbq.restclient.config.TracingConfig;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.UUID;

public class TracingService {

    private final TracingConfig config;

    public TracingService(TracingConfig config) {
        this.config = config;
    }

    public String getOrCreateCorrelationId(HttpHeaders headers) {
        if (!config.isEnabled() || !config.isCorrelationIdEnabled()) {
            return null;
        }

        String correlationId = headers.getFirst(config.getCorrelationIdHeader());

        if (correlationId == null && config.isGenerateIfMissing()) {
            correlationId = generateCorrelationId();
        }

        return correlationId;
    }

    public String getOrCreateCorrelationId(HttpHeaders headers, Context context) {
        if (!config.isEnabled() || !config.isCorrelationIdEnabled()) {
            return null;
        }

        String correlationId = headers.getFirst(config.getCorrelationIdHeader());

        if (correlationId == null && context != null) {
            correlationId = context.<String>getOrEmpty("correlationId").orElse(null);
        }

        if (correlationId == null && config.isGenerateIfMissing()) {
            correlationId = generateCorrelationId();
        }

        return correlationId;
    }

    public void addTracingHeaders(HttpHeaders headers, String correlationId) {
        if (!config.isEnabled()) return;

        if (config.isCorrelationIdEnabled() && correlationId != null) {
            headers.set(config.getCorrelationIdHeader(), correlationId);
        }

        if (config.isOpenTelemetryEnabled()) {

        }
    }

    public void propagateHeaders(HttpHeaders source, HttpHeaders target) {
        if (!config.isEnabled()) return;

        for (String header : config.getAllPropagationHeaders()) {
            String value = source.getFirst(header);
            if (value != null) {
                target.set(header, value);
            }
        }
    }

    public Context createTracingContext(String correlationId, String requestId) {
        Context ctx = Context.empty();

        if (correlationId != null) {
            ctx = ctx.put("correlationId", correlationId);
        }
        if (requestId != null) {
            ctx = ctx.put("requestId", requestId);
        }

        return ctx;
    }

    public String generateCorrelationId() {
        return UUID.randomUUID().toString();
    }

    public String generateRequestId() {
        return UUID.randomUUID().toString().substring(0, 8);
    }
}
