package com.cbq.restclient.config;

import java.time.Duration;
import java.util.*;

public class EmailNotifierConfig {

    private boolean enabled = false;
    private boolean async = true;

    private int maxEmailsPerWindow = 5;
    private Duration rateLimitWindow = Duration.ofMinutes(1);

    private boolean circuitBreakerEnabled = true;
    private int circuitBreakerThreshold = 3;
    private Duration circuitBreakerResetTime = Duration.ofMinutes(5);

    private String host;
    private int port = 587;
    private String username;
    private String password;
    private boolean startTls = true;
    private boolean ssl = false;

    private String defaultFrom;
    private List<String> defaultTo = new ArrayList<>();
    private String defaultSubject = "CBQ Rest Client Error Notification";

    private EmailNotifierConfig() {}

    public static EmailNotifierConfig disabled() {
        return new EmailNotifierConfig();
    }

    public static EmailNotifierConfig custom() {
        return new EmailNotifierConfig().enabled(true);
    }

    public EmailNotifierConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public EmailNotifierConfig async(boolean async) {
        this.async = async;
        return this;
    }

    public EmailNotifierConfig rateLimit(int maxEmails, Duration window) {
        this.maxEmailsPerWindow = maxEmails;
        this.rateLimitWindow = window;
        return this;
    }

    public EmailNotifierConfig circuitBreaker(boolean enabled) {
        this.circuitBreakerEnabled = enabled;
        return this;
    }

    public EmailNotifierConfig circuitBreakerThreshold(int failures) {
        this.circuitBreakerThreshold = failures;
        return this;
    }

    public EmailNotifierConfig circuitBreakerResetTime(Duration duration) {
        this.circuitBreakerResetTime = duration;
        return this;
    }

    public EmailNotifierConfig host(String host) {
        this.host = host;
        return this;
    }

    public EmailNotifierConfig port(int port) {
        this.port = port;
        return this;
    }

    public EmailNotifierConfig credentials(String username, String password) {
        this.username = username;
        this.password = password;
        return this;
    }

    public EmailNotifierConfig startTls(boolean startTls) {
        this.startTls = startTls;
        return this;
    }

    public EmailNotifierConfig ssl(boolean ssl) {
        this.ssl = ssl;
        return this;
    }

    public EmailNotifierConfig defaultFrom(String from) {
        this.defaultFrom = from;
        return this;
    }

    public EmailNotifierConfig defaultTo(String... recipients) {
        this.defaultTo.addAll(Arrays.asList(recipients));
        return this;
    }

    public EmailNotifierConfig defaultSubject(String subject) {
        this.defaultSubject = subject;
        return this;
    }

    public boolean isEnabled() { return enabled; }
    public boolean isAsync() { return async; }
    public int getMaxEmailsPerWindow() { return maxEmailsPerWindow; }
    public Duration getRateLimitWindow() { return rateLimitWindow; }
    public boolean isCircuitBreakerEnabled() { return circuitBreakerEnabled; }
    public int getCircuitBreakerThreshold() { return circuitBreakerThreshold; }
    public Duration getCircuitBreakerResetTime() { return circuitBreakerResetTime; }
    public String getHost() { return host; }
    public int getPort() { return port; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public boolean isStartTls() { return startTls; }
    public boolean isSsl() { return ssl; }
    public String getDefaultFrom() { return defaultFrom; }
    public List<String> getDefaultTo() { return defaultTo; }
    public String getDefaultSubject() { return defaultSubject; }
}
