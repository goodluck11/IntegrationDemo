package com.cbq.restclient.config;

import java.util.*;

public class MetricsConfig {

    private boolean enabled = false;

    private String metricPrefix = "cbq.rest.client";

    private boolean recordRequestDuration = true;
    private boolean recordRequestCount = true;
    private boolean recordActiveRequests = true;
    private boolean recordCircuitBreakerMetrics = true;
    private boolean recordRetryMetrics = true;
    private boolean recordRateLimiterMetrics = true;
    private boolean recordBulkheadMetrics = true;

    private Map<String, String> commonTags = new HashMap<>();
    private boolean includeMethodTag = true;
    private boolean includeUriTag = true;
    private boolean includeStatusTag = true;
    private boolean includeClientNameTag = true;

    private boolean normalizeUri = true;
    private int maxUriSegments = 5;

    private MetricsConfig() {}

    public static MetricsConfig disabled() {
        return new MetricsConfig();
    }

    public static MetricsConfig defaults() {
        return new MetricsConfig().enabled(true);
    }

    public static MetricsConfig custom() {
        return new MetricsConfig().enabled(true);
    }

    public MetricsConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public MetricsConfig metricPrefix(String prefix) {
        this.metricPrefix = prefix;
        return this;
    }

    public MetricsConfig recordRequestDuration(boolean record) {
        this.recordRequestDuration = record;
        return this;
    }

    public MetricsConfig recordRequestCount(boolean record) {
        this.recordRequestCount = record;
        return this;
    }

    public MetricsConfig recordActiveRequests(boolean record) {
        this.recordActiveRequests = record;
        return this;
    }

    public MetricsConfig recordResilienceMetrics(boolean record) {
        this.recordCircuitBreakerMetrics = record;
        this.recordRetryMetrics = record;
        this.recordRateLimiterMetrics = record;
        this.recordBulkheadMetrics = record;
        return this;
    }

    public MetricsConfig commonTag(String key, String value) {
        this.commonTags.put(key, value);
        return this;
    }

    public MetricsConfig commonTags(Map<String, String> tags) {
        this.commonTags.putAll(tags);
        return this;
    }

    public MetricsConfig includeTags(boolean method, boolean uri, boolean status, boolean clientName) {
        this.includeMethodTag = method;
        this.includeUriTag = uri;
        this.includeStatusTag = status;
        this.includeClientNameTag = clientName;
        return this;
    }

    public MetricsConfig normalizeUri(boolean normalize) {
        this.normalizeUri = normalize;
        return this;
    }

    public MetricsConfig maxUriSegments(int max) {
        this.maxUriSegments = max;
        return this;
    }

    public boolean isEnabled() { return enabled; }
    public String getMetricPrefix() { return metricPrefix; }
    public boolean isRecordRequestDuration() { return recordRequestDuration; }
    public boolean isRecordRequestCount() { return recordRequestCount; }
    public boolean isRecordActiveRequests() { return recordActiveRequests; }
    public boolean isRecordCircuitBreakerMetrics() { return recordCircuitBreakerMetrics; }
    public boolean isRecordRetryMetrics() { return recordRetryMetrics; }
    public boolean isRecordRateLimiterMetrics() { return recordRateLimiterMetrics; }
    public boolean isRecordBulkheadMetrics() { return recordBulkheadMetrics; }
    public Map<String, String> getCommonTags() { return commonTags; }
    public boolean isIncludeMethodTag() { return includeMethodTag; }
    public boolean isIncludeUriTag() { return includeUriTag; }
    public boolean isIncludeStatusTag() { return includeStatusTag; }
    public boolean isIncludeClientNameTag() { return includeClientNameTag; }
    public boolean isNormalizeUri() { return normalizeUri; }
    public int getMaxUriSegments() { return maxUriSegments; }

    public String normalizeUri(String uri) {
        if (!normalizeUri || uri == null) return uri;

        int queryIndex = uri.indexOf('?');
        if (queryIndex > 0) {
            uri = uri.substring(0, queryIndex);
        }

        String[] segments = uri.split("/");
        StringBuilder normalized = new StringBuilder();
        int count = 0;

        for (String segment : segments) {
            if (segment.isEmpty()) continue;
            if (count >= maxUriSegments) {
                normalized.append("/...");
                break;
            }

            normalized.append("/");

            if (segment.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")) {
                normalized.append("{uuid}");
            }

            else if (segment.matches("\\d+")) {
                normalized.append("{id}");
            }

            else if (segment.matches("[0-9a-fA-F]{24}")) {
                normalized.append("{objectId}");
            }
            else {
                normalized.append(segment);
            }

            count++;
        }

        return normalized.length() > 0 ? normalized.toString() : "/";
    }
}
