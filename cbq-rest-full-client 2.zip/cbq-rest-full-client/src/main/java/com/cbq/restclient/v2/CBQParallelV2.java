package com.cbq.restclient.v2;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
public class CBQParallelV2 {
   private final List<? extends Mono<?>> monos;

   public static CBQParallelV2 of(CBQRequestV2... requests) {
      return new CBQParallelV2(
              Arrays.stream(requests)
                      .map(r -> r.retrieve(Object.class))
                      .collect(Collectors.toList())
      );
   }

   public Mono<List<Object>> waitAll() {
      return Mono.deferContextual(ctx -> 
          Mono.zip(
              monos.stream()
                  .map(m -> m.contextWrite(ctx))
                  .collect(java.util.stream.Collectors.toList()),
              Arrays::asList
          )
      );
   }

   public Mono<Object> failFast() {
      return Mono.deferContextual(ctx -> 
          Mono.firstWithSignal(
              monos.stream()
                  .map(m -> m.contextWrite(ctx))
                  .collect(java.util.stream.Collectors.toList())
          )
      );
   }
}
