package com.cbq.restclient.config;

import lombok.Getter;

import java.time.Duration;
import java.util.function.Consumer;

@Getter
public class RequestOverride {

    private Boolean retryEnabled;
    private Boolean circuitBreakerEnabled;
    private Boolean rateLimiterEnabled;
    private Boolean bulkheadEnabled;

    private Integer maxAttempts;
    private Duration waitDuration;

    private Duration responseTimeout;

    private RequestOverride() {}

    public static RequestOverride create() {
        return new RequestOverride();
    }

    public RequestOverride disableRetry() {
        this.retryEnabled = false;
        return this;
    }

    public RequestOverride enableRetry() {
        this.retryEnabled = true;
        return this;
    }

    public RequestOverride disableCircuitBreaker() {
        this.circuitBreakerEnabled = false;
        return this;
    }

    public RequestOverride enableCircuitBreaker() {
        this.circuitBreakerEnabled = true;
        return this;
    }

    public RequestOverride disableRateLimiter() {
        this.rateLimiterEnabled = false;
        return this;
    }

    public RequestOverride enableRateLimiter() {
        this.rateLimiterEnabled = true;
        return this;
    }

    public RequestOverride disableBulkhead() {
        this.bulkheadEnabled = false;
        return this;
    }

    public RequestOverride enableBulkhead() {
        this.bulkheadEnabled = true;
        return this;
    }

    public RequestOverride disableAllResilience() {
        this.retryEnabled = false;
        this.circuitBreakerEnabled = false;
        this.rateLimiterEnabled = false;
        this.bulkheadEnabled = false;
        return this;
    }

    public RequestOverride maxAttempts(int attempts) {
        this.maxAttempts = attempts;
        return this;
    }

    public RequestOverride waitDuration(Duration duration) {
        this.waitDuration = duration;
        return this;
    }

    public RequestOverride responseTimeout(Duration timeout) {
        this.responseTimeout = timeout;
        return this;
    }
}
