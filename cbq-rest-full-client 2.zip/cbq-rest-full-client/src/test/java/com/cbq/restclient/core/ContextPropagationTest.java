package com.cbq.restclient.core;

import com.cbq.restclient.model.CBQParallelResult;
import com.cbq.restclient.model.CBQResponse;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.context.Context;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ContextPropagationTest {

    @Test
    public void testContextPropagationInParallel() {
        CBQRestClient client = CBQRestClientBuilder.builder()
                .baseUrl("https://httpbin.org")
                .tracingEnabled(true)
                .build();

        String correlationId = "test-correlation-id";

        Mono<CBQParallelResult<String>> parallelMono = Mono.defer(() -> 
            client.parallel(
                client.get().uri("/get").retrieve(String.class),
                client.get().uri("/get").retrieve(String.class)
            ).waitAll().execute()
        );

        StepVerifier.create(parallelMono.contextWrite(Context.of("correlationId", correlationId)))
                .assertNext(result -> {
                    assertNotNull(result);
                    assertEquals(2, result.size());
                    for (CBQResponse<String> response : result.getResponses()) {
                        System.out.println("[DEBUG_LOG] V1 Response Correlation ID: " + response.getCorrelationId());
                        assertEquals(correlationId, response.getCorrelationId(), "Correlation ID should be propagated from Reactor Context in V1");
                    }
                })
                .verifyComplete();
    }
}
