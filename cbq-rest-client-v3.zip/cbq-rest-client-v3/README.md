# CBQ REST Client v3

Production-ready HTTP client library built on **Spring 6 RestClient** + **Java 21 Virtual Threads**.

> **v3 is a ground-up rewrite** of the WebClient-based v2. The reactive Mono/Flux API is replaced with simple synchronous calls. Virtual threads make blocking cheap, so the programming model is dramatically simpler while maintaining the same throughput characteristics.

---

## What Changed from v2

| Aspect | v2 (WebClient) | v3 (RestClient + Virtual Threads) |
|--------|----------------|----------------------------------|
| HTTP Engine | Netty WebClient (reactive) | JDK HttpClient + RestClient (blocking) |
| Threading | Reactor schedulers (boundedElastic) | Virtual threads (Project Loom) |
| API Style | `Mono<T>` / `Flux<T>` / `.block()` | Direct return types (`T`, `CBQResponse<T>`) |
| Async | `Mono.subscribeOn()` | `CompletableFuture` on virtual threads |
| Resilience | Resilience4j reactive operators | Resilience4j synchronous decorators |
| Correlation | Reactor Context propagation | MDC (natural with virtual threads) |
| Workflow | `CBQWorkflow<T>` with Mono chains | `CBQWorkflow<T>` with supplier chains |
| Timeouts | Netty channel timeouts | JDK HttpClient + RestClient timeouts |
| Java | 11+ | 21+ |
| Spring | 2.7.x | 3.2.x+ |

---

## Maven Dependency

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-rest-client</artifactId>
    <version>3.0.0</version>
</dependency>
```

### Optional Dependencies (add only what you need)

```xml
<!-- Resilience4j (retry, circuit breaker, rate limiter, bulkhead) -->
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-retry</artifactId>
    <version>2.2.0</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-circuitbreaker</artifactId>
    <version>2.2.0</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-ratelimiter</artifactId>
    <version>2.2.0</version>
</dependency>

<!-- Micrometer (metrics) -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-core</artifactId>
</dependency>

<!-- Spring Mail (email notifications) -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-mail</artifactId>
</dependency>
```

---

## Quick Start

### Minimal

```java
CBQRestClient client = CBQRestClientBuilder.builder()
    .baseUrl("https://api.example.com")
    .build();

// GET
User user = client.get()
    .uri("/users/{}", 123)
    .retrieveBody(User.class);

// POST
Order order = client.post()
    .uri("/orders")
    .bodyValue(new CreateOrderRequest("item-1", 2))
    .retrieveBody(Order.class);

// Full response with metadata
CBQResponse<User> response = client.get()
    .uri("/users/{}", 123)
    .retrieve(User.class);

User body = response.body();
int status = response.statusCode();
String requestId = response.requestId();
long duration = response.durationMs();

client.shutdown();
```

### Production Setup

```java
CBQRestClient client = CBQRestClientBuilder.builder("payment-service")
    .baseUrl("https://api.payment.com")

    // Timeouts
    .timeouts(TimeoutConfig.custom()
        .connection(Duration.ofSeconds(5))
        .read(Duration.ofSeconds(30))
        .response(Duration.ofSeconds(60))
        .build())

    // Resilience
    .resilience(ResilienceConfig.custom()
        .retry(RetryConfig.custom()
            .maxAttempts(3)
            .waitDuration(Duration.ofMillis(500))
            .backoffStrategy(BackoffStrategy.EXPONENTIAL_WITH_JITTER)
            .build())
        .circuitBreaker(CircuitBreakerConfig.custom()
            .failureRateThreshold(50)
            .waitDurationInOpenState(Duration.ofSeconds(30))
            .build())
        .rateLimiter(RateLimiterConfig.custom()
            .limitForPeriod(100)
            .limitRefreshPeriod(Duration.ofSeconds(1))
            .build())
        .build())

    // Logging (JSON/Stripe-style for Splunk)
    .logging(LoggingConfig.custom()
        .logAll()
        .jsonFormat()
        .serviceName("payment-service")
        .maskFields("cardNumber", "cvv", "password", "token")
        .build())

    // Auth
    .addRequestFilter(Filters.bearerToken(() -> tokenService.getToken()))

    // Global error mapping
    .addErrorMapper(ErrorMapper.onStatus(
        s -> s.value() == 401,
        ctx -> new AuthException("Token expired")))

    .build();
```

### Spring Boot Auto-Configuration (application.yml)

```yaml
spring:
  threads:
    virtual:
      enabled: true  # Enable virtual threads globally

cbq:
  rest-client:
    name: payment-service
    base-url: https://api.payment.com
    timeouts:
      connection: 5s
      read: 30s
      response: 60s
    resilience:
      enabled: true
      retry:
        enabled: true
        max-attempts: 3
        wait-duration: 500ms
        backoff-strategy: EXPONENTIAL_WITH_JITTER
      circuit-breaker:
        enabled: true
        sliding-window-size: 100
        failure-rate-threshold: 50
        wait-duration-in-open-state: 60s
    logging:
      enabled: true
      format: JSON
      log-all: true
      service-name: payment-service
      mask-fields: cardNumber,cvv,password,token
```

Then just inject:

```java
@Service
public class PaymentService {

    private final CBQRestClient client;

    public PaymentService(CBQRestClient client) {
        this.client = client;
    }

    public Payment charge(ChargeRequest request) {
        return client.post()
            .uri("/v1/charges")
            .bodyValue(request)
            .retrieveBody(Payment.class);
    }
}
```

---

## 1. HTTP Methods

```java
// All standard methods
client.get().uri("/users").retrieve(UserList.class);
client.post().uri("/users").bodyValue(newUser).retrieve(User.class);
client.put().uri("/users/{}", 1).bodyValue(updated).retrieve(User.class);
client.patch().uri("/users/{}", 1).bodyValue(partial).retrieve(User.class);
client.delete().uri("/users/{}", 1).retrieve(Void.class);
client.head().uri("/users/{}", 1).retrieveStatus();
client.options().uri("/users").retrieve(String.class);
```

### URI Templates

```java
// Sequential {} placeholders
client.get().uri("/users/{}/orders/{}", userId, orderId).retrieveBody(Order.class);

// Query parameters (manual)
client.get().uri("/users?page=" + page + "&size=" + size).retrieveBody(UserList.class);
```

### Response Types

```java
// Full response (body + status + headers + requestId + correlationId + duration)
CBQResponse<User> response = client.get().uri("/users/1").retrieve(User.class);

// Body only
User user = client.get().uri("/users/1").retrieveBody(User.class);

// Status only
HttpStatusCode status = client.delete().uri("/users/1").retrieveStatus();

// Async (returns CompletableFuture)
CompletableFuture<CBQResponse<User>> future = client.get()
    .uri("/users/1")
    .retrieveAsync(User.class);

CompletableFuture<User> bodyFuture = client.get()
    .uri("/users/1")
    .retrieveBodyAsync(User.class);
```

---

## 2. Per-Request Customization

### Headers

```java
client.get()
    .uri("/users/1")
    .header("X-Custom", "value")
    .header("X-Tenant-Id", "tenant-123")
    .accept(MediaType.APPLICATION_XML)
    .bearerAuth("custom-token")
    .retrieve(User.class);
```

### Per-Request Error Mapping

```java
User user = client.get()
    .uri("/users/{}", userId)
    .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException("User not found: " + userId))
    .onStatus(s -> s.value() == 409, ctx -> new ConflictException("Conflict: " + ctx.body()))
    .retrieveBody(User.class);
```

### Per-Request Resilience Override

```java
// Disable all resilience for this call
client.post().uri("/one-time-charge").bodyValue(req).noResilience().retrieveBody(Payment.class);

// Disable retry only (non-idempotent call)
client.post().uri("/send-sms").bodyValue(sms).noRetry().retrieveBody(Void.class);
```

---

## 3. Parallel Execution

```java
// Wait for all (any failure throws)
List<CBQResponse<User>> results = client.parallel(
    () -> client.get().uri("/users/1").retrieve(User.class),
    () -> client.get().uri("/users/2").retrieve(User.class),
    () -> client.get().uri("/users/3").retrieve(User.class)
);

// Partial success (failed calls return null)
List<CBQResponse<User>> partial = client.parallelPartial(
    () -> client.get().uri("/users/1").retrieve(User.class),
    () -> client.get().uri("/users/2").retrieve(User.class),  // might fail
    () -> client.get().uri("/users/3").retrieve(User.class)
);
// partial.get(1) == null if it failed
```

---

## 4. CBQWorkflow — Orchestration

### Sequential Chain

```java
Shipping result = CBQWorkflow
    .startWith(() -> client.post().uri("/orders").bodyValue(orderReq).retrieveBody(Order.class))
    .step(order -> client.post().uri("/payments").bodyValue(new PayReq(order.id())).retrieveBody(Payment.class))
    .step(payment -> client.post().uri("/shipping").bodyValue(new ShipReq(payment.orderId())).retrieveBody(Shipping.class))
    .execute();
```

### Sequential + Fire-and-Forget

```java
Order order = CBQWorkflow
    .startWith(() -> client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class))
    .step(o -> {
        repository.save(o);  // blocking DB call — fine with virtual threads
        return o;
    })
    .fireAndForget(
        () -> client.post().uri("/email/send").bodyValue(emailReq).retrieveBody(Void.class),
        () -> client.post().uri("/audit/log").bodyValue(auditReq).retrieveBody(Void.class),
        () -> client.post().uri("/analytics/track").bodyValue(event).retrieveBody(Void.class)
    )
    .execute();
// Returns immediately after DB save. Email/audit/analytics run in background.
```

### Fire-and-Forget with Result Access

```java
CBQWorkflow.startWith(() -> client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class))
    .fireAndForgetWith(order ->
        client.post().uri("/email/confirmation/" + order.id()).retrieveBody(Void.class))
    .execute();
```

### Partial Success (Continue on Error)

```java
EnrichedOrder result = CBQWorkflow
    .startWith(() -> client.get().uri("/orders/{}", orderId).retrieveBody(Order.class))
    .stepContinueOnError(
        order -> enrichWithRecommendations(order),  // might fail (external API)
        order -> order.withEmptyRecommendations()    // fallback: return without enrichment
    )
    .stepContinueOnError(
        order -> enrichWithLoyaltyPoints(order),     // might fail
        order -> order.withDefaultPoints()            // fallback
    )
    .execute();
// Even if enrichment APIs fail, the order is still returned with fallback data
```

### Error Handling (Rollback)

```java
Order order = CBQWorkflow
    .startWith(() -> client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class))
    .step(o -> client.post().uri("/payments/charge").bodyValue(new ChargeReq(o)).retrieveBody(Payment.class))
    .onFailure(error -> {
        // Rollback: cancel order if payment fails
        client.post().uri("/orders/cancel").bodyValue(new CancelReq(req.orderId())).retrieveBody(Void.class);
    })
    .execute();
```

### Async Workflow

```java
CompletableFuture<Order> future = CBQWorkflow
    .startWith(() -> client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class))
    .step(o -> enrich(o))
    .executeAsync();
```

### Workflow Timeout

```java
Order order = CBQWorkflow
    .startWith(() -> client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class))
    .execute(Duration.ofSeconds(30));
```

### Fire-and-Forget Entire Workflow

```java
CBQWorkflow
    .startWith(() -> client.post().uri("/batch/process").bodyValue(batchReq).retrieveBody(Void.class))
    .executeAndForget();
// Returns immediately, workflow runs in background
```

---

## 5. Resilience

### Retry

```java
.resilience(ResilienceConfig.custom()
    .retry(RetryConfig.custom()
        .maxAttempts(3)
        .waitDuration(Duration.ofMillis(500))
        .backoffStrategy(BackoffStrategy.EXPONENTIAL_WITH_JITTER)  // or FIXED, EXPONENTIAL
        .backoffMultiplier(2.0)
        .maxWaitDuration(Duration.ofSeconds(10))
        .build())
    .build())
```

### Circuit Breaker

```java
.resilience(ResilienceConfig.custom()
    .circuitBreaker(CircuitBreakerConfig.custom()
        .slidingWindowSize(100)
        .minimumNumberOfCalls(10)
        .failureRateThreshold(50)
        .waitDurationInOpenState(Duration.ofSeconds(60))
        .permittedNumberOfCallsInHalfOpenState(5)
        .build())
    .build())
```

### Rate Limiter

```java
.resilience(ResilienceConfig.custom()
    .rateLimiter(RateLimiterConfig.custom()
        .limitForPeriod(100)
        .limitRefreshPeriod(Duration.ofSeconds(1))
        .timeoutDuration(Duration.ofSeconds(5))
        .build())
    .build())
```

### Bulkhead

```java
.resilience(ResilienceConfig.custom()
    .bulkhead(BulkheadConfig.custom()
        .maxConcurrentCalls(25)
        .maxWaitDuration(Duration.ofMillis(500))
        .build())
    .build())
```

### Runtime Detection

If Resilience4j is not on the classpath, calls pass through without any wrapping. You'll see:
```
INFO  CBQResilienceManager - Resilience4j not on classpath – resilience features disabled (pass-through)
```

---

## 6. Logging & Masking

### JSON Format (Stripe-style, Splunk-friendly)

```java
.logging(LoggingConfig.custom()
    .logAll()                                // log request + response + headers + body
    .jsonFormat()                            // JSON output
    .serviceName("payment-service")
    .maskFields("cardNumber", "cvv", "password", "token", "apiKey")
    .maskChar('*')
    .maxBodyLogSize(4096)
    .build())
```

**Output:**
```json
{"timestamp":"2025-01-15T10:30:00Z","service":"payment-service","type":"request","task_type":"http","request_id":"req_a1b2c3d4e5f6","correlation_id":"corr_x9y8z7w6v5u4","method":"POST","uri":"/v1/charges","body":{"amount":2000,"cardNumber":"********4242"}}
{"timestamp":"2025-01-15T10:30:01Z","service":"payment-service","type":"response","task_type":"http","request_id":"req_a1b2c3d4e5f6","correlation_id":"corr_x9y8z7w6v5u4","status":200,"duration_ms":245,"body":{"id":"ch_1abc","status":"succeeded"}}
```

### Task Logging (DB, Email, Cache, Queue)

```java
CBQLoggingService logger = client.getLoggingService();
String correlationId = CorrelationContext.getOrCreateCorrelationId();

logger.logDb(correlationId, "save", "orders", 45, true);
logger.logEmail(correlationId, "send", "john@example.com", 120, true);
logger.logCache(correlationId, "set", "order:123", 3, true);
logger.logQueue(correlationId, "publish", "order-events", 8, true);
logger.logTask(correlationId, "custom", "validate", "fraud-check", 200, true, "score=0.95");
```

### Splunk Query

```
index=app correlation_id="corr_x9y8z7w6v5u4"
| table timestamp, type, task_type, method, uri, operation, target, status, duration_ms, success
| sort timestamp
```

---

## 7. Error Handling

### Global Error Mappers

```java
CBQRestClientBuilder.builder()
    .addErrorMapper(ErrorMapper.onStatus(
        s -> s.value() == 404,
        ctx -> new ResourceNotFoundException("Not found: " + ctx.uri())))
    .addErrorMapper(ErrorMapper.onStatus(
        s -> s.value() == 401,
        ctx -> new AuthException("Auth failed")))
    .addErrorMapper(ErrorMapper.onStatus(
        HttpStatusCode::is5xxServerError,
        ctx -> new ServiceException("Service error: " + ctx.body())))
    .build();
```

### Per-Request Error Mapping (overrides global)

```java
User user = client.get().uri("/users/{}", id)
    .onStatus(404, ctx -> new UserNotFoundException(id))
    .retrieveBody(User.class);
```

### Exception Hierarchy

```
CBQRestClientException (base — carries requestId, correlationId, method, uri, status, responseBody, durationMs)
├── ClientErrorException (4xx)
├── ServerErrorException (5xx)
├── TimeoutException
├── SslException
├── CircuitBreakerOpenException
├── RateLimitExceededException
├── BulkheadFullException
└── RetryExhaustedException
```

### Try-Catch Pattern

```java
try {
    Order order = client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class);
    return ApiResponse.success(order);

} catch (CBQExceptions.CircuitBreakerOpenException e) {
    return ApiResponse.error("SERVICE_UNAVAILABLE", "Payment service is temporarily unavailable");

} catch (CBQExceptions.TimeoutException e) {
    return ApiResponse.error("TIMEOUT", "Request timed out");

} catch (CBQExceptions.ClientErrorException e) {
    return ApiResponse.error("CLIENT_ERROR", e.getResponseBody());

} catch (CBQRestClientException e) {
    log.error("HTTP error [req={}, corr={}]: {}", e.getRequestId(), e.getCorrelationId(), e.getMessage());
    return ApiResponse.error("SERVICE_ERROR", "Please try again");
}
```

---

## 8. Filters

### Built-in

```java
// Dynamic bearer token
Filters.bearerToken(() -> tokenService.getAccessToken())

// Static bearer token
Filters.bearerToken("my-static-token")

// Basic auth
Filters.basicAuth("username", "password")

// API key header
Filters.apiKey("X-API-Key", "my-api-key")

// Static headers
Filters.headers("X-Client", "my-app", "X-Version", "1.0")

// Dynamic header
Filters.dynamicHeader("X-Timestamp", () -> Instant.now().toString())

// Correlation ID
Filters.correlationId(() -> CorrelationContext.getOrCreateCorrelationId())
```

### Custom Filter

```java
CBQRequestFilter tenantFilter = (method, uri, headers) -> {
    String tenantId = TenantContext.getCurrentTenant();
    if (tenantId != null) {
        headers.set("X-Tenant-Id", tenantId);
    }
};

CBQRestClientBuilder.builder()
    .addRequestFilter(tenantFilter)
    .build();
```

---

## 9. SSL/TLS

```java
// Default (JVM truststore)
.ssl(SslConfig.defaults())

// Trust all (DEV ONLY!)
.ssl(SslConfig.trustAll())

// Custom truststore
.ssl(SslConfig.custom()
    .trustStorePath("/certs/truststore.jks")
    .trustStorePassword("changeit")
    .build())

// mTLS (client certificate + truststore)
.ssl(SslConfig.custom()
    .keyStorePath("/certs/client-keystore.p12")
    .keyStorePassword("secret")
    .trustStorePath("/certs/truststore.jks")
    .trustStorePassword("changeit")
    .protocol("TLSv1.3")
    .build())
```

---

## 10. Client Pool (Multiple Timeout Profiles)

```java
CBQRestClientPool pool = CBQRestClientPool.builder()
    .baseUrl("https://api.example.com")
    .resilience(ResilienceConfig.defaults())
    .logging(LoggingConfig.custom().logAll().jsonFormat().serviceName("my-service").build())
    .addRequestFilter(Filters.bearerToken(() -> tokenService.getToken()))
    .build();

// Pre-built profiles
pool.getFast().get().uri("/health").retrieveBody(String.class);         // 2s/5s/10s
pool.getDefault().get().uri("/users/1").retrieveBody(User.class);       // 5s/30s/60s
pool.getSlow().post().uri("/reports/generate").retrieveBody(Report.class); // 10s/2min/5min
pool.getBatch().get().uri("/exports/large").retrieveBody(byte[].class); // 10s/10min/30min

// Custom profile
CBQRestClientPool customPool = CBQRestClientPool.builder()
    .baseUrl("https://api.example.com")
    .addProfile("ultra-fast", TimeoutConfig.custom()
        .connection(Duration.ofSeconds(1))
        .read(Duration.ofSeconds(2))
        .response(Duration.ofSeconds(3))
        .build())
    .build();

customPool.get("ultra-fast").get().uri("/ping").retrieveBody(String.class);

pool.shutdown(); // Shuts down all clients
```

---

## 11. Real-World Examples

### Payment Service

```java
@Service
public class PaymentService {

    private final CBQRestClient client;
    private final PaymentRepository repository;

    public PaymentResult processPayment(PaymentRequest request) {
        return CBQWorkflow
            .startWith(() -> client.post()
                .uri("/v1/validate")
                .bodyValue(request)
                .retrieveBody(ValidationResult.class))

            .step(validation -> {
                if (!validation.isValid()) {
                    throw new ValidationException(validation.errors());
                }
                return client.post()
                    .uri("/v1/charges")
                    .bodyValue(new ChargeRequest(request, validation.token()))
                    .retrieveBody(PaymentResult.class);
            })

            .step(payment -> {
                repository.save(PaymentEntity.from(payment));
                return payment;
            })

            .fireAndForget(
                () -> client.post().uri("/v1/receipts").bodyValue(receiptReq).retrieveBody(Void.class),
                () -> client.post().uri("/notifications/email").bodyValue(emailReq).retrieveBody(Void.class)
            )

            .onFailure(error -> {
                client.post().uri("/v1/charges/rollback")
                    .bodyValue(new RollbackRequest(request.transactionId()))
                    .noRetry()
                    .retrieveBody(Void.class);
            })

            .execute();
    }
}
```

### Multi-Service Aggregation

```java
@Service
public class DashboardService {

    private final CBQRestClient client;

    public Dashboard getDashboard(String userId) {
        // Parallel calls to multiple services
        var results = client.parallelPartial(
            () -> client.get().uri("/users/{}", userId).retrieve(UserProfile.class),
            () -> client.get().uri("/orders/recent?userId=" + userId).retrieve(OrderList.class),
            () -> client.get().uri("/notifications/count?userId=" + userId).retrieve(NotificationCount.class),
            () -> client.get().uri("/recommendations?userId=" + userId).retrieve(Recommendations.class)
        );

        return Dashboard.builder()
            .profile(results.get(0) != null ? results.get(0).body() : null)
            .recentOrders(results.get(1) != null ? results.get(1).body() : OrderList.empty())
            .notificationCount(results.get(2) != null ? results.get(2).body() : NotificationCount.zero())
            .recommendations(results.get(3) != null ? results.get(3).body() : Recommendations.empty())
            .build();
    }
}
```

---

## 12. Migration Guide (v2 → v3)

### Before (v2 — WebClient/Reactive)

```java
// v2: Reactive
User user = client.get()
    .uri("/users/1")
    .retrieveBody(User.class)
    .block();                    // ← had to block()

Mono<User> userMono = client.get()
    .uri("/users/1")
    .retrieveBody(User.class);  // returns Mono<User>

// v2: Workflow
CBQWorkflow.startWith(() -> client.post().uri("/orders").retrieve(Order.class))
    .step(o -> client.post().uri("/payments").retrieve(Payment.class))
    .execute();                  // internally called .block()
```

### After (v3 — RestClient/Virtual Threads)

```java
// v3: Synchronous (no block needed)
User user = client.get()
    .uri("/users/1")
    .retrieveBody(User.class);  // returns User directly

CompletableFuture<User> future = client.get()
    .uri("/users/1")
    .retrieveBodyAsync(User.class);  // async via virtual thread

// v3: Workflow (same API, no Mono under the hood)
CBQWorkflow.startWith(() -> client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class))
    .step(o -> client.post().uri("/payments").bodyValue(payReq).retrieveBody(Payment.class))
    .execute();
```

### Key Migration Steps

1. **Remove `.block()`** — calls return directly now
2. **Replace `Mono<T>`/`Flux<T>`** with `T`/`List<T>` or `CompletableFuture<T>`
3. **Replace `Schedulers.boundedElastic()`** — virtual threads handle this
4. **Replace `Mono.deferContextual()`** — use `CorrelationContext` (MDC-based)
5. **Add `spring.threads.virtual.enabled=true`** to application.yml
6. **Update Spring Boot** to 3.2+ and Java to 21+
7. **Remove `spring-boot-starter-webflux`**, add `spring-boot-starter-web`

---

## Architecture

```
CBQRestClientBuilder
       │
       ▼
CBQRestClient
├── RestClient (Spring 6)              ← HTTP engine
│   └── JdkClientHttpRequestFactory
│       └── java.net.http.HttpClient   ← virtual thread executor
├── CBQResilienceManager               ← retry, CB, rate limiter, bulkhead
│   └── Resilience4jDelegate           ← isolated to avoid ClassNotFoundException
├── CBQLoggingService                  ← JSON/text logging with masking
├── List<CBQRequestFilter>             ← auth, correlation, custom headers
├── List<ErrorMapper>                  ← status → exception mapping
└── ExecutorService (virtual)          ← for parallel() and async

CBQRequestSpec (per-call builder)
├── URI resolution
├── Header merging (filters → global → per-request)
├── Body serialization
├── Error mapping (per-request → global → default)
├── Resilience wrapping
└── Structured logging

CBQWorkflow<T> (orchestration)
├── Supplier chain (synchronous)
├── stepContinueOnError (fallback)
├── Fire-and-forget (virtual threads + semaphore)
└── Correlation propagation (MDC)
```

---

## Best Practices

1. **Enable virtual threads** — `spring.threads.virtual.enabled=true`
2. **Use correlation IDs** — automatically propagated via MDC; use `CorrelationContext.getOrCreateCorrelationId()` for workflows
3. **Use `noRetry()`** for non-idempotent calls (SMS, payment charges)
4. **Use `stepContinueOnError()`** for enrichment steps that shouldn't block the main flow
5. **Use `fireAndForget()`** for email, audit, analytics — things that shouldn't delay the response
6. **Mask sensitive fields** in logging — `cardNumber`, `cvv`, `password`, `token`, `apiKey`
7. **Use timeout profiles** via `CBQRestClientPool` instead of changing timeouts per-request
8. **Call `shutdown()`** on application shutdown (or use `@PreDestroy`)
