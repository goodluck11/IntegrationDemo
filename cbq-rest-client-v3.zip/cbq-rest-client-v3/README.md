# CBQ REST Client v3

Production-ready HTTP client built on **Spring 6 RestClient** + **Java 21 Virtual Threads**.

> Complete rewrite of v2 (WebClient/Reactor). No more `Mono`/`Flux`/`.block()` — synchronous calls that scale via virtual threads.

## Quick Start

```java
CBQRestClient client = CBQRestClientBuilder.builder("my-service")
    .baseUrl("https://api.example.com")
    .build();

User user = client.get().uri("/users/{}", 123).retrieveBody(User.class);
client.shutdown();
```

## Production Setup

```java
CBQRestClient client = CBQRestClientBuilder.builder("payment-service")
    .baseUrl("https://api.payment.com")
    .timeouts(TimeoutConfig.custom().connection(Duration.ofSeconds(5)).read(Duration.ofSeconds(30)).build())
    .resilience(ResilienceConfig.custom()
        .retry(RetryConfig.custom().maxAttempts(3).backoffStrategy(BackoffStrategy.EXPONENTIAL_WITH_JITTER).build())
        .circuitBreaker(CircuitBreakerConfig.custom().failureRateThreshold(50).build())
        .rateLimiter(RateLimiterConfig.custom().limitForPeriod(100).build())
        .build())
    .logging(LoggingConfig.custom().logAll().jsonFormat().serviceName("payment-service").maskFields("cardNumber", "cvv", "password").build())
    .ssl(SslConfig.custom().trustStorePath("/certs/truststore.jks").build())
    .addRequestFilter(Filters.bearerToken(() -> tokenService.getToken()))
    .addErrorMapper(ErrorMapper.onStatus(401, ctx -> new AuthException("Token expired")))
    .build();
```

## Spring Boot Auto-Configuration

```yaml
spring.threads.virtual.enabled: true
cbq:
  rest-client:
    base-url: https://api.payment.com
    name: payment-service
    timeouts: { connection: 5s, read: 30s }
    resilience: { enabled: true, retry: { enabled: true, max-attempts: 3 } }
    logging: { enabled: true, format: JSON, log-all: true, mask-fields: cardNumber,cvv }
```

```java
@Service
public class PaymentService {
    private final CBQRestClient client; // auto-injected
    public PaymentService(CBQRestClient client) { this.client = client; }
}
```

## Features

### HTTP Methods + Fluent API

```java
client.get().uri("/users").retrieve(UserList.class);
client.post().uri("/users").bodyValue(newUser).retrieveBody(User.class);
client.put().uri("/users/{}", 1).bodyValue(updated).retrieve(User.class);
client.patch().uri("/users/{}", 1).bodyValue(partial).retrieve(User.class);
client.delete().uri("/users/{}", 1).retrieve(Void.class);

// Full response with metadata
CBQResponse<User> resp = client.get().uri("/users/1").retrieve(User.class);
resp.body(); resp.statusCode(); resp.requestId(); resp.correlationId(); resp.durationMs();

// Async (virtual thread)
CompletableFuture<User> future = client.get().uri("/users/1").retrieveBodyAsync(User.class);
```

### Per-Request Overrides

```java
client.get().uri("/users/{}", id)
    .header("X-Tenant", "t1")
    .bearerAuth("custom-token")
    .onStatus(404, ctx -> new UserNotFoundException(id))
    .onStatus(409, ctx -> new ConflictException(ctx.body()))
    .noRetry()     // disable retry for this call
    .retrieveBody(User.class);
```

### Parallel Execution

```java
List<CBQResponse<User>> all = client.parallel(
    () -> client.get().uri("/users/1").retrieve(User.class),
    () -> client.get().uri("/users/2").retrieve(User.class));

List<CBQResponse<User>> partial = client.parallelPartial(  // null on failure
    () -> client.get().uri("/users/1").retrieve(User.class),
    () -> client.get().uri("/users/2").retrieve(User.class));
```

### CBQWorkflow — Orchestration

```java
// Sequential chain with fire-and-forget
Order order = CBQWorkflow
    .startWith(() -> client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class))
    .step(o -> { repository.save(o); return o; })               // DB step (blocking is fine)
    .stepContinueOnError(o -> enrich(o), o -> o)                 // degraded fallback
    .fireAndForget(
        () -> client.post().uri("/email/send").bodyValue(email).retrieveBody(Void.class),
        () -> client.post().uri("/audit/log").bodyValue(audit).retrieveBody(Void.class))
    .fireAndForgetWith(o -> notifySlack(o))                      // needs result
    .onFailure(e -> client.post().uri("/orders/cancel").bodyValue(cancel).noRetry().retrieveBody(Void.class))
    .execute();

// Async, timeout, fire-and-forget variants
workflow.executeAsync();
workflow.execute(Duration.ofSeconds(30));
workflow.executeAndForget();
```

### Resilience (Optional Resilience4j)

```java
.resilience(ResilienceConfig.custom()
    .retry(RetryConfig.custom().maxAttempts(3).waitDuration(Duration.ofMillis(500))
        .backoffStrategy(BackoffStrategy.EXPONENTIAL_WITH_JITTER).build())
    .circuitBreaker(CircuitBreakerConfig.custom().failureRateThreshold(50)
        .waitDurationInOpenState(Duration.ofSeconds(60)).build())
    .rateLimiter(RateLimiterConfig.custom().limitForPeriod(100).build())
    .bulkhead(BulkheadConfig.custom().maxConcurrentCalls(25).build())
    .build())
```

Auto-detects Resilience4j on classpath. Without it, calls pass through undecorated.

### Async Logging (Virtual Thread)

All logging runs on a dedicated virtual thread executor — never blocks the calling thread.

```java
.logging(LoggingConfig.custom()
    .logAll().jsonFormat().serviceName("payment-service")
    .maskFields("cardNumber", "cvv", "password", "token")
    .maxBodyLogSize(4096).build())
```

JSON output (Splunk-friendly):
```json
{"timestamp":"2025-01-15T10:30:00Z","service":"payment-service","type":"request","task_type":"http","request_id":"req_a1b2c3d4e5f6","correlation_id":"corr_x9y8z7w6v5u4","method":"POST","uri":"/v1/charges","body":{"amount":2000,"cardNumber":"************4242"}}
```

Task logging (DB, cache, email, queue):
```java
CBQLoggingService logger = client.getLoggingService();
logger.logDb(corrId, "save", "orders", 45, true);
logger.logCache(corrId, "set", "order:123", 3, true);
logger.logEmail(corrId, "send", "user@example.com", 120, true);
```

### Error Handling

```java
try {
    client.post().uri("/orders").bodyValue(req).retrieveBody(Order.class);
} catch (CBQExceptions.CircuitBreakerOpenException e) { /* service down */ }
  catch (CBQExceptions.TimeoutException e)            { /* timed out */ }
  catch (CBQExceptions.ClientErrorException e)        { e.getStatusCode(); e.getResponseBody(); }
  catch (CBQExceptions.ServerErrorException e)        { e.getRequestId(); e.getCorrelationId(); }
  catch (CBQRestClientException e)                    { e.toContextMap(); /* structured logging */ }
```

### Filters

```java
Filters.bearerToken(() -> tokenService.getAccessToken())
Filters.bearerToken("static-token")
Filters.basicAuth("user", "pass")
Filters.apiKey("X-API-Key", "key")
Filters.headers("X-Client", "app", "X-Version", "1.0")
Filters.dynamicHeader("X-Timestamp", () -> Instant.now().toString())
```

### SSL/TLS

```java
.ssl(SslConfig.defaults())                          // JVM truststore
.ssl(SslConfig.trustAll())                           // dev only
.ssl(SslConfig.custom().keyStorePath("/certs/client.p12").keyStorePassword("secret")
    .trustStorePath("/certs/truststore.jks").protocol("TLSv1.3").build())  // mTLS
```

### Client Pool (Timeout Profiles)

```java
CBQRestClientPool pool = CBQRestClientPool.builder()
    .baseUrl("https://api.example.com")
    .resilience(ResilienceConfig.defaults())
    .logging(LoggingConfig.custom().logAll().jsonFormat().build())
    .build();

pool.getFast().get().uri("/health").retrieveBody(String.class);      // 2s/5s
pool.getDefault().get().uri("/users/1").retrieveBody(User.class);    // 5s/30s
pool.getSlow().post().uri("/reports").retrieveBody(Report.class);    // 10s/2m
pool.getBatch().get().uri("/exports").retrieveBody(byte[].class);    // 10s/10m
pool.shutdown();
```

## Architecture

```
CBQRestClientBuilder
  → CBQRestClient
      ├── RestClient (Spring 6)
      │   └── JdkClientHttpRequestFactory + java.net.http.HttpClient (virtual thread executor)
      ├── CBQResilienceManager (Bulkhead → RateLimiter → CircuitBreaker → Retry)
      │   └── R4JDelegate (isolated inner class — no ClassNotFoundException without R4j)
      ├── CBQLoggingService (async on virtual thread executor)
      │   └── FieldMasker (JSON + header masking)
      ├── List<CBQRequestFilter> (bearerToken, apiKey, etc.)
      ├── List<ErrorMapper> (status → exception)
      └── ExecutorService (virtual threads for parallel/async)

CBQRequestSpec (per-call):  URI → Headers → Filters → Resilience → HTTP → ErrorMapping → Logging
CBQWorkflow<T>:             startWith → step → stepContinueOnError → fireAndForget → execute
```

## v2 → v3 Migration

1. Remove `.block()` — calls return `T` directly
2. Replace `Mono<T>`/`Flux<T>` with `T` / `CompletableFuture<T>`
3. Replace `spring-boot-starter-webflux` with `spring-boot-starter-web`
4. Add `spring.threads.virtual.enabled=true`
5. Update to Spring Boot 3.2+ / Java 21+
