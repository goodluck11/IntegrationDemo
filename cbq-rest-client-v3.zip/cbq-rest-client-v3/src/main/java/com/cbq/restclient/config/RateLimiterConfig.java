package com.cbq.restclient.config;

import java.time.Duration;

public record RateLimiterConfig(int limitForPeriod, Duration limitRefreshPeriod, Duration timeoutDuration) {
    public static final RateLimiterConfig DEFAULT = new RateLimiterConfig(100, Duration.ofSeconds(1), Duration.ofSeconds(5));
    public static Builder custom() { return new Builder(); }
    public static class Builder {
        private int limitForPeriod = 100; private Duration limitRefreshPeriod = Duration.ofSeconds(1), timeoutDuration = Duration.ofSeconds(5);
        public Builder limitForPeriod(int n)          { this.limitForPeriod = n; return this; }
        public Builder limitRefreshPeriod(Duration d)  { this.limitRefreshPeriod = d; return this; }
        public Builder timeoutDuration(Duration d)     { this.timeoutDuration = d; return this; }
        public RateLimiterConfig build() { return new RateLimiterConfig(limitForPeriod, limitRefreshPeriod, timeoutDuration); }
    }
}
