package com.cbq.restclient.config;

import java.time.Duration;

public record BulkheadConfig(int maxConcurrentCalls, Duration maxWaitDuration) {
    public static final BulkheadConfig DEFAULT = new BulkheadConfig(25, Duration.ofMillis(500));
    public static Builder custom() { return new Builder(); }
    public static class Builder {
        private int maxConcurrentCalls = 25; private Duration maxWaitDuration = Duration.ofMillis(500);
        public Builder maxConcurrentCalls(int n)   { this.maxConcurrentCalls = n; return this; }
        public Builder maxWaitDuration(Duration d) { this.maxWaitDuration = d; return this; }
        public BulkheadConfig build() { return new BulkheadConfig(maxConcurrentCalls, maxWaitDuration); }
    }
}
