package com.cbq.restclient.filter;

import org.springframework.http.HttpHeaders;

import java.util.Base64;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Filter applied before each request. Can modify headers, URI, etc.
 */
@FunctionalInterface
public interface CBQRequestFilter {
    void apply(MutableRequestContext context);
}
