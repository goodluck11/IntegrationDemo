package com.cbq.restclient.filter;

import org.springframework.http.HttpHeaders;

@FunctionalInterface
public interface CBQRequestFilter {
    void apply(String method, String uri, HttpHeaders headers);
}
