package com.cbq.restclient.filter;

import java.util.Map;
import java.util.function.Supplier;

public final class Filters {
    private Filters() {}

    public static CBQRequestFilter bearerToken(Supplier<String> s) { return (m, u, h) -> h.setBearerAuth(s.get()); }
    public static CBQRequestFilter bearerToken(String token)       { return (m, u, h) -> h.setBearerAuth(token); }
    public static CBQRequestFilter basicAuth(String user, String pass) { return (m, u, h) -> h.setBasicAuth(user, pass); }
    public static CBQRequestFilter apiKey(String header, String key)   { return (m, u, h) -> h.set(header, key); }
    public static CBQRequestFilter headers(Map<String, String> map)    { return (m, u, h) -> map.forEach(h::set); }
    public static CBQRequestFilter dynamicHeader(String name, Supplier<String> val) { return (m, u, h) -> h.set(name, val.get()); }

    public static CBQRequestFilter headers(String... kv) {
        if (kv.length % 2 != 0) throw new IllegalArgumentException("Must be key-value pairs");
        return (m, u, h) -> { for (int i = 0; i < kv.length; i += 2) h.set(kv[i], kv[i + 1]); };
    }
}
