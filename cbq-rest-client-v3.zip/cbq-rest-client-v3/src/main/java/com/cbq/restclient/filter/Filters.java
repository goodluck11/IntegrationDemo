package com.cbq.restclient.filter;

import java.util.Base64;
import java.util.function.Supplier;

/**
 * Pre-built request filters for common patterns.
 */
public final class Filters {

    private Filters() {}

    /** Dynamic bearer token from a supplier (e.g. token refresh). */
    public static CBQRequestFilter bearerToken(Supplier<String> tokenSupplier) {
        return ctx -> ctx.setHeader("Authorization", "Bearer " + tokenSupplier.get());
    }

    /** Static bearer token. */
    public static CBQRequestFilter bearerToken(String token) {
        return ctx -> ctx.setHeader("Authorization", "Bearer " + token);
    }

    /** Basic authentication. */
    public static CBQRequestFilter basicAuth(String username, String password) {
        String encoded = Base64.getEncoder().encodeToString((username + ":" + password).getBytes());
        return ctx -> ctx.setHeader("Authorization", "Basic " + encoded);
    }

    /** API key header. */
    public static CBQRequestFilter apiKey(String headerName, String key) {
        return ctx -> ctx.setHeader(headerName, key);
    }

    /** Static headers (key1, value1, key2, value2, ...). */
    public static CBQRequestFilter headers(String... keyValues) {
        if (keyValues.length % 2 != 0) {
            throw new IllegalArgumentException("headers() requires even number of arguments (key/value pairs)");
        }
        return ctx -> {
            for (int i = 0; i < keyValues.length; i += 2) {
                ctx.setHeader(keyValues[i], keyValues[i + 1]);
            }
        };
    }

    /** Propagate correlation ID from the request context. */
    public static CBQRequestFilter correlationId(String headerName) {
        return ctx -> {
            if (ctx.getCorrelationId() != null) {
                ctx.setHeader(headerName, ctx.getCorrelationId());
            }
        };
    }
}
