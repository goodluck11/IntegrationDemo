package com.cbq.restclient.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.List;
import java.util.Set;

/**
 * Spring Boot configuration properties for CBQ Rest Client.
 * Prefix: cbq.rest-client
 *
 * <pre>
 * cbq:
 *   rest-client:
 *     name: payment-service
 *     base-url: https://api.payment.com
 *     timeouts:
 *       connection: 5s
 *       read: 30s
 *       write: 30s
 *       response: 60s
 *     resilience:
 *       retry:
 *         max-attempts: 3
 *         wait-duration: 500ms
 *         backoff-strategy: EXPONENTIAL_WITH_JITTER
 *       circuit-breaker:
 *         sliding-window-size: 100
 *         failure-rate-threshold: 50
 *         wait-duration-in-open-state: 60s
 *       rate-limiter:
 *         limit-for-period: 100
 *         limit-refresh-period: 1s
 *     logging:
 *       format: JSON
 *       log-all: true
 *       service-name: payment-service
 *       mask-fields: cardNumber,cvv,password,token
 *     ssl:
 *       enabled: true
 *       trust-all: false
 *       trust-store-path: /certs/truststore.jks
 * </pre>
 */
@ConfigurationProperties(prefix = "cbq.rest-client")
public class CBQRestClientProperties {

    private String name = "cbq-client";
    private String baseUrl;
    private TimeoutsProperties timeouts = new TimeoutsProperties();
    private ResilienceProperties resilience = new ResilienceProperties();
    private LoggingProperties logging = new LoggingProperties();
    private SslProperties ssl = new SslProperties();

    // ── Getters/Setters ──────────────────────────────────────────────────────

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public TimeoutsProperties getTimeouts() { return timeouts; }
    public void setTimeouts(TimeoutsProperties timeouts) { this.timeouts = timeouts; }
    public ResilienceProperties getResilience() { return resilience; }
    public void setResilience(ResilienceProperties resilience) { this.resilience = resilience; }
    public LoggingProperties getLogging() { return logging; }
    public void setLogging(LoggingProperties logging) { this.logging = logging; }
    public SslProperties getSsl() { return ssl; }
    public void setSsl(SslProperties ssl) { this.ssl = ssl; }

    // ── Nested Classes ───────────────────────────────────────────────────────

    public static class TimeoutsProperties {
        private Duration connection = Duration.ofSeconds(5);
        private Duration read = Duration.ofSeconds(30);
        private Duration write = Duration.ofSeconds(30);
        private Duration response = Duration.ofSeconds(60);

        public Duration getConnection() { return connection; }
        public void setConnection(Duration connection) { this.connection = connection; }
        public Duration getRead() { return read; }
        public void setRead(Duration read) { this.read = read; }
        public Duration getWrite() { return write; }
        public void setWrite(Duration write) { this.write = write; }
        public Duration getResponse() { return response; }
        public void setResponse(Duration response) { this.response = response; }
    }

    public static class ResilienceProperties {
        private boolean enabled = false;
        private RetryProperties retry = new RetryProperties();
        private CircuitBreakerProperties circuitBreaker = new CircuitBreakerProperties();
        private RateLimiterProperties rateLimiter = new RateLimiterProperties();

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public RetryProperties getRetry() { return retry; }
        public void setRetry(RetryProperties retry) { this.retry = retry; }
        public CircuitBreakerProperties getCircuitBreaker() { return circuitBreaker; }
        public void setCircuitBreaker(CircuitBreakerProperties circuitBreaker) { this.circuitBreaker = circuitBreaker; }
        public RateLimiterProperties getRateLimiter() { return rateLimiter; }
        public void setRateLimiter(RateLimiterProperties rateLimiter) { this.rateLimiter = rateLimiter; }
    }

    public static class RetryProperties {
        private boolean enabled = false;
        private int maxAttempts = 3;
        private Duration waitDuration = Duration.ofMillis(500);
        private String backoffStrategy = "EXPONENTIAL_WITH_JITTER";

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public int getMaxAttempts() { return maxAttempts; }
        public void setMaxAttempts(int maxAttempts) { this.maxAttempts = maxAttempts; }
        public Duration getWaitDuration() { return waitDuration; }
        public void setWaitDuration(Duration waitDuration) { this.waitDuration = waitDuration; }
        public String getBackoffStrategy() { return backoffStrategy; }
        public void setBackoffStrategy(String backoffStrategy) { this.backoffStrategy = backoffStrategy; }
    }

    public static class CircuitBreakerProperties {
        private boolean enabled = false;
        private int slidingWindowSize = 100;
        private int minimumNumberOfCalls = 10;
        private float failureRateThreshold = 50f;
        private Duration waitDurationInOpenState = Duration.ofSeconds(60);

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public int getSlidingWindowSize() { return slidingWindowSize; }
        public void setSlidingWindowSize(int slidingWindowSize) { this.slidingWindowSize = slidingWindowSize; }
        public int getMinimumNumberOfCalls() { return minimumNumberOfCalls; }
        public void setMinimumNumberOfCalls(int minimumNumberOfCalls) { this.minimumNumberOfCalls = minimumNumberOfCalls; }
        public float getFailureRateThreshold() { return failureRateThreshold; }
        public void setFailureRateThreshold(float failureRateThreshold) { this.failureRateThreshold = failureRateThreshold; }
        public Duration getWaitDurationInOpenState() { return waitDurationInOpenState; }
        public void setWaitDurationInOpenState(Duration waitDurationInOpenState) { this.waitDurationInOpenState = waitDurationInOpenState; }
    }

    public static class RateLimiterProperties {
        private boolean enabled = false;
        private int limitForPeriod = 100;
        private Duration limitRefreshPeriod = Duration.ofSeconds(1);
        private Duration timeoutDuration = Duration.ofSeconds(5);

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public int getLimitForPeriod() { return limitForPeriod; }
        public void setLimitForPeriod(int limitForPeriod) { this.limitForPeriod = limitForPeriod; }
        public Duration getLimitRefreshPeriod() { return limitRefreshPeriod; }
        public void setLimitRefreshPeriod(Duration limitRefreshPeriod) { this.limitRefreshPeriod = limitRefreshPeriod; }
        public Duration getTimeoutDuration() { return timeoutDuration; }
        public void setTimeoutDuration(Duration timeoutDuration) { this.timeoutDuration = timeoutDuration; }
    }

    public static class LoggingProperties {
        private boolean enabled = false;
        private String format = "JSON";
        private boolean logAll = false;
        private String serviceName = "cbq-client";
        private Set<String> maskFields = Set.of();

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public String getFormat() { return format; }
        public void setFormat(String format) { this.format = format; }
        public boolean isLogAll() { return logAll; }
        public void setLogAll(boolean logAll) { this.logAll = logAll; }
        public String getServiceName() { return serviceName; }
        public void setServiceName(String serviceName) { this.serviceName = serviceName; }
        public Set<String> getMaskFields() { return maskFields; }
        public void setMaskFields(Set<String> maskFields) { this.maskFields = maskFields; }
    }

    public static class SslProperties {
        private boolean enabled = false;
        private boolean trustAll = false;
        private String trustStorePath;
        private String trustStorePassword;
        private String keyStorePath;
        private String keyStorePassword;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public boolean isTrustAll() { return trustAll; }
        public void setTrustAll(boolean trustAll) { this.trustAll = trustAll; }
        public String getTrustStorePath() { return trustStorePath; }
        public void setTrustStorePath(String trustStorePath) { this.trustStorePath = trustStorePath; }
        public String getTrustStorePassword() { return trustStorePassword; }
        public void setTrustStorePassword(String trustStorePassword) { this.trustStorePassword = trustStorePassword; }
        public String getKeyStorePath() { return keyStorePath; }
        public void setKeyStorePath(String keyStorePath) { this.keyStorePath = keyStorePath; }
        public String getKeyStorePassword() { return keyStorePassword; }
        public void setKeyStorePassword(String keyStorePassword) { this.keyStorePassword = keyStorePassword; }
    }
}
