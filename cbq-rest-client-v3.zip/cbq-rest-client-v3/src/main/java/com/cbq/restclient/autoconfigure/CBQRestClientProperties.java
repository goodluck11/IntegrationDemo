package com.cbq.restclient.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;
import java.time.Duration;
import java.util.Set;

@ConfigurationProperties(prefix = "cbq.rest-client")
public class CBQRestClientProperties {
    private String name = "cbq-client", baseUrl;
    private Timeouts timeouts = new Timeouts();
    private Resilience resilience = new Resilience();
    private Logging logging = new Logging();
    private Ssl ssl = new Ssl();

    public String getName() { return name; } public void setName(String v) { this.name = v; }
    public String getBaseUrl() { return baseUrl; } public void setBaseUrl(String v) { this.baseUrl = v; }
    public Timeouts getTimeouts() { return timeouts; } public void setTimeouts(Timeouts v) { this.timeouts = v; }
    public Resilience getResilience() { return resilience; } public void setResilience(Resilience v) { this.resilience = v; }
    public Logging getLogging() { return logging; } public void setLogging(Logging v) { this.logging = v; }
    public Ssl getSsl() { return ssl; } public void setSsl(Ssl v) { this.ssl = v; }

    public static class Timeouts {
        private Duration connection = Duration.ofSeconds(5), read = Duration.ofSeconds(30), write = Duration.ofSeconds(30), response = Duration.ofSeconds(60);
        public Duration getConnection() { return connection; } public void setConnection(Duration v) { this.connection = v; }
        public Duration getRead() { return read; } public void setRead(Duration v) { this.read = v; }
        public Duration getWrite() { return write; } public void setWrite(Duration v) { this.write = v; }
        public Duration getResponse() { return response; } public void setResponse(Duration v) { this.response = v; }
    }

    public static class Resilience {
        private boolean enabled; private Retry retry = new Retry(); private CB circuitBreaker = new CB(); private RL rateLimiter = new RL();
        public boolean isEnabled() { return enabled; } public void setEnabled(boolean v) { this.enabled = v; }
        public Retry getRetry() { return retry; } public void setRetry(Retry v) { this.retry = v; }
        public CB getCircuitBreaker() { return circuitBreaker; } public void setCircuitBreaker(CB v) { this.circuitBreaker = v; }
        public RL getRateLimiter() { return rateLimiter; } public void setRateLimiter(RL v) { this.rateLimiter = v; }
    }

    public static class Retry {
        private boolean enabled; private int maxAttempts = 3; private Duration waitDuration = Duration.ofMillis(500); private String backoffStrategy = "EXPONENTIAL_WITH_JITTER";
        public boolean isEnabled() { return enabled; } public void setEnabled(boolean v) { this.enabled = v; }
        public int getMaxAttempts() { return maxAttempts; } public void setMaxAttempts(int v) { this.maxAttempts = v; }
        public Duration getWaitDuration() { return waitDuration; } public void setWaitDuration(Duration v) { this.waitDuration = v; }
        public String getBackoffStrategy() { return backoffStrategy; } public void setBackoffStrategy(String v) { this.backoffStrategy = v; }
    }

    public static class CB {
        private boolean enabled; private int slidingWindowSize = 100, minimumNumberOfCalls = 10; private float failureRateThreshold = 50f; private Duration waitDurationInOpenState = Duration.ofSeconds(60);
        public boolean isEnabled() { return enabled; } public void setEnabled(boolean v) { this.enabled = v; }
        public int getSlidingWindowSize() { return slidingWindowSize; } public void setSlidingWindowSize(int v) { this.slidingWindowSize = v; }
        public int getMinimumNumberOfCalls() { return minimumNumberOfCalls; } public void setMinimumNumberOfCalls(int v) { this.minimumNumberOfCalls = v; }
        public float getFailureRateThreshold() { return failureRateThreshold; } public void setFailureRateThreshold(float v) { this.failureRateThreshold = v; }
        public Duration getWaitDurationInOpenState() { return waitDurationInOpenState; } public void setWaitDurationInOpenState(Duration v) { this.waitDurationInOpenState = v; }
    }

    public static class RL {
        private boolean enabled; private int limitForPeriod = 100; private Duration limitRefreshPeriod = Duration.ofSeconds(1), timeoutDuration = Duration.ofSeconds(5);
        public boolean isEnabled() { return enabled; } public void setEnabled(boolean v) { this.enabled = v; }
        public int getLimitForPeriod() { return limitForPeriod; } public void setLimitForPeriod(int v) { this.limitForPeriod = v; }
        public Duration getLimitRefreshPeriod() { return limitRefreshPeriod; } public void setLimitRefreshPeriod(Duration v) { this.limitRefreshPeriod = v; }
        public Duration getTimeoutDuration() { return timeoutDuration; } public void setTimeoutDuration(Duration v) { this.timeoutDuration = v; }
    }

    public static class Logging {
        private boolean enabled; private String format = "JSON", serviceName = "cbq-client"; private boolean logAll; private Set<String> maskFields = Set.of();
        public boolean isEnabled() { return enabled; } public void setEnabled(boolean v) { this.enabled = v; }
        public String getFormat() { return format; } public void setFormat(String v) { this.format = v; }
        public String getServiceName() { return serviceName; } public void setServiceName(String v) { this.serviceName = v; }
        public boolean isLogAll() { return logAll; } public void setLogAll(boolean v) { this.logAll = v; }
        public Set<String> getMaskFields() { return maskFields; } public void setMaskFields(Set<String> v) { this.maskFields = v; }
    }

    public static class Ssl {
        private boolean enabled, trustAll; private String trustStorePath, trustStorePassword, keyStorePath, keyStorePassword;
        public boolean isEnabled() { return enabled; } public void setEnabled(boolean v) { this.enabled = v; }
        public boolean isTrustAll() { return trustAll; } public void setTrustAll(boolean v) { this.trustAll = v; }
        public String getTrustStorePath() { return trustStorePath; } public void setTrustStorePath(String v) { this.trustStorePath = v; }
        public String getTrustStorePassword() { return trustStorePassword; } public void setTrustStorePassword(String v) { this.trustStorePassword = v; }
        public String getKeyStorePath() { return keyStorePath; } public void setKeyStorePath(String v) { this.keyStorePath = v; }
        public String getKeyStorePassword() { return keyStorePassword; } public void setKeyStorePassword(String v) { this.keyStorePassword = v; }
    }
}
