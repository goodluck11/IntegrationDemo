package com.cbq.restclient.config;

import java.time.Duration;

public record RetryConfig(int maxAttempts, Duration waitDuration, BackoffStrategy backoffStrategy, double backoffMultiplier, Duration maxWaitDuration) {
    public enum BackoffStrategy { FIXED, EXPONENTIAL, EXPONENTIAL_WITH_JITTER }
    public static final RetryConfig DEFAULT = new RetryConfig(3, Duration.ofMillis(500), BackoffStrategy.EXPONENTIAL_WITH_JITTER, 2.0, Duration.ofSeconds(10));

    public static Builder custom() { return new Builder(); }

    public static class Builder {
        private int maxAttempts = 3; private Duration waitDuration = Duration.ofMillis(500);
        private BackoffStrategy backoffStrategy = BackoffStrategy.EXPONENTIAL_WITH_JITTER;
        private double backoffMultiplier = 2.0; private Duration maxWaitDuration = Duration.ofSeconds(10);
        public Builder maxAttempts(int n)                 { this.maxAttempts = n; return this; }
        public Builder waitDuration(Duration d)           { this.waitDuration = d; return this; }
        public Builder backoffStrategy(BackoffStrategy s) { this.backoffStrategy = s; return this; }
        public Builder backoffMultiplier(double m)        { this.backoffMultiplier = m; return this; }
        public Builder maxWaitDuration(Duration d)        { this.maxWaitDuration = d; return this; }
        public RetryConfig build() { return new RetryConfig(maxAttempts, waitDuration, backoffStrategy, backoffMultiplier, maxWaitDuration); }
    }
}
