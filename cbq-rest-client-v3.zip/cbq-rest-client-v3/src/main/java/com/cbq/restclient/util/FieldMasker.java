package com.cbq.restclient.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Masks sensitive fields in JSON strings.
 */
public final class FieldMasker {

    private final Set<String> fullMaskFields;
    private final Map<String, Integer> partialMaskFields;
    private final char maskSymbol;
    private final ObjectMapper mapper;

    public FieldMasker(Set<String> fullMaskFields, Map<String, Integer> partialMaskFields,
                       char maskSymbol, ObjectMapper mapper) {
        this.fullMaskFields = fullMaskFields;
        this.partialMaskFields = partialMaskFields;
        this.maskSymbol = maskSymbol;
        this.mapper = mapper;
    }

    /**
     * Mask sensitive fields in a JSON string.
     */
    public String mask(String json) {
        if (json == null || json.isBlank() || (fullMaskFields.isEmpty() && partialMaskFields.isEmpty())) {
            return json;
        }
        try {
            JsonNode node = mapper.readTree(json);
            maskNode(node);
            return mapper.writeValueAsString(node);
        } catch (JsonProcessingException e) {
            return json; // Not valid JSON, return as-is
        }
    }

    /**
     * Mask fields in an object, returns masked JSON string.
     */
    public String maskObject(Object obj) {
        if (obj == null) return "null";
        try {
            String json = mapper.writeValueAsString(obj);
            return mask(json);
        } catch (JsonProcessingException e) {
            return obj.toString();
        }
    }

    private void maskNode(JsonNode node) {
        if (node.isObject()) {
            ObjectNode obj = (ObjectNode) node;
            Iterator<Map.Entry<String, JsonNode>> fields = obj.fields();
            while (fields.hasNext()) {
                var entry = fields.next();
                String fieldName = entry.getKey();
                JsonNode value = entry.getValue();

                if (fullMaskFields.contains(fieldName) && value.isTextual()) {
                    obj.set(fieldName, TextNode.valueOf(String.valueOf(maskSymbol).repeat(8)));
                } else if (partialMaskFields.containsKey(fieldName) && value.isTextual()) {
                    int visible = partialMaskFields.get(fieldName);
                    obj.set(fieldName, TextNode.valueOf(partialMask(value.asText(), visible)));
                } else {
                    maskNode(value);
                }
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) {
                maskNode(child);
            }
        }
    }

    private String partialMask(String value, int visibleChars) {
        if (value.length() <= visibleChars * 2) {
            return String.valueOf(maskSymbol).repeat(value.length());
        }
        String start = value.substring(0, visibleChars);
        String end = value.substring(value.length() - visibleChars);
        String middle = String.valueOf(maskSymbol).repeat(value.length() - visibleChars * 2);
        return start + middle + end;
    }
}
