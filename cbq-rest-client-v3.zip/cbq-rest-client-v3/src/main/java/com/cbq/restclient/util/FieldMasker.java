package com.cbq.restclient.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import java.util.*;

public final class FieldMasker {
    private final Set<String> fields;
    private final char maskChar;
    private final ObjectMapper om = new ObjectMapper();

    public FieldMasker(Set<String> fields, char maskChar) { this.fields = Set.copyOf(fields); this.maskChar = maskChar; }

    public String maskJson(String json) {
        if (json == null || json.isBlank() || fields.isEmpty()) return json;
        try { JsonNode n = om.readTree(json); maskNode(n); return om.writeValueAsString(n); }
        catch (JsonProcessingException e) { return json; }
    }

    public String maskHeaderValue(String name, String value) {
        if (name == null || value == null) return value;
        if (name.equalsIgnoreCase("Authorization")) return value.length() > 10 ? value.substring(0, 7) + "..." + mc(4) : mc(value.length());
        for (String f : fields) if (name.equalsIgnoreCase(f)) return mc(Math.max(value.length(), 4));
        return value;
    }

    private void maskNode(JsonNode node) {
        if (node.isObject()) {
            ObjectNode obj = (ObjectNode) node;
            var it = obj.fields();
            while (it.hasNext()) {
                var e = it.next();
                if (shouldMask(e.getKey())) obj.set(e.getKey(), new TextNode(mc(Math.max(e.getValue().asText("").length(), 4))));
                else maskNode(e.getValue());
            }
        } else if (node.isArray()) { for (JsonNode el : node) maskNode(el); }
    }

    private boolean shouldMask(String name) { for (String f : fields) if (name.equalsIgnoreCase(f)) return true; return false; }
    private String mc(int len) { return String.valueOf(maskChar).repeat(len); }
}
