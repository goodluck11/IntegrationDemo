package com.cbq.restclient.util;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Generates and manages correlation IDs for request tracing.
 * Thread-safe, uses ScopedValue for virtual-thread-friendly propagation.
 */
public final class CorrelationContext {

    private CorrelationContext() {}

    /**
     * ScopedValue for virtual-thread-safe correlation propagation.
     * Preferred over ThreadLocal in virtual thread environments.
     */
    private static final ScopedValue<String> CORRELATION_ID = ScopedValue.newInstance();

    /**
     * Fallback ThreadLocal for cases where ScopedValue isn't practical
     * (e.g., existing code that can't restructure to run inside ScopedValue.where()).
     */
    private static final ThreadLocal<String> CORRELATION_TL = new ThreadLocal<>();

    private static final AtomicLong REQUEST_COUNTER = new AtomicLong(0);

    /** Generate a new correlation ID. */
    public static String newCorrelationId() {
        return "corr_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
    }

    /** Generate a new request ID. */
    public static String newRequestId() {
        return "req_" + String.format("%06d", REQUEST_COUNTER.incrementAndGet());
    }

    /** Get current correlation ID (ScopedValue first, then ThreadLocal fallback). */
    public static String current() {
        if (CORRELATION_ID.isBound()) {
            return CORRELATION_ID.get();
        }
        return CORRELATION_TL.get();
    }

    /** Get current or generate new. */
    public static String currentOrNew() {
        String id = current();
        return id != null ? id : newCorrelationId();
    }

    /** Run a block with a correlation ID bound via ScopedValue. */
    public static <T> T withCorrelation(String correlationId, java.util.concurrent.Callable<T> task) {
        try {
            return ScopedValue.callWhere(CORRELATION_ID, correlationId, task);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /** Run a Runnable with correlation ID bound via ScopedValue. */
    public static void withCorrelation(String correlationId, Runnable task) {
        ScopedValue.runWhere(CORRELATION_ID, correlationId, task);
    }

    /** Set correlation ID via ThreadLocal (fallback for legacy code). */
    public static void set(String correlationId) {
        CORRELATION_TL.set(correlationId);
    }

    /** Clear ThreadLocal. */
    public static void clear() {
        CORRELATION_TL.remove();
    }
}
