package com.cbq.restclient.util;

import org.slf4j.MDC;
import java.util.UUID;
import java.util.concurrent.Callable;

public final class CorrelationContext {
    public static final String CORRELATION_ID_KEY = "correlationId";
    public static final String REQUEST_ID_KEY = "requestId";
    public static final String HEADER_CORRELATION_ID = "X-Correlation-ID";
    public static final String HEADER_REQUEST_ID = "X-Request-ID";
    private CorrelationContext() {}

    public static String getOrCreateCorrelationId() {
        String id = MDC.get(CORRELATION_ID_KEY);
        if (id == null || id.isBlank()) { id = genId("corr"); MDC.put(CORRELATION_ID_KEY, id); }
        return id;
    }
    public static String getCorrelationId()         { return MDC.get(CORRELATION_ID_KEY); }
    public static void setCorrelationId(String id)  { if (id != null) MDC.put(CORRELATION_ID_KEY, id); }
    public static String newRequestId()             { String id = genId("req"); MDC.put(REQUEST_ID_KEY, id); return id; }
    public static void clear()                      { MDC.remove(CORRELATION_ID_KEY); MDC.remove(REQUEST_ID_KEY); }

    public static <T> T withCorrelationId(String corrId, Callable<T> fn) throws Exception {
        String prev = MDC.get(CORRELATION_ID_KEY);
        try { MDC.put(CORRELATION_ID_KEY, corrId); return fn.call(); }
        finally { if (prev != null) MDC.put(CORRELATION_ID_KEY, prev); else MDC.remove(CORRELATION_ID_KEY); }
    }

    public static void withCorrelationId(String corrId, Runnable fn) {
        String prev = MDC.get(CORRELATION_ID_KEY);
        try { MDC.put(CORRELATION_ID_KEY, corrId); fn.run(); }
        finally { if (prev != null) MDC.put(CORRELATION_ID_KEY, prev); else MDC.remove(CORRELATION_ID_KEY); }
    }

    private static String genId(String prefix) { return prefix + "_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12); }
}
