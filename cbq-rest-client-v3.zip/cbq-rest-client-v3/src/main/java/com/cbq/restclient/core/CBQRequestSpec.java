package com.cbq.restclient.core;

import com.cbq.restclient.exception.CBQExceptions;
import com.cbq.restclient.exception.CBQRestClientException;
import com.cbq.restclient.model.CBQResponse;
import com.cbq.restclient.model.ErrorMapper;
import com.cbq.restclient.model.ErrorMapper.ErrorContext;
import com.cbq.restclient.resilience.CBQResilienceManager.ResilienceOverride;
import com.cbq.restclient.util.CorrelationContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Predicate;

public final class CBQRequestSpec {
    private static final Logger log = LoggerFactory.getLogger(CBQRequestSpec.class);
    private final CBQRestClient client;
    private final HttpMethod method;
    private String uri;
    private Object[] uriVars = {};
    private Object body;
    private MediaType contentType;
    private final HttpHeaders extraHeaders = new HttpHeaders();
    private final List<ErrorMapper> perRequestMappers = new ArrayList<>();
    private ResilienceOverride resilienceOverride;

    CBQRequestSpec(CBQRestClient client, HttpMethod method) { this.client = client; this.method = method; }

    public CBQRequestSpec uri(String uri, Object... vars) { this.uri = uri; this.uriVars = vars != null ? vars : new Object[0]; return this; }
    public CBQRequestSpec bodyValue(Object body) { this.body = body; return this; }
    public CBQRequestSpec contentType(MediaType ct) { this.contentType = ct; return this; }
    public CBQRequestSpec header(String n, String v) { extraHeaders.set(n, v); return this; }
    public CBQRequestSpec headers(HttpHeaders h) { extraHeaders.addAll(h); return this; }
    public CBQRequestSpec accept(MediaType... mt) { extraHeaders.setAccept(List.of(mt)); return this; }
    public CBQRequestSpec bearerAuth(String t) { extraHeaders.setBearerAuth(t); return this; }
    public CBQRequestSpec basicAuth(String u, String p) { extraHeaders.setBasicAuth(u, p); return this; }

    public CBQRequestSpec onStatus(Predicate<HttpStatusCode> pred, Function<ErrorContext, ? extends RuntimeException> factory) {
        perRequestMappers.add(ErrorMapper.onStatus(pred, factory)); return this;
    }
    public CBQRequestSpec onStatus(int code, Function<ErrorContext, ? extends RuntimeException> factory) {
        perRequestMappers.add(ErrorMapper.onStatus(code, factory)); return this;
    }

    public CBQRequestSpec resilience(ResilienceOverride ov) { this.resilienceOverride = ov; return this; }
    public CBQRequestSpec noResilience() { this.resilienceOverride = ResilienceOverride.disableAll(); return this; }
    public CBQRequestSpec noRetry() { this.resilienceOverride = ResilienceOverride.disableRetry(); return this; }

    public <T> CBQResponse<T> retrieve(Class<T> type) { return exec(type); }
    public <T> T retrieveBody(Class<T> type) { return retrieve(type).body(); }
    public HttpStatusCode retrieveStatus() { return retrieve(String.class).status(); }

    public <T> CompletableFuture<CBQResponse<T>> retrieveAsync(Class<T> type) {
        String corrId = CorrelationContext.getOrCreateCorrelationId();
        return CompletableFuture.supplyAsync(() -> { CorrelationContext.setCorrelationId(corrId); return exec(type); }, client.getVirtualExecutor());
    }
    public <T> CompletableFuture<T> retrieveBodyAsync(Class<T> type) { return retrieveAsync(type).thenApply(CBQResponse::body); }

    // ── Internal ─────────────────────────────────────────────────────────────

    private <T> CBQResponse<T> exec(Class<T> type) {
        String reqId = CorrelationContext.newRequestId();
        String corrId = CorrelationContext.getOrCreateCorrelationId();
        long start = System.nanoTime();
        String resolvedUri = resolveUri();

        // Merge headers: filters → correlation → per-request
        HttpHeaders merged = new HttpHeaders();
        for (var f : client.getRequestFilters()) f.apply(method.name(), resolvedUri, merged);
        merged.setIfAbsent(CorrelationContext.HEADER_CORRELATION_ID, List.of(corrId));
        merged.setIfAbsent(CorrelationContext.HEADER_REQUEST_ID, List.of(reqId));
        merged.addAll(extraHeaders);

        String bodyStr = serializeBody();
        var logging = client.getLoggingService();
        if (logging != null) logging.logRequest(reqId, corrId, method.name(), resolvedUri, merged, bodyStr);

        try {
            CBQResponse<T> resp = client.getResilience().execute(
                    () -> doHttp(resolvedUri, merged, type, reqId, corrId, start), resilienceOverride);
            long ms = elapsedMs(start);
            if (logging != null) {
                String respBody = resp.body() != null ? serialize(resp.body()) : null;
                logging.logResponse(reqId, corrId, method.name(), resolvedUri, resp.statusCode(), resp.headers(), respBody, ms);
            }
            return resp;
        } catch (CBQRestClientException e) {
            if (logging != null) logging.logError(reqId, corrId, method.name(), resolvedUri, e, elapsedMs(start));
            throw e;
        } catch (Exception e) {
            long ms = elapsedMs(start);
            if (logging != null) logging.logError(reqId, corrId, method.name(), resolvedUri, e, ms);
            throw CBQRestClientException.builder().message("Request failed: " + e.getMessage()).cause(e)
                    .requestId(reqId).correlationId(corrId).method(method.name()).uri(resolvedUri).durationMs(ms).build();
        }
    }

    private <T> CBQResponse<T> doHttp(String resolvedUri, HttpHeaders merged, Class<T> type,
                                       String reqId, String corrId, long start) {
        try {
            var spec = client.getRestClient().method(method).uri(resolvedUri).headers(h -> h.addAll(merged));
            if (body != null) { if (contentType != null) spec.contentType(contentType); spec.body(body); }

            if (type == Void.class || type == void.class) {
                var entity = spec.retrieve().toBodilessEntity();
                return new CBQResponse<>(null, entity.getStatusCode(), entity.getHeaders(), reqId, corrId, elapsedMs(start));
            }
            var entity = spec.retrieve().toEntity(type);
            return new CBQResponse<>(entity.getBody(), entity.getStatusCode(), entity.getHeaders(), reqId, corrId, elapsedMs(start));
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            return handleHttpError(e.getStatusCode(), e.getResponseBodyAsString(), e.getResponseHeaders(), reqId, corrId, resolvedUri, start, e);
        } catch (ResourceAccessException e) {
            if (e.getCause() instanceof SocketTimeoutException)
                throw new CBQExceptions.TimeoutException("Timeout on %s %s: %s".formatted(method, resolvedUri, e.getMessage()), e);
            throw CBQRestClientException.builder().message("Connection error: " + e.getMessage()).cause(e)
                    .requestId(reqId).correlationId(corrId).method(method.name()).uri(resolvedUri).durationMs(elapsedMs(start)).build();
        }
    }

    private <T> CBQResponse<T> handleHttpError(HttpStatusCode status, String respBody, HttpHeaders respHeaders,
                                                String reqId, String corrId, String resolvedUri, long start, Exception cause) {
        long ms = elapsedMs(start);
        var ctx = new ErrorContext(reqId, corrId, method.name(), resolvedUri, status, respBody, ms);
        // Per-request mappers first, then global
        for (var m : perRequestMappers) if (m.statusPredicate().test(status)) throw m.exceptionFactory().apply(ctx);
        for (var m : client.getErrorMappers()) if (m.statusPredicate().test(status)) throw m.exceptionFactory().apply(ctx);
        // Default
        var b = CBQRestClientException.builder().message("HTTP %d on %s %s".formatted(status.value(), method, resolvedUri))
                .cause(cause).requestId(reqId).correlationId(corrId).method(method.name()).uri(resolvedUri)
                .status(status).responseBody(respBody).durationMs(ms);
        if (status.is4xxClientError()) throw new CBQExceptions.ClientErrorException(b);
        throw new CBQExceptions.ServerErrorException(b);
    }

    private String resolveUri() {
        if (uri == null) throw new IllegalStateException("URI not set");
        if (uriVars.length == 0) return uri;
        var sb = new StringBuilder(); int vi = 0;
        for (int i = 0; i < uri.length(); i++) {
            if (i < uri.length() - 1 && uri.charAt(i) == '{' && uri.charAt(i + 1) == '}') {
                sb.append(vi < uriVars.length ? uriVars[vi++] : "{}"); i++;
            } else sb.append(uri.charAt(i));
        }
        return sb.toString();
    }

    private String serializeBody() { return body == null ? null : (body instanceof String s ? s : serialize(body)); }
    private String serialize(Object o) {
        if (o == null) return null; if (o instanceof String s) return s;
        try { return client.getObjectMapper().writeValueAsString(o); } catch (JsonProcessingException e) { return o.toString(); }
    }
    private long elapsedMs(long startNanos) { return (System.nanoTime() - startNanos) / 1_000_000; }
}
