package com.cbq.restclient.core;

import com.cbq.restclient.exception.CBQExceptions;
import com.cbq.restclient.exception.CBQRestClientException;
import com.cbq.restclient.model.CBQResponse;
import com.cbq.restclient.model.ErrorMapper;
import com.cbq.restclient.model.ErrorMapper.ErrorContext;
import com.cbq.restclient.resilience.CBQResilienceManager.ResilienceOverride;
import com.cbq.restclient.util.CorrelationContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Fluent request builder for a single HTTP call.
 * Supports URI templates, body, headers, per-request error mapping, and resilience overrides.
 *
 * <p>Usage:
 * <pre>{@code
 * CBQResponse<User> resp = client.get()
 *     .uri("/users/{}", userId)
 *     .header("X-Custom", "value")
 *     .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException(ctx.uri()))
 *     .retrieve(User.class);
 *
 * User body = client.post()
 *     .uri("/users")
 *     .bodyValue(newUser)
 *     .retrieveBody(User.class);
 * }</pre>
 */
public final class CBQRequestSpec {

    private static final Logger log = LoggerFactory.getLogger(CBQRequestSpec.class);

    private final CBQRestClient client;
    private final HttpMethod method;

    private String uri;
    private Object[] uriVars = new Object[0];
    private Object body;
    private MediaType contentType;
    private final HttpHeaders extraHeaders = new HttpHeaders();
    private final List<ErrorMapper> perRequestErrorMappers = new ArrayList<>();
    private ResilienceOverride resilienceOverride;

    CBQRequestSpec(CBQRestClient client, HttpMethod method) {
        this.client = client;
        this.method = method;
    }

    // ── URI ──────────────────────────────────────────────────────────────────

    /** Set URI with optional path variable substitution: uri("/users/{}/orders/{}", userId, orderId) */
    public CBQRequestSpec uri(String uri, Object... vars) {
        this.uri = uri;
        this.uriVars = vars != null ? vars : new Object[0];
        return this;
    }

    // ── Body ─────────────────────────────────────────────────────────────────

    public CBQRequestSpec bodyValue(Object body) {
        this.body = body;
        return this;
    }

    public CBQRequestSpec contentType(MediaType contentType) {
        this.contentType = contentType;
        return this;
    }

    // ── Headers ──────────────────────────────────────────────────────────────

    public CBQRequestSpec header(String name, String value) {
        this.extraHeaders.set(name, value);
        return this;
    }

    public CBQRequestSpec headers(HttpHeaders headers) {
        this.extraHeaders.addAll(headers);
        return this;
    }

    public CBQRequestSpec accept(MediaType... mediaTypes) {
        this.extraHeaders.setAccept(List.of(mediaTypes));
        return this;
    }

    public CBQRequestSpec bearerAuth(String token) {
        this.extraHeaders.setBearerAuth(token);
        return this;
    }

    public CBQRequestSpec basicAuth(String username, String password) {
        this.extraHeaders.setBasicAuth(username, password);
        return this;
    }

    // ── Per-Request Error Mapping ────────────────────────────────────────────

    /**
     * Add a per-request error mapper. Takes precedence over global mappers.
     * <pre>{@code
     * client.get().uri("/users/{}", id)
     *     .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException(id))
     *     .onStatus(s -> s.value() == 409, ctx -> new ConflictException("User exists"))
     *     .retrieve(User.class);
     * }</pre>
     */
    public CBQRequestSpec onStatus(Predicate<HttpStatusCode> predicate,
                                   Function<ErrorContext, ? extends RuntimeException> exceptionFactory) {
        this.perRequestErrorMappers.add(ErrorMapper.onStatus(predicate, exceptionFactory));
        return this;
    }

    /** Map a specific HTTP status code to an exception */
    public CBQRequestSpec onStatus(int statusCode,
                                   Function<ErrorContext, ? extends RuntimeException> exceptionFactory) {
        this.perRequestErrorMappers.add(ErrorMapper.onStatus(statusCode, exceptionFactory));
        return this;
    }

    // ── Resilience Override ──────────────────────────────────────────────────

    /** Override resilience settings for this specific request */
    public CBQRequestSpec resilience(ResilienceOverride override) {
        this.resilienceOverride = override;
        return this;
    }

    /** Disable all resilience for this request */
    public CBQRequestSpec noResilience() {
        this.resilienceOverride = ResilienceOverride.disableAll();
        return this;
    }

    /** Disable retry only for this request (useful for non-idempotent calls) */
    public CBQRequestSpec noRetry() {
        this.resilienceOverride = ResilienceOverride.disableRetry();
        return this;
    }

    // ── Execution ────────────────────────────────────────────────────────────

    /**
     * Execute and return full CBQResponse with metadata.
     */
    public <T> CBQResponse<T> retrieve(Class<T> responseType) {
        return executeInternal(responseType);
    }

    /**
     * Execute and return only the response body.
     */
    public <T> T retrieveBody(Class<T> responseType) {
        CBQResponse<T> response = retrieve(responseType);
        return response.body();
    }

    /**
     * Execute and return only the status code.
     */
    public HttpStatusCode retrieveStatus() {
        CBQResponse<String> response = retrieve(String.class);
        return response.status();
    }

    /**
     * Execute asynchronously on a virtual thread.
     */
    public <T> CompletableFuture<CBQResponse<T>> retrieveAsync(Class<T> responseType) {
        String correlationId = CorrelationContext.getOrCreateCorrelationId();
        return CompletableFuture.supplyAsync(() -> {
            CorrelationContext.setCorrelationId(correlationId);
            return executeInternal(responseType);
        }, client.getVirtualExecutor());
    }

    /**
     * Execute asynchronously and return only the body.
     */
    public <T> CompletableFuture<T> retrieveBodyAsync(Class<T> responseType) {
        return retrieveAsync(responseType).thenApply(CBQResponse::body);
    }

    // ── Internal Execution ───────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private <T> CBQResponse<T> executeInternal(Class<T> responseType) {
        String requestId = CorrelationContext.newRequestId();
        String correlationId = CorrelationContext.getOrCreateCorrelationId();
        long startTime = System.nanoTime();

        // Resolve URI (replace {} with args)
        String resolvedUri = resolveUri();

        // Build merged headers (filters → global → per-request)
        HttpHeaders mergedHeaders = new HttpHeaders();
        // Apply request filters
        for (var filter : client.getRequestFilters()) {
            filter.apply(method.name(), resolvedUri, mergedHeaders);
        }
        // Add correlation/request ID headers
        mergedHeaders.setIfAbsent(CorrelationContext.HEADER_CORRELATION_ID, List.of(correlationId));
        mergedHeaders.setIfAbsent(CorrelationContext.HEADER_REQUEST_ID, List.of(requestId));
        // Per-request headers override
        mergedHeaders.addAll(extraHeaders);

        // Serialize body for logging
        String bodyString = serializeBody();

        // Log request
        if (client.getLoggingService() != null) {
            client.getLoggingService().logRequest(requestId, correlationId, method.name(), resolvedUri,
                    mergedHeaders, bodyString);
        }

        // Execute with resilience wrapper
        try {
            CBQResponse<T> response = client.getResilience().execute(() -> {
                return doHttpCall(resolvedUri, mergedHeaders, responseType, requestId, correlationId, startTime);
            }, resilienceOverride);

            // Log response
            long durationMs = elapsed(startTime);
            if (client.getLoggingService() != null) {
                String respBody = response.body() != null ? serialize(response.body()) : null;
                client.getLoggingService().logResponse(requestId, correlationId, method.name(), resolvedUri,
                        response.statusCode(), response.headers(), respBody, durationMs);
            }

            return response;

        } catch (CBQRestClientException e) {
            long durationMs = elapsed(startTime);
            if (client.getLoggingService() != null) {
                client.getLoggingService().logError(requestId, correlationId, method.name(), resolvedUri, e, durationMs);
            }
            throw e;
        } catch (Exception e) {
            long durationMs = elapsed(startTime);
            if (client.getLoggingService() != null) {
                client.getLoggingService().logError(requestId, correlationId, method.name(), resolvedUri, e, durationMs);
            }
            throw CBQRestClientException.builder()
                    .message("Request failed: " + e.getMessage())
                    .cause(e)
                    .requestId(requestId)
                    .correlationId(correlationId)
                    .method(method.name())
                    .uri(resolvedUri)
                    .durationMs(durationMs)
                    .build();
        }
    }

    @SuppressWarnings("unchecked")
    private <T> CBQResponse<T> doHttpCall(String resolvedUri, HttpHeaders mergedHeaders,
                                          Class<T> responseType, String requestId,
                                          String correlationId, long startTime) {
        try {
            // Build the RestClient request
            RestClient.RequestBodySpec spec = client.getRestClient()
                    .method(method)
                    .uri(resolvedUri, uriVars)
                    .headers(h -> h.addAll(mergedHeaders));

            if (body != null) {
                if (contentType != null) {
                    spec.contentType(contentType);
                }
                spec.body(body);
            }

            // Execute
            ResponseEntity<T> entity;
            if (responseType == Void.class || responseType == void.class) {
                spec.retrieve().toBodilessEntity();
                return new CBQResponse<>(null, HttpStatus.OK, new HttpHeaders(),
                        requestId, correlationId, elapsed(startTime));
            } else {
                entity = spec.retrieve().toEntity(responseType);
            }

            return new CBQResponse<>(
                    entity.getBody(),
                    entity.getStatusCode(),
                    entity.getHeaders(),
                    requestId,
                    correlationId,
                    elapsed(startTime)
            );

        } catch (HttpClientErrorException | HttpServerErrorException e) {
            return handleHttpError(e.getStatusCode(), e.getResponseBodyAsString(), e.getResponseHeaders(),
                    requestId, correlationId, resolvedUri, startTime, e);
        } catch (ResourceAccessException e) {
            if (e.getCause() instanceof SocketTimeoutException) {
                throw new CBQExceptions.TimeoutException(
                        "Timeout on %s %s: %s".formatted(method, resolvedUri, e.getMessage()), e);
            }
            throw CBQRestClientException.builder()
                    .message("Connection error: " + e.getMessage())
                    .cause(e)
                    .requestId(requestId)
                    .correlationId(correlationId)
                    .method(method.name())
                    .uri(resolvedUri)
                    .durationMs(elapsed(startTime))
                    .build();
        }
    }

    private <T> CBQResponse<T> handleHttpError(HttpStatusCode status, String responseBody,
                                                HttpHeaders responseHeaders,
                                                String requestId, String correlationId,
                                                String resolvedUri, long startTime, Exception cause) {
        long durationMs = elapsed(startTime);
        ErrorContext ctx = new ErrorContext(requestId, correlationId, method.name(), resolvedUri,
                status, responseBody, durationMs);

        // Check per-request error mappers first
        for (var mapper : perRequestErrorMappers) {
            if (mapper.statusPredicate().test(status)) {
                throw mapper.exceptionFactory().apply(ctx);
            }
        }

        // Then global error mappers
        for (var mapper : client.getErrorMappers()) {
            if (mapper.statusPredicate().test(status)) {
                throw mapper.exceptionFactory().apply(ctx);
            }
        }

        // Default error handling
        CBQRestClientException.Builder builder = CBQRestClientException.builder()
                .message("HTTP %d on %s %s".formatted(status.value(), method, resolvedUri))
                .cause(cause)
                .requestId(requestId)
                .correlationId(correlationId)
                .method(method.name())
                .uri(resolvedUri)
                .status(status)
                .responseBody(responseBody)
                .durationMs(durationMs);

        if (status.is4xxClientError()) {
            throw new CBQExceptions.ClientErrorException(builder);
        } else {
            throw new CBQExceptions.ServerErrorException(builder);
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /**
     * Resolve simple {} placeholders in URI (like v2 had).
     * Replaces sequential {} with positional args.
     */
    private String resolveUri() {
        if (uri == null) throw new IllegalStateException("URI not set");
        if (uriVars == null || uriVars.length == 0) return uri;

        StringBuilder resolved = new StringBuilder();
        int varIndex = 0;
        int i = 0;
        while (i < uri.length()) {
            if (i < uri.length() - 1 && uri.charAt(i) == '{' && uri.charAt(i + 1) == '}') {
                if (varIndex < uriVars.length) {
                    resolved.append(uriVars[varIndex++]);
                } else {
                    resolved.append("{}");
                }
                i += 2;
            } else {
                resolved.append(uri.charAt(i));
                i++;
            }
        }
        return resolved.toString();
    }

    private String serializeBody() {
        if (body == null) return null;
        if (body instanceof String s) return s;
        return serialize(body);
    }

    private String serialize(Object obj) {
        if (obj == null) return null;
        if (obj instanceof String s) return s;
        try {
            return client.getObjectMapper().writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            return obj.toString();
        }
    }

    private long elapsed(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }
}
