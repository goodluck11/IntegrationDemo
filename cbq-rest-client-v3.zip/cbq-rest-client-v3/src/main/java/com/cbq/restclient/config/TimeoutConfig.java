package com.cbq.restclient.config;

import java.time.Duration;

public record TimeoutConfig(Duration connection, Duration read, Duration write, Duration response) {
    public static TimeoutConfig defaults() { return new TimeoutConfig(Duration.ofSeconds(5), Duration.ofSeconds(30), Duration.ofSeconds(30), Duration.ofSeconds(60)); }
    public static TimeoutConfig fast()     { return new TimeoutConfig(Duration.ofSeconds(2), Duration.ofSeconds(5), Duration.ofSeconds(5), Duration.ofSeconds(10)); }
    public static TimeoutConfig slow()     { return new TimeoutConfig(Duration.ofSeconds(10), Duration.ofMinutes(2), Duration.ofMinutes(2), Duration.ofMinutes(5)); }
    public static TimeoutConfig batch()    { return new TimeoutConfig(Duration.ofSeconds(10), Duration.ofMinutes(10), Duration.ofMinutes(10), Duration.ofMinutes(30)); }

    public static Builder custom() { return new Builder(); }

    public static class Builder {
        private Duration connection = Duration.ofSeconds(5), read = Duration.ofSeconds(30),
                write = Duration.ofSeconds(30), response = Duration.ofSeconds(60);
        public Builder connection(Duration d) { this.connection = d; return this; }
        public Builder read(Duration d)       { this.read = d; return this; }
        public Builder write(Duration d)      { this.write = d; return this; }
        public Builder response(Duration d)   { this.response = d; return this; }
        public TimeoutConfig build() { return new TimeoutConfig(connection, read, write, response); }
    }
}
