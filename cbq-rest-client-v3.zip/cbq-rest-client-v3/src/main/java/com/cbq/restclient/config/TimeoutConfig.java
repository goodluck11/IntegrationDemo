package com.cbq.restclient.config;

import java.time.Duration;
import java.util.*;

/**
 * Timeout configuration for HTTP connections.
 */
public record TimeoutConfig(
        Duration connection,
        Duration read,
        Duration write,
        Duration response
) {
    public static final TimeoutConfig DEFAULT = new TimeoutConfig(
            Duration.ofSeconds(10), Duration.ofSeconds(30),
            Duration.ofSeconds(30), Duration.ofSeconds(60)
    );

    public static Builder custom() { return new Builder(); }

    public static final class Builder {
        private Duration connection = Duration.ofSeconds(10);
        private Duration read = Duration.ofSeconds(30);
        private Duration write = Duration.ofSeconds(30);
        private Duration response = Duration.ofSeconds(60);

        public Builder connection(Duration d) { this.connection = d; return this; }
        public Builder read(Duration d) { this.read = d; return this; }
        public Builder write(Duration d) { this.write = d; return this; }
        public Builder response(Duration d) { this.response = d; return this; }

        public TimeoutConfig build() {
            return new TimeoutConfig(connection, read, write, response);
        }
    }
}
