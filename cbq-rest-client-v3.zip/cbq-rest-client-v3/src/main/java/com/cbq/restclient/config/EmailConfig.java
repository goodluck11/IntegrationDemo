package com.cbq.restclient.config;

import java.util.List;

/**
 * Email notification configuration for error alerting.
 */
public record EmailConfig(
        String host,
        int port,
        String username,
        String password,
        boolean starttls,
        String from,
        List<String> defaultTo,
        String subjectPrefix
) {
    public static Builder custom() { return new Builder(); }

    public static class Builder {
        private String host;
        private int port = 587;
        private String username;
        private String password;
        private boolean starttls = true;
        private String from;
        private List<String> defaultTo = List.of();
        private String subjectPrefix = "[CBQ Alert]";

        public Builder host(String h)            { this.host = h; return this; }
        public Builder port(int p)               { this.port = p; return this; }
        public Builder username(String u)         { this.username = u; return this; }
        public Builder password(String p)         { this.password = p; return this; }
        public Builder starttls(boolean b)        { this.starttls = b; return this; }
        public Builder from(String f)             { this.from = f; return this; }
        public Builder defaultTo(String... to)    { this.defaultTo = List.of(to); return this; }
        public Builder subjectPrefix(String s)    { this.subjectPrefix = s; return this; }

        public EmailConfig build() {
            return new EmailConfig(host, port, username, password, starttls, from, defaultTo, subjectPrefix);
        }
    }
}
