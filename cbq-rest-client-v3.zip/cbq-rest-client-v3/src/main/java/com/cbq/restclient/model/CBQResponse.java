package com.cbq.restclient.model;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;

public record CBQResponse<T>(T body, HttpStatusCode status, HttpHeaders headers, String requestId, String correlationId, long durationMs) {
    public int statusCode()       { return status != null ? status.value() : 0; }
    public boolean isSuccess()    { return status != null && status.is2xxSuccessful(); }
    public String header(String n){ return headers != null ? headers.getFirst(n) : null; }
}
