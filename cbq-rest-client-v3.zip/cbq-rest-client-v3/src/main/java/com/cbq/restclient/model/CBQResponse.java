package com.cbq.restclient.model;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;

import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

/**
 * Unified response wrapper carrying body, headers, status, and request metadata.
 *
 * @param <T> response body type
 */
public record CBQResponse<T>(
        T body,
        HttpStatusCode status,
        HttpHeaders headers,
        String requestId,
        String correlationId,
        String method,
        String uri,
        Duration duration,
        Instant timestamp
) {
    public int statusCode() {
        return status.value();
    }

    public boolean isSuccess() {
        return status.is2xxSuccessful();
    }

    public boolean isClientError() {
        return status.is4xxClientError();
    }

    public boolean isServerError() {
        return status.is5xxServerError();
    }

    public Optional<T> bodyOptional() {
        return Optional.ofNullable(body);
    }

    public <R> CBQResponse<R> withBody(R newBody) {
        return new CBQResponse<>(newBody, status, headers, requestId, correlationId,
                method, uri, duration, timestamp);
    }

    public static <T> Builder<T> builder() {
        return new Builder<>();
    }

    public static final class Builder<T> {
        private T body;
        private HttpStatusCode status;
        private HttpHeaders headers = new HttpHeaders();
        private String requestId;
        private String correlationId;
        private String method;
        private String uri;
        private Duration duration;
        private Instant timestamp = Instant.now();

        public Builder<T> body(T body) { this.body = body; return this; }
        public Builder<T> status(HttpStatusCode status) { this.status = status; return this; }
        public Builder<T> headers(HttpHeaders headers) { this.headers = headers; return this; }
        public Builder<T> requestId(String requestId) { this.requestId = requestId; return this; }
        public Builder<T> correlationId(String correlationId) { this.correlationId = correlationId; return this; }
        public Builder<T> method(String method) { this.method = method; return this; }
        public Builder<T> uri(String uri) { this.uri = uri; return this; }
        public Builder<T> duration(Duration duration) { this.duration = duration; return this; }
        public Builder<T> timestamp(Instant timestamp) { this.timestamp = timestamp; return this; }

        public CBQResponse<T> build() {
            return new CBQResponse<>(body, status, headers, requestId, correlationId,
                    method, uri, duration, timestamp);
        }
    }
}
