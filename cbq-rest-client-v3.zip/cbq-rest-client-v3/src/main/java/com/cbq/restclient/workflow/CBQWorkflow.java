package com.cbq.restclient.workflow;

import com.cbq.restclient.exception.CBQExceptions;
import com.cbq.restclient.util.CorrelationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public final class CBQWorkflow<T> {
    private static final Logger log = LoggerFactory.getLogger(CBQWorkflow.class);

    private final Supplier<T> chainSupplier;
    private final String correlationId;
    private final List<Supplier<Runnable>> ffSuppliers;          // fire-and-forget without result
    private final List<Function<T, ?>> ffWithResult;              // fire-and-forget with result access
    private Consumer<Throwable> failureHandler;
    private Consumer<Throwable> ffErrorHandler = e -> log.warn("Fire-and-forget failed: {}", e.getMessage());
    private int maxConcurrentFF = 10;

    private CBQWorkflow(Supplier<T> supplier, String corrId, List<Supplier<Runnable>> ffSuppliers,
                        List<Function<T, ?>> ffWithResult, Consumer<Throwable> failureHandler,
                        Consumer<Throwable> ffErrorHandler, int maxConcurrentFF) {
        this.chainSupplier = supplier; this.correlationId = corrId;
        this.ffSuppliers = ffSuppliers; this.ffWithResult = ffWithResult;
        this.failureHandler = failureHandler; this.ffErrorHandler = ffErrorHandler;
        this.maxConcurrentFF = maxConcurrentFF;
    }

    public static <T> CBQWorkflow<T> startWith(Supplier<T> supplier) {
        return new CBQWorkflow<>(supplier, CorrelationContext.getOrCreateCorrelationId(),
                new ArrayList<>(), new ArrayList<>(), null, e -> log.warn("FF failed: {}", e.getMessage()), 10);
    }

    public static <T> CBQWorkflow<T> startWith(T value) { return startWith(() -> value); }

    public <R> CBQWorkflow<R> step(Function<T, R> fn) {
        Supplier<T> prev = this.chainSupplier;
        return carry(new CBQWorkflow<>(() -> fn.apply(prev.get()), correlationId, new ArrayList<>(ffSuppliers),
                new ArrayList<>(), failureHandler, ffErrorHandler, maxConcurrentFF));
    }

    public <R> CBQWorkflow<R> stepContinueOnError(Function<T, R> fn, Function<T, R> fallback) {
        Supplier<T> prev = this.chainSupplier;
        return carry(new CBQWorkflow<>(() -> {
            T r = prev.get();
            try { return fn.apply(r); } catch (Exception e) { log.warn("Step failed, using fallback: {}", e.getMessage()); return fallback.apply(r); }
        }, correlationId, new ArrayList<>(ffSuppliers), new ArrayList<>(), failureHandler, ffErrorHandler, maxConcurrentFF));
    }

    public <R> CBQWorkflow<R> stepSync(Function<T, R> fn) { return step(fn); }

    @SafeVarargs
    public final CBQWorkflow<T> fireAndForget(Supplier<?>... tasks) {
        for (var t : tasks) ffSuppliers.add(() -> () -> { try { t.get(); } catch (Exception e) { ffErrorHandler.accept(e); } });
        return this;
    }

    public CBQWorkflow<T> fireAndForgetWith(Function<T, ?> task) { ffWithResult.add(task); return this; }
    public CBQWorkflow<T> onFailure(Consumer<Throwable> handler) { this.failureHandler = handler; return this; }
    public CBQWorkflow<T> onFireAndForgetError(Consumer<Throwable> handler) { this.ffErrorHandler = handler; return this; }
    public CBQWorkflow<T> maxConcurrentFireAndForget(int n) { this.maxConcurrentFF = n; return this; }

    public T execute() {
        CorrelationContext.setCorrelationId(correlationId);
        try {
            T result = chainSupplier.get();
            triggerFF(result);
            return result;
        } catch (Exception e) {
            if (failureHandler != null) try { failureHandler.accept(e); } catch (Exception fe) { log.error("Failure handler error: {}", fe.getMessage()); }
            throw (e instanceof RuntimeException re) ? re : new RuntimeException(e);
        }
    }

    public T execute(Duration timeout) {
        try { return CompletableFuture.supplyAsync(this::execute, Executors.newVirtualThreadPerTaskExecutor()).get(timeout.toMillis(), TimeUnit.MILLISECONDS); }
        catch (TimeoutException e) { throw new CBQExceptions.TimeoutException("Workflow timed out after " + timeout, e); }
        catch (ExecutionException e) { throw (e.getCause() instanceof RuntimeException re) ? re : new RuntimeException(e.getCause()); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new RuntimeException("Interrupted", e); }
    }

    public CompletableFuture<T> executeAsync() { return CompletableFuture.supplyAsync(this::execute, Executors.newVirtualThreadPerTaskExecutor()); }

    public void executeAndForget() {
        Thread.startVirtualThread(() -> { CorrelationContext.setCorrelationId(correlationId);
            try { execute(); } catch (Exception e) { log.error("FF workflow failed: {}", e.getMessage()); } });
    }

    private void triggerFF(T result) {
        String corrId = this.correlationId;
        List<Runnable> tasks = new ArrayList<>();
        for (var s : ffSuppliers) tasks.add(s.get());
        for (var fn : ffWithResult) tasks.add(() -> { try { fn.apply(result); } catch (Exception e) { ffErrorHandler.accept(e); } });
        if (tasks.isEmpty()) return;
        log.debug("Triggering {} fire-and-forget tasks", tasks.size());
        var sem = new Semaphore(maxConcurrentFF);
        for (var task : tasks) {
            Thread.startVirtualThread(() -> {
                CorrelationContext.setCorrelationId(corrId);
                try { sem.acquire(); task.run(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally { sem.release(); }
            });
        }
    }

    private <R> CBQWorkflow<R> carry(CBQWorkflow<R> next) {
        // Transfer accumulated ff suppliers into new workflow
        return next;
    }
}
