package com.cbq.restclient.workflow;

import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.model.CBQResponse;
import com.cbq.restclient.util.CorrelationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Workflow orchestrator for chaining HTTP calls, DB operations, and background tasks.
 *
 * <p>Rewritten for Java 21 virtual threads: all steps are synchronous (blocking is cheap),
 * fire-and-forget tasks run on virtual threads, and correlation IDs propagate via MDC.
 *
 * <p>Usage patterns:
 * <pre>{@code
 * // Sequential chain
 * Order order = CBQWorkflow.startWith(() -> client.post().uri("/orders").retrieveBody(Order.class))
 *     .step(o -> client.post().uri("/payments").bodyValue(new PayReq(o.id())).retrieveBody(Payment.class))
 *     .step(p -> client.post().uri("/shipping").bodyValue(new ShipReq(p.orderId())).retrieveBody(Shipping.class))
 *     .execute();
 *
 * // With fire-and-forget
 * CBQWorkflow.startWith(() -> client.post().uri("/orders").retrieveBody(Order.class))
 *     .fireAndForget(
 *         () -> client.post().uri("/email/send").bodyValue(emailReq).retrieveBody(Void.class),
 *         () -> client.post().uri("/audit/log").bodyValue(auditReq).retrieveBody(Void.class)
 *     )
 *     .execute();
 *
 * // Partial success (continue even if step fails)
 * Result result = CBQWorkflow.startWith(() -> fetchPrimaryData())
 *     .stepContinueOnError(data -> enrichWithExternalApi(data), data -> data) // fallback returns original
 *     .execute();
 * }</pre>
 *
 * @param <T> Current result type in the chain
 */
public final class CBQWorkflow<T> {

    private static final Logger log = LoggerFactory.getLogger(CBQWorkflow.class);

    private final Supplier<T> chainSupplier;
    private final List<Supplier<Runnable>> fireAndForgetSuppliers = new ArrayList<>();
    private Consumer<Throwable> failureHandler;
    private Consumer<Throwable> fireAndForgetErrorHandler = e ->
            log.warn("Fire-and-forget task failed: {}", e.getMessage());
    private int maxConcurrentFireAndForget = 10;
    private final String correlationId;

    private CBQWorkflow(Supplier<T> supplier, String correlationId) {
        this.chainSupplier = supplier;
        this.correlationId = correlationId;
    }

    // ── Factory Methods ──────────────────────────────────────────────────────

    /**
     * Start a workflow with an initial supplier (HTTP call, DB query, etc.)
     */
    public static <T> CBQWorkflow<T> startWith(Supplier<T> supplier) {
        String corrId = CorrelationContext.getOrCreateCorrelationId();
        return new CBQWorkflow<>(supplier, corrId);
    }

    /**
     * Start with a static value (useful for pre-fetched data).
     */
    public static <T> CBQWorkflow<T> startWith(T value) {
        String corrId = CorrelationContext.getOrCreateCorrelationId();
        return new CBQWorkflow<>(() -> value, corrId);
    }

    // ── Sequential Steps ─────────────────────────────────────────────────────

    /**
     * Chain a step that transforms the current result into a new result.
     * If this step fails, the entire workflow fails.
     */
    public <R> CBQWorkflow<R> step(Function<T, R> fn) {
        Supplier<T> prevSupplier = this.chainSupplier;
        var next = new CBQWorkflow<R>(() -> {
            T result = prevSupplier.get();
            return fn.apply(result);
        }, this.correlationId);
        next.fireAndForgetSuppliers.addAll(this.fireAndForgetSuppliers);
        next.failureHandler = this.failureHandler;
        next.fireAndForgetErrorHandler = this.fireAndForgetErrorHandler;
        next.maxConcurrentFireAndForget = this.maxConcurrentFireAndForget;
        return next;
    }

    /**
     * Chain a step that can fail gracefully — if it throws, use the fallback function instead.
     * The fallback receives the original input so it can return a degraded result.
     *
     * <pre>{@code
     * .stepContinueOnError(
     *     order -> enrichOrder(order),   // might fail
     *     order -> order                 // fallback: return unmodified
     * )
     * }</pre>
     */
    public <R> CBQWorkflow<R> stepContinueOnError(Function<T, R> fn, Function<T, R> fallback) {
        Supplier<T> prevSupplier = this.chainSupplier;
        var next = new CBQWorkflow<R>(() -> {
            T result = prevSupplier.get();
            try {
                return fn.apply(result);
            } catch (Exception e) {
                log.warn("Step failed, using fallback: {}", e.getMessage());
                return fallback.apply(result);
            }
        }, this.correlationId);
        next.fireAndForgetSuppliers.addAll(this.fireAndForgetSuppliers);
        next.failureHandler = this.failureHandler;
        next.fireAndForgetErrorHandler = this.fireAndForgetErrorHandler;
        next.maxConcurrentFireAndForget = this.maxConcurrentFireAndForget;
        return next;
    }

    /**
     * Chain a blocking DB/sync step. Runs on the same virtual thread (blocking is fine).
     */
    public <R> CBQWorkflow<R> stepSync(Function<T, R> fn) {
        return step(fn); // With virtual threads, sync == step
    }

    // ── Fire-and-Forget ──────────────────────────────────────────────────────

    /**
     * Add background tasks that run after the main chain completes.
     * These do NOT block the workflow result.
     */
    @SafeVarargs
    public final CBQWorkflow<T> fireAndForget(Supplier<?>... tasks) {
        for (var task : tasks) {
            fireAndForgetSuppliers.add(() -> () -> {
                try { task.get(); }
                catch (Exception e) { fireAndForgetErrorHandler.accept(e); }
            });
        }
        return this;
    }

    /**
     * Fire-and-forget tasks that have access to the current result.
     */
    public CBQWorkflow<T> fireAndForgetWith(Function<T, ?> task) {
        fireAndForgetSuppliers.add(() -> {
            // The supplier is resolved at execution time, binding the result
            return () -> {}; // placeholder, overridden in execute
        });
        // Store the function for later — we'll resolve it during execute
        fireAndForgetFunctions.add(task);
        return this;
    }

    private final List<Function<T, ?>> fireAndForgetFunctions = new ArrayList<>();

    /**
     * Error handler for fire-and-forget tasks.
     */
    public CBQWorkflow<T> onFireAndForgetError(Consumer<Throwable> handler) {
        this.fireAndForgetErrorHandler = handler;
        return this;
    }

    /**
     * Set max concurrent fire-and-forget tasks (default: 10).
     */
    public CBQWorkflow<T> maxConcurrentFireAndForget(int max) {
        this.maxConcurrentFireAndForget = max;
        return this;
    }

    // ── Failure Handler ──────────────────────────────────────────────────────

    /**
     * Handler that runs if the main chain fails. Useful for rollback/compensation.
     * The error is still re-thrown after the handler runs.
     */
    public CBQWorkflow<T> onFailure(Consumer<Throwable> handler) {
        this.failureHandler = handler;
        return this;
    }

    // ── Execution ────────────────────────────────────────────────────────────

    /**
     * Execute the workflow synchronously, blocking until the result is ready.
     */
    public T execute() {
        CorrelationContext.setCorrelationId(correlationId);
        try {
            T result = chainSupplier.get();

            // Trigger fire-and-forget tasks on success
            triggerFireAndForget(result);

            return result;
        } catch (Exception e) {
            if (failureHandler != null) {
                try {
                    failureHandler.accept(e);
                } catch (Exception failErr) {
                    log.error("Failure handler itself failed: {}", failErr.getMessage());
                }
            }
            throw (e instanceof RuntimeException re) ? re : new RuntimeException(e);
        }
    }

    /**
     * Execute with a timeout.
     */
    public T execute(Duration timeout) {
        try {
            return CompletableFuture.supplyAsync(this::execute, Executors.newVirtualThreadPerTaskExecutor())
                    .get(timeout.toMillis(), TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            throw new com.cbq.restclient.exception.CBQExceptions.TimeoutException(
                    "Workflow timed out after " + timeout, e);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            throw (cause instanceof RuntimeException re) ? re : new RuntimeException(cause);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Workflow interrupted", e);
        }
    }

    /**
     * Execute asynchronously on a virtual thread.
     */
    public CompletableFuture<T> executeAsync() {
        return CompletableFuture.supplyAsync(this::execute, Executors.newVirtualThreadPerTaskExecutor());
    }

    /**
     * Execute and ignore result (fire-and-forget the entire workflow).
     */
    public void executeAndForget() {
        Thread.startVirtualThread(() -> {
            CorrelationContext.setCorrelationId(correlationId);
            try {
                execute();
            } catch (Exception e) {
                log.error("Fire-and-forget workflow failed: {}", e.getMessage());
            }
        });
    }

    // ── Internal ─────────────────────────────────────────────────────────────

    private void triggerFireAndForget(T result) {
        String corrId = this.correlationId;

        // Standard fire-and-forget (no result access)
        List<Runnable> tasks = new ArrayList<>();
        for (var supplier : fireAndForgetSuppliers) {
            tasks.add(supplier.get());
        }

        // Fire-and-forget with result access
        for (var fn : fireAndForgetFunctions) {
            tasks.add(() -> {
                try {
                    fn.apply(result);
                } catch (Exception e) {
                    fireAndForgetErrorHandler.accept(e);
                }
            });
        }

        if (tasks.isEmpty()) return;

        log.debug("Triggering {} fire-and-forget tasks", tasks.size());

        // Use a semaphore to limit concurrency
        var semaphore = new Semaphore(maxConcurrentFireAndForget);
        for (var task : tasks) {
            Thread.startVirtualThread(() -> {
                CorrelationContext.setCorrelationId(corrId);
                try {
                    semaphore.acquire();
                    task.run();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    semaphore.release();
                }
            });
        }
    }
}
