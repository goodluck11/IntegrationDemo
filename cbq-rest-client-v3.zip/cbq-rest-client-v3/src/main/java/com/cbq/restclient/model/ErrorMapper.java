package com.cbq.restclient.model;

import org.springframework.http.HttpStatusCode;
import java.util.function.Function;
import java.util.function.Predicate;

public record ErrorMapper(Predicate<HttpStatusCode> statusPredicate, Function<ErrorContext, ? extends RuntimeException> exceptionFactory) {
    public static ErrorMapper onStatus(Predicate<HttpStatusCode> p, Function<ErrorContext, ? extends RuntimeException> f) { return new ErrorMapper(p, f); }
    public static ErrorMapper onStatus(int code, Function<ErrorContext, ? extends RuntimeException> f) { return new ErrorMapper(s -> s.value() == code, f); }

    public record ErrorContext(String requestId, String correlationId, String method, String uri, HttpStatusCode status, String body, long durationMs) {}
}
