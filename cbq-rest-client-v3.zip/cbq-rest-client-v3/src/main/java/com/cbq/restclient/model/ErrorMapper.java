package com.cbq.restclient.model;

import org.springframework.http.HttpStatusCode;

import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Maps HTTP status codes to custom exceptions.
 * Used for global error mapping in the client builder and per-request overrides.
 */
public record ErrorMapper(
        Predicate<HttpStatusCode> statusPredicate,
        Function<ErrorContext, ? extends RuntimeException> exceptionFactory
) {
    /** Create an error mapper for a status predicate */
    public static ErrorMapper onStatus(Predicate<HttpStatusCode> predicate,
                                       Function<ErrorContext, ? extends RuntimeException> factory) {
        return new ErrorMapper(predicate, factory);
    }

    /** Create an error mapper for a specific status code */
    public static ErrorMapper onStatus(int statusCode,
                                       Function<ErrorContext, ? extends RuntimeException> factory) {
        return new ErrorMapper(s -> s.value() == statusCode, factory);
    }

    /**
     * Context passed to exception factory with full response details.
     */
    public record ErrorContext(
            String requestId,
            String correlationId,
            String method,
            String uri,
            HttpStatusCode status,
            String body,
            long durationMs
    ) {}
}
