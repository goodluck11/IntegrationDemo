package com.cbq.restclient.config;

import java.time.Duration;

public record CircuitBreakerConfig(int slidingWindowSize, int minimumNumberOfCalls, float failureRateThreshold, Duration waitDurationInOpenState, int permittedInHalfOpen) {
    public static final CircuitBreakerConfig DEFAULT = new CircuitBreakerConfig(100, 10, 50f, Duration.ofSeconds(60), 5);

    public static Builder custom() { return new Builder(); }

    public static class Builder {
        private int slidingWindowSize = 100, minimumNumberOfCalls = 10, permittedInHalfOpen = 5;
        private float failureRateThreshold = 50f; private Duration waitDurationInOpenState = Duration.ofSeconds(60);
        public Builder slidingWindowSize(int n)            { this.slidingWindowSize = n; return this; }
        public Builder minimumNumberOfCalls(int n)         { this.minimumNumberOfCalls = n; return this; }
        public Builder failureRateThreshold(float f)       { this.failureRateThreshold = f; return this; }
        public Builder waitDurationInOpenState(Duration d) { this.waitDurationInOpenState = d; return this; }
        public Builder permittedInHalfOpen(int n)          { this.permittedInHalfOpen = n; return this; }
        public CircuitBreakerConfig build() { return new CircuitBreakerConfig(slidingWindowSize, minimumNumberOfCalls, failureRateThreshold, waitDurationInOpenState, permittedInHalfOpen); }
    }
}
