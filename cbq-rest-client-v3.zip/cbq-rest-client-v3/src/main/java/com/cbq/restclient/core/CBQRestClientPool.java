package com.cbq.restclient.core;

import com.cbq.restclient.builder.CBQRestClientBuilder;
import com.cbq.restclient.config.*;
import com.cbq.restclient.filter.CBQRequestFilter;
import com.cbq.restclient.model.ErrorMapper;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class CBQRestClientPool {
    private final Map<String, CBQRestClient> clients;
    private CBQRestClientPool(Map<String, CBQRestClient> c) { this.clients = c; }

    public CBQRestClient getFast()    { return clients.get("fast"); }
    public CBQRestClient getDefault() { return clients.get("default"); }
    public CBQRestClient getSlow()    { return clients.get("slow"); }
    public CBQRestClient getBatch()   { return clients.get("batch"); }
    public CBQRestClient get(String name) {
        CBQRestClient c = clients.get(name);
        if (c == null) throw new IllegalArgumentException("No profile '%s'. Available: %s".formatted(name, clients.keySet()));
        return c;
    }
    public void shutdown() { clients.values().forEach(CBQRestClient::shutdown); }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String baseUrl; private ResilienceConfig resilience; private LoggingConfig logging; private SslConfig ssl;
        private final Map<String, String> headers = new LinkedHashMap<>();
        private final List<CBQRequestFilter> filters = new ArrayList<>();
        private final List<ErrorMapper> mappers = new ArrayList<>();
        private final Map<String, TimeoutConfig> custom = new LinkedHashMap<>();

        public Builder baseUrl(String u)                  { this.baseUrl = u; return this; }
        public Builder resilience(ResilienceConfig c)     { this.resilience = c; return this; }
        public Builder logging(LoggingConfig c)           { this.logging = c; return this; }
        public Builder ssl(SslConfig c)                   { this.ssl = c; return this; }
        public Builder header(String n, String v)         { this.headers.put(n, v); return this; }
        public Builder addRequestFilter(CBQRequestFilter f) { this.filters.add(f); return this; }
        public Builder addErrorMapper(ErrorMapper m)      { this.mappers.add(m); return this; }
        public Builder addProfile(String name, TimeoutConfig t) { this.custom.put(name, t); return this; }

        public CBQRestClientPool build() {
            var pool = new ConcurrentHashMap<String, CBQRestClient>();
            pool.put("fast", mk("fast", TimeoutConfig.fast()));
            pool.put("default", mk("default", TimeoutConfig.defaults()));
            pool.put("slow", mk("slow", TimeoutConfig.slow()));
            pool.put("batch", mk("batch", TimeoutConfig.batch()));
            custom.forEach((n, t) -> pool.put(n, mk(n, t)));
            return new CBQRestClientPool(pool);
        }

        private CBQRestClient mk(String name, TimeoutConfig t) {
            var b = CBQRestClientBuilder.builder(name).baseUrl(baseUrl).timeouts(t);
            if (resilience != null) b.resilience(resilience);
            if (logging != null) b.logging(logging);
            if (ssl != null) b.ssl(ssl);
            headers.forEach(b::header); filters.forEach(b::addRequestFilter); mappers.forEach(b::addErrorMapper);
            return b.build();
        }
    }
}
