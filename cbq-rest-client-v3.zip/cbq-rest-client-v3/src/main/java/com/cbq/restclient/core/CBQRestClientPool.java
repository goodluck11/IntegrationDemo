package com.cbq.restclient.core;

import com.cbq.restclient.builder.CBQRestClientBuilder;
import com.cbq.restclient.config.*;
import com.cbq.restclient.filter.CBQRequestFilter;
import com.cbq.restclient.model.ErrorMapper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Pool of CBQRestClient instances with different timeout profiles but shared base configuration.
 *
 * <p>Since connection/read/write timeouts are configured at the HTTP client level and cannot
 * be changed per-request, use this pool to maintain multiple clients with different profiles.
 *
 * <pre>{@code
 * CBQRestClientPool pool = CBQRestClientPool.builder()
 *     .baseUrl("https://api.example.com")
 *     .resilience(ResilienceConfig.defaults())
 *     .logging(LoggingConfig.custom().logAll().jsonFormat().build())
 *     .build();
 *
 * pool.getFast().get().uri("/health").retrieveBody(String.class);      // 2s/5s/10s
 * pool.getDefault().get().uri("/users/1").retrieveBody(User.class);    // 5s/30s/60s
 * pool.getSlow().post().uri("/reports").retrieveBody(Report.class);    // 10s/2m/5m
 * pool.getBatch().get().uri("/exports/large").retrieveBody(byte[].class); // 10s/10m/30m
 * }</pre>
 */
public final class CBQRestClientPool {

    private final Map<String, CBQRestClient> clients;

    private CBQRestClientPool(Map<String, CBQRestClient> clients) {
        this.clients = clients;
    }

    public CBQRestClient getFast()    { return clients.get("fast"); }
    public CBQRestClient getDefault() { return clients.get("default"); }
    public CBQRestClient getSlow()    { return clients.get("slow"); }
    public CBQRestClient getBatch()   { return clients.get("batch"); }

    /** Get a client by custom profile name */
    public CBQRestClient get(String profileName) {
        CBQRestClient client = clients.get(profileName);
        if (client == null) {
            throw new IllegalArgumentException("No client profile named '" + profileName + "'. Available: " + clients.keySet());
        }
        return client;
    }

    /** Shutdown all clients in the pool */
    public void shutdown() {
        clients.values().forEach(CBQRestClient::shutdown);
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String baseUrl;
        private ResilienceConfig resilience;
        private LoggingConfig logging;
        private SslConfig ssl;
        private final Map<String, String> defaultHeaders = new LinkedHashMap<>();
        private final List<CBQRequestFilter> filters = new ArrayList<>();
        private final List<ErrorMapper> errorMappers = new ArrayList<>();
        private final Map<String, TimeoutConfig> customProfiles = new LinkedHashMap<>();

        public Builder baseUrl(String url)                     { this.baseUrl = url; return this; }
        public Builder resilience(ResilienceConfig config)     { this.resilience = config; return this; }
        public Builder logging(LoggingConfig config)           { this.logging = config; return this; }
        public Builder ssl(SslConfig config)                   { this.ssl = config; return this; }
        public Builder header(String name, String value)       { this.defaultHeaders.put(name, value); return this; }
        public Builder addRequestFilter(CBQRequestFilter f)    { this.filters.add(f); return this; }
        public Builder addErrorMapper(ErrorMapper m)           { this.errorMappers.add(m); return this; }

        /** Add a custom named profile */
        public Builder addProfile(String name, TimeoutConfig timeouts) {
            this.customProfiles.put(name, timeouts);
            return this;
        }

        public CBQRestClientPool build() {
            Map<String, CBQRestClient> pool = new ConcurrentHashMap<>();

            // Built-in profiles
            pool.put("fast", buildClient("fast", TimeoutConfig.fast()));
            pool.put("default", buildClient("default", TimeoutConfig.defaults()));
            pool.put("slow", buildClient("slow", TimeoutConfig.slow()));
            pool.put("batch", buildClient("batch", TimeoutConfig.batch()));

            // Custom profiles
            customProfiles.forEach((name, timeouts) ->
                    pool.put(name, buildClient(name, timeouts)));

            return new CBQRestClientPool(pool);
        }

        private CBQRestClient buildClient(String profileName, TimeoutConfig timeouts) {
            CBQRestClientBuilder b = CBQRestClientBuilder.builder(profileName)
                    .baseUrl(baseUrl)
                    .timeouts(timeouts);

            if (resilience != null) b.resilience(resilience);
            if (logging != null) b.logging(logging);
            if (ssl != null) b.ssl(ssl);
            defaultHeaders.forEach(b::header);
            filters.forEach(b::addRequestFilter);
            errorMappers.forEach(b::addErrorMapper);

            return b.build();
        }
    }
}
