package com.cbq.restclient.config;

import java.time.Duration;

/**
 * SSL/TLS configuration.
 */
public record SslConfig(
        boolean enabled,
        boolean trustAll,
        String certificatePath,
        String keyStorePath,
        String keyStorePassword,
        String keyStoreType,
        String trustStorePath,
        String trustStorePassword,
        Duration handshakeTimeout
) {
    public static final SslConfig DEFAULT = new SslConfig(
            false, false, null, null, null, "PKCS12",
            null, null, Duration.ofSeconds(10)
    );

    public static Builder custom() { return new Builder(); }

    public static final class Builder {
        private boolean enabled = true;
        private boolean trustAll = false;
        private String certificatePath;
        private String keyStorePath;
        private String keyStorePassword;
        private String keyStoreType = "PKCS12";
        private String trustStorePath;
        private String trustStorePassword;
        private Duration handshakeTimeout = Duration.ofSeconds(10);

        public Builder trustAll() { this.trustAll = true; return this; }
        public Builder certificatePath(String p) { this.certificatePath = p; return this; }
        public Builder keyStore(String path, String password) {
            this.keyStorePath = path; this.keyStorePassword = password; return this;
        }
        public Builder keyStoreType(String t) { this.keyStoreType = t; return this; }
        public Builder trustStore(String path, String password) {
            this.trustStorePath = path; this.trustStorePassword = password; return this;
        }
        public Builder handshakeTimeout(Duration d) { this.handshakeTimeout = d; return this; }

        public SslConfig build() {
            return new SslConfig(enabled, trustAll, certificatePath, keyStorePath,
                    keyStorePassword, keyStoreType, trustStorePath, trustStorePassword, handshakeTimeout);
        }
    }
}
