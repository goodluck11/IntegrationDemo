package com.cbq.restclient.config;

public record SslConfig(boolean enabled, boolean trustAll, String trustStorePath, String trustStorePassword, String keyStorePath, String keyStorePassword, String protocol) {
    public static SslConfig defaults() { return new SslConfig(true, false, null, null, null, null, "TLSv1.3"); }
    public static SslConfig trustAll() { return new SslConfig(true, true, null, null, null, null, "TLSv1.3"); }
    public static Builder custom() { return new Builder(); }
    public static class Builder {
        private boolean enabled = true, trustAll = false;
        private String trustStorePath, trustStorePassword, keyStorePath, keyStorePassword, protocol = "TLSv1.3";
        public Builder enabled(boolean b)           { this.enabled = b; return this; }
        public Builder trustAll()                   { this.trustAll = true; return this; }
        public Builder trustStorePath(String p)     { this.trustStorePath = p; return this; }
        public Builder trustStorePassword(String p) { this.trustStorePassword = p; return this; }
        public Builder keyStorePath(String p)       { this.keyStorePath = p; return this; }
        public Builder keyStorePassword(String p)   { this.keyStorePassword = p; return this; }
        public Builder protocol(String p)           { this.protocol = p; return this; }
        public SslConfig build() { return new SslConfig(enabled, trustAll, trustStorePath, trustStorePassword, keyStorePath, keyStorePassword, protocol); }
    }
}
