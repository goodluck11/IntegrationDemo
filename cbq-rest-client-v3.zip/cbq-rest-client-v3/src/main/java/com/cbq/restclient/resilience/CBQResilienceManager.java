package com.cbq.restclient.resilience;

import com.cbq.restclient.config.*;
import com.cbq.restclient.exception.CBQExceptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.concurrent.Callable;

public final class CBQResilienceManager {
    private static final Logger log = LoggerFactory.getLogger(CBQResilienceManager.class);
    private static final boolean R4J;
    static {
        boolean ok; try { Class.forName("io.github.resilience4j.retry.Retry"); ok = true; } catch (ClassNotFoundException e) { ok = false; }
        R4J = ok;
        if (!ok) log.info("Resilience4j not on classpath – resilience features disabled (pass-through)");
    }

    private final String name;
    private final Object retry, circuitBreaker, rateLimiter, bulkhead;

    public CBQResilienceManager(String name, ResilienceConfig config) {
        this.name = name;
        if (!R4J || config == null) { retry = circuitBreaker = rateLimiter = bulkhead = null; return; }
        retry = config.retry() != null ? R4JDelegate.createRetry(name, config.retry()) : null;
        circuitBreaker = config.circuitBreaker() != null ? R4JDelegate.createCB(name, config.circuitBreaker()) : null;
        rateLimiter = config.rateLimiter() != null ? R4JDelegate.createRL(name, config.rateLimiter()) : null;
        bulkhead = config.bulkhead() != null ? R4JDelegate.createBH(name, config.bulkhead()) : null;
    }

    public <T> T execute(Callable<T> callable, ResilienceOverride override) {
        if (!R4J) return callUnchecked(callable);
        return R4JDelegate.execute(callable, override, name, retry, circuitBreaker, rateLimiter, bulkhead);
    }

    public boolean isAnyEnabled() { return retry != null || circuitBreaker != null || rateLimiter != null || bulkhead != null; }
    public String getName() { return name; }

    private static <T> T callUnchecked(Callable<T> c) {
        try { return c.call(); } catch (RuntimeException e) { throw e; } catch (Exception e) { throw new RuntimeException(e); }
    }

    public record ResilienceOverride(Boolean retryEnabled, Boolean cbEnabled, Boolean rlEnabled, Boolean bhEnabled) {
        public static ResilienceOverride disableAll()   { return new ResilienceOverride(false, false, false, false); }
        public static ResilienceOverride disableRetry() { return new ResilienceOverride(false, null, null, null); }
    }

    // Isolated inner class — only loaded if Resilience4j is on classpath
    private static final class R4JDelegate {
        static Object createRetry(String name, RetryConfig c) {
            var b = io.github.resilience4j.retry.RetryConfig.custom()
                    .maxAttempts(c.maxAttempts()).waitDuration(c.waitDuration())
                    .retryExceptions(Exception.class)
                    .ignoreExceptions(CBQExceptions.CircuitBreakerOpenException.class, CBQExceptions.RateLimitExceededException.class, CBQExceptions.BulkheadFullException.class);
            switch (c.backoffStrategy()) {
                case EXPONENTIAL -> b.intervalFunction(io.github.resilience4j.core.IntervalFunction.ofExponentialBackoff(c.waitDuration(), c.backoffMultiplier()));
                case EXPONENTIAL_WITH_JITTER -> b.intervalFunction(io.github.resilience4j.core.IntervalFunction.ofExponentialRandomBackoff(c.waitDuration(), c.backoffMultiplier()));
                case FIXED -> {}
            }
            return io.github.resilience4j.retry.Retry.of(name + "-retry", b.build());
        }

        static Object createCB(String name, CircuitBreakerConfig c) {
            return io.github.resilience4j.circuitbreaker.CircuitBreaker.of(name + "-cb",
                    io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.custom()
                            .slidingWindowSize(c.slidingWindowSize()).minimumNumberOfCalls(c.minimumNumberOfCalls())
                            .failureRateThreshold(c.failureRateThreshold()).waitDurationInOpenState(c.waitDurationInOpenState())
                            .permittedNumberOfCallsInHalfOpenState(c.permittedInHalfOpen()).build());
        }

        static Object createRL(String name, RateLimiterConfig c) {
            return io.github.resilience4j.ratelimiter.RateLimiter.of(name + "-rl",
                    io.github.resilience4j.ratelimiter.RateLimiterConfig.custom()
                            .limitForPeriod(c.limitForPeriod()).limitRefreshPeriod(c.limitRefreshPeriod())
                            .timeoutDuration(c.timeoutDuration()).build());
        }

        static Object createBH(String name, BulkheadConfig c) {
            return io.github.resilience4j.bulkhead.Bulkhead.of(name + "-bh",
                    io.github.resilience4j.bulkhead.BulkheadConfig.custom()
                            .maxConcurrentCalls(c.maxConcurrentCalls()).maxWaitDuration(c.maxWaitDuration()).build());
        }

        static <T> T execute(Callable<T> callable, ResilienceOverride ov, String name, Object retry, Object cb, Object rl, Object bh) {
            Callable<T> d = callable;
            if (bh != null && ok(ov, ov != null ? ov.bhEnabled() : null))    d = io.github.resilience4j.bulkhead.Bulkhead.decorateCallable((io.github.resilience4j.bulkhead.Bulkhead) bh, d);
            if (rl != null && ok(ov, ov != null ? ov.rlEnabled() : null))    d = io.github.resilience4j.ratelimiter.RateLimiter.decorateCallable((io.github.resilience4j.ratelimiter.RateLimiter) rl, d);
            if (cb != null && ok(ov, ov != null ? ov.cbEnabled() : null))    d = io.github.resilience4j.circuitbreaker.CircuitBreaker.decorateCallable((io.github.resilience4j.circuitbreaker.CircuitBreaker) cb, d);
            if (retry != null && ok(ov, ov != null ? ov.retryEnabled() : null)) d = io.github.resilience4j.retry.Retry.decorateCallable((io.github.resilience4j.retry.Retry) retry, d);
            try { return d.call(); }
            catch (io.github.resilience4j.circuitbreaker.CallNotPermittedException e) { throw new CBQExceptions.CircuitBreakerOpenException(name, e); }
            catch (io.github.resilience4j.ratelimiter.RequestNotPermitted e) { throw new CBQExceptions.RateLimitExceededException(name, e); }
            catch (io.github.resilience4j.bulkhead.BulkheadFullException e) { throw new CBQExceptions.BulkheadFullException(name, e); }
            catch (RuntimeException e) { throw e; }
            catch (Exception e) { throw new RuntimeException(e); }
        }

        private static boolean ok(ResilienceOverride ov, Boolean flag) { return ov == null || flag == null || flag; }
    }
}
