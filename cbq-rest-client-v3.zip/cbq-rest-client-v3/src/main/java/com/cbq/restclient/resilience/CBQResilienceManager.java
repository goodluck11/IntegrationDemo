package com.cbq.restclient.resilience;

import com.cbq.restclient.config.ResilienceConfig;
import com.cbq.restclient.config.ResilienceConfig.*;
import com.cbq.restclient.exception.CBQExceptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Callable;

/**
 * Manages Resilience4j patterns (retry, circuit breaker, rate limiter, bulkhead).
 * Auto-detects Resilience4j on classpath — gracefully degrades if absent.
 *
 * <p>With virtual threads, all resilience patterns execute synchronously (blocking is cheap),
 * which is simpler than the reactive Mono/Flux transformers in v2.
 */
public final class CBQResilienceManager {

    private static final Logger log = LoggerFactory.getLogger(CBQResilienceManager.class);

    private static final boolean RESILIENCE4J_AVAILABLE;

    static {
        boolean available;
        try {
            Class.forName("io.github.resilience4j.retry.Retry");
            available = true;
        } catch (ClassNotFoundException e) {
            available = false;
        }
        RESILIENCE4J_AVAILABLE = available;
        if (!available) {
            log.info("Resilience4j not on classpath – resilience features disabled (pass-through)");
        }
    }

    private final String name;
    private final Object retry;          // io.github.resilience4j.retry.Retry
    private final Object circuitBreaker; // io.github.resilience4j.circuitbreaker.CircuitBreaker
    private final Object rateLimiter;    // io.github.resilience4j.ratelimiter.RateLimiter
    private final Object bulkhead;       // io.github.resilience4j.bulkhead.Bulkhead

    public CBQResilienceManager(String name, ResilienceConfig config) {
        this.name = name;

        if (!RESILIENCE4J_AVAILABLE || config == null) {
            this.retry = null;
            this.circuitBreaker = null;
            this.rateLimiter = null;
            this.bulkhead = null;
            return;
        }

        this.retry = config.retry() != null
                ? Resilience4jDelegate.createRetry(name, config.retry()) : null;
        this.circuitBreaker = config.circuitBreaker() != null
                ? Resilience4jDelegate.createCircuitBreaker(name, config.circuitBreaker()) : null;
        this.rateLimiter = config.rateLimiter() != null
                ? Resilience4jDelegate.createRateLimiter(name, config.rateLimiter()) : null;
        this.bulkhead = config.bulkhead() != null
                ? Resilience4jDelegate.createBulkhead(name, config.bulkhead()) : null;
    }

    /**
     * Execute a callable wrapped in all configured resilience patterns.
     * Order: Bulkhead → Rate Limiter → Circuit Breaker → Retry → actual call.
     */
    public <T> T execute(Callable<T> callable, ResilienceOverride override) {
        if (!RESILIENCE4J_AVAILABLE) {
            return callUnchecked(callable);
        }
        return Resilience4jDelegate.execute(
                callable, override, name, retry, circuitBreaker, rateLimiter, bulkhead);
    }

    public boolean isRetryEnabled()          { return retry != null; }
    public boolean isCircuitBreakerEnabled()  { return circuitBreaker != null; }
    public boolean isRateLimiterEnabled()     { return rateLimiter != null; }
    public boolean isBulkheadEnabled()        { return bulkhead != null; }
    public String getName()                   { return name; }

    private static <T> T callUnchecked(Callable<T> callable) {
        try {
            return callable.call();
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ── Per-request override ─────────────────────────────────────────────────

    public record ResilienceOverride(
            Boolean retryEnabled,
            Boolean circuitBreakerEnabled,
            Boolean rateLimiterEnabled,
            Boolean bulkheadEnabled
    ) {
        public static ResilienceOverride disableAll() {
            return new ResilienceOverride(false, false, false, false);
        }

        public static ResilienceOverride disableRetry() {
            return new ResilienceOverride(false, null, null, null);
        }

        public static ResilienceOverride disableCircuitBreaker() {
            return new ResilienceOverride(null, false, null, null);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // DELEGATE: Isolated in inner class to prevent ClassNotFoundException
    // when Resilience4j is not on the classpath.
    // ═════════════════════════════════════════════════════════════════════════

    private static final class Resilience4jDelegate {

        static Object createRetry(String name, RetryConfig config) {
            var r4jBuilder = io.github.resilience4j.retry.RetryConfig.custom()
                    .maxAttempts(config.maxAttempts())
                    .waitDuration(config.waitDuration())
                    .retryExceptions(Exception.class)
                    .ignoreExceptions(
                            CBQExceptions.CircuitBreakerOpenException.class,
                            CBQExceptions.RateLimitExceededException.class,
                            CBQExceptions.BulkheadFullException.class);

            switch (config.backoffStrategy()) {
                case EXPONENTIAL -> r4jBuilder.intervalFunction(
                        io.github.resilience4j.core.IntervalFunction.ofExponentialBackoff(
                                config.waitDuration(), config.backoffMultiplier()));
                case EXPONENTIAL_WITH_JITTER -> r4jBuilder.intervalFunction(
                        io.github.resilience4j.core.IntervalFunction.ofExponentialRandomBackoff(
                                config.waitDuration(), config.backoffMultiplier()));
                case FIXED -> {} // default fixed wait
            }

            return io.github.resilience4j.retry.Retry.of(name + "-retry", r4jBuilder.build());
        }

        static Object createCircuitBreaker(String name, CircuitBreakerConfig config) {
            var r4jConfig = io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.custom()
                    .slidingWindowSize(config.slidingWindowSize())
                    .minimumNumberOfCalls(config.minimumNumberOfCalls())
                    .failureRateThreshold(config.failureRateThreshold())
                    .waitDurationInOpenState(config.waitDurationInOpenState())
                    .permittedNumberOfCallsInHalfOpenState(config.permittedNumberOfCallsInHalfOpenState())
                    .build();
            return io.github.resilience4j.circuitbreaker.CircuitBreaker.of(name + "-cb", r4jConfig);
        }

        static Object createRateLimiter(String name, RateLimiterConfig config) {
            var r4jConfig = io.github.resilience4j.ratelimiter.RateLimiterConfig.custom()
                    .limitForPeriod(config.limitForPeriod())
                    .limitRefreshPeriod(config.limitRefreshPeriod())
                    .timeoutDuration(config.timeoutDuration())
                    .build();
            return io.github.resilience4j.ratelimiter.RateLimiter.of(name + "-rl", r4jConfig);
        }

        static Object createBulkhead(String name, BulkheadConfig config) {
            var r4jConfig = io.github.resilience4j.bulkhead.BulkheadConfig.custom()
                    .maxConcurrentCalls(config.maxConcurrentCalls())
                    .maxWaitDuration(config.maxWaitDuration())
                    .build();
            return io.github.resilience4j.bulkhead.Bulkhead.of(name + "-bh", r4jConfig);
        }

        static <T> T execute(Callable<T> callable, ResilienceOverride override, String name,
                             Object retryObj, Object cbObj, Object rlObj, Object bhObj) {

            Callable<T> decorated = callable;

            // Wrap outermost → innermost: Bulkhead → Rate Limiter → CB → Retry
            if (bhObj != null && shouldApply(override, override != null ? override.bulkheadEnabled() : null)) {
                var bh = (io.github.resilience4j.bulkhead.Bulkhead) bhObj;
                final Callable<T> prev = decorated;
                decorated = io.github.resilience4j.bulkhead.Bulkhead.decorateCallable(bh, prev);
            }

            if (rlObj != null && shouldApply(override, override != null ? override.rateLimiterEnabled() : null)) {
                var rl = (io.github.resilience4j.ratelimiter.RateLimiter) rlObj;
                final Callable<T> prev = decorated;
                decorated = io.github.resilience4j.ratelimiter.RateLimiter.decorateCallable(rl, prev);
            }

            if (cbObj != null && shouldApply(override, override != null ? override.circuitBreakerEnabled() : null)) {
                var cb = (io.github.resilience4j.circuitbreaker.CircuitBreaker) cbObj;
                final Callable<T> prev = decorated;
                decorated = io.github.resilience4j.circuitbreaker.CircuitBreaker.decorateCallable(cb, prev);
            }

            if (retryObj != null && shouldApply(override, override != null ? override.retryEnabled() : null)) {
                var retry = (io.github.resilience4j.retry.Retry) retryObj;
                final Callable<T> prev = decorated;
                decorated = io.github.resilience4j.retry.Retry.decorateCallable(retry, prev);
            }

            try {
                return decorated.call();
            } catch (io.github.resilience4j.circuitbreaker.CallNotPermittedException e) {
                throw new CBQExceptions.CircuitBreakerOpenException(name, e);
            } catch (io.github.resilience4j.ratelimiter.RequestNotPermitted e) {
                throw new CBQExceptions.RateLimitExceededException(name, e);
            } catch (io.github.resilience4j.bulkhead.BulkheadFullException e) {
                throw new CBQExceptions.BulkheadFullException(name, e);
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception e) {
                throw new RuntimeException("Unexpected checked exception", e);
            }
        }

        private static boolean shouldApply(ResilienceOverride override, Boolean flag) {
            if (override == null || flag == null) return true;
            return flag;
        }
    }
}
