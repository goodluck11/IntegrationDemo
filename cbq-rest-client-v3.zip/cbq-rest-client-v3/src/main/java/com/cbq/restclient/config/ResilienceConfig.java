package com.cbq.restclient.config;

public record ResilienceConfig(RetryConfig retry, CircuitBreakerConfig circuitBreaker, RateLimiterConfig rateLimiter, BulkheadConfig bulkhead) {
    public static ResilienceConfig none()     { return new ResilienceConfig(null, null, null, null); }
    public static ResilienceConfig defaults() { return new ResilienceConfig(RetryConfig.DEFAULT, CircuitBreakerConfig.DEFAULT, null, null); }
    public static Builder custom() { return new Builder(); }
    public static class Builder {
        private RetryConfig retry; private CircuitBreakerConfig circuitBreaker;
        private RateLimiterConfig rateLimiter; private BulkheadConfig bulkhead;
        public Builder retry(RetryConfig r)                   { this.retry = r; return this; }
        public Builder circuitBreaker(CircuitBreakerConfig c) { this.circuitBreaker = c; return this; }
        public Builder rateLimiter(RateLimiterConfig r)       { this.rateLimiter = r; return this; }
        public Builder bulkhead(BulkheadConfig b)             { this.bulkhead = b; return this; }
        public ResilienceConfig build() { return new ResilienceConfig(retry, circuitBreaker, rateLimiter, bulkhead); }
    }
}
