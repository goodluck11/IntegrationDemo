package com.cbq.restclient.config;

/**
 * Composite resilience configuration.
 */
public record ResilienceConfig(
        RetryConfig retry,
        CircuitBreakerConfig circuitBreaker,
        RateLimiterConfig rateLimiter,
        BulkheadConfig bulkhead
) {
    public static final ResilienceConfig DEFAULT = new ResilienceConfig(
            RetryConfig.DEFAULT, CircuitBreakerConfig.DEFAULT,
            RateLimiterConfig.DEFAULT, BulkheadConfig.DEFAULT
    );

    public static Builder custom() { return new Builder(); }

    public static final class Builder {
        private RetryConfig retry = RetryConfig.DEFAULT;
        private CircuitBreakerConfig circuitBreaker = CircuitBreakerConfig.DEFAULT;
        private RateLimiterConfig rateLimiter = RateLimiterConfig.DEFAULT;
        private BulkheadConfig bulkhead = BulkheadConfig.DEFAULT;

        public Builder retry(RetryConfig r) { this.retry = r; return this; }
        public Builder circuitBreaker(CircuitBreakerConfig c) { this.circuitBreaker = c; return this; }
        public Builder rateLimiter(RateLimiterConfig r) { this.rateLimiter = r; return this; }
        public Builder bulkhead(BulkheadConfig b) { this.bulkhead = b; return this; }

        public ResilienceConfig build() {
            return new ResilienceConfig(retry, circuitBreaker, rateLimiter, bulkhead);
        }
    }
}
