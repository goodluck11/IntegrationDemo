package com.cbq.restclient.builder;

import com.cbq.restclient.config.*;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.filter.CBQRequestFilter;
import com.cbq.restclient.logging.CBQLoggingService;
import com.cbq.restclient.model.ErrorMapper;
import com.cbq.restclient.resilience.CBQResilienceManager;
import com.cbq.restclient.ssl.SslContextFactory;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.http.MediaType;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import javax.net.ssl.SSLContext;
import java.net.http.HttpClient;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.Executors;

public final class CBQRestClientBuilder {
    private String name = "cbq-client";
    private String baseUrl;
    private TimeoutConfig timeouts = TimeoutConfig.defaults();
    private ResilienceConfig resilience;
    private LoggingConfig logging;
    private SslConfig ssl;
    private final Map<String, String> defaultHeaders = new LinkedHashMap<>();
    private final List<CBQRequestFilter> requestFilters = new ArrayList<>();
    private final List<ErrorMapper> errorMappers = new ArrayList<>();
    private ObjectMapper objectMapper;
    private RestClient.Builder restClientBuilder;

    private CBQRestClientBuilder() {}
    public static CBQRestClientBuilder builder() { return new CBQRestClientBuilder(); }
    public static CBQRestClientBuilder builder(String name) { var b = new CBQRestClientBuilder(); b.name = name; return b; }

    public CBQRestClientBuilder baseUrl(String v)              { this.baseUrl = v; return this; }
    public CBQRestClientBuilder timeouts(TimeoutConfig v)      { this.timeouts = v; return this; }
    public CBQRestClientBuilder resilience(ResilienceConfig v)  { this.resilience = v; return this; }
    public CBQRestClientBuilder logging(LoggingConfig v)        { this.logging = v; return this; }
    public CBQRestClientBuilder ssl(SslConfig v)                { this.ssl = v; return this; }
    public CBQRestClientBuilder header(String n, String v)     { this.defaultHeaders.put(n, v); return this; }
    public CBQRestClientBuilder headers(Map<String, String> m) { this.defaultHeaders.putAll(m); return this; }
    public CBQRestClientBuilder addRequestFilter(CBQRequestFilter f) { this.requestFilters.add(f); return this; }
    public CBQRestClientBuilder addErrorMapper(ErrorMapper m)  { this.errorMappers.add(m); return this; }
    public CBQRestClientBuilder objectMapper(ObjectMapper v)    { this.objectMapper = v; return this; }
    public CBQRestClientBuilder restClientBuilder(RestClient.Builder v) { this.restClientBuilder = v; return this; }

    public CBQRestClient build() {
        Objects.requireNonNull(baseUrl, "baseUrl is required");
        ObjectMapper mapper = objectMapper != null ? objectMapper : defaultMapper();

        // JDK HttpClient with virtual threads + SSL
        HttpClient.Builder httpBuilder = HttpClient.newBuilder()
                .connectTimeout(timeouts.connection())
                .executor(Executors.newVirtualThreadPerTaskExecutor());
        if (ssl != null && ssl.enabled()) {
            SSLContext sslCtx = SslContextFactory.create(ssl);
            httpBuilder.sslContext(sslCtx);
        }
        JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory(httpBuilder.build());
        factory.setReadTimeout(timeouts.read());

        RestClient.Builder rcb = restClientBuilder != null ? restClientBuilder : RestClient.builder();
        rcb.baseUrl(baseUrl).requestFactory(factory)
                .defaultHeaders(h -> { h.setContentType(MediaType.APPLICATION_JSON); h.setAccept(List.of(MediaType.APPLICATION_JSON)); defaultHeaders.forEach(h::set); });

        return new CBQRestClient(name, rcb.build(), new CBQResilienceManager(name, resilience),
                logging != null ? new CBQLoggingService(logging) : null, requestFilters, errorMappers, mapper);
    }

    private ObjectMapper defaultMapper() {
        return new ObjectMapper().registerModule(new JavaTimeModule())
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
    }
}
