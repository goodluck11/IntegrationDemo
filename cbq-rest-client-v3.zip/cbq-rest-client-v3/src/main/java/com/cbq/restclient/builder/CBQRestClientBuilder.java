package com.cbq.restclient.builder;

import com.cbq.restclient.config.*;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.filter.CBQRequestFilter;
import com.cbq.restclient.logging.CBQLoggingService;
import com.cbq.restclient.model.ErrorMapper;
import com.cbq.restclient.resilience.CBQResilienceManager;
import com.cbq.restclient.ssl.SslContextFactory;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import javax.net.ssl.SSLContext;
import java.net.http.HttpClient;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Fluent builder for CBQRestClient.
 *
 * <p>Minimal usage:
 * <pre>{@code
 * CBQRestClient client = CBQRestClientBuilder.builder()
 *     .baseUrl("https://api.example.com")
 *     .build();
 * }</pre>
 *
 * <p>Production usage:
 * <pre>{@code
 * CBQRestClient client = CBQRestClientBuilder.builder("payment-service")
 *     .baseUrl("https://api.payment.com")
 *     .timeouts(TimeoutConfig.custom().connection(Duration.ofSeconds(5)).read(Duration.ofSeconds(30)).build())
 *     .resilience(ResilienceConfig.custom()
 *         .retry(RetryConfig.custom().maxAttempts(3).build())
 *         .circuitBreaker(CircuitBreakerConfig.defaults())
 *         .build())
 *     .logging(LoggingConfig.custom().logAll().jsonFormat().maskFields("cardNumber", "cvv").build())
 *     .ssl(SslConfig.custom().trustStorePath("/certs/truststore.jks").build())
 *     .addRequestFilter(Filters.bearerToken(() -> tokenService.getToken()))
 *     .addErrorMapper(ErrorMapper.onStatus(s -> s.value() == 404, ctx -> new NotFoundException(ctx.uri())))
 *     .build();
 * }</pre>
 */
public final class CBQRestClientBuilder {

    private String name = "cbq-client";
    private String baseUrl;
    private TimeoutConfig timeouts = TimeoutConfig.defaults();
    private ResilienceConfig resilience;
    private LoggingConfig logging;
    private SslConfig ssl;
    private EmailConfig email;
    private final Map<String, String> defaultHeaders = new LinkedHashMap<>();
    private final List<CBQRequestFilter> requestFilters = new ArrayList<>();
    private final List<ErrorMapper> errorMappers = new ArrayList<>();
    private ObjectMapper objectMapper;
    private RestClient.Builder restClientBuilder;

    private CBQRestClientBuilder() {}

    public static CBQRestClientBuilder builder() {
        return new CBQRestClientBuilder();
    }

    public static CBQRestClientBuilder builder(String name) {
        var b = new CBQRestClientBuilder();
        b.name = name;
        return b;
    }

    // ── Configuration ────────────────────────────────────────────────────────

    public CBQRestClientBuilder baseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
        return this;
    }

    public CBQRestClientBuilder timeouts(TimeoutConfig timeouts) {
        this.timeouts = timeouts;
        return this;
    }

    public CBQRestClientBuilder resilience(ResilienceConfig config) {
        this.resilience = config;
        return this;
    }

    public CBQRestClientBuilder logging(LoggingConfig config) {
        this.logging = config;
        return this;
    }

    public CBQRestClientBuilder ssl(SslConfig config) {
        this.ssl = config;
        return this;
    }

    public CBQRestClientBuilder email(EmailConfig config) {
        this.email = config;
        return this;
    }

    // ── Headers ──────────────────────────────────────────────────────────────

    public CBQRestClientBuilder header(String name, String value) {
        this.defaultHeaders.put(name, value);
        return this;
    }

    public CBQRestClientBuilder headers(Map<String, String> headers) {
        this.defaultHeaders.putAll(headers);
        return this;
    }

    // ── Filters ──────────────────────────────────────────────────────────────

    public CBQRestClientBuilder addRequestFilter(CBQRequestFilter filter) {
        this.requestFilters.add(filter);
        return this;
    }

    // ── Error Mappers ────────────────────────────────────────────────────────

    public CBQRestClientBuilder addErrorMapper(ErrorMapper mapper) {
        this.errorMappers.add(mapper);
        return this;
    }

    // ── Advanced ─────────────────────────────────────────────────────────────

    /** Provide a custom ObjectMapper (otherwise a sensible default is used) */
    public CBQRestClientBuilder objectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
        return this;
    }

    /** Provide a pre-configured RestClient.Builder for full control */
    public CBQRestClientBuilder restClientBuilder(RestClient.Builder builder) {
        this.restClientBuilder = builder;
        return this;
    }

    // ── Build ────────────────────────────────────────────────────────────────

    public CBQRestClient build() {
        Objects.requireNonNull(baseUrl, "baseUrl is required");

        // 1. ObjectMapper
        ObjectMapper mapper = this.objectMapper != null ? this.objectMapper : createDefaultObjectMapper();

        // 2. HTTP Client (JDK HttpClient with virtual threads)
        HttpClient.Builder httpBuilder = HttpClient.newBuilder()
                .connectTimeout(timeouts.connection())
                .executor(Executors.newVirtualThreadPerTaskExecutor());

        // 3. SSL
        if (ssl != null && ssl.enabled()) {
            SSLContext sslContext = SslContextFactory.create(ssl);
            httpBuilder.sslContext(sslContext);
        }

        HttpClient httpClient = httpBuilder.build();

        // 4. Request Factory with timeouts
        JdkClientHttpRequestFactory requestFactory = new JdkClientHttpRequestFactory(httpClient);
        requestFactory.setReadTimeout(timeouts.read());

        // 5. Build RestClient
        RestClient.Builder rcBuilder = this.restClientBuilder != null
                ? this.restClientBuilder
                : RestClient.builder();

        rcBuilder.baseUrl(baseUrl)
                .requestFactory(requestFactory)
                .defaultHeaders(headers -> {
                    headers.setContentType(MediaType.APPLICATION_JSON);
                    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
                    defaultHeaders.forEach(headers::set);
                });

        RestClient restClient = rcBuilder.build();

        // 6. Resilience
        CBQResilienceManager resilienceManager = new CBQResilienceManager(name, resilience);

        // 7. Logging
        CBQLoggingService loggingService = logging != null ? new CBQLoggingService(logging) : null;

        // 8. Build CBQRestClient
        return new CBQRestClient(
                name,
                restClient,
                resilienceManager,
                loggingService,
                requestFilters,
                errorMappers,
                mapper
        );
    }

    private ObjectMapper createDefaultObjectMapper() {
        return new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
    }
}
