package com.cbq.restclient.autoconfigure;

import com.cbq.restclient.builder.CBQRestClientBuilder;
import com.cbq.restclient.config.*;
import com.cbq.restclient.core.CBQRestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Auto-configures a CBQRestClient bean from application.yml/properties.
 * Only activates when cbq.rest-client.base-url is set.
 *
 * <p>Users can still create CBQRestClient manually via the builder for full control.
 */
@AutoConfiguration
@EnableConfigurationProperties(CBQRestClientProperties.class)
@ConditionalOnProperty(prefix = "cbq.rest-client", name = "base-url")
public class CBQRestClientAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(CBQRestClientAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public CBQRestClient cbqRestClient(CBQRestClientProperties props) {
        log.info("Auto-configuring CBQRestClient '{}' → {}", props.getName(), props.getBaseUrl());

        CBQRestClientBuilder builder = CBQRestClientBuilder.builder(props.getName())
                .baseUrl(props.getBaseUrl())
                .timeouts(new TimeoutConfig(
                        props.getTimeouts().getConnection(),
                        props.getTimeouts().getRead(),
                        props.getTimeouts().getWrite(),
                        props.getTimeouts().getResponse()));

        // Resilience
        if (props.getResilience().isEnabled()) {
            var rb = ResilienceConfig.custom();

            if (props.getResilience().getRetry().isEnabled()) {
                rb.retry(ResilienceConfig.RetryConfig.custom()
                        .maxAttempts(props.getResilience().getRetry().getMaxAttempts())
                        .waitDuration(props.getResilience().getRetry().getWaitDuration())
                        .backoffStrategy(ResilienceConfig.RetryConfig.BackoffStrategy.valueOf(
                                props.getResilience().getRetry().getBackoffStrategy()))
                        .build());
            }

            if (props.getResilience().getCircuitBreaker().isEnabled()) {
                rb.circuitBreaker(ResilienceConfig.CircuitBreakerConfig.custom()
                        .slidingWindowSize(props.getResilience().getCircuitBreaker().getSlidingWindowSize())
                        .minimumNumberOfCalls(props.getResilience().getCircuitBreaker().getMinimumNumberOfCalls())
                        .failureRateThreshold(props.getResilience().getCircuitBreaker().getFailureRateThreshold())
                        .waitDurationInOpenState(props.getResilience().getCircuitBreaker().getWaitDurationInOpenState())
                        .build());
            }

            if (props.getResilience().getRateLimiter().isEnabled()) {
                rb.rateLimiter(ResilienceConfig.RateLimiterConfig.custom()
                        .limitForPeriod(props.getResilience().getRateLimiter().getLimitForPeriod())
                        .limitRefreshPeriod(props.getResilience().getRateLimiter().getLimitRefreshPeriod())
                        .timeoutDuration(props.getResilience().getRateLimiter().getTimeoutDuration())
                        .build());
            }

            builder.resilience(rb.build());
        }

        // Logging
        if (props.getLogging().isEnabled()) {
            var lb = LoggingConfig.custom()
                    .serviceName(props.getLogging().getServiceName());

            if ("JSON".equalsIgnoreCase(props.getLogging().getFormat())) {
                lb.jsonFormat();
            } else {
                lb.textFormat();
            }

            if (props.getLogging().isLogAll()) {
                lb.logAll();
            }

            if (props.getLogging().getMaskFields() != null && !props.getLogging().getMaskFields().isEmpty()) {
                lb.maskFields(props.getLogging().getMaskFields().toArray(String[]::new));
            }

            builder.logging(lb.build());
        }

        // SSL
        if (props.getSsl().isEnabled()) {
            var sb = SslConfig.custom().enabled(true);
            if (props.getSsl().isTrustAll()) sb.trustAll();
            if (props.getSsl().getTrustStorePath() != null) sb.trustStorePath(props.getSsl().getTrustStorePath());
            if (props.getSsl().getTrustStorePassword() != null) sb.trustStorePassword(props.getSsl().getTrustStorePassword());
            if (props.getSsl().getKeyStorePath() != null) sb.keyStorePath(props.getSsl().getKeyStorePath());
            if (props.getSsl().getKeyStorePassword() != null) sb.keyStorePassword(props.getSsl().getKeyStorePassword());
            builder.ssl(sb.build());
        }

        return builder.build();
    }
}
