package com.cbq.restclient.autoconfigure;

import com.cbq.restclient.builder.CBQRestClientBuilder;
import com.cbq.restclient.config.*;
import com.cbq.restclient.core.CBQRestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(CBQRestClientProperties.class)
@ConditionalOnProperty(prefix = "cbq.rest-client", name = "base-url")
public class CBQRestClientAutoConfiguration {
    private static final Logger log = LoggerFactory.getLogger(CBQRestClientAutoConfiguration.class);

    @Bean @ConditionalOnMissingBean
    public CBQRestClient cbqRestClient(CBQRestClientProperties p) {
        log.info("Auto-configuring CBQRestClient '{}' → {}", p.getName(), p.getBaseUrl());
        var b = CBQRestClientBuilder.builder(p.getName()).baseUrl(p.getBaseUrl())
                .timeouts(new TimeoutConfig(p.getTimeouts().getConnection(), p.getTimeouts().getRead(), p.getTimeouts().getWrite(), p.getTimeouts().getResponse()));
        if (p.getResilience().isEnabled()) {
            var rb = ResilienceConfig.custom();
            if (p.getResilience().getRetry().isEnabled())
                rb.retry(RetryConfig.custom().maxAttempts(p.getResilience().getRetry().getMaxAttempts())
                        .waitDuration(p.getResilience().getRetry().getWaitDuration())
                        .backoffStrategy(RetryConfig.BackoffStrategy.valueOf(p.getResilience().getRetry().getBackoffStrategy())).build());
            if (p.getResilience().getCircuitBreaker().isEnabled())
                rb.circuitBreaker(CircuitBreakerConfig.custom().slidingWindowSize(p.getResilience().getCircuitBreaker().getSlidingWindowSize())
                        .minimumNumberOfCalls(p.getResilience().getCircuitBreaker().getMinimumNumberOfCalls())
                        .failureRateThreshold(p.getResilience().getCircuitBreaker().getFailureRateThreshold())
                        .waitDurationInOpenState(p.getResilience().getCircuitBreaker().getWaitDurationInOpenState()).build());
            if (p.getResilience().getRateLimiter().isEnabled())
                rb.rateLimiter(RateLimiterConfig.custom().limitForPeriod(p.getResilience().getRateLimiter().getLimitForPeriod())
                        .limitRefreshPeriod(p.getResilience().getRateLimiter().getLimitRefreshPeriod())
                        .timeoutDuration(p.getResilience().getRateLimiter().getTimeoutDuration()).build());
            b.resilience(rb.build());
        }
        if (p.getLogging().isEnabled()) {
            var lb = LoggingConfig.custom().serviceName(p.getLogging().getServiceName());
            if ("JSON".equalsIgnoreCase(p.getLogging().getFormat())) lb.jsonFormat(); else lb.textFormat();
            if (p.getLogging().isLogAll()) lb.logAll();
            if (p.getLogging().getMaskFields() != null && !p.getLogging().getMaskFields().isEmpty())
                lb.maskFields(p.getLogging().getMaskFields().toArray(String[]::new));
            b.logging(lb.build());
        }
        if (p.getSsl().isEnabled()) {
            var sb = SslConfig.custom().enabled(true);
            if (p.getSsl().isTrustAll()) sb.trustAll();
            if (p.getSsl().getTrustStorePath() != null) sb.trustStorePath(p.getSsl().getTrustStorePath());
            if (p.getSsl().getTrustStorePassword() != null) sb.trustStorePassword(p.getSsl().getTrustStorePassword());
            if (p.getSsl().getKeyStorePath() != null) sb.keyStorePath(p.getSsl().getKeyStorePath());
            if (p.getSsl().getKeyStorePassword() != null) sb.keyStorePassword(p.getSsl().getKeyStorePassword());
            b.ssl(sb.build());
        }
        return b.build();
    }
}
