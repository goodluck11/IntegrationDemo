package com.cbq.restclient.config;

import java.util.*;

public record LoggingConfig(LogFormat format, boolean logRequest, boolean logResponse, boolean logHeaders, boolean logBody, String serviceName, Set<String> maskFields, char maskChar, int maxBodyLogSize) {
    public enum LogFormat { TEXT, JSON }
    public static LoggingConfig none() { return new LoggingConfig(LogFormat.TEXT, false, false, false, false, "cbq-client", Set.of(), '*', 4096); }
    public static Builder custom() { return new Builder(); }
    public static class Builder {
        private LogFormat format = LogFormat.JSON; private boolean logRequest, logResponse, logHeaders, logBody;
        private String serviceName = "cbq-client"; private final Set<String> maskFields = new LinkedHashSet<>();
        private char maskChar = '*'; private int maxBodyLogSize = 4096;
        public Builder textFormat()             { this.format = LogFormat.TEXT; return this; }
        public Builder jsonFormat()             { this.format = LogFormat.JSON; return this; }
        public Builder logAll()                 { logRequest = logResponse = logHeaders = logBody = true; return this; }
        public Builder logRequest()             { this.logRequest = true; return this; }
        public Builder logResponse()            { this.logResponse = true; return this; }
        public Builder logHeaders()             { this.logHeaders = true; return this; }
        public Builder logBody()                { this.logBody = true; return this; }
        public Builder serviceName(String n)    { this.serviceName = n; return this; }
        public Builder maskFields(String... f)  { this.maskFields.addAll(List.of(f)); return this; }
        public Builder maskChar(char c)         { this.maskChar = c; return this; }
        public Builder maxBodyLogSize(int s)    { this.maxBodyLogSize = s; return this; }
        public LoggingConfig build() { return new LoggingConfig(format, logRequest, logResponse, logHeaders, logBody, serviceName, Set.copyOf(maskFields), maskChar, maxBodyLogSize); }
    }
}
