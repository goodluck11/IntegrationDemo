package com.cbq.restclient.config;

import java.util.*;

/**
 * Logging configuration for request/response logging with field masking.
 */
public record LoggingConfig(
        boolean enabled,
        boolean logRequest,
        boolean logResponse,
        boolean logHeaders,
        boolean logBody,
        LogFormat format,
        String serviceName,
        Set<String> maskFields,
        Map<String, Integer> partialMaskFields,
        char maskSymbol,
        int maxBodySize
) {
    public enum LogFormat { JSON, PRETTY, SIMPLE }

    public static final LoggingConfig DEFAULT = new LoggingConfig(
            true, true, true, false, false, LogFormat.JSON,
            "cbq-client", Set.of(), Map.of(), '*', 10_000
    );

    public static final LoggingConfig NONE = new LoggingConfig(
            false, false, false, false, false, LogFormat.JSON,
            "cbq-client", Set.of(), Map.of(), '*', 0
    );

    public static Builder custom() { return new Builder(); }

    public static final class Builder {
        private boolean enabled = true;
        private boolean logRequest = true;
        private boolean logResponse = true;
        private boolean logHeaders = false;
        private boolean logBody = false;
        private LogFormat format = LogFormat.JSON;
        private String serviceName = "cbq-client";
        private final Set<String> maskFields = new HashSet<>();
        private final Map<String, Integer> partialMaskFields = new HashMap<>();
        private char maskSymbol = '*';
        private int maxBodySize = 10_000;

        public Builder logAll() {
            this.logRequest = true; this.logResponse = true;
            this.logHeaders = true; this.logBody = true;
            return this;
        }
        public Builder logRequestOnly() { this.logRequest = true; this.logResponse = false; return this; }
        public Builder logResponseOnly() { this.logRequest = false; this.logResponse = true; return this; }
        public Builder logHeaders(boolean b) { this.logHeaders = b; return this; }
        public Builder logBody(boolean b) { this.logBody = b; return this; }
        public Builder jsonFormat() { this.format = LogFormat.JSON; return this; }
        public Builder prettyFormat() { this.format = LogFormat.PRETTY; return this; }
        public Builder simpleFormat() { this.format = LogFormat.SIMPLE; return this; }
        public Builder serviceName(String n) { this.serviceName = n; return this; }
        public Builder maskFields(String... fields) {
            maskFields.addAll(Arrays.asList(fields));
            return this;
        }
        public Builder maskField(String field, int visibleChars) {
            partialMaskFields.put(field, visibleChars);
            return this;
        }
        public Builder maskSymbol(char s) { this.maskSymbol = s; return this; }
        public Builder maxBodySize(int s) { this.maxBodySize = s; return this; }
        public Builder disabled() { this.enabled = false; return this; }

        public LoggingConfig build() {
            return new LoggingConfig(enabled, logRequest, logResponse, logHeaders, logBody,
                    format, serviceName, Set.copyOf(maskFields), Map.copyOf(partialMaskFields),
                    maskSymbol, maxBodySize);
        }
    }
}
