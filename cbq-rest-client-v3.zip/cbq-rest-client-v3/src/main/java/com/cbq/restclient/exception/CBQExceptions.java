package com.cbq.restclient.exception;

/**
 * All specific exception types for CBQ Rest Client.
 * Each extends CBQRestClientException and carries full request context.
 */
public final class CBQExceptions {

    private CBQExceptions() {}

    /** Circuit breaker is OPEN — call was rejected without attempting */
    public static class CircuitBreakerOpenException extends CBQRestClientException {
        private final String circuitBreakerName;

        public CircuitBreakerOpenException(String name, Throwable cause) {
            super(CBQRestClientException.builder()
                    .message("Circuit breaker '%s' is OPEN".formatted(name))
                    .cause(cause));
            this.circuitBreakerName = name;
        }

        public String getCircuitBreakerName() { return circuitBreakerName; }
    }

    /** Rate limiter rejected the call */
    public static class RateLimitExceededException extends CBQRestClientException {
        private final String rateLimiterName;

        public RateLimitExceededException(String name, Throwable cause) {
            super(CBQRestClientException.builder()
                    .message("Rate limit exceeded for '%s'".formatted(name))
                    .cause(cause));
            this.rateLimiterName = name;
        }

        public String getRateLimiterName() { return rateLimiterName; }
    }

    /** Bulkhead is full — call was rejected */
    public static class BulkheadFullException extends CBQRestClientException {
        public BulkheadFullException(String name, Throwable cause) {
            super(CBQRestClientException.builder()
                    .message("Bulkhead '%s' is full".formatted(name))
                    .cause(cause));
        }
    }

    /** All retry attempts exhausted */
    public static class RetryExhaustedException extends CBQRestClientException {
        private final int attempts;

        public RetryExhaustedException(String name, int attempts, Throwable cause) {
            super(CBQRestClientException.builder()
                    .message("Retry exhausted for '%s' after %d attempts".formatted(name, attempts))
                    .cause(cause));
            this.attempts = attempts;
        }

        public int getAttempts() { return attempts; }
    }

    /** Connection or read/write timeout */
    public static class TimeoutException extends CBQRestClientException {
        public TimeoutException(String message, Throwable cause) {
            super(CBQRestClientException.builder()
                    .message(message)
                    .cause(cause));
        }
    }

    /** SSL/TLS handshake failure */
    public static class SslException extends CBQRestClientException {
        public SslException(String message, Throwable cause) {
            super(CBQRestClientException.builder()
                    .message(message)
                    .cause(cause));
        }
    }

    /** HTTP 4xx response */
    public static class ClientErrorException extends CBQRestClientException {
        public ClientErrorException(Builder builder) {
            super(builder);
        }
    }

    /** HTTP 5xx response */
    public static class ServerErrorException extends CBQRestClientException {
        public ServerErrorException(Builder builder) {
            super(builder);
        }
    }
}
