package com.cbq.restclient.exception;

public final class CBQExceptions {
    private CBQExceptions() {}

    public static class CircuitBreakerOpenException extends CBQRestClientException {
        private final String cbName;
        public CircuitBreakerOpenException(String name, Throwable cause) {
            super(builder().message("Circuit breaker '%s' is OPEN".formatted(name)).cause(cause)); this.cbName = name;
        }
        public String getCbName() { return cbName; }
    }

    public static class RateLimitExceededException extends CBQRestClientException {
        public RateLimitExceededException(String name, Throwable cause) {
            super(builder().message("Rate limit exceeded for '%s'".formatted(name)).cause(cause));
        }
    }

    public static class BulkheadFullException extends CBQRestClientException {
        public BulkheadFullException(String name, Throwable cause) {
            super(builder().message("Bulkhead '%s' is full".formatted(name)).cause(cause));
        }
    }

    public static class RetryExhaustedException extends CBQRestClientException {
        private final int attempts;
        public RetryExhaustedException(String name, int attempts, Throwable cause) {
            super(builder().message("Retry exhausted for '%s' after %d attempts".formatted(name, attempts)).cause(cause));
            this.attempts = attempts;
        }
        public int getAttempts() { return attempts; }
    }

    public static class TimeoutException extends CBQRestClientException {
        public TimeoutException(String message, Throwable cause) { super(builder().message(message).cause(cause)); }
    }

    public static class SslException extends CBQRestClientException {
        public SslException(String message, Throwable cause) { super(builder().message(message).cause(cause)); }
    }

    public static class ClientErrorException extends CBQRestClientException {
        public ClientErrorException(Builder b) { super(b); }
    }

    public static class ServerErrorException extends CBQRestClientException {
        public ServerErrorException(Builder b) { super(b); }
    }
}
