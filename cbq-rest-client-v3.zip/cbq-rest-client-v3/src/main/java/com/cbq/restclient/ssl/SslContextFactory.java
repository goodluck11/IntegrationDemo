package com.cbq.restclient.ssl;

import com.cbq.restclient.config.SslConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.net.ssl.*;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

public final class SslContextFactory {
    private static final Logger log = LoggerFactory.getLogger(SslContextFactory.class);
    private SslContextFactory() {}

    public static SSLContext create(SslConfig config) {
        try {
            if (!config.enabled()) return SSLContext.getDefault();
            if (config.trustAll()) {
                log.warn("SSL trust-all mode — DO NOT USE IN PRODUCTION");
                return trustAllContext(config.protocol());
            }
            TrustManager[] tm = config.trustStorePath() != null ? loadTrustManagers(config.trustStorePath(), config.trustStorePassword()) : null;
            KeyManager[] km = config.keyStorePath() != null ? loadKeyManagers(config.keyStorePath(), config.keyStorePassword()) : null;
            SSLContext ctx = SSLContext.getInstance(config.protocol());
            ctx.init(km, tm, new SecureRandom());
            return ctx;
        } catch (Exception e) { throw new RuntimeException("SSL context creation failed", e); }
    }

    private static SSLContext trustAllContext(String protocol) throws Exception {
        TrustManager[] tm = { new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            public void checkClientTrusted(X509Certificate[] c, String a) {}
            public void checkServerTrusted(X509Certificate[] c, String a) {}
        }};
        SSLContext ctx = SSLContext.getInstance(protocol);
        ctx.init(null, tm, new SecureRandom());
        return ctx;
    }

    private static TrustManager[] loadTrustManagers(String path, String password) throws Exception {
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        try (InputStream is = new FileInputStream(path)) { ks.load(is, password != null ? password.toCharArray() : null); }
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ks);
        return tmf.getTrustManagers();
    }

    private static KeyManager[] loadKeyManagers(String path, String password) throws Exception {
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        try (InputStream is = new FileInputStream(path)) { ks.load(is, password != null ? password.toCharArray() : null); }
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, password != null ? password.toCharArray() : null);
        return kmf.getKeyManagers();
    }
}
