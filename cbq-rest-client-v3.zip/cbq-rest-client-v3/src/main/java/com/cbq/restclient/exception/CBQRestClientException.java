package com.cbq.restclient.exception;

import org.springframework.http.HttpStatusCode;
import java.util.LinkedHashMap;
import java.util.Map;

public class CBQRestClientException extends RuntimeException {
    private final String requestId, correlationId, method, uri, responseBody;
    private final HttpStatusCode status;
    private final long durationMs;

    protected CBQRestClientException(Builder b) {
        super(b.message, b.cause);
        this.requestId = b.requestId; this.correlationId = b.correlationId;
        this.method = b.method; this.uri = b.uri; this.status = b.status;
        this.responseBody = b.responseBody; this.durationMs = b.durationMs;
    }

    public String getRequestId()     { return requestId; }
    public String getCorrelationId() { return correlationId; }
    public String getMethod()        { return method; }
    public String getUri()           { return uri; }
    public HttpStatusCode getStatus(){ return status; }
    public String getResponseBody()  { return responseBody; }
    public long getDurationMs()      { return durationMs; }
    public int getStatusCode()       { return status != null ? status.value() : 0; }

    public Map<String, Object> toContextMap() {
        var m = new LinkedHashMap<String, Object>();
        if (requestId != null) m.put("request_id", requestId);
        if (correlationId != null) m.put("correlation_id", correlationId);
        if (method != null) m.put("method", method);
        if (uri != null) m.put("uri", uri);
        if (status != null) m.put("status", status.value());
        if (responseBody != null) m.put("response_body", responseBody);
        m.put("duration_ms", durationMs);
        m.put("error", getClass().getSimpleName());
        m.put("error_message", getMessage());
        return m;
    }

    @Override public String toString() {
        return "%s{req='%s', method='%s', uri='%s', status=%s, msg='%s'}".formatted(
                getClass().getSimpleName(), requestId, method, uri, status != null ? status.value() : "null", getMessage());
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        String message, requestId, correlationId, method, uri, responseBody;
        Throwable cause; HttpStatusCode status; long durationMs;
        public Builder message(String v)        { this.message = v; return this; }
        public Builder cause(Throwable v)       { this.cause = v; return this; }
        public Builder requestId(String v)      { this.requestId = v; return this; }
        public Builder correlationId(String v)  { this.correlationId = v; return this; }
        public Builder method(String v)         { this.method = v; return this; }
        public Builder uri(String v)            { this.uri = v; return this; }
        public Builder status(HttpStatusCode v) { this.status = v; return this; }
        public Builder responseBody(String v)   { this.responseBody = v; return this; }
        public Builder durationMs(long v)       { this.durationMs = v; return this; }
        public CBQRestClientException build()   { return new CBQRestClientException(this); }
    }
}
