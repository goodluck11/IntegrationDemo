package com.cbq.restclient.exception;

import org.springframework.http.HttpStatusCode;

import java.io.Serial;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Base exception for all CBQ Rest Client errors.
 * Carries request context (requestId, correlationId, method, uri, status, responseBody, durationMs)
 * for structured error logging and downstream handling.
 */
public class CBQRestClientException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 3L;

    private final String requestId;
    private final String correlationId;
    private final String method;
    private final String uri;
    private final HttpStatusCode status;
    private final String responseBody;
    private final long durationMs;

    protected CBQRestClientException(Builder builder) {
        super(builder.message, builder.cause);
        this.requestId = builder.requestId;
        this.correlationId = builder.correlationId;
        this.method = builder.method;
        this.uri = builder.uri;
        this.status = builder.status;
        this.responseBody = builder.responseBody;
        this.durationMs = builder.durationMs;
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    public String getRequestId()     { return requestId; }
    public String getCorrelationId() { return correlationId; }
    public String getMethod()        { return method; }
    public String getUri()           { return uri; }
    public HttpStatusCode getStatus(){ return status; }
    public String getResponseBody()  { return responseBody; }
    public long getDurationMs()      { return durationMs; }

    public int getStatusCode() {
        return status != null ? status.value() : 0;
    }

    /** Structured context map for JSON logging */
    public Map<String, Object> toContextMap() {
        var map = new LinkedHashMap<String, Object>();
        if (requestId != null)     map.put("request_id", requestId);
        if (correlationId != null) map.put("correlation_id", correlationId);
        if (method != null)        map.put("method", method);
        if (uri != null)           map.put("uri", uri);
        if (status != null)        map.put("status", status.value());
        if (responseBody != null)  map.put("response_body", responseBody);
        map.put("duration_ms", durationMs);
        map.put("error", getClass().getSimpleName());
        map.put("error_message", getMessage());
        return map;
    }

    @Override
    public String toString() {
        return "%s{requestId='%s', method='%s', uri='%s', status=%s, message='%s'}"
                .formatted(getClass().getSimpleName(), requestId, method, uri,
                        status != null ? String.valueOf(status.value()) : "null", getMessage());
    }

    // ── Builder ──────────────────────────────────────────────────────────────

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        String message;
        Throwable cause;
        String requestId;
        String correlationId;
        String method;
        String uri;
        HttpStatusCode status;
        String responseBody;
        long durationMs;

        public Builder message(String message)              { this.message = message; return this; }
        public Builder cause(Throwable cause)               { this.cause = cause; return this; }
        public Builder requestId(String requestId)          { this.requestId = requestId; return this; }
        public Builder correlationId(String correlationId)  { this.correlationId = correlationId; return this; }
        public Builder method(String method)                { this.method = method; return this; }
        public Builder uri(String uri)                      { this.uri = uri; return this; }
        public Builder status(HttpStatusCode status)        { this.status = status; return this; }
        public Builder responseBody(String responseBody)    { this.responseBody = responseBody; return this; }
        public Builder durationMs(long durationMs)          { this.durationMs = durationMs; return this; }

        public CBQRestClientException build() {
            return new CBQRestClientException(this);
        }
    }
}
