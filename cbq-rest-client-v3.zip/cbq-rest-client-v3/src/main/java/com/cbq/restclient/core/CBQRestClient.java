package com.cbq.restclient.core;

import com.cbq.restclient.filter.CBQRequestFilter;
import com.cbq.restclient.logging.CBQLoggingService;
import com.cbq.restclient.model.CBQResponse;
import com.cbq.restclient.model.ErrorMapper;
import com.cbq.restclient.resilience.CBQResilienceManager;
import com.cbq.restclient.util.CorrelationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;

import java.util.List;
import java.util.concurrent.*;

/**
 * Production-ready HTTP client built on Spring 6 RestClient.
 *
 * <p>Key design differences from v2 (WebClient-based):
 * <ul>
 *   <li>Synchronous by default — virtual threads make blocking cheap</li>
 *   <li>No Mono/Flux — plain Java types, CompletableFuture for async</li>
 *   <li>Resilience4j patterns wrap synchronous calls directly</li>
 *   <li>MDC-based correlation propagates naturally across virtual threads</li>
 * </ul>
 */
public final class CBQRestClient {

    private static final Logger log = LoggerFactory.getLogger(CBQRestClient.class);

    private final String name;
    private final org.springframework.web.client.RestClient restClient;
    private final CBQResilienceManager resilience;
    private final CBQLoggingService loggingService;
    private final List<CBQRequestFilter> requestFilters;
    private final List<ErrorMapper> errorMappers;
    private final ObjectMapper objectMapper;
    private final ExecutorService virtualExecutor;

    // Package-private: created via CBQRestClientBuilder
    CBQRestClient(String name,
                  org.springframework.web.client.RestClient restClient,
                  CBQResilienceManager resilience,
                  CBQLoggingService loggingService,
                  List<CBQRequestFilter> requestFilters,
                  List<ErrorMapper> errorMappers,
                  ObjectMapper objectMapper) {
        this.name = name;
        this.restClient = restClient;
        this.resilience = resilience;
        this.loggingService = loggingService;
        this.requestFilters = List.copyOf(requestFilters);
        this.errorMappers = List.copyOf(errorMappers);
        this.objectMapper = objectMapper;
        this.virtualExecutor = Executors.newVirtualThreadPerTaskExecutor();
    }

    // ── HTTP Method Starters ─────────────────────────────────────────────────

    public CBQRequestSpec get()     { return new CBQRequestSpec(this, HttpMethod.GET); }
    public CBQRequestSpec post()    { return new CBQRequestSpec(this, HttpMethod.POST); }
    public CBQRequestSpec put()     { return new CBQRequestSpec(this, HttpMethod.PUT); }
    public CBQRequestSpec patch()   { return new CBQRequestSpec(this, HttpMethod.PATCH); }
    public CBQRequestSpec delete()  { return new CBQRequestSpec(this, HttpMethod.DELETE); }
    public CBQRequestSpec head()    { return new CBQRequestSpec(this, HttpMethod.HEAD); }
    public CBQRequestSpec options() { return new CBQRequestSpec(this, HttpMethod.OPTIONS); }

    // ── Parallel Execution ───────────────────────────────────────────────────

    /**
     * Execute multiple requests in parallel using virtual threads.
     * Waits for ALL to complete. Any failure throws immediately.
     */
    @SafeVarargs
    public final <T> List<CBQResponse<T>> parallel(Callable<CBQResponse<T>>... calls) {
        return parallelInternal(List.of(calls), false);
    }

    /**
     * Execute in parallel, returning partial results. Failed calls return null.
     */
    @SafeVarargs
    public final <T> List<CBQResponse<T>> parallelPartial(Callable<CBQResponse<T>>... calls) {
        return parallelInternal(List.of(calls), true);
    }

    private <T> List<CBQResponse<T>> parallelInternal(List<Callable<CBQResponse<T>>> calls, boolean partial) {
        String correlationId = CorrelationContext.getOrCreateCorrelationId();

        var futures = calls.stream()
                .map(call -> CompletableFuture.supplyAsync(() -> {
                    CorrelationContext.setCorrelationId(correlationId);
                    try {
                        return call.call();
                    } catch (Exception e) {
                        if (partial) {
                            log.warn("Parallel call failed (partial mode): {}", e.getMessage());
                            return null;
                        }
                        throw (e instanceof RuntimeException re) ? re : new RuntimeException(e);
                    }
                }, virtualExecutor))
                .toList();

        return futures.stream()
                .map(f -> {
                    try {
                        return f.join();
                    } catch (CompletionException e) {
                        if (partial) return null;
                        throw (e.getCause() instanceof RuntimeException re) ? re : new RuntimeException(e.getCause());
                    }
                })
                .toList();
    }

    // ── Accessors ────────────────────────────────────────────────────────────

    public String getName()                                    { return name; }
    public CBQLoggingService getLoggingService()               { return loggingService; }
    public CBQResilienceManager getResilience()                { return resilience; }
    org.springframework.web.client.RestClient getRestClient()  { return restClient; }
    List<CBQRequestFilter> getRequestFilters()                 { return requestFilters; }
    List<ErrorMapper> getErrorMappers()                        { return errorMappers; }
    ObjectMapper getObjectMapper()                             { return objectMapper; }
    ExecutorService getVirtualExecutor()                        { return virtualExecutor; }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    /**
     * Shutdown the virtual thread executor. Call on application shutdown or via @PreDestroy.
     */
    public void shutdown() {
        virtualExecutor.shutdown();
        try {
            if (!virtualExecutor.awaitTermination(10, TimeUnit.SECONDS)) {
                virtualExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            virtualExecutor.shutdownNow();
            Thread.currentThread().interrupt();
        }
        log.info("CBQRestClient '{}' shut down", name);
    }
}
