package com.cbq.restclient.core;

import com.cbq.restclient.filter.CBQRequestFilter;
import com.cbq.restclient.logging.CBQLoggingService;
import com.cbq.restclient.model.CBQResponse;
import com.cbq.restclient.model.ErrorMapper;
import com.cbq.restclient.resilience.CBQResilienceManager;
import com.cbq.restclient.util.CorrelationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.concurrent.*;

public final class CBQRestClient {
    private static final Logger log = LoggerFactory.getLogger(CBQRestClient.class);

    private final String name;
    private final RestClient restClient;
    private final CBQResilienceManager resilience;
    private final CBQLoggingService loggingService;
    private final List<CBQRequestFilter> requestFilters;
    private final List<ErrorMapper> errorMappers;
    private final ObjectMapper objectMapper;
    private final ExecutorService virtualExecutor;

    public CBQRestClient(String name, RestClient restClient, CBQResilienceManager resilience,
                         CBQLoggingService loggingService, List<CBQRequestFilter> requestFilters,
                         List<ErrorMapper> errorMappers, ObjectMapper objectMapper) {
        this.name = name; this.restClient = restClient; this.resilience = resilience;
        this.loggingService = loggingService; this.requestFilters = List.copyOf(requestFilters);
        this.errorMappers = List.copyOf(errorMappers); this.objectMapper = objectMapper;
        this.virtualExecutor = Executors.newVirtualThreadPerTaskExecutor();
    }

    public CBQRequestSpec get()     { return new CBQRequestSpec(this, HttpMethod.GET); }
    public CBQRequestSpec post()    { return new CBQRequestSpec(this, HttpMethod.POST); }
    public CBQRequestSpec put()     { return new CBQRequestSpec(this, HttpMethod.PUT); }
    public CBQRequestSpec patch()   { return new CBQRequestSpec(this, HttpMethod.PATCH); }
    public CBQRequestSpec delete()  { return new CBQRequestSpec(this, HttpMethod.DELETE); }
    public CBQRequestSpec head()    { return new CBQRequestSpec(this, HttpMethod.HEAD); }
    public CBQRequestSpec options() { return new CBQRequestSpec(this, HttpMethod.OPTIONS); }

    @SafeVarargs
    public final <T> List<CBQResponse<T>> parallel(Callable<CBQResponse<T>>... calls) { return doParallel(List.of(calls), false); }

    @SafeVarargs
    public final <T> List<CBQResponse<T>> parallelPartial(Callable<CBQResponse<T>>... calls) { return doParallel(List.of(calls), true); }

    private <T> List<CBQResponse<T>> doParallel(List<Callable<CBQResponse<T>>> calls, boolean partial) {
        String corrId = CorrelationContext.getOrCreateCorrelationId();
        var futures = calls.stream().map(call -> CompletableFuture.supplyAsync(() -> {
            CorrelationContext.setCorrelationId(corrId);
            try { return call.call(); }
            catch (Exception e) { if (partial) { log.warn("Parallel call failed (partial): {}", e.getMessage()); return null; }
                throw (e instanceof RuntimeException re) ? re : new RuntimeException(e); }
        }, virtualExecutor)).toList();
        return futures.stream().map(f -> {
            try { return f.join(); }
            catch (CompletionException e) { if (partial) return null;
                throw (e.getCause() instanceof RuntimeException re) ? re : new RuntimeException(e.getCause()); }
        }).toList();
    }

    // ── Accessors ────────────────────────────────────────────────────────────
    public String getName()                       { return name; }
    public CBQLoggingService getLoggingService()   { return loggingService; }
    public CBQResilienceManager getResilience()    { return resilience; }
    public RestClient getRestClient()              { return restClient; }
    public List<CBQRequestFilter> getRequestFilters() { return requestFilters; }
    public List<ErrorMapper> getErrorMappers()     { return errorMappers; }
    public ObjectMapper getObjectMapper()          { return objectMapper; }
    public ExecutorService getVirtualExecutor()     { return virtualExecutor; }

    public void shutdown() {
        virtualExecutor.shutdown();
        if (loggingService != null) loggingService.shutdown();
        try { if (!virtualExecutor.awaitTermination(10, TimeUnit.SECONDS)) virtualExecutor.shutdownNow(); }
        catch (InterruptedException e) { virtualExecutor.shutdownNow(); Thread.currentThread().interrupt(); }
        log.info("CBQRestClient '{}' shut down", name);
    }
}
