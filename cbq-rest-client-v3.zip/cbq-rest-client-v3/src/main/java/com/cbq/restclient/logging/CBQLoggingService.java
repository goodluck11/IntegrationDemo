package com.cbq.restclient.logging;

import com.cbq.restclient.config.LoggingConfig;
import com.cbq.restclient.config.LoggingConfig.LogFormat;
import com.cbq.restclient.util.FieldMasker;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Structured logging for HTTP requests/responses and other task types.
 * Supports JSON (Splunk-friendly), Pretty (box format), and Simple formats.
 */
public final class CBQLoggingService {

    private static final Logger log = LoggerFactory.getLogger(CBQLoggingService.class);

    private final LoggingConfig config;
    private final FieldMasker masker;
    private final ObjectMapper mapper;

    public CBQLoggingService(LoggingConfig config, ObjectMapper mapper) {
        this.config = config;
        this.masker = new FieldMasker(config.maskFields(), config.partialMaskFields(),
                config.maskSymbol(), mapper);
        this.mapper = mapper;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // HTTP Logging
    // ═══════════════════════════════════════════════════════════════════════

    public void logRequest(String requestId, String correlationId, String method, String uri,
                           Map<String, String> headers, Object body) {
        if (!config.enabled() || !config.logRequest()) return;

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("timestamp", Instant.now().toString());
        data.put("service", config.serviceName());
        data.put("type", "request");
        data.put("task_type", "http");
        data.put("request_id", requestId);
        data.put("correlation_id", correlationId);
        data.put("method", method);
        data.put("uri", uri);
        if (config.logHeaders() && headers != null) data.put("headers", headers);
        if (config.logBody() && body != null) data.put("body", masker.maskObject(body));

        emit(data);
    }

    public void logResponse(String requestId, String correlationId, String method, String uri,
                            int status, long durationMs, Object body) {
        if (!config.enabled() || !config.logResponse()) return;

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("timestamp", Instant.now().toString());
        data.put("service", config.serviceName());
        data.put("type", "response");
        data.put("task_type", "http");
        data.put("request_id", requestId);
        data.put("correlation_id", correlationId);
        data.put("method", method);
        data.put("uri", uri);
        data.put("status", status);
        data.put("duration_ms", durationMs);
        if (config.logBody() && body != null) {
            String bodyStr = body instanceof String s ? s : masker.maskObject(body);
            if (bodyStr.length() > config.maxBodySize()) {
                bodyStr = bodyStr.substring(0, config.maxBodySize()) + "...[truncated]";
            }
            data.put("body", bodyStr);
        }

        emit(data);
    }

    public void logError(String requestId, String correlationId, String method, String uri,
                         Throwable error, long durationMs) {
        if (!config.enabled()) return;

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("timestamp", Instant.now().toString());
        data.put("service", config.serviceName());
        data.put("type", "error");
        data.put("task_type", "http");
        data.put("request_id", requestId);
        data.put("correlation_id", correlationId);
        data.put("method", method);
        data.put("uri", uri);
        data.put("duration_ms", durationMs);
        data.put("error", error.getClass().getSimpleName());
        data.put("error_message", error.getMessage());

        emitError(data);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Task Logging (DB, Email, Cache, Queue)
    // ═══════════════════════════════════════════════════════════════════════

    public void logDb(String correlationId, String operation, String table,
                      Object data, long durationMs) {
        logTask("db", correlationId, operation, table, data, durationMs);
    }

    public void logEmail(String correlationId, String operation, String recipient,
                         Object data, long durationMs) {
        logTask("email", correlationId, operation, recipient, data, durationMs);
    }

    public void logCache(String correlationId, String operation, String key,
                         Object data, long durationMs) {
        logTask("cache", correlationId, operation, key, data, durationMs);
    }

    public void logQueue(String correlationId, String operation, String queue,
                         Object data, long durationMs) {
        logTask("queue", correlationId, operation, queue, data, durationMs);
    }

    private void logTask(String taskType, String correlationId, String operation,
                         String target, Object body, long durationMs) {
        if (!config.enabled()) return;

        Map<String, Object> entry = new LinkedHashMap<>();
        entry.put("timestamp", Instant.now().toString());
        entry.put("service", config.serviceName());
        entry.put("type", "task");
        entry.put("task_type", taskType);
        entry.put("correlation_id", correlationId);
        entry.put("operation", operation);
        entry.put("target", target);
        entry.put("duration_ms", durationMs);
        if (config.logBody() && body != null) entry.put("body", masker.maskObject(body));

        emit(entry);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Output formatting
    // ═══════════════════════════════════════════════════════════════════════

    private void emit(Map<String, Object> data) {
        try {
            switch (config.format()) {
                case JSON -> log.info(mapper.writeValueAsString(data));
                case PRETTY -> log.info("\n{}", formatPretty(data));
                case SIMPLE -> log.info("{} {} {} [{}] {}",
                        data.get("type"), data.get("method"), data.get("uri"),
                        data.get("request_id"), data.getOrDefault("status", ""));
            }
        } catch (Exception e) {
            log.warn("Failed to log request: {}", e.getMessage());
        }
    }

    private void emitError(Map<String, Object> data) {
        try {
            switch (config.format()) {
                case JSON -> log.error(mapper.writeValueAsString(data));
                case PRETTY -> log.error("\n{}", formatPretty(data));
                case SIMPLE -> log.error("{} {} {} [{}] ERROR: {}",
                        data.get("type"), data.get("method"), data.get("uri"),
                        data.get("request_id"), data.get("error_message"));
            }
        } catch (Exception e) {
            log.warn("Failed to log error: {}", e.getMessage());
        }
    }

    private String formatPretty(Map<String, Object> data) {
        var sb = new StringBuilder();
        String type = String.valueOf(data.get("type")).toUpperCase();
        sb.append("╔══════════════════════════════════════════════════════════════════╗\n");
        sb.append("║ CBQ HTTP ").append(type).append("\n");
        sb.append("╠══════════════════════════════════════════════════════════════════╣\n");
        for (var entry : data.entrySet()) {
            if ("body".equals(entry.getKey())) {
                sb.append("║ Body:\n");
                try {
                    sb.append(mapper.writerWithDefaultPrettyPrinter()
                            .writeValueAsString(mapper.readTree(String.valueOf(entry.getValue()))));
                } catch (Exception e) {
                    sb.append(entry.getValue());
                }
                sb.append("\n");
            } else {
                sb.append("║ ").append(capitalize(entry.getKey())).append(": ").append(entry.getValue()).append("\n");
            }
        }
        sb.append("╚══════════════════════════════════════════════════════════════════╝");
        return sb.toString();
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1).replace('_', ' ');
    }

    public FieldMasker getMasker() { return masker; }
}
