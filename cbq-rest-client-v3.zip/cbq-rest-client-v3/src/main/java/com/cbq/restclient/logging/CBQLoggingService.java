package com.cbq.restclient.logging;

import com.cbq.restclient.config.LoggingConfig;
import com.cbq.restclient.util.FieldMasker;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Structured async logging service. All log writes execute on a dedicated virtual thread
 * executor so they never block the calling HTTP thread.
 */
public final class CBQLoggingService {

    private static final Logger httpLog = LoggerFactory.getLogger("cbq.http");
    private static final Logger taskLog = LoggerFactory.getLogger("cbq.task");

    private final LoggingConfig config;
    private final FieldMasker masker;
    private final ObjectMapper mapper;
    private final ExecutorService logExecutor;

    public CBQLoggingService(LoggingConfig config) {
        this.config = config;
        this.masker = new FieldMasker(config.maskFields(), config.maskChar());
        this.mapper = new ObjectMapper();
        // Virtual thread executor for non-blocking log writes
        this.logExecutor = Executors.newVirtualThreadPerTaskExecutor();
    }

    // ── HTTP Request/Response Logging (async) ────────────────────────────────

    public void logRequest(String requestId, String correlationId, String method, String uri,
                           HttpHeaders headers, String body) {
        if (!config.logRequest()) return;
        logExecutor.execute(() -> doLogRequest(requestId, correlationId, method, uri, headers, body));
    }

    public void logResponse(String requestId, String correlationId, String method, String uri,
                            int status, HttpHeaders headers, String body, long durationMs) {
        if (!config.logResponse()) return;
        logExecutor.execute(() -> doLogResponse(requestId, correlationId, method, uri, status, headers, body, durationMs));
    }

    public void logError(String requestId, String correlationId, String method, String uri,
                         Throwable error, long durationMs) {
        logExecutor.execute(() -> doLogError(requestId, correlationId, method, uri, error, durationMs));
    }

    // ── Task Logging (DB, email, cache, queue — async) ───────────────────────

    public void logTask(String correlationId, String taskType, String operation,
                        String target, long durationMs, boolean success, String detail) {
        logExecutor.execute(() -> doLogTask(correlationId, taskType, operation, target, durationMs, success, detail));
    }

    public void logDb(String correlationId, String op, String target, long ms, boolean ok)    { logTask(correlationId, "db", op, target, ms, ok, null); }
    public void logCache(String correlationId, String op, String target, long ms, boolean ok) { logTask(correlationId, "cache", op, target, ms, ok, null); }
    public void logEmail(String correlationId, String op, String target, long ms, boolean ok) { logTask(correlationId, "email", op, target, ms, ok, null); }
    public void logQueue(String correlationId, String op, String target, long ms, boolean ok) { logTask(correlationId, "queue", op, target, ms, ok, null); }

    // ── Internal (runs on virtual thread) ────────────────────────────────────

    private void doLogRequest(String requestId, String correlationId, String method, String uri,
                              HttpHeaders headers, String body) {
        if (config.format() == LoggingConfig.LogFormat.JSON) {
            var e = baseEntry("request", "http", requestId, correlationId);
            e.put("method", method); e.put("uri", uri);
            if (config.logHeaders() && headers != null) e.put("headers", maskHeaders(headers));
            if (config.logBody() && body != null) e.put("body", parseOrString(masker.maskJson(truncate(body))));
            httpLog.info(toJson(e));
        } else {
            var sb = new StringBuilder("→ %s %s [req=%s, corr=%s]".formatted(method, uri, requestId, correlationId));
            if (config.logHeaders() && headers != null) sb.append("\n  Headers: ").append(maskHeaders(headers));
            if (config.logBody() && body != null) sb.append("\n  Body: ").append(masker.maskJson(truncate(body)));
            httpLog.info(sb.toString());
        }
    }

    private void doLogResponse(String requestId, String correlationId, String method, String uri,
                               int status, HttpHeaders headers, String body, long durationMs) {
        if (config.format() == LoggingConfig.LogFormat.JSON) {
            var e = baseEntry("response", "http", requestId, correlationId);
            e.put("method", method); e.put("uri", uri); e.put("status", status); e.put("duration_ms", durationMs);
            if (config.logHeaders() && headers != null) e.put("headers", maskHeaders(headers));
            if (config.logBody() && body != null) e.put("body", parseOrString(masker.maskJson(truncate(body))));
            httpLog.info(toJson(e));
        } else {
            var sb = new StringBuilder("← %d %s %s [req=%s, corr=%s, %dms]".formatted(status, method, uri, requestId, correlationId, durationMs));
            if (config.logBody() && body != null) sb.append("\n  Body: ").append(masker.maskJson(truncate(body)));
            httpLog.info(sb.toString());
        }
    }

    private void doLogError(String requestId, String correlationId, String method, String uri,
                            Throwable error, long durationMs) {
        if (config.format() == LoggingConfig.LogFormat.JSON) {
            var e = baseEntry("error", "http", requestId, correlationId);
            e.put("method", method); e.put("uri", uri); e.put("duration_ms", durationMs);
            e.put("error", error.getClass().getSimpleName()); e.put("error_message", error.getMessage());
            httpLog.error(toJson(e));
        } else {
            httpLog.error("✗ {} {} [req={}, corr={}, {}ms] {} - {}", method, uri, requestId, correlationId, durationMs,
                    error.getClass().getSimpleName(), error.getMessage());
        }
    }

    private void doLogTask(String correlationId, String taskType, String operation,
                           String target, long durationMs, boolean success, String detail) {
        if (config.format() == LoggingConfig.LogFormat.JSON) {
            var e = new LinkedHashMap<String, Object>();
            e.put("timestamp", Instant.now().toString()); e.put("service", config.serviceName());
            e.put("type", "task"); e.put("task_type", taskType);
            e.put("task_id", "task_" + UUID.randomUUID().toString().substring(0, 8));
            e.put("correlation_id", correlationId); e.put("operation", operation);
            e.put("target", target); e.put("duration_ms", durationMs); e.put("success", success);
            if (detail != null) e.put("detail", detail);
            taskLog.info(toJson(e));
        } else {
            taskLog.info("{} [{}] {} {} → {} [corr={}, {}ms]", success ? "✓" : "✗", taskType, operation, target,
                    success ? "OK" : "FAIL", correlationId, durationMs);
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private LinkedHashMap<String, Object> baseEntry(String type, String taskType, String requestId, String correlationId) {
        var e = new LinkedHashMap<String, Object>();
        e.put("timestamp", Instant.now().toString()); e.put("service", config.serviceName());
        e.put("type", type); e.put("task_type", taskType);
        e.put("request_id", requestId); e.put("correlation_id", correlationId);
        return e;
    }

    private Map<String, String> maskHeaders(HttpHeaders headers) {
        var m = new LinkedHashMap<String, String>();
        headers.forEach((n, v) -> m.put(n, masker.maskHeaderValue(n, String.join(", ", v))));
        return m;
    }

    private String truncate(String body) {
        return body != null && body.length() > config.maxBodyLogSize() ? body.substring(0, config.maxBodyLogSize()) + "...[TRUNCATED]" : body;
    }

    private Object parseOrString(String text) {
        try { return mapper.readTree(text); } catch (Exception e) { return text; }
    }

    private String toJson(Map<String, Object> entry) {
        try { return mapper.writeValueAsString(entry); } catch (JsonProcessingException e) { return entry.toString(); }
    }

    public void shutdown() {
        logExecutor.shutdown();
        try { if (!logExecutor.awaitTermination(5, TimeUnit.SECONDS)) logExecutor.shutdownNow(); }
        catch (InterruptedException e) { logExecutor.shutdownNow(); Thread.currentThread().interrupt(); }
    }
}
