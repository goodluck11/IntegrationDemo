package io.tomcat.reactive.app.model;

import java.util.List;

/*
 * @created by 06/02/2026  - 06:59
 * @project ReactivePlayground
 * @author Goodluck
 */
public record Page<T>(
        Long nextCursor,
        Boolean hasNext,
        List<T> items
) {
}
