package io.tomcat.reactive.app.helper;

import io.r2dbc.spi.Connection;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.ValidationDepth;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.Duration;

/*
 * @created by 06/02/2026  - 05:35
 * @project ReactivePlayground
 * @author Goodluck
 */
@Component
@RequiredArgsConstructor
@Slf4j
@Order(1)
public class DatabaseHealthCheck implements ApplicationRunner {
   private final ConnectionFactory connectionFactory;

   @Override
   public void run(ApplicationArguments args) {
      validateConnection()
              .doOnSuccess(valid -> {
                 if (Boolean.TRUE.equals(valid)) {
                    log.info("✅ Database connection validated successfully");
                 } else {
                    log.error("❌ Database connection validation failed");
                 }
              })
              .doOnError(ex -> log.error("❌ Database connection error", ex))
              .subscribe();
   }

   private Mono<Boolean> validateConnection() {
      return Mono.usingWhen(
              connectionFactory.create(),
              connection -> Mono.from(connection.validate(ValidationDepth.LOCAL))
                      .timeout(Duration.ofSeconds(5))
                      .thenReturn(true),
              Connection::close
      ).onErrorReturn(false);
   }
}
