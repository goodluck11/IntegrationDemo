package io.tomcat.reactive.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TomcatReactivePlaygroundApplication {

   public static void main(String[] args) {
      SpringApplication.run(TomcatReactivePlaygroundApplication.class, args);
   }

}
