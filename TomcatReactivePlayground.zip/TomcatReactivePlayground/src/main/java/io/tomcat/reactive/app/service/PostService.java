package io.tomcat.reactive.app.service;

import io.tomcat.reactive.app.model.Page;
import io.tomcat.reactive.app.model.Post;
import io.tomcat.reactive.app.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/*
 * @created by 06/02/2026  - 06:00
 * @project ReactivePlayground
 * @author Goodluck
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PostService {
   private final PostRepository postRepository;

   public Flux<Post> findAll() {
      return postRepository.findAll();
   }

   public Mono<Page<Post>> findAll(int limit, Long cursor) {
      log.info("Fetching posts with limit: {} and cursor: {}", limit, cursor);
      return postRepository.getPosts(limit, cursor);
   }

   public Mono<Long> deleteAll() {
      return postRepository.deleteAll()
              .doOnNext(count -> log.info("🗑️  Deleted {} posts from database", count));
   }
}

