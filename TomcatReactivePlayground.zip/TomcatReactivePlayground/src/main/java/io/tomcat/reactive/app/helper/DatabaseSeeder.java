package io.tomcat.reactive.app.helper;

/*
 * @created by 06/02/2026  - 06:26
 * @project ReactivePlayground
 * @author Goodluck
 */

import io.tomcat.reactive.app.model.Post;
import io.tomcat.reactive.app.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicLong;

@Slf4j
@RequiredArgsConstructor
@Component
@Order(2)
public class DatabaseSeeder implements ApplicationRunner {
   private final WebClient webClient;
   private final ObjectMapper objectMapper;
   private final DatabaseClient databaseClient;
   private final PostRepository postRepository;

   @Override
   public void run(ApplicationArguments args) {
      checkAndSeedPosts()
              .doOnSuccess(count -> {
                 if (count != null && count > 0) {
                    log.info("✅ Successfully seeded {} posts into database", count);
                 } else {
                    log.info("✅ Database already contains data, skipping seed");
                 }
              })
              .doOnError(ex -> log.error("Failed to seed database", ex))
              .subscribe();
   }

   public Mono<Long> checkAndSeedPosts() {
      return postRepository.count()
              .flatMap(count -> {
                 if (count == 0) {
                    log.info("📥 Posts table is empty, seeding data from JSONPlaceholder...");
                    return fetchAndSavePosts();
                 } else {
                    log.info("📊 Database already contains {} posts", count);
                    return Mono.just(count);
                 }
              });
   }

   public Mono<Long> fetchAndSavePosts() {
      return webClient.get()
              .uri("/posts")
              .retrieve()
              .bodyToMono(String.class)
              .flatMapMany(this::parsePostsFromJson)
              .buffer(50)
              .concatMap(batch -> savePostBatch(batch)
                      .delayElement(Duration.ofMillis(100))) // Small delay between batches
              .reduce(0L, Long::sum)
              .doOnNext(total -> log.info("📥 Successfully saved {} posts to database", total));
   }

   private Flux<Post> parsePostsFromJson(String jsonResponse) {
      try {
         JsonNode rootNode = objectMapper.readTree(jsonResponse);
         if (rootNode.isArray()) {
            return Flux.fromIterable(rootNode)
                    .map(node -> new Post(
                            node.get("id").asLong(),
                            node.get("userId").asLong(),
                            node.get("title").asString(),
                            node.get("body").asString()
                    ));
         }
      } catch (Exception e) {
         log.error("Failed to parse JSON: {}", e.getMessage());
      }
      return Flux.empty();
   }

   private Mono<Long> savePostBatch(Iterable<Post> posts) {
      AtomicLong counter = new AtomicLong(0);

      return Flux.fromIterable(posts)
              .flatMap(post ->
                      databaseClient.sql("""
                                      INSERT INTO posts (user_id, title, body, created_at) 
                                      VALUES (:userId, :title, :body, :createdAt)
                                      ON CONFLICT (id) DO NOTHING
                                      """)
                              .bind("userId", post.userId())
                              .bind("title", post.title())
                              .bind("body", post.body())
                              .bind("createdAt", LocalDateTime.now())
                              .fetch()
                              .rowsUpdated()
                              .doOnNext(rows -> {
                                 if (rows > 0) counter.incrementAndGet();
                              })
              )
              .then(Mono.fromCallable(counter::get))
              .doOnNext(count -> {
                 if (count > 0) {
                    log.debug("Saved batch of {} posts", count);
                 }
              });
   }
}
