package io.tomcat.reactive.app.controller;

import io.tomcat.reactive.app.model.Page;
import io.tomcat.reactive.app.model.Post;
import io.tomcat.reactive.app.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/*
 * @created by 06/02/2026 - 06:01
 * @project ReactivePlayground
 * @author Goodluck
 */
@RestController
@RequestMapping("/posts")
@RequiredArgsConstructor
public class PostController {
   private final PostService postService;

   @GetMapping
   public Mono<Page<Post>> getPosts(
           @RequestParam(required = false) Long cursor,
           @RequestParam(defaultValue = "10") int limit) {
      return postService.findAll(limit, cursor);
   }

   @GetMapping("/all")
   public Flux<Post> findAll() {
      return postService.findAll();
   }

   @DeleteMapping("/delete-all")
   public Mono<Long> deleteAll() {
      return postService.deleteAll();
   }
}
