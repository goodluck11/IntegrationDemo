package io.tomcat.reactive.app;

public class ServletInitializer {}
/*extends SpringBootServletInitializer {

   @Override
   protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
      return application.sources(TomcatReactivePlaygroundApplication.class);
   }

}*/
