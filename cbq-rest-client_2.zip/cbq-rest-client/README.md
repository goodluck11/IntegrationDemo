# CBQ REST Client

A production-ready HTTP client library for Java/Spring applications with built-in resilience, observability, and workflow capabilities.

---

## 📦 Maven Dependency

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-rest-client</artifactId>
    <version>2.0.0</version>
</dependency>
```

### Optional Dependencies (add only what you need)

```xml
<!-- Resilience4j - for retry, circuit breaker, rate limiter -->
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-reactor</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-circuitbreaker</artifactId>
    <version>1.7.1</version>
</dependency>

<!-- Micrometer - for metrics -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-core</artifactId>
    <version>1.9.17</version>
</dependency>

<!-- Spring Mail - for email notifications -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-mail</artifactId>
</dependency>
```

---

## 🚀 Quick Start

### Simplest Setup

```java
CBQRestClient client = CBQRestClientBuilder.builder()
    .baseUrl("https://api.example.com")
    .build();

// GET request
User user = client.get()
    .uri("/users/1")
    .retrieveBody(User.class)
    .block();

// POST request
Order order = client.post()
    .uri("/orders")
    .bodyValue(new CreateOrderRequest("item-1", 2))
    .retrieveBody(Order.class)
    .block();

// Don't forget to shutdown
client.shutdown();
```

### Production Setup

```java
CBQRestClient client = CBQRestClientBuilder.builder("payment-service")
    .baseUrl("https://api.payment.com")
    
    // Timeouts
    .timeouts(TimeoutConfig.custom()
        .connection(Duration.ofSeconds(5))
        .read(Duration.ofSeconds(30))
        .response(Duration.ofSeconds(60)))
    
    // Resilience (retry, circuit breaker)
    .resilience(ResilienceConfig.custom()
        .retry(RetryConfig.custom()
            .maxAttempts(3)
            .waitDuration(Duration.ofMillis(500)))
        .circuitBreaker(CircuitBreakerConfig.custom()
            .failureRate(50)
            .openStateWait(Duration.ofSeconds(30))))
    
    // Logging (JSON format for Splunk)
    .logging(LoggingConfig.custom()
        .logAll()
        .jsonFormat()
        .serviceName("payment-service")
        .maskFields("cardNumber", "cvv", "password"))
    
    // Default headers
    .header("X-API-Version", "2.0")
    
    // Auth filter
    .addRequestFilter(Filters.bearerToken(() -> tokenService.getToken()))
    
    .build();
```

---

## 📖 Table of Contents

1. [HTTP Methods](#1-http-methods)
2. [Request Options](#2-request-options)
3. [Response Handling](#3-response-handling)
4. [Parallel Execution](#4-parallel-execution)
5. [Sequential Execution](#5-sequential-execution)
6. [CBQWorkflow - Advanced Workflows](#6-cbqworkflow---advanced-workflows)
7. [Resilience (Retry, Circuit Breaker)](#7-resilience)
8. [Logging & Masking](#8-logging--masking)
9. [Error Handling](#9-error-handling)
10. [Filters](#10-filters)
11. [Real-World Examples](#11-real-world-examples)

---

## 1. HTTP Methods

```java
// GET
client.get().uri("/users").retrieve(UserList.class);

// POST
client.post().uri("/users").bodyValue(newUser).retrieve(User.class);

// PUT
client.put().uri("/users/1").bodyValue(updateUser).retrieve(User.class);

// PATCH
client.patch().uri("/users/1").bodyValue(partialUpdate).retrieve(User.class);

// DELETE
client.delete().uri("/users/1").retrieve(Void.class);

// HEAD
client.head().uri("/users/1").retrieve(Void.class);

// OPTIONS
client.options().uri("/users").retrieve(String.class);
```

### URI with Variables

```java
// Single variable
client.get().uri("/users/{}", userId).retrieve(User.class);

// Multiple variables
client.get().uri("/users/{}/orders/{}", userId, orderId).retrieve(Order.class);
```

---

## 2. Request Options

### Headers

```java
client.post()
    .uri("/orders")
    .header("X-Idempotency-Key", UUID.randomUUID().toString())
    .header("X-Request-Source", "mobile-app")
    .headers(h -> {
        h.add("X-Custom-1", "value1");
        h.add("X-Custom-2", "value2");
    })
    .bodyValue(order)
    .retrieve(Order.class);
```

### Content Type

```java
// JSON (default)
client.post().uri("/api").bodyValue(obj).retrieve(Result.class);

// Form data
client.post()
    .uri("/login")
    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
    .bodyValue("username=john&password=secret")
    .retrieve(LoginResult.class);
```

### Per-Request Timeout Override

```java
// Override timeout for slow endpoint
client.post()
    .uri("/reports/generate")
    .bodyValue(request)
    .override(o -> o
        .responseTimeout(Duration.ofMinutes(5))
        .retryEnabled(false)
        .circuitBreakerEnabled(false))
    .retrieve(Report.class);
```

---

## 3. Response Handling

### Full Response (with metadata)

```java
CBQResponse<User> response = client.get()
    .uri("/users/1")
    .retrieve(User.class)
    .block();

User user = response.getBody();
int status = response.getStatus().value();
HttpHeaders headers = response.getHeaders();
long duration = response.getDurationMs();
String requestId = response.getRequestId();
```

### Body Only (simpler)

```java
User user = client.get()
    .uri("/users/1")
    .retrieveBody(User.class)
    .block();
```

### Blocking vs Reactive

```java
// Blocking (traditional code)
User user = client.get().uri("/users/1").retrieveBody(User.class).block();

// Blocking with timeout
User user = client.get().uri("/users/1").retrieveBody(User.class)
    .block(Duration.ofSeconds(10));

// Reactive (WebFlux)
Mono<User> userMono = client.get().uri("/users/1").retrieveBody(User.class);

// Subscribe
client.get().uri("/users/1").retrieveBody(User.class)
    .subscribe(
        user -> log.info("Got user: {}", user.getName()),
        error -> log.error("Failed: {}", error.getMessage())
    );
```

### Streaming (Flux)

```java
Flux<Event> events = client.get()
    .uri("/events/stream")
    .retrieveFlux(Event.class);

events.subscribe(event -> processEvent(event));
```

---

## 4. Parallel Execution

Execute multiple requests at the same time.

### Basic Parallel

```java
CBQParallelResult<Object> result = client.parallel(
    client.get().uri("/users/1").retrieve(User.class),
    client.get().uri("/orders/recent").retrieve(OrderList.class),
    client.get().uri("/notifications").retrieve(NotificationList.class)
).execute().block();

// Get results by index
User user = (User) result.getResponses().get(0).getBody();
OrderList orders = (OrderList) result.getResponses().get(1).getBody();
```

### Parallel Strategies

| Strategy | Behavior |
|----------|----------|
| `waitAll()` | Wait for ALL requests (default) |
| `failFast()` | Stop on FIRST failure |
| `partialSuccess()` | Continue even if some fail |

```java
// WAIT_ALL - Wait for all, fail if any fails
client.parallel(req1, req2, req3)
    .waitAll()
    .execute();

// FAIL_FAST - Stop immediately on first failure
client.parallel(req1, req2, req3)
    .failFast()
    .execute();

// PARTIAL_SUCCESS - Get what you can
CBQParallelResult<User> result = client.parallel(req1, req2, req3)
    .partialSuccess()
    .execute()
    .block();

// Check for errors
if (result.hasErrors()) {
    result.getErrors().forEach((index, error) -> 
        log.warn("Request {} failed: {}", index, error.getMessage()));
}
```

---

## 5. Sequential Execution

Execute requests in order, passing data from one to the next.

```java
// Step 1 result feeds into Step 2
Order order = client.sequence()
    .then(() -> client.get().uri("/users/1").retrieve(User.class))
    .then((User user) -> client.post()
        .uri("/orders")
        .bodyValue(new CreateOrderRequest(user.getId(), items))
        .retrieve(Order.class))
    .<Order>execute()
    .block();
```

---

## 6. CBQWorkflow - Reactive Workflow DSL

Production-grade workflow orchestration with **proper reactive patterns**.

### ⚠️ IMPORTANT: Never block in reactive chains!

```java
// ❌ WRONG - blocks Netty event loop
User user = userRepo.findById(id).block();  // NEVER DO THIS

// ✅ CORRECT - use thenBlocking() which offloads to boundedElastic
CBQWorkflow.http(() -> client.get().uri("/user").retrieve(User.class))
    .thenBlocking(user -> userRepo.save(user))  // Properly offloaded
    .toMono();  // Returns Mono, not blocking
```

### Quick Reference

| Method | Blocking? | Use For |
|--------|-----------|---------|
| `http()` | No | Start with HTTP call |
| `mono()` | No | Start with reactive call (R2DBC) |
| `blocking()` | Offloaded | Start with JDBC call |
| `thenHttp()` | No | Chain HTTP call |
| `thenMono()` | No | Chain reactive call |
| `thenBlocking()` | Offloaded | Chain JDBC call (safe!) |
| `thenHttpOptional()` | No | HTTP that can fail |
| `thenBlockingOptional()` | Offloaded | JDBC that can fail |
| `fireAndForget()` | No | Background HTTP |
| `fireAndForgetBlocking()` | Offloaded | Background JDBC |
| `onErrorRollback()` | No | HTTP rollback |
| `onErrorLog()` | Offloaded | Log error to DB |
| `toMono()` | No | **Terminal: Returns Mono** |
| `blockingGet()` | Yes | **Terminal: Only at edge!** |

### 6.1 Basic Payment Flow (Your Use Case 1)

```java
@GetMapping("/process-payment")
public Mono<PaymentResult> processPayment(@RequestBody PaymentRequest request) {
    
    return CBQWorkflow
        // Step 1: Check app status
        .http(() -> client.get()
            .uri("/app/status")
            .retrieve(AppStatus.class))
        
        // Step 2: Get customer card details
        .thenHttp(status -> client.get()
            .uri("/customers/{}/cards", status.getCustomerId())
            .retrieve(Card.class))
        
        // Step 3: Check card status
        .thenHttp(card -> client.get()
            .uri("/cards/{}/status", card.getId())
            .retrieve(CardStatus.class))
        
        // Step 4: Validate balance
        .filter(
            cardStatus -> cardStatus.getBalance().compareTo(request.getAmount()) >= 0,
            () -> new InsufficientBalanceException("Not enough balance")
        )
        
        // Step 5: Account posting
        .thenHttp(cardStatus -> client.post()
            .uri("/accounts/post")
            .bodyValue(new PostingRequest(cardStatus.getAccountId(), request.getAmount()))
            .retrieve(PaymentResult.class))
        
        // On error: Reversal API call
        .onErrorRollback(error -> client.post()
            .uri("/accounts/reverse")
            .bodyValue(new ReversalRequest(request.getTransactionId()))
            .retrieve(Void.class))
        
        // On error: Log to DB (fire-and-forget, properly offloaded)
        .onErrorLog(error -> errorLogRepository.save(
            new ErrorLog(request.getTransactionId(), error.getMessage())))
        
        // Fire-and-forget: Send email
        .fireAndForget(result -> client.post()
            .uri("/notifications/email")
            .bodyValue(new EmailRequest(request.getEmail(), result.getReceiptId()))
            .retrieve(Void.class))
        
        .toMono();  // Returns Mono<PaymentResult>
}
```

### 6.2 Continue on Error - Partial Results (Your Use Case 2)

```java
@GetMapping("/composite")
public Mono<CompositeResult> getComposite(@RequestParam String id) {
    
    return CBQWorkflow
        // Step 1: Get first result (must succeed)
        .http(() -> client.get()
            .uri("/first/{}", id)
            .retrieve(FirstResult.class))
        
        // Capture for later use (stored in Reactor Context - thread-safe)
        .capture("first")
        
        // Step 2: Get second result (optional - can fail)
        .thenHttpOptional(first -> client.get()
            .uri("/second/{}", first.getReferenceId())
            .retrieve(SecondResult.class))
        
        // Combine: first (from context) + optional second
        .withCaptured("first", (optionalResult, first) -> {
            // optionalResult contains: previous value + optional result
            SecondResult second = optionalResult.getResult().orElse(null);
            return new CompositeResult(first, second);
        })
        
        // Fire-and-forget: Save audit to DB (properly offloaded)
        .fireAndForgetBlocking(result -> 
            auditRepository.save(new AuditLog("composite_fetched", result.getId())))
        
        .toMono();
}
```

### 6.3 With Database Calls (Reactive R2DBC vs Blocking JDBC)

```java
// ✅ REACTIVE DB (R2DBC) - stays on event loop
CBQWorkflow
    .http(() -> client.post().uri("/orders").retrieve(Order.class))
    .thenMono(order -> r2dbcOrderRepo.save(order))  // R2DBC - non-blocking
    .toMono();

// ✅ BLOCKING DB (JDBC) - offloaded to boundedElastic
CBQWorkflow
    .http(() -> client.post().uri("/orders").retrieve(Order.class))
    .thenBlocking(order -> jpaOrderRepo.save(order))  // JDBC - safely offloaded
    .toMono();
```

### 6.4 Fire-and-Forget (Background Tasks)

```java
CBQWorkflow
    .http(() -> client.post().uri("/orders").retrieve(Order.class))
    
    // Fire-and-forget HTTP calls
    .fireAndForget(order -> client.post()
        .uri("/audit")
        .bodyValue(new AuditEvent(order))
        .retrieve(Void.class))
    
    // Fire-and-forget reactive call
    .fireAndForgetMono(order -> 
        kafkaTemplate.send("order-events", order))
    
    // Fire-and-forget JDBC call (properly offloaded)
    .fireAndForgetBlocking(order -> 
        analyticsRepo.trackOrderCreated(order.getId()))
    
    .toMono();
```

### 6.5 Deep Chain with Multiple Captures

```java
return CBQWorkflow
    // Step 1
    .http(() -> client.get().uri("/step1").retrieve(Step1Result.class))
    .capture("step1")
    
    // Step 2
    .thenHttp(s1 -> client.get().uri("/step2/{}", s1.getId()).retrieve(Step2Result.class))
    .capture("step2")
    
    // Step 3 (optional)
    .thenHttpOptional(s2 -> client.get().uri("/step3/{}", s2.getId()).retrieve(Step3Result.class))
    
    // Combine all results
    .map(optResult -> {
        Step1Result s1 = getCaptured("step1");
        Step2Result s2 = getCaptured("step2");
        Step3Result s3 = optResult.getResult().orElse(null);
        return new FinalResult(s1, s2, s3);
    })
    
    .toMono();
```

### 6.6 Context Propagation (Observability)

MDC context (correlation ID, trace ID) is automatically propagated:

```java
// In your filter - set MDC
MDC.put("correlationId", correlationId);
MDC.put("traceId", traceId);

// In workflow - context is automatically propagated
CBQWorkflow
    .http(() -> client.get().uri("/api").retrieve(Result.class))
    .thenBlocking(result -> {
        // MDC is available here on the boundedElastic thread!
        String correlationId = MDC.get("correlationId");
        log.info("Processing with correlation: {}", correlationId);
        return repository.save(result);
    })
    .fireAndForgetBlocking(result -> {
        // MDC also available in fire-and-forget!
        auditRepo.save(new Audit(MDC.get("correlationId"), result));
    })
    .toMono();
```

### 6.7 Terminal Operations

```java
// ✅ PREFERRED: Return Mono (non-blocking)
@GetMapping("/order")
public Mono<Order> getOrder() {
    return CBQWorkflow
        .http(() -> client.get().uri("/order").retrieve(Order.class))
        .toMono();
}

// ✅ OK: Subscribe and forget
CBQWorkflow
    .http(() -> client.post().uri("/background-job").retrieve(Void.class))
    .subscribe();  // Fire and forget entire workflow

// ⚠️ ONLY AT EDGE: Blocking get (CLI, @Scheduled, tests)
@Scheduled(fixedRate = 60000)
public void scheduledTask() {
    // OK here because @Scheduled runs on its own thread
    Result result = CBQWorkflow
        .http(() -> client.get().uri("/sync-data").retrieve(Result.class))
        .blockingGet(Duration.ofSeconds(30));
}
```

### 6.8 Error Handling Patterns

```java
// Fallback value
.onErrorReturn(new DefaultResult())

// Fallback Mono
.onErrorResume(error -> {
    if (error instanceof NotFoundException) {
        return Mono.just(Result.empty());
    }
    return Mono.error(error);
})

// HTTP rollback
.onErrorRollback(error -> client.post()
    .uri("/rollback")
    .retrieve(Void.class))

// Log to DB on error
.onErrorLog(error -> errorRepo.save(new ErrorLog(error)))
```

---

## 7. Resilience

### Retry

```java
ResilienceConfig.custom()
    .retry(RetryConfig.custom()
        .enabled(true)
        .maxAttempts(3)
        .waitDuration(Duration.ofMillis(500))
        .backoffStrategy(BackoffStrategy.EXPONENTIAL_WITH_JITTER)
        .retryOnConnectionTimeout(true)
        .retryOnReadTimeout(true))
```

### Circuit Breaker

```java
ResilienceConfig.custom()
    .circuitBreaker(CircuitBreakerConfig.custom()
        .enabled(true)
        .failureRate(50)           // Open at 50% failures
        .slowCallRate(80)          // Open at 80% slow calls
        .slowCallDuration(Duration.ofSeconds(5))
        .windowSize(10)
        .openStateWait(Duration.ofSeconds(30)))
```

### Rate Limiter

```java
ResilienceConfig.custom()
    .rateLimiter(RateLimiterConfig.custom()
        .enabled(true)
        .limitForPeriod(100)       // 100 calls per second
        .refreshPeriod(Duration.ofSeconds(1)))
```

### Disable Per-Request

```java
client.post()
    .uri("/payments/charge")
    .override(o -> o
        .retryEnabled(false)
        .circuitBreakerEnabled(false))
    .retrieve(Result.class);
```

---

## 8. Logging & Masking

### JSON Format (Splunk-Friendly)

```java
LoggingConfig.custom()
    .logAll()
    .jsonFormat()                    // Single-line JSON
    .serviceName("order-service")
    .maskFields("password", "cardNumber", "cvv", "token")
    .maskField("iban", 4)            // Show first/last 4 chars
    .maxBodySize(10_000)             // Truncate large bodies
```

### JSON Log Output

```json
{"timestamp":"2024-01-15T10:30:00Z","service":"order-service","type":"request","request_id":"req_001","correlation_id":"corr_abc123","method":"POST","uri":"/orders","body":{"amount":100,"cardNumber":"4111********1111"}}

{"timestamp":"2024-01-15T10:30:01Z","service":"order-service","type":"response","request_id":"req_001","correlation_id":"corr_abc123","status":200,"duration_ms":245}
```

### Pretty Format (Human-Readable)

```java
LoggingConfig.custom()
    .logAll()
    .prettyFormat()  // Box format
```

```
╔══════════════════════════════════════════════════════════════════╗
║ CBQ HTTP REQUEST
╠══════════════════════════════════════════════════════════════════╣
║ Request ID: req_001
║ Correlation ID: corr_abc123
║ Method: POST
║ URI: /orders
║ Body:
{
  "amount": 100,
  "cardNumber": "4111********1111"
}
╚══════════════════════════════════════════════════════════════════╝
```

### Log Other Tasks (DB, Email, etc.)

```java
LoggingService logger = client.getLoggingService();
String correlationId = "corr_abc123";

// DB operation
logger.logDb(correlationId, "save", "orders", order, durationMs);

// Email
logger.logEmail(correlationId, "send", "john@example.com", data, durationMs);

// Cache
logger.logCache(correlationId, "set", "order:123", null, durationMs);

// Queue
logger.logQueue(correlationId, "publish", "order-events", event, durationMs);
```

---

## 9. Error Handling

### Global Error Mappers

```java
CBQRestClientBuilder.builder()
    .addErrorMapper(ErrorMapper.onStatus(
        status -> status == HttpStatus.NOT_FOUND,
        ctx -> new ResourceNotFoundException("Not found: " + ctx.getUri())))
    
    .addErrorMapper(ErrorMapper.onStatus(
        status -> status == HttpStatus.UNAUTHORIZED,
        ctx -> new AuthException("Authentication failed")))
    
    .addErrorMapper(ErrorMapper.onStatus(
        HttpStatus::is5xxServerError,
        ctx -> new ServiceException("Service error: " + ctx.getBody())))
    
    .build();
```

### Per-Request Error Handling

```java
User user = client.get()
    .uri("/users/{}", userId)
    .onStatus(
        status -> status == HttpStatus.NOT_FOUND,
        ctx -> new UserNotFoundException("User not found: " + userId))
    .retrieveBody(User.class)
    .block();
```

### Try-Catch Pattern

```java
try {
    Order order = CBQWorkflow
        .startWith(() -> client.post().uri("/orders").retrieve(Order.class))
        .execute();
    return ApiResponse.success(order);
    
} catch (ResourceNotFoundException e) {
    return ApiResponse.error("NOT_FOUND", e.getMessage());
    
} catch (CBQRestClientException e) {
    log.error("HTTP error - requestId: {}", e.getRequestId(), e);
    return ApiResponse.error("SERVICE_ERROR", "Please try again");
    
} catch (Exception e) {
    return ApiResponse.error("INTERNAL_ERROR", "Unexpected error");
}
```

---

## 10. Filters

### Built-in Filters

```java
// Bearer token (dynamic)
Filters.bearerToken(() -> tokenService.getAccessToken())

// Basic auth
Filters.basicAuth("username", "password")

// API key
Filters.apiKey("X-API-Key", "my-api-key")

// Custom headers
Filters.headers("X-Client", "my-app", "X-Version", "1.0")
```

### Custom Filter

```java
RequestFilter correlationFilter = context -> {
    String correlationId = MDC.get("correlationId");
    if (correlationId != null) {
        context.addHeader("X-Correlation-Id", correlationId);
    }
    return Mono.just(context);
};

CBQRestClientBuilder.builder()
    .addRequestFilter(correlationFilter)
    .build();
```

---

## 11. Real-World Examples

### Payment Service (Proper Reactive)

```java
@Service
public class PaymentService {
    
    private final CBQRestClient client;
    private final PaymentRepository repository;  // Can be R2DBC or JDBC
    private final ErrorLogRepository errorLogRepo;
    
    /**
     * Process payment with full observability.
     * Returns Mono - never blocks!
     */
    public Mono<PaymentResult> processPayment(PaymentRequest request) {
        String correlationId = UUID.randomUUID().toString();
        
        return CBQWorkflow
            // 1. Fraud check
            .http(() -> client.post()
                .uri("/fraud/check")
                .header("X-Correlation-Id", correlationId)
                .bodyValue(request)
                .retrieve(FraudResult.class))
            
            // 2. Validate (with business logic)
            .filter(
                fraud -> fraud.getRiskScore() <= 80,
                () -> new FraudException("High risk transaction")
            )
            
            // 3. Get card details
            .thenHttp(fraud -> client.post()
                .uri("/validation")
                .bodyValue(request)
                .retrieve(ValidationResult.class))
            
            // 4. Charge
            .thenHttp(validation -> client.post()
                .uri("/charge")
                .bodyValue(new ChargeRequest(validation.getToken(), request.getAmount()))
                .retrieve(PaymentResult.class))
            
            // 5. Save to DB (JDBC - properly offloaded)
            .thenBlocking(payment -> {
                repository.save(Payment.from(payment));
                return payment;
            })
            
            // On error: Rollback via API
            .onErrorRollback(error -> client.post()
                .uri("/payments/rollback")
                .bodyValue(new RollbackRequest(request.getTransactionId()))
                .retrieve(Void.class))
            
            // On error: Log to DB (fire-and-forget)
            .onErrorLog(error -> 
                errorLogRepo.save(new ErrorLog(correlationId, error.getMessage())))
            
            // Fire-and-forget: Send confirmation email
            .fireAndForget(payment -> client.post()
                .uri("/notifications/email")
                .bodyValue(new EmailRequest(request.getEmail(), payment.getId()))
                .retrieve(Void.class))
            
            .toMono();
    }
}
```

### Dashboard Aggregation (Parallel)

```java
@Service
public class DashboardService {
    
    private final CBQRestClient client;
    
    public Mono<DashboardData> getDashboard(String userId) {
        // Execute all in parallel with partial success
        return client.parallel(
            client.get().uri("/users/{}", userId).retrieve(User.class),
            client.get().uri("/orders/recent?userId={}", userId).retrieve(OrderList.class),
            client.get().uri("/notifications?userId={}", userId).retrieve(NotificationList.class),
            client.get().uri("/recommendations?userId={}", userId).retrieve(RecommendationList.class)
        )
        .partialSuccess()  // Don't fail if recommendations is down
        .execute()
        .map(result -> {
            DashboardData dashboard = new DashboardData();
            dashboard.setUser((User) getResult(result, 0));
            dashboard.setOrders((OrderList) getResult(result, 1));
            dashboard.setNotifications((NotificationList) getResult(result, 2));
            dashboard.setRecommendations((RecommendationList) getResult(result, 3));
            return dashboard;
        });
    }
    
    private Object getResult(CBQParallelResult<?> result, int index) {
        return result.getErrors().containsKey(index) 
            ? null 
            : result.getResponses().get(index).getBody();
    }
}
```

### Order with Partial Results

```java
@Service
public class OrderService {
    
    private final CBQRestClient client;
    private final AuditRepository auditRepo;
    
    /**
     * Get order with optional enrichment.
     * If enrichment fails, still return basic order.
     */
    public Mono<EnrichedOrder> getEnrichedOrder(String orderId) {
        
        return CBQWorkflow
            // Step 1: Get basic order (must succeed)
            .http(() -> client.get()
                .uri("/orders/{}", orderId)
                .retrieve(Order.class))
            .capture()  // Save for later
            
            // Step 2: Get customer details (optional)
            .thenHttpOptional(order -> client.get()
                .uri("/customers/{}", order.getCustomerId())
                .retrieve(Customer.class))
            
            // Combine results
            .combineWithCaptured((optResult, order) -> {
                Customer customer = optResult.getResult().orElse(null);
                return new EnrichedOrder(order, customer);
            })
            
            // Fire-and-forget: Audit log
            .fireAndForgetBlocking(enriched -> 
                auditRepo.logAccess("order_viewed", enriched.getOrder().getId()))
            
            .toMono();
    }
}
```

### Controller Example

```java
@RestController
@RequestMapping("/api/payments")
public class PaymentController {
    
    private final PaymentService paymentService;
    
    @PostMapping
    public Mono<ResponseEntity<PaymentResult>> processPayment(
            @RequestBody PaymentRequest request) {
        
        return paymentService.processPayment(request)
            .map(ResponseEntity::ok)
            .onErrorResume(FraudException.class, e -> 
                Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(PaymentResult.failed(e.getMessage()))))
            .onErrorResume(InsufficientBalanceException.class, e -> 
                Mono.just(ResponseEntity.badRequest()
                    .body(PaymentResult.failed(e.getMessage()))));
    }
}
```
```

---

## 💡 Tips

1. **Always call `shutdown()`** when your application stops
2. **Use `correlationId`** to trace requests across services
3. **Use `stepContinueOnError()`** for non-critical steps
4. **Use `fireAndForget*()`** for background tasks that shouldn't block response
5. **Use `partialSuccess()`** for parallel calls where some can fail
6. **Mask sensitive fields** in logs (passwords, tokens, card numbers)
7. **Set appropriate timeouts** per endpoint type

---

## 📞 Support

For questions or issues, contact the platform team.
