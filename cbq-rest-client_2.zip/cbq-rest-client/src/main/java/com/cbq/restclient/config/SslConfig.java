package com.cbq.restclient.config;

import java.time.Duration;

/**
 * SSL/TLS configuration for secure connections.
 */
public class SslConfig {
    
    private boolean enabled = false;
    private boolean insecure = false;
    private String certificatePath;
    private String keystorePath;
    private String keystorePassword;
    private String keystoreType = "PKCS12";
    private Duration handshakeTimeout = Duration.ofSeconds(10);

    private SslConfig() {}

    /**
     * Creates an insecure SSL config (for development only!)
     * Uses InsecureTrustManager that trusts all certificates.
     */
    public static SslConfig defaultInsecure() {
        SslConfig config = new SslConfig();
        config.enabled = true;
        config.insecure = true;
        return config;
    }

    /**
     * Creates a custom SSL config builder
     */
    public static SslConfig custom() {
        return new SslConfig();
    }

    /**
     * Disabled SSL config
     */
    public static SslConfig disabled() {
        return new SslConfig();
    }

    public SslConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public SslConfig certificatePath(String path) {
        this.certificatePath = path;
        this.enabled = true;
        return this;
    }

    public SslConfig keystore(String path, String password) {
        this.keystorePath = path;
        this.keystorePassword = password;
        this.enabled = true;
        return this;
    }

    public SslConfig keystoreType(String type) {
        this.keystoreType = type;
        return this;
    }

    public SslConfig handshakeTimeout(Duration timeout) {
        this.handshakeTimeout = timeout;
        return this;
    }

    public boolean isEnabled() { return enabled; }
    public boolean isInsecure() { return insecure; }
    public String getCertificatePath() { return certificatePath; }
    public String getKeystorePath() { return keystorePath; }
    public String getKeystorePassword() { return keystorePassword; }
    public String getKeystoreType() { return keystoreType; }
    public Duration getHandshakeTimeout() { return handshakeTimeout; }
}
