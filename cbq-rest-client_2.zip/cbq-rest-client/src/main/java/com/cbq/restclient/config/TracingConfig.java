package com.cbq.restclient.config;

import java.util.*;

/**
 * Tracing and correlation configuration.
 * 
 * <p>Supports:</p>
 * <ul>
 *   <li>X-Correlation-Id propagation and generation</li>
 *   <li>OpenTelemetry / Sleuth traceId/spanId</li>
 *   <li>Custom header propagation</li>
 * </ul>
 */
public class TracingConfig {

    private boolean enabled = false;
    
    // Correlation ID
    private boolean correlationIdEnabled = true;
    private String correlationIdHeader = "X-Correlation-Id";
    private boolean generateIfMissing = true;
    
    // OpenTelemetry / Sleuth integration
    private boolean openTelemetryEnabled = false;
    private String traceIdHeader = "X-B3-TraceId";
    private String spanIdHeader = "X-B3-SpanId";
    private String parentSpanIdHeader = "X-B3-ParentSpanId";
    private String sampledHeader = "X-B3-Sampled";
    
    // W3C Trace Context (alternative to B3)
    private boolean w3cTraceContextEnabled = false;
    private String traceParentHeader = "traceparent";
    private String traceStateHeader = "tracestate";
    
    // Additional headers to propagate
    private Set<String> propagateHeaders = new HashSet<>();

    private TracingConfig() {}

    public static TracingConfig disabled() {
        return new TracingConfig();
    }

    public static TracingConfig defaults() {
        return new TracingConfig().enabled(true);
    }

    public static TracingConfig custom() {
        return new TracingConfig().enabled(true);
    }

    public TracingConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    // Correlation ID settings
    public TracingConfig correlationId(boolean enabled) {
        this.correlationIdEnabled = enabled;
        return this;
    }

    public TracingConfig correlationIdHeader(String header) {
        this.correlationIdHeader = header;
        return this;
    }

    public TracingConfig generateCorrelationIdIfMissing(boolean generate) {
        this.generateIfMissing = generate;
        return this;
    }

    // OpenTelemetry / Sleuth (B3 propagation)
    public TracingConfig openTelemetry(boolean enabled) {
        this.openTelemetryEnabled = enabled;
        return this;
    }

    public TracingConfig b3Headers(String traceId, String spanId, String parentSpanId, String sampled) {
        this.traceIdHeader = traceId;
        this.spanIdHeader = spanId;
        this.parentSpanIdHeader = parentSpanId;
        this.sampledHeader = sampled;
        return this;
    }

    // W3C Trace Context
    public TracingConfig w3cTraceContext(boolean enabled) {
        this.w3cTraceContextEnabled = enabled;
        return this;
    }

    // Additional header propagation
    public TracingConfig propagateHeaders(String... headers) {
        this.propagateHeaders.addAll(Arrays.asList(headers));
        return this;
    }

    // Getters
    public boolean isEnabled() { return enabled; }
    public boolean isCorrelationIdEnabled() { return correlationIdEnabled; }
    public String getCorrelationIdHeader() { return correlationIdHeader; }
    public boolean isGenerateIfMissing() { return generateIfMissing; }
    public boolean isOpenTelemetryEnabled() { return openTelemetryEnabled; }
    public String getTraceIdHeader() { return traceIdHeader; }
    public String getSpanIdHeader() { return spanIdHeader; }
    public String getParentSpanIdHeader() { return parentSpanIdHeader; }
    public String getSampledHeader() { return sampledHeader; }
    public boolean isW3cTraceContextEnabled() { return w3cTraceContextEnabled; }
    public String getTraceParentHeader() { return traceParentHeader; }
    public String getTraceStateHeader() { return traceStateHeader; }
    public Set<String> getPropagateHeaders() { return propagateHeaders; }

    /**
     * Returns all headers that should be propagated
     */
    public Set<String> getAllPropagationHeaders() {
        Set<String> headers = new HashSet<>(propagateHeaders);
        
        if (correlationIdEnabled) {
            headers.add(correlationIdHeader);
        }
        
        if (openTelemetryEnabled) {
            headers.add(traceIdHeader);
            headers.add(spanIdHeader);
            headers.add(parentSpanIdHeader);
            headers.add(sampledHeader);
        }
        
        if (w3cTraceContextEnabled) {
            headers.add(traceParentHeader);
            headers.add(traceStateHeader);
        }
        
        return headers;
    }
}
