package com.cbq.restclient.core;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Utility methods for mixing reactive and blocking operations.
 * 
 * <h2>Key Methods</h2>
 * <ul>
 *   <li>{@link #blocking(Supplier)} - Execute blocking call, returns Mono (for reactive chains)</li>
 *   <li>{@link #blockingWithContext(Callable)} - Same but with MDC propagation</li>
 *   <li>{@link #fireAndForget(Runnable)} - Fire-and-forget on platform thread</li>
 *   <li>{@link #fireAndForgetWithContext(Runnable)} - Same but with MDC propagation</li>
 *   <li>{@link #background(Supplier)} - Run on platform thread, returns CompletableFuture</li>
 * </ul>
 * 
 * <h2>Usage in Reactive Chain</h2>
 * <pre>{@code
 * return client.get().uri("/api").retrieve(User.class)
 *     .flatMap(response -> CBQWorkflow.blockingWithContext(() -> 
 *         userRepository.save(response.getBody())))
 *     .map(saved -> ResponseEntity.ok(saved));
 * }</pre>
 * 
 * <h2>Fire-and-Forget</h2>
 * <pre>{@code
 * CBQWorkflow.fireAndForgetWithContext(() -> auditRepo.log(event));
 * }</pre>
 */
@Slf4j
public final class CBQWorkflow {

    private CBQWorkflow() {} // Utility class

    // ═══════════════════════════════════════════════════════════════════════════
    // BLOCKING -> REACTIVE (for use in reactive chains)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Execute blocking call on boundedElastic, returns Mono.
     * Use in reactive chains via flatMap.
     * 
     * @param blockingCall The blocking operation (JDBC, file I/O, etc.)
     * @return Mono that completes when blocking call finishes
     */
    public static <T> Mono<T> blocking(Supplier<T> blockingCall) {
        return Mono.fromCallable(blockingCall::get)
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Execute blocking call with MDC context propagation.
     * Preserves correlation ID, trace ID across thread boundary.
     * 
     * @param blockingCall The blocking operation
     * @return Mono that completes when blocking call finishes
     */
    public static <T> Mono<T> blockingWithContext(Callable<T> blockingCall) {
        Map<String, String> mdc = MDC.getCopyOfContextMap();
        
        return Mono.fromCallable(() -> {
            Map<String, String> previous = MDC.getCopyOfContextMap();
            try {
                if (mdc != null && !mdc.isEmpty()) {
                    MDC.setContextMap(mdc);
                }
                return blockingCall.call();
            } finally {
                if (previous != null) {
                    MDC.setContextMap(previous);
                } else {
                    MDC.clear();
                }
            }
        }).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Execute blocking void operation with MDC context.
     */
    public static Mono<Void> blockingRunWithContext(Runnable blockingCall) {
        Map<String, String> mdc = MDC.getCopyOfContextMap();
        
        return Mono.fromRunnable(() -> {
            Map<String, String> previous = MDC.getCopyOfContextMap();
            try {
                if (mdc != null && !mdc.isEmpty()) {
                    MDC.setContextMap(mdc);
                }
                blockingCall.run();
            } finally {
                if (previous != null) {
                    MDC.setContextMap(previous);
                } else {
                    MDC.clear();
                }
            }
        }).subscribeOn(Schedulers.boundedElastic()).then();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // FIRE AND FORGET (detached execution)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Fire-and-forget on platform thread (boundedElastic).
     * Does not block caller. Errors are logged but not propagated.
     * 
     * @param task The task to execute
     */
    public static void fireAndForget(Runnable task) {
        Schedulers.boundedElastic().schedule(() -> {
            try {
                task.run();
            } catch (Exception e) {
                log.warn("Fire-and-forget task failed: {}", e.getMessage(), e);
            }
        });
    }

    /**
     * Fire-and-forget with MDC context propagation.
     * Preserves correlation ID for logging/tracing.
     * 
     * @param task The task to execute
     */
    public static void fireAndForgetWithContext(Runnable task) {
        Map<String, String> mdc = MDC.getCopyOfContextMap();
        
        Schedulers.boundedElastic().schedule(() -> {
            Map<String, String> previous = MDC.getCopyOfContextMap();
            try {
                if (mdc != null && !mdc.isEmpty()) {
                    MDC.setContextMap(mdc);
                }
                task.run();
            } catch (Exception e) {
                log.warn("Fire-and-forget task failed: {}", e.getMessage(), e);
            } finally {
                if (previous != null) {
                    MDC.setContextMap(previous);
                } else {
                    MDC.clear();
                }
            }
        });
    }

    /**
     * Fire-and-forget with custom error handler.
     */
    public static void fireAndForget(Runnable task, Consumer<Throwable> errorHandler) {
        Schedulers.boundedElastic().schedule(() -> {
            try {
                task.run();
            } catch (Exception e) {
                try {
                    errorHandler.accept(e);
                } catch (Exception handlerError) {
                    log.error("Error handler also failed: {}", handlerError.getMessage(), handlerError);
                }
            }
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BACKGROUND EXECUTION (returns Future)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Execute on background thread, returns CompletableFuture.
     * Use when you need the result later but don't want to block now.
     * 
     * @param task The task to execute
     * @return CompletableFuture for the result
     */
    public static <T> CompletableFuture<T> background(Supplier<T> task) {
        CompletableFuture<T> future = new CompletableFuture<>();
        
        Schedulers.boundedElastic().schedule(() -> {
            try {
                future.complete(task.get());
            } catch (Exception e) {
                future.completeExceptionally(e);
            }
        });
        
        return future;
    }

    /**
     * Execute on background thread with MDC context, returns CompletableFuture.
     */
    public static <T> CompletableFuture<T> backgroundWithContext(Callable<T> task) {
        Map<String, String> mdc = MDC.getCopyOfContextMap();
        CompletableFuture<T> future = new CompletableFuture<>();
        
        Schedulers.boundedElastic().schedule(() -> {
            Map<String, String> previous = MDC.getCopyOfContextMap();
            try {
                if (mdc != null && !mdc.isEmpty()) {
                    MDC.setContextMap(mdc);
                }
                future.complete(task.call());
            } catch (Exception e) {
                future.completeExceptionally(e);
            } finally {
                if (previous != null) {
                    MDC.setContextMap(previous);
                } else {
                    MDC.clear();
                }
            }
        });
        
        return future;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CONTEXT UTILITIES
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Capture current MDC context for manual propagation.
     * 
     * @return Immutable copy of current MDC context
     */
    public static Map<String, String> captureContext() {
        Map<String, String> mdc = MDC.getCopyOfContextMap();
        return mdc != null ? Collections.unmodifiableMap(mdc) : Collections.emptyMap();
    }

    /**
     * Run with specific MDC context.
     * 
     * @param context The MDC context to use
     * @param task The task to run
     */
    public static void runWithContext(Map<String, String> context, Runnable task) {
        Map<String, String> previous = MDC.getCopyOfContextMap();
        try {
            if (context != null && !context.isEmpty()) {
                MDC.setContextMap(context);
            }
            task.run();
        } finally {
            if (previous != null) {
                MDC.setContextMap(previous);
            } else {
                MDC.clear();
            }
        }
    }

    /**
     * Call with specific MDC context.
     */
    public static <T> T callWithContext(Map<String, String> context, Callable<T> task) throws Exception {
        Map<String, String> previous = MDC.getCopyOfContextMap();
        try {
            if (context != null && !context.isEmpty()) {
                MDC.setContextMap(context);
            }
            return task.call();
        } finally {
            if (previous != null) {
                MDC.setContextMap(previous);
            } else {
                MDC.clear();
            }
        }
    }
}
