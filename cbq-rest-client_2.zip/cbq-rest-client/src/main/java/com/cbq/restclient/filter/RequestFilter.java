package com.cbq.restclient.filter;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * Request filter for intercepting outgoing requests.
 * 
 * <p>Use cases:</p>
 * <ul>
 *   <li>Add authentication tokens</li>
 *   <li>Add audit headers</li>
 *   <li>Header enrichment</li>
 *   <li>Request validation</li>
 * </ul>
 */
@FunctionalInterface
public interface RequestFilter {
    
    /**
     * Filters the request before it's sent.
     * 
     * @param context The request context
     * @return Mono that completes with the (possibly modified) context, 
     *         or errors to abort the request
     */
    Mono<RequestContext> filter(RequestContext context);

    /**
     * Request context available to filters
     */
    class RequestContext {
        private final String requestId;
        private final HttpMethod method;
        private String uri;
        private final HttpHeaders headers;
        private Object body;
        private final Map<String, Object> attributes;

        public RequestContext(String requestId, HttpMethod method, String uri, 
                            HttpHeaders headers, Object body, Map<String, Object> attributes) {
            this.requestId = requestId;
            this.method = method;
            this.uri = uri;
            this.headers = headers;
            this.body = body;
            this.attributes = attributes;
        }

        public String getRequestId() { return requestId; }
        public HttpMethod getMethod() { return method; }
        public String getUri() { return uri; }
        public HttpHeaders getHeaders() { return headers; }
        public Object getBody() { return body; }
        public Map<String, Object> getAttributes() { return attributes; }

        public void setUri(String uri) { this.uri = uri; }
        public void setBody(Object body) { this.body = body; }
        
        public void addHeader(String name, String value) {
            headers.add(name, value);
        }
        
        public boolean hasHeader(String name) {
            return headers.containsKey(name);
        }
        
        public String getHeader(String name) {
            return headers.getFirst(name);
        }
        
        public void setAttribute(String key, Object value) {
            attributes.put(key, value);
        }
        
        @SuppressWarnings("unchecked")
        public <T> T getAttribute(String key) {
            return (T) attributes.get(key);
        }
    }
}
