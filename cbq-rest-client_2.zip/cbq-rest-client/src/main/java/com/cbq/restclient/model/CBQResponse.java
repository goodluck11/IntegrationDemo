package com.cbq.restclient.model;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

/**
 * Response wrapper containing body, status, headers, and metadata.
 */
public class CBQResponse<T> {

    private final T body;
    private final HttpStatus status;
    private final HttpHeaders headers;
    private final long durationMs;
    private final String requestId;
    private final String correlationId;

    private CBQResponse(Builder<T> builder) {
        this.body = builder.body;
        this.status = builder.status;
        this.headers = builder.headers;
        this.durationMs = builder.durationMs;
        this.requestId = builder.requestId;
        this.correlationId = builder.correlationId;
    }

    public T getBody() { return body; }
    public HttpStatus getStatus() { return status; }
    public int getStatusCode() { return status.value(); }
    public HttpHeaders getHeaders() { return headers; }
    public long getDurationMs() { return durationMs; }
    public String getRequestId() { return requestId; }
    public String getCorrelationId() { return correlationId; }

    public boolean isSuccessful() { return status.is2xxSuccessful(); }
    public boolean isClientError() { return status.is4xxClientError(); }
    public boolean isServerError() { return status.is5xxServerError(); }
    public boolean isRedirect() { return status.is3xxRedirection(); }

    public String getHeader(String name) {
        return headers.getFirst(name);
    }

    public static <T> Builder<T> builder() {
        return new Builder<>();
    }

    public static class Builder<T> {
        private T body;
        private HttpStatus status;
        private HttpHeaders headers = new HttpHeaders();
        private long durationMs;
        private String requestId;
        private String correlationId;

        public Builder<T> body(T body) {
            this.body = body;
            return this;
        }

        public Builder<T> status(HttpStatus status) {
            this.status = status;
            return this;
        }

        public Builder<T> statusCode(int code) {
            this.status = HttpStatus.resolve(code);
            return this;
        }

        public Builder<T> headers(HttpHeaders headers) {
            this.headers = headers;
            return this;
        }

        public Builder<T> durationMs(long durationMs) {
            this.durationMs = durationMs;
            return this;
        }

        public Builder<T> requestId(String requestId) {
            this.requestId = requestId;
            return this;
        }

        public Builder<T> correlationId(String correlationId) {
            this.correlationId = correlationId;
            return this;
        }

        public CBQResponse<T> build() {
            return new CBQResponse<>(this);
        }
    }
}
