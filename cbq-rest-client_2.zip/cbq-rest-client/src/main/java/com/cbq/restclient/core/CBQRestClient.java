package com.cbq.restclient.core;

import com.cbq.restclient.config.*;
import com.cbq.restclient.email.EmailNotifier;
import com.cbq.restclient.exception.CBQRestClientException;
import com.cbq.restclient.filter.*;
import com.cbq.restclient.logging.LoggingService;
import com.cbq.restclient.model.*;
import com.cbq.restclient.resilience.ResilienceManager;
import com.cbq.restclient.ssl.SslContextFactory;
import com.cbq.restclient.tracing.TracingService;
import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Production-ready HTTP client with full resilience, observability, and safety features.
 */
public class CBQRestClient {
    private static final Logger log = LoggerFactory.getLogger(CBQRestClient.class);

    private final CBQRestClientConfig config;
    private final WebClient webClient;
    private final ResilienceManager resilienceManager;
    private final LoggingService loggingService;
    private final EmailNotifier emailNotifier;
    private final TracingService tracingService;
    private final Scheduler parallelScheduler;

    CBQRestClient(CBQRestClientConfig config, WebClient webClient,
                  ResilienceManager resilienceManager, LoggingService loggingService,
                  EmailNotifier emailNotifier, TracingService tracingService) {
        this.config = config;
        this.webClient = webClient;
        this.resilienceManager = resilienceManager;
        this.loggingService = loggingService;
        this.emailNotifier = emailNotifier;
        this.tracingService = tracingService;
        this.parallelScheduler = Schedulers.newBoundedElastic(
                10, 100, "cbq-parallel-" + config.getName());
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HTTP Methods
    // ═══════════════════════════════════════════════════════════════════════════

    public RequestSpec get() { return new RequestSpec(this, HttpMethod.GET); }
    public RequestSpec post() { return new RequestSpec(this, HttpMethod.POST); }
    public RequestSpec put() { return new RequestSpec(this, HttpMethod.PUT); }
    public RequestSpec delete() { return new RequestSpec(this, HttpMethod.DELETE); }
    public RequestSpec patch() { return new RequestSpec(this, HttpMethod.PATCH); }
    public RequestSpec head() { return new RequestSpec(this, HttpMethod.HEAD); }
    public RequestSpec options() { return new RequestSpec(this, HttpMethod.OPTIONS); }

    // ═══════════════════════════════════════════════════════════════════════════
    // Parallel & Sequential Execution
    // ═══════════════════════════════════════════════════════════════════════════

    @SafeVarargs
    public final <T> ParallelBuilder<T> parallel(Mono<CBQResponse<T>>... requests) {
        return new ParallelBuilder<>(this, Arrays.asList(requests));
    }

    public SequenceBuilder sequence() {
        return new SequenceBuilder(this);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Request Specification
    // ═══════════════════════════════════════════════════════════════════════════

    public static class RequestSpec {
        private final CBQRestClient client;
        private final HttpMethod method;
        private String uri = "";
        private final HttpHeaders headers = new HttpHeaders();
        private Object body;
        private MediaType contentType = MediaType.APPLICATION_JSON;
        private RequestOverride override;
        private EmailNotification emailNotification;
        private final List<ErrorMapper> errorMappers = new ArrayList<>();

        RequestSpec(CBQRestClient client, HttpMethod method) {
            this.client = client;
            this.method = method;
        }

        public RequestSpec uri(String uri) {
            this.uri = uri;
            return this;
        }

        public RequestSpec uri(String template, Object... vars) {
            this.uri = String.format(template.replace("{}", "%s"), vars);
            return this;
        }

        public RequestSpec header(String name, String value) {
            this.headers.add(name, value);
            return this;
        }

        public RequestSpec headers(Consumer<HttpHeaders> consumer) {
            consumer.accept(this.headers);
            return this;
        }

        public RequestSpec bodyValue(Object body) {
            this.body = body;
            return this;
        }

        public RequestSpec contentType(MediaType contentType) {
            this.contentType = contentType;
            return this;
        }

        public RequestSpec override(Consumer<RequestOverride> configurer) {
            this.override = RequestOverride.create();
            configurer.accept(this.override);
            return this;
        }

        public RequestSpec onStatus(java.util.function.Predicate<HttpStatus> predicate,
                                   java.util.function.Function<ErrorMapper.ErrorContext, Throwable> mapper) {
            this.errorMappers.add(ErrorMapper.onStatus(predicate, mapper));
            return this;
        }

        public RequestSpec onErrorNotify(Consumer<EmailNotification> configurer) {
            this.emailNotification = EmailNotification.create();
            configurer.accept(this.emailNotification);
            return this;
        }

        public <T> Mono<CBQResponse<T>> retrieve(Class<T> responseType) {
            return client.execute(this, responseType);
        }

        public Mono<CBQResponse<String>> retrieve() {
            return client.execute(this, String.class);
        }

        public <T> Mono<T> retrieveBody(Class<T> responseType) {
            return retrieve(responseType).map(CBQResponse::getBody);
        }

        public <T> Flux<T> retrieveFlux(Class<T> responseType) {
            return client.executeFlux(this, responseType);
        }

        // Getters for internal use
        HttpMethod getMethod() { return method; }
        String getUri() { return uri; }
        HttpHeaders getHeaders() { return headers; }
        Object getBody() { return body; }
        MediaType getContentType() { return contentType; }
        RequestOverride getOverride() { return override; }
        EmailNotification getEmailNotification() { return emailNotification; }
        List<ErrorMapper> getErrorMappers() { return errorMappers; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Internal Execution
    // ═══════════════════════════════════════════════════════════════════════════

    <T> Mono<CBQResponse<T>> execute(RequestSpec spec, Class<T> responseType) {
        String requestId = tracingService.generateRequestId();
        long startTime = System.currentTimeMillis();
        String fullUrl = buildFullUrl(spec.getUri());

        // Merge global headers with request headers (request headers override global)
        HttpHeaders mergedHeaders = new HttpHeaders();
        // 1. Add global default headers first
        config.getDefaultHeaders().forEach(mergedHeaders::add);
        // 2. Add request-specific headers (overrides global if same name)
        spec.getHeaders().forEach((name, values) -> {
            mergedHeaders.remove(name);  // Remove global header with same name
            values.forEach(v -> mergedHeaders.add(name, v));
        });

        String correlationId = tracingService.getOrCreateCorrelationId(mergedHeaders);

        // Apply request filters
        RequestFilter.RequestContext reqCtx = new RequestFilter.RequestContext(
                requestId, spec.getMethod(), spec.getUri(), mergedHeaders, 
                spec.getBody(), new HashMap<>());

        Mono<RequestFilter.RequestContext> filterChain = Mono.just(reqCtx);
        for (RequestFilter filter : config.getRequestFilters()) {
            filterChain = filterChain.flatMap(filter::filter);
        }

        return filterChain.flatMap(ctx -> {
            // Add tracing headers
            tracingService.addTracingHeaders(ctx.getHeaders(), correlationId);

            // Log request (side-effect, non-blocking)
            loggingService.logRequest(requestId, correlationId, ctx.getMethod().name(), fullUrl,
                    ctx.getHeaders(), ctx.getBody(), 
                    spec.getContentType() != null ? spec.getContentType().toString() : null);

            // Build WebClient request
            WebClient.RequestBodySpec requestSpec = webClient
                    .method(ctx.getMethod())
                    .uri(ctx.getUri());

            ctx.getHeaders().forEach((name, values) -> 
                    values.forEach(v -> requestSpec.header(name, v)));

            WebClient.RequestHeadersSpec<?> headersSpec;
            if (ctx.getBody() != null) {
                headersSpec = requestSpec
                        .contentType(spec.getContentType())
                        .body(BodyInserters.fromValue(ctx.getBody()));
            } else {
                headersSpec = requestSpec;
            }

            // Execute with response timeout
            Duration responseTimeout = getEffectiveTimeout(spec.getOverride());
            Mono<CBQResponse<T>> responseMono = headersSpec
                    .exchangeToMono(clientResponse -> 
                            handleResponse(clientResponse, responseType, requestId, 
                                    correlationId, spec, fullUrl, startTime))
                    .timeout(responseTimeout);

            // Apply resilience patterns
            responseMono = resilienceManager.applyResilience(
                    responseMono, spec.getOverride(), requestId, fullUrl, spec.getMethod().name());

            // Handle errors
            responseMono = responseMono.doOnError(error -> {
                long duration = System.currentTimeMillis() - startTime;
                loggingService.logError(requestId, spec.getMethod().name(), fullUrl, error, duration);
                
                // Notify via email if configured
                if (spec.getEmailNotification() != null && emailNotifier != null) {
                    emailNotifier.notify(
                            new EmailNotifier.ErrorEvent(requestId, correlationId, 
                                    spec.getMethod().name(), fullUrl, error, duration),
                            spec.getEmailNotification());
                }
            });

            return responseMono;
        });
    }

    private <T> Mono<CBQResponse<T>> handleResponse(ClientResponse clientResponse,
                                                     Class<T> responseType,
                                                     String requestId,
                                                     String correlationId,
                                                     RequestSpec spec,
                                                     String url,
                                                     long startTime) {
        HttpStatus status = clientResponse.statusCode();
        HttpHeaders headers = clientResponse.headers().asHttpHeaders();

        // Check for custom error mappers
        List<ErrorMapper> mappers = new ArrayList<>(config.getErrorMappers());
        mappers.addAll(spec.getErrorMappers());

        for (ErrorMapper mapper : mappers) {
            if (mapper.matches(status)) {
                return clientResponse.bodyToMono(String.class)
                        .defaultIfEmpty("")
                        .flatMap(body -> {
                            ErrorMapper.ErrorContext ctx = new ErrorMapper.ErrorContext(
                                    requestId, status, spec.getMethod().name(), url, body, headers);
                            return Mono.error(mapper.mapError(ctx));
                        });
            }
        }

        return clientResponse.bodyToMono(responseType)
                .defaultIfEmpty(createEmptyResponse(responseType))
                .map(body -> {
                    long duration = System.currentTimeMillis() - startTime;

                    // Log response (side-effect, non-blocking)
                    String contentType = headers.getFirst(HttpHeaders.CONTENT_TYPE);
                    loggingService.logResponse(requestId, correlationId, status.value(), headers,
                            body != null ? body.toString() : null, duration, contentType);

                    return CBQResponse.<T>builder()
                            .body(body)
                            .status(status)
                            .headers(headers)
                            .durationMs(duration)
                            .requestId(requestId)
                            .correlationId(correlationId)
                            .build();
                });
    }

    <T> Flux<T> executeFlux(RequestSpec spec, Class<T> responseType) {
        // Merge global headers with request headers (request headers override global)
        HttpHeaders mergedHeaders = new HttpHeaders();
        config.getDefaultHeaders().forEach(mergedHeaders::add);
        spec.getHeaders().forEach((name, values) -> {
            mergedHeaders.remove(name);
            values.forEach(v -> mergedHeaders.add(name, v));
        });

        WebClient.RequestBodySpec requestSpec = webClient
                .method(spec.getMethod())
                .uri(spec.getUri());

        mergedHeaders.forEach((name, values) -> 
                values.forEach(v -> requestSpec.header(name, v)));

        WebClient.RequestHeadersSpec<?> headersSpec;
        if (spec.getBody() != null) {
            headersSpec = requestSpec
                    .contentType(spec.getContentType())
                    .body(BodyInserters.fromValue(spec.getBody()));
        } else {
            headersSpec = requestSpec;
        }

        return headersSpec.retrieve().bodyToFlux(responseType);
    }

    private Duration getEffectiveTimeout(RequestOverride override) {
        if (override != null && override.getResponseTimeout() != null) {
            return override.getResponseTimeout();
        }
        return config.getTimeouts().getResponseTimeout();
    }

    private String buildFullUrl(String uri) {
        String baseUrl = config.getBaseUrl();
        if (baseUrl != null && !baseUrl.isEmpty()) {
            return uri.startsWith("/") ? baseUrl + uri : baseUrl + "/" + uri;
        }
        return uri;
    }

    @SuppressWarnings("unchecked")
    private <T> T createEmptyResponse(Class<T> type) {
        if (type == String.class) return (T) "";
        if (type == Void.class) return null;
        try { return type.getDeclaredConstructor().newInstance(); } 
        catch (Exception e) { return null; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Parallel Builder
    // ═══════════════════════════════════════════════════════════════════════════

    public static class ParallelBuilder<T> {
        private final CBQRestClient client;
        private final List<Mono<CBQResponse<T>>> requests;
        private CBQParallelResult.ParallelStrategy strategy = CBQParallelResult.ParallelStrategy.WAIT_ALL;

        ParallelBuilder(CBQRestClient client, List<Mono<CBQResponse<T>>> requests) {
            this.client = client;
            this.requests = requests;
        }

        public ParallelBuilder<T> waitAll() {
            this.strategy = CBQParallelResult.ParallelStrategy.WAIT_ALL;
            return this;
        }

        public ParallelBuilder<T> failFast() {
            this.strategy = CBQParallelResult.ParallelStrategy.FAIL_FAST;
            return this;
        }

        public ParallelBuilder<T> partialSuccess() {
            this.strategy = CBQParallelResult.ParallelStrategy.PARTIAL_SUCCESS;
            return this;
        }

        public Mono<CBQParallelResult<T>> execute() {
            long startTime = System.currentTimeMillis();
            
            switch (strategy) {
                case FAIL_FAST:
                    return executeFailFast(startTime);
                case PARTIAL_SUCCESS:
                    return executePartialSuccess(startTime);
                case WAIT_ALL:
                default:
                    return executeWaitAll(startTime);
            }
        }

        private Mono<CBQParallelResult<T>> executeWaitAll(long startTime) {
            // Use Mono.zip for wait-all semantics
            @SuppressWarnings("unchecked")
            Mono<CBQResponse<T>>[] monos = requests.toArray(new Mono[0]);
            
            return Mono.zip(Arrays.asList(monos), results -> {
                List<CBQResponse<T>> responses = new ArrayList<>();
                for (Object result : results) {
                    responses.add((CBQResponse<T>) result);
                }
                return CBQParallelResult.<T>builder()
                        .responses(responses)
                        .totalDurationMs(System.currentTimeMillis() - startTime)
                        .strategy(strategy)
                        .build();
            }).subscribeOn(client.parallelScheduler);
        }

        private Mono<CBQParallelResult<T>> executeFailFast(long startTime) {
            // Use Flux.merge which fails fast
            Map<Integer, Throwable> errors = new HashMap<>();
            List<CBQResponse<T>> responses = new ArrayList<>();
            
            return Flux.merge(requests)
                    .collectList()
                    .map(list -> CBQParallelResult.<T>builder()
                            .responses(list)
                            .totalDurationMs(System.currentTimeMillis() - startTime)
                            .strategy(strategy)
                            .build())
                    .subscribeOn(client.parallelScheduler);
        }

        private Mono<CBQParallelResult<T>> executePartialSuccess(long startTime) {
            Map<Integer, Throwable> errors = Collections.synchronizedMap(new HashMap<>());
            List<CBQResponse<T>> responses = Collections.synchronizedList(new ArrayList<>());
            
            List<Mono<CBQResponse<T>>> safeRequests = new ArrayList<>();
            for (int i = 0; i < requests.size(); i++) {
                final int index = i;
                safeRequests.add(requests.get(i)
                        .doOnNext(responses::add)
                        .onErrorResume(e -> {
                            errors.put(index, e);
                            return Mono.empty();
                        }));
            }
            
            return Flux.merge(safeRequests)
                    .then(Mono.fromSupplier(() -> CBQParallelResult.<T>builder()
                            .responses(responses)
                            .errors(errors)
                            .totalDurationMs(System.currentTimeMillis() - startTime)
                            .strategy(strategy)
                            .build()))
                    .subscribeOn(client.parallelScheduler);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Sequence Builder
    // ═══════════════════════════════════════════════════════════════════════════

    public static class SequenceBuilder {
        private final CBQRestClient client;
        private final List<java.util.function.Function<Object, Mono<?>>> steps = new ArrayList<>();

        SequenceBuilder(CBQRestClient client) {
            this.client = client;
        }

        public <T> SequenceBuilder then(java.util.function.Supplier<Mono<CBQResponse<T>>> step) {
            steps.add(prev -> step.get());
            return this;
        }

        public <I, O> SequenceBuilder then(java.util.function.Function<I, Mono<CBQResponse<O>>> step) {
            steps.add(prev -> step.apply((I) prev));
            return this;
        }

        @SuppressWarnings("unchecked")
        public <T> Mono<T> execute() {
            if (steps.isEmpty()) return Mono.empty();
            
            Mono<Object> chain = (Mono<Object>) steps.get(0).apply(null)
                    .map(resp -> ((CBQResponse<?>) resp).getBody());
            
            for (int i = 1; i < steps.size(); i++) {
                final int idx = i;
                chain = chain.flatMap(prev -> 
                        (Mono<Object>) steps.get(idx).apply(prev)
                                .map(resp -> ((CBQResponse<?>) resp).getBody()));
            }
            
            return (Mono<T>) chain;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Lifecycle
    // ═══════════════════════════════════════════════════════════════════════════

    public void shutdown() {
        if (loggingService != null) loggingService.shutdown();
        if (parallelScheduler != null) parallelScheduler.dispose();
    }

    public CBQRestClientConfig getConfig() { return config; }
    public ResilienceManager getResilienceManager() { return resilienceManager; }
}
