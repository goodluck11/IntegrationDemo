package com.cbq.restclient.config;

import com.cbq.restclient.filter.ErrorMapper;
import com.cbq.restclient.filter.RequestFilter;
import com.cbq.restclient.filter.ResponseFilter;

import java.util.*;
import java.util.function.Consumer;

/**
 * Main configuration aggregating all settings for CBQRestClient.
 */
public class CBQRestClientConfig {

    private String name;
    private String baseUrl;
    private Map<String, String> defaultHeaders = new LinkedHashMap<>();
    
    private TimeoutConfig timeouts = TimeoutConfig.defaults();
    private SslConfig ssl = SslConfig.disabled();
    private ResilienceConfig resilience = ResilienceConfig.disabled();
    private LoggingConfig logging = LoggingConfig.disabled();
    private EmailNotifierConfig emailNotifier = EmailNotifierConfig.disabled();
    private TracingConfig tracing = TracingConfig.defaults();
    private MetricsConfig metrics = MetricsConfig.disabled();
    
    private List<RequestFilter> requestFilters = new ArrayList<>();
    private List<ResponseFilter> responseFilters = new ArrayList<>();
    private List<ErrorMapper> errorMappers = new ArrayList<>();

    private CBQRestClientConfig() {}

    public static CBQRestClientConfig create() {
        return new CBQRestClientConfig();
    }

    public static CBQRestClientConfig create(String name) {
        CBQRestClientConfig config = new CBQRestClientConfig();
        config.name = name;
        return config;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // FLUENT SETTERS
    // ═══════════════════════════════════════════════════════════════════════════

    public CBQRestClientConfig name(String name) {
        this.name = name;
        return this;
    }

    public CBQRestClientConfig baseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
        return this;
    }

    public CBQRestClientConfig header(String name, String value) {
        this.defaultHeaders.put(name, value);
        return this;
    }

    public CBQRestClientConfig headers(Consumer<Map<String, String>> headersConsumer) {
        headersConsumer.accept(this.defaultHeaders);
        return this;
    }

    public CBQRestClientConfig timeouts(TimeoutConfig config) {
        this.timeouts = config;
        return this;
    }

    public CBQRestClientConfig timeouts(Consumer<TimeoutConfig> configurer) {
        configurer.accept(this.timeouts);
        return this;
    }

    public CBQRestClientConfig ssl(SslConfig config) {
        this.ssl = config;
        return this;
    }

    public CBQRestClientConfig resilience(ResilienceConfig config) {
        this.resilience = config;
        return this;
    }

    public CBQRestClientConfig logging(LoggingConfig config) {
        this.logging = config;
        return this;
    }

    public CBQRestClientConfig emailNotifier(EmailNotifierConfig config) {
        this.emailNotifier = config;
        return this;
    }

    public CBQRestClientConfig tracing(TracingConfig config) {
        this.tracing = config;
        return this;
    }

    public CBQRestClientConfig metrics(MetricsConfig config) {
        this.metrics = config;
        return this;
    }

    public CBQRestClientConfig metricsEnabled(boolean enabled) {
        this.metrics = enabled ? MetricsConfig.defaults() : MetricsConfig.disabled();
        return this;
    }

    public CBQRestClientConfig tracingEnabled(boolean enabled) {
        this.tracing = enabled ? TracingConfig.defaults() : TracingConfig.disabled();
        return this;
    }

    public CBQRestClientConfig addRequestFilter(RequestFilter filter) {
        this.requestFilters.add(filter);
        return this;
    }

    public CBQRestClientConfig addResponseFilter(ResponseFilter filter) {
        this.responseFilters.add(filter);
        return this;
    }

    public CBQRestClientConfig addErrorMapper(ErrorMapper mapper) {
        this.errorMappers.add(mapper);
        return this;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GETTERS
    // ═══════════════════════════════════════════════════════════════════════════

    public String getName() { return name != null ? name : "cbq-client-" + UUID.randomUUID().toString().substring(0, 8); }
    public String getBaseUrl() { return baseUrl; }
    public Map<String, String> getDefaultHeaders() { return defaultHeaders; }
    public TimeoutConfig getTimeouts() { return timeouts; }
    public SslConfig getSsl() { return ssl; }
    public ResilienceConfig getResilience() { return resilience; }
    public LoggingConfig getLogging() { return logging; }
    public EmailNotifierConfig getEmailNotifier() { return emailNotifier; }
    public TracingConfig getTracing() { return tracing; }
    public MetricsConfig getMetrics() { return metrics; }
    public List<RequestFilter> getRequestFilters() { return requestFilters; }
    public List<ResponseFilter> getResponseFilters() { return responseFilters; }
    public List<ErrorMapper> getErrorMappers() { return errorMappers; }

    /**
     * Creates a copy of this config for per-request overrides
     */
    public CBQRestClientConfig copy() {
        CBQRestClientConfig copy = new CBQRestClientConfig();
        copy.name = this.name;
        copy.baseUrl = this.baseUrl;
        copy.defaultHeaders = new LinkedHashMap<>(this.defaultHeaders);
        copy.timeouts = this.timeouts.copy();
        copy.ssl = this.ssl;
        copy.resilience = this.resilience;
        copy.logging = this.logging;
        copy.emailNotifier = this.emailNotifier;
        copy.tracing = this.tracing;
        copy.metrics = this.metrics;
        copy.requestFilters = new ArrayList<>(this.requestFilters);
        copy.responseFilters = new ArrayList<>(this.responseFilters);
        copy.errorMappers = new ArrayList<>(this.errorMappers);
        return copy;
    }
}
