package com.cbq.restclient.logging.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Lombok-style annotation for structured JSON logging.
 * 
 * <p>Usage:</p>
 * <pre>
 * {@code
 * @StructuredLog
 * public class OrderService {
 *     
 *     public void processOrder(Order order) {
 *         slog.http("POST", "/payments", 200, 145);
 *         slog.db("INSERT", "orders", 45);
 *         slog.email("user@example.com", "Order Confirmed", 230);
 *     }
 * }
 * }
 * </pre>
 * 
 * <p>Since Java doesn't support compile-time code generation like Lombok without
 * annotation processing, use the static factory method instead:</p>
 * <pre>
 * {@code
 * private static final SLog slog = SLog.forClass(OrderService.class);
 * }
 * </pre>
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface StructuredLog {
    
    /**
     * Component name for logs. Defaults to class simple name.
     */
    String component() default "";
}
