package com.cbq.restclient.resilience;

import com.cbq.restclient.config.ResilienceConfig;
import com.cbq.restclient.config.RequestOverride;
import com.cbq.restclient.exception.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;

import java.time.Duration;

/**
 * Manages Resilience4j patterns: Retry, Circuit Breaker, Rate Limiter, Bulkhead.
 * 
 * <p>If Resilience4j is not on the classpath, this manager operates in pass-through mode.</p>
 */
public class ResilienceManager {
    private static final Logger log = LoggerFactory.getLogger(ResilienceManager.class);
    private static final boolean RESILIENCE4J_AVAILABLE = isResilience4jAvailable();

    private final String name;
    private final ResilienceConfig config;
    
    // Resilience4j components (null if library not available)
    private Object retry;
    private Object circuitBreaker;
    private Object rateLimiter;
    private Object bulkhead;

    public ResilienceManager(String name, ResilienceConfig config) {
        this.name = name;
        this.config = config;
        
        if (RESILIENCE4J_AVAILABLE) {
            initializeResilience4j();
        } else {
            log.info("Resilience4j not on classpath - resilience features disabled. " +
                    "Add resilience4j-reactor dependency to enable.");
        }
    }

    private static boolean isResilience4jAvailable() {
        try {
            Class.forName("io.github.resilience4j.reactor.retry.RetryOperator");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    private void initializeResilience4j() {
        try {
            Resilience4jDelegate delegate = new Resilience4jDelegate(name, config);
            this.retry = delegate.getRetry();
            this.circuitBreaker = delegate.getCircuitBreaker();
            this.rateLimiter = delegate.getRateLimiter();
            this.bulkhead = delegate.getBulkhead();
        } catch (Exception e) {
            log.warn("Failed to initialize Resilience4j: {}", e.getMessage());
        }
    }

    /**
     * Applies resilience patterns to a Mono with optional per-request overrides
     */
    public <T> Mono<T> applyResilience(Mono<T> mono, RequestOverride override, 
                                        String requestId, String uri, String method) {
        if (!RESILIENCE4J_AVAILABLE) {
            return mono;  // Pass-through if Resilience4j not available
        }

        try {
            return Resilience4jDelegate.applyResilience(
                    mono, override, config, name, requestId, uri, method,
                    retry, circuitBreaker, rateLimiter, bulkhead);
        } catch (Exception e) {
            log.warn("Failed to apply resilience: {}", e.getMessage());
            return mono;
        }
    }

    public boolean isResilience4jAvailable() {
        return RESILIENCE4J_AVAILABLE;
    }
}
