package com.cbq.restclient.logging;

import com.cbq.restclient.config.LoggingConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Production-safe logging service with:
 * - JSON format (Stripe-style, Splunk-friendly)
 * - Pretty format (human-readable)
 * - Correlation ID tracking across all calls
 * - Max body size limits
 * - Async logging (never blocks Netty)
 * - Field masking for sensitive data
 */
public class LoggingService {
    private static final Logger log = LoggerFactory.getLogger(LoggingService.class);
    
    private final LoggingConfig config;
    private final ObjectMapper objectMapper;
    private final Scheduler loggingScheduler;
    
    // Pre-computed lowercase sets for efficient lookup
    private final Set<String> fieldsToMaskLower;
    private final Set<String> fieldsToExcludeLower;
    
    // Pattern for masking in non-JSON content
    private final Map<String, Pattern> maskPatterns = new HashMap<>();

    public LoggingService(LoggingConfig config) {
        this.config = config;
        this.objectMapper = new ObjectMapper();
        this.loggingScheduler = Schedulers.newBoundedElastic(2, 100, "cbq-logging");
        
        // Pre-compute lowercase sets at startup
        this.fieldsToMaskLower = new HashSet<>();
        for (String field : config.getFieldsToMask()) {
            this.fieldsToMaskLower.add(field.toLowerCase());
        }
        
        this.fieldsToExcludeLower = new HashSet<>();
        for (String field : config.getFieldsToExclude()) {
            this.fieldsToExcludeLower.add(field.toLowerCase());
        }
        
        // Build mask patterns
        for (String field : fieldsToMaskLower) {
            String pattern = String.format("(?i)(\"%s\"\\s*:\\s*\")[^\"]*(\"|$)", field);
            maskPatterns.put(field, Pattern.compile(pattern));
        }
    }

    /**
     * Logs request asynchronously - returns Mono for chaining if needed.
     * Prefer {@link #logRequest} for fire-and-forget logging.
     */
    public Mono<Void> logRequestAsync(String requestId, String correlationId, String method, 
                                       String uri, HttpHeaders headers, Object body, 
                                       String contentType, String taskType) {
        if (!config.isEnabled() || !config.isLogRequest()) {
            return Mono.empty();
        }
        
        return Mono.fromRunnable(() -> doLogRequest(requestId, correlationId, method, uri, 
                headers, body, contentType, taskType))
                .subscribeOn(loggingScheduler)
                .then();
    }
    
    // Backward compatible overload
    public Mono<Void> logRequestAsync(String requestId, String method, String uri,
                                       HttpHeaders headers, Object body, String contentType) {
        return logRequestAsync(requestId, null, method, uri, headers, body, contentType, "http");
    }

    /**
     * Logs response asynchronously - returns Mono for chaining if needed.
     * Prefer {@link #logResponse} for fire-and-forget logging.
     */
    public Mono<Void> logResponseAsync(String requestId, String correlationId, int status, 
                                        HttpHeaders headers, String body, long durationMs, 
                                        String contentType, String taskType) {
        if (!config.isEnabled() || !config.isLogResponse()) {
            return Mono.empty();
        }
        
        return Mono.fromRunnable(() -> doLogResponse(requestId, correlationId, status, headers, 
                body, durationMs, contentType, taskType))
                .subscribeOn(loggingScheduler)
                .then();
    }
    
    // Backward compatible overload
    public Mono<Void> logResponseAsync(String requestId, int status, HttpHeaders headers,
                                        String body, long durationMs, String contentType) {
        return logResponseAsync(requestId, null, status, headers, body, durationMs, contentType, "http");
    }

    /**
     * Fire-and-forget request logging.
     * Non-blocking: offloads to dedicated scheduler internally.
     */
    public void logRequest(String requestId, String correlationId, String method, String uri,
                          HttpHeaders headers, Object body, String contentType) {
        if (!config.isEnabled() || !config.isLogRequest()) {
            return;
        }
        loggingScheduler.schedule(() -> 
            doLogRequest(requestId, correlationId, method, uri, headers, body, contentType, "http"));
    }

    /**
     * Fire-and-forget response logging.
     * Non-blocking: offloads to dedicated scheduler internally.
     */
    public void logResponse(String requestId, String correlationId, int status, HttpHeaders headers,
                           String body, long durationMs, String contentType) {
        if (!config.isEnabled() || !config.isLogResponse()) {
            return;
        }
        loggingScheduler.schedule(() -> 
            doLogResponse(requestId, correlationId, status, headers, body, durationMs, contentType, "http"));
    }

    private void doLogRequest(String requestId, String correlationId, String method, String uri,
                             HttpHeaders headers, Object body, String contentType, String taskType) {
        if (config.getFormat() == LoggingConfig.LogFormat.JSON) {
            logRequestJson(requestId, correlationId, method, uri, headers, body, contentType, taskType);
        } else {
            logRequestPretty(requestId, correlationId, method, uri, headers, body, contentType, taskType);
        }
    }

    private void doLogResponse(String requestId, String correlationId, int status, HttpHeaders headers,
                              String body, long durationMs, String contentType, String taskType) {
        if (config.getFormat() == LoggingConfig.LogFormat.JSON) {
            logResponseJson(requestId, correlationId, status, headers, body, durationMs, contentType, taskType);
        } else {
            logResponsePretty(requestId, correlationId, status, headers, body, durationMs, contentType, taskType);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // JSON FORMAT (Stripe-style, Splunk-friendly)
    // ═══════════════════════════════════════════════════════════════════════════

    private void logRequestJson(String requestId, String correlationId, String method, String uri,
                                HttpHeaders headers, Object body, String contentType, String taskType) {
        logRequestJson(requestId, correlationId, null, method, uri, headers, body, contentType, taskType);
    }

    private void logRequestJson(String requestId, String correlationId, String traceId, String method, String uri,
                                HttpHeaders headers, Object body, String contentType, String taskType) {
        try {
            ObjectNode logNode = objectMapper.createObjectNode();
            
            // Standard fields (Splunk/ELK friendly)
            logNode.put("timestamp", Instant.now().toString());
            logNode.put("level", "INFO");
            logNode.put("service", config.getServiceName());
            logNode.put("version", config.getServiceVersion());
            logNode.put("env", config.getEnvironment().getValue());
            logNode.put("host", config.getHost());
            
            // Event classification
            logNode.put("event", "http_request");
            logNode.put("span_kind", "client");  // outgoing request
            
            // Identifiers
            logNode.put("request_id", requestId);
            if (correlationId != null) {
                logNode.put("correlation_id", correlationId);
            }
            if (traceId != null) {
                logNode.put("trace_id", traceId);
            }
            
            // Request details
            logNode.put("task_type", taskType);
            logNode.put("method", method);
            logNode.put("uri", uri);
            
            if (config.isLogHeaders() && headers != null) {
                ObjectNode headersNode = objectMapper.createObjectNode();
                headers.forEach((name, values) -> {
                    if (!fieldsToExcludeLower.contains(name.toLowerCase())) {
                        String value = maskHeaderValue(name, String.join(", ", values));
                        headersNode.put(name, value);
                    }
                });
                logNode.set("headers", headersNode);
            }
            
            if (body != null && shouldLogBody(contentType)) {
                String bodyStr = formatBodyCompact(body);
                String maskedBody = maskBodyCompact(bodyStr);
                String truncatedBody = truncateBody(maskedBody);
                try {
                    JsonNode bodyNode = objectMapper.readTree(truncatedBody);
                    logNode.set("body", bodyNode);
                } catch (Exception e) {
                    logNode.put("body", truncatedBody);
                }
            }
            
            log.info(objectMapper.writeValueAsString(logNode));
        } catch (Exception e) {
            log.warn("Failed to create JSON log: {}", e.getMessage());
        }
    }

    private void logResponseJson(String requestId, String correlationId, int status, 
                                 HttpHeaders headers, String body, long durationMs, 
                                 String contentType, String taskType) {
        logResponseJson(requestId, correlationId, null, status, headers, body, durationMs, contentType, taskType);
    }

    private void logResponseJson(String requestId, String correlationId, String traceId, int status, 
                                 HttpHeaders headers, String body, long durationMs, 
                                 String contentType, String taskType) {
        try {
            ObjectNode logNode = objectMapper.createObjectNode();
            
            // Standard fields
            logNode.put("timestamp", Instant.now().toString());
            logNode.put("level", status >= 400 ? (status >= 500 ? "ERROR" : "WARN") : "INFO");
            logNode.put("service", config.getServiceName());
            logNode.put("version", config.getServiceVersion());
            logNode.put("env", config.getEnvironment().getValue());
            logNode.put("host", config.getHost());
            
            // Event classification
            logNode.put("event", "http_response");
            logNode.put("span_kind", "client");
            
            // Identifiers
            logNode.put("request_id", requestId);
            if (correlationId != null) {
                logNode.put("correlation_id", correlationId);
            }
            if (traceId != null) {
                logNode.put("trace_id", traceId);
            }
            
            // Response details
            logNode.put("task_type", taskType);
            logNode.put("status", status);
            logNode.put("duration_ms", durationMs);
            
            if (config.isLogHeaders() && headers != null) {
                ObjectNode headersNode = objectMapper.createObjectNode();
                headers.forEach((name, values) -> {
                    if (!fieldsToExcludeLower.contains(name.toLowerCase())) {
                        headersNode.put(name, String.join(", ", values));
                    }
                });
                logNode.set("headers", headersNode);
            }
            
            if (body != null && shouldLogBody(contentType)) {
                String maskedBody = maskBodyCompact(body);
                String truncatedBody = truncateBody(maskedBody);
                try {
                    JsonNode bodyNode = objectMapper.readTree(truncatedBody);
                    logNode.set("body", bodyNode);
                } catch (Exception e) {
                    logNode.put("body", truncatedBody);
                }
            }
            
            log.info(objectMapper.writeValueAsString(logNode));
        } catch (Exception e) {
            log.warn("Failed to create JSON log: {}", e.getMessage());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PRETTY FORMAT (Human-readable)
    // ═══════════════════════════════════════════════════════════════════════════

    private void logRequestPretty(String requestId, String correlationId, String method, String uri,
                                  HttpHeaders headers, Object body, String contentType, String taskType) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════════════════════════╗\n");
        sb.append("║ CBQ HTTP REQUEST [").append(taskType.toUpperCase()).append("]\n");
        sb.append("╠══════════════════════════════════════════════════════════════════╣\n");
        sb.append("║ Request ID: ").append(requestId).append("\n");
        if (correlationId != null) {
            sb.append("║ Correlation ID: ").append(correlationId).append("\n");
        }
        sb.append("║ Method: ").append(method).append("\n");
        sb.append("║ URI: ").append(uri).append("\n");
        
        if (config.isLogHeaders() && headers != null) {
            sb.append("║ Headers:\n");
            headers.forEach((name, values) -> {
                if (!fieldsToExcludeLower.contains(name.toLowerCase())) {
                    String value = String.join(", ", values);
                    value = maskHeaderValue(name, value);
                    sb.append("║   ").append(name).append(": ").append(value).append("\n");
                }
            });
        }
        
        if (body != null && shouldLogBody(contentType)) {
            String bodyStr = formatBody(body, contentType);
            sb.append("║ Body:\n").append(bodyStr).append("\n");
        } else if (body != null) {
            sb.append("║ Body: [").append(contentType).append(" - not logged]\n");
        }
        
        sb.append("╚══════════════════════════════════════════════════════════════════╝");
        
        log.info(sb.toString());
    }

    private void logResponsePretty(String requestId, String correlationId, int status, 
                                   HttpHeaders headers, String body, long durationMs, 
                                   String contentType, String taskType) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════════════════════════╗\n");
        sb.append("║ CBQ HTTP RESPONSE [").append(taskType.toUpperCase()).append("]\n");
        sb.append("╠══════════════════════════════════════════════════════════════════╣\n");
        sb.append("║ Request ID: ").append(requestId).append("\n");
        if (correlationId != null) {
            sb.append("║ Correlation ID: ").append(correlationId).append("\n");
        }
        sb.append("║ Status: ").append(status).append("\n");
        sb.append("║ Duration: ").append(durationMs).append("ms\n");
        
        if (config.isLogHeaders() && headers != null) {
            sb.append("║ Headers:\n");
            headers.forEach((name, values) -> {
                if (!fieldsToExcludeLower.contains(name.toLowerCase())) {
                    String value = String.join(", ", values);
                    sb.append("║   ").append(name).append(": ").append(value).append("\n");
                }
            });
        }
        
        if (body != null && shouldLogBody(contentType)) {
            String maskedBody = maskBody(body);
            String truncatedBody = truncateBody(maskedBody);
            sb.append("║ Body:\n").append(truncatedBody).append("\n");
        } else if (body != null) {
            sb.append("║ Body: [").append(contentType).append(" - not logged]\n");
        }
        
        sb.append("╚══════════════════════════════════════════════════════════════════╝");
        
        log.info(sb.toString());
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HELPER METHODS
    // ═══════════════════════════════════════════════════════════════════════════

    private boolean shouldLogBody(String contentType) {
        return LoggingConfig.shouldLogContentType(contentType);
    }

    private String formatBody(Object body, String contentType) {
        if (body == null) return "";
        
        String bodyStr;
        if (body instanceof String) {
            bodyStr = (String) body;
        } else {
            try {
                bodyStr = objectMapper.writeValueAsString(body);
            } catch (JsonProcessingException e) {
                bodyStr = body.toString();
            }
        }
        
        return truncateBody(maskBody(bodyStr));
    }
    
    private String formatBodyCompact(Object body) {
        if (body == null) return "";
        
        if (body instanceof String) {
            return (String) body;
        }
        try {
            return objectMapper.writeValueAsString(body);
        } catch (JsonProcessingException e) {
            return body.toString();
        }
    }

    private String maskBody(String body) {
        if (body == null || body.isEmpty()) return body;
        
        if (body.trim().startsWith("{") || body.trim().startsWith("[")) {
            try {
                JsonNode node = objectMapper.readTree(body);
                maskJsonNode(node);
                return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(node);
            } catch (Exception e) {
                log.debug("JSON parsing failed: {}", e.getMessage());
            }
        }
        
        return applyPatternMasking(body);
    }
    
    private String maskBodyCompact(String body) {
        if (body == null || body.isEmpty()) return body;
        
        if (body.trim().startsWith("{") || body.trim().startsWith("[")) {
            try {
                JsonNode node = objectMapper.readTree(body);
                maskJsonNode(node);
                return objectMapper.writeValueAsString(node);  // Compact, no pretty print
            } catch (Exception e) {
                log.debug("JSON parsing failed: {}", e.getMessage());
            }
        }
        
        return applyPatternMasking(body);
    }
    
    private String applyPatternMasking(String body) {
        String masked = body;
        for (Map.Entry<String, Pattern> entry : maskPatterns.entrySet()) {
            Matcher matcher = entry.getValue().matcher(masked);
            int visibleChars = config.getFieldMaskLengths().getOrDefault(
                    entry.getKey().toLowerCase(), config.getDefaultVisibleChars());
            masked = matcher.replaceAll("$1" + generateMask(visibleChars) + "$2");
        }
        return masked;
    }

    private void maskJsonNode(JsonNode node) {
        if (node == null) return;
        
        if (node.isObject()) {
            ObjectNode objNode = (ObjectNode) node;
            Iterator<String> fieldNames = objNode.fieldNames();
            List<String> names = new ArrayList<>();
            fieldNames.forEachRemaining(names::add);
            
            for (String fieldName : names) {
                String fieldNameLower = fieldName.toLowerCase();
                
                if (fieldsToExcludeLower.contains(fieldNameLower)) {
                    objNode.remove(fieldName);
                    continue;
                }
                
                boolean shouldMask = fieldsToMaskLower.contains(fieldNameLower) ||
                        shouldMaskPartial(fieldNameLower);
                
                if (shouldMask) {
                    int visibleChars = config.getFieldMaskLengths().getOrDefault(
                            fieldNameLower, config.getDefaultVisibleChars());
                    JsonNode valueNode = objNode.get(fieldName);
                    if (valueNode != null && valueNode.isTextual()) {
                        String value = valueNode.asText();
                        objNode.put(fieldName, maskValue(value, visibleChars));
                    } else if (valueNode != null && !valueNode.isNull()) {
                        objNode.put(fieldName, generateMask(0));
                    }
                } else {
                    maskJsonNode(objNode.get(fieldName));
                }
            }
        } else if (node.isArray()) {
            for (JsonNode element : node) {
                maskJsonNode(element);
            }
        }
    }
    
    private boolean shouldMaskPartial(String fieldNameLower) {
        for (String maskField : fieldsToMaskLower) {
            if (fieldNameLower.contains(maskField) || maskField.contains(fieldNameLower)) {
                return true;
            }
        }
        return false;
    }

    private String maskValue(String value, int visibleChars) {
        if (value == null || value.length() <= visibleChars * 2) {
            return generateMask(0);
        }
        
        String mask = String.valueOf(config.getMaskSymbol()).repeat(
                Math.min(8, value.length() - visibleChars * 2));
        
        if (visibleChars > 0) {
            return value.substring(0, visibleChars) + mask + 
                   value.substring(value.length() - visibleChars);
        }
        return mask;
    }

    private String generateMask(int visibleChars) {
        return String.valueOf(config.getMaskSymbol()).repeat(8);
    }

    private String maskHeaderValue(String headerName, String value) {
        String lowerName = headerName.toLowerCase();
        if (fieldsToMaskLower.contains(lowerName) || 
            lowerName.contains("authorization") || 
            lowerName.contains("token") ||
            lowerName.contains("api-key") ||
            lowerName.contains("apikey")) {
            int visibleChars = config.getFieldMaskLengths().getOrDefault(
                    lowerName, config.getDefaultVisibleChars());
            return maskValue(value, visibleChars);
        }
        return value;
    }

    private String truncateBody(String body) {
        if (body == null) return "";
        
        int maxSize = config.getMaxBodySize();
        if (body.length() <= maxSize) {
            return body;
        }
        
        return body.substring(0, maxSize) + "...[TRUNCATED]";
    }

    public void logError(String requestId, String correlationId, String method, String uri, 
                        Throwable error, long durationMs) {
        if (config.getFormat() == LoggingConfig.LogFormat.JSON) {
            try {
                ObjectNode logNode = objectMapper.createObjectNode();
                
                // Standard fields
                logNode.put("timestamp", Instant.now().toString());
                logNode.put("level", "ERROR");
                logNode.put("service", config.getServiceName());
                logNode.put("version", config.getServiceVersion());
                logNode.put("env", config.getEnvironment().getValue());
                logNode.put("host", config.getHost());
                
                // Event classification
                logNode.put("event", "http_error");
                logNode.put("span_kind", "client");
                
                // Identifiers
                logNode.put("request_id", requestId);
                if (correlationId != null) {
                    logNode.put("correlation_id", correlationId);
                }
                
                // Request details
                logNode.put("method", method);
                logNode.put("uri", uri);
                logNode.put("duration_ms", durationMs);
                
                // Error details
                logNode.put("error", error.getClass().getSimpleName());
                logNode.put("error_message", error.getMessage());
                
                log.error(objectMapper.writeValueAsString(logNode));
            } catch (Exception e) {
                log.error("Request {} {} failed after {}ms: {}", method, uri, durationMs, error.getMessage(), error);
            }
        } else {
            log.error("Request {} {} failed after {}ms: {}", method, uri, durationMs, error.getMessage(), error);
        }
    }
    
    // Backward compatible
    public void logError(String requestId, String method, String uri, Throwable error, long durationMs) {
        logError(requestId, null, method, uri, error, durationMs);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // TASK LOGGING (DB, Email, etc.)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Log a generic task (DB call, email, file operation, etc.)
     * 
     * @param correlationId Shared ID across all calls in workflow
     * @param taskType Type: "db", "email", "file", "cache", etc.
     * @param operation Operation name: "save", "find", "send", etc.
     * @param target Target: table name, email recipient, file path, etc.
     * @param data Optional data to log (will be masked)
     * @param durationMs How long it took
     * @param success Whether it succeeded
     * @param error Error if failed (null if success)
     */
    public void logTask(String correlationId, String taskType, String operation, 
                       String target, Object data, long durationMs, 
                       boolean success, Throwable error) {
        if (!config.isEnabled()) return;
        
        String taskId = "task_" + UUID.randomUUID().toString().substring(0, 8);
        
        if (config.getFormat() == LoggingConfig.LogFormat.JSON) {
            logTaskJson(taskId, correlationId, taskType, operation, target, data, durationMs, success, error);
        } else {
            logTaskPretty(taskId, correlationId, taskType, operation, target, data, durationMs, success, error);
        }
    }

    private void logTaskJson(String taskId, String correlationId, String taskType, 
                            String operation, String target, Object data, 
                            long durationMs, boolean success, Throwable error) {
        try {
            ObjectNode logNode = objectMapper.createObjectNode();
            
            // Standard fields
            logNode.put("timestamp", Instant.now().toString());
            logNode.put("level", success ? "INFO" : "ERROR");
            logNode.put("service", config.getServiceName());
            logNode.put("version", config.getServiceVersion());
            logNode.put("env", config.getEnvironment().getValue());
            logNode.put("host", config.getHost());
            
            // Event classification
            logNode.put("event", taskType + "_" + operation);
            logNode.put("span_kind", "internal");
            
            // Identifiers
            logNode.put("task_id", taskId);
            if (correlationId != null) {
                logNode.put("correlation_id", correlationId);
            }
            
            // Task details
            logNode.put("task_type", taskType);
            logNode.put("operation", operation);
            logNode.put("target", target);
            logNode.put("duration_ms", durationMs);
            logNode.put("success", success);
            
            if (data != null) {
                String dataStr = formatBodyCompact(data);
                String maskedData = maskBodyCompact(dataStr);
                try {
                    JsonNode dataNode = objectMapper.readTree(maskedData);
                    logNode.set("data", dataNode);
                } catch (Exception e) {
                    logNode.put("data", maskedData);
                }
            }
            
            if (error != null) {
                logNode.put("error", error.getClass().getSimpleName());
                logNode.put("error_message", error.getMessage());
            }
            
            if (success) {
                log.info(objectMapper.writeValueAsString(logNode));
            } else {
                log.error(objectMapper.writeValueAsString(logNode));
            }
        } catch (Exception e) {
            log.warn("Failed to create task JSON log: {}", e.getMessage());
        }
    }

    private void logTaskPretty(String taskId, String correlationId, String taskType,
                              String operation, String target, Object data,
                              long durationMs, boolean success, Throwable error) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════════════════════════╗\n");
        sb.append("║ CBQ TASK [").append(taskType.toUpperCase()).append("] - ")
          .append(success ? "SUCCESS" : "FAILED").append("\n");
        sb.append("╠══════════════════════════════════════════════════════════════════╣\n");
        sb.append("║ Task ID: ").append(taskId).append("\n");
        if (correlationId != null) {
            sb.append("║ Correlation ID: ").append(correlationId).append("\n");
        }
        sb.append("║ Operation: ").append(operation).append("\n");
        sb.append("║ Target: ").append(target).append("\n");
        sb.append("║ Duration: ").append(durationMs).append("ms\n");
        
        if (data != null) {
            String dataStr = formatBodyCompact(data);
            String maskedData = maskBodyCompact(dataStr);
            sb.append("║ Data: ").append(truncateBody(maskedData)).append("\n");
        }
        
        if (error != null) {
            sb.append("║ Error: ").append(error.getClass().getSimpleName())
              .append(" - ").append(error.getMessage()).append("\n");
        }
        
        sb.append("╚══════════════════════════════════════════════════════════════════╝");
        
        if (success) {
            log.info(sb.toString());
        } else {
            log.error(sb.toString());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CONVENIENCE METHODS FOR COMMON TASKS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Log a database operation
     */
    public void logDb(String correlationId, String operation, String table, 
                     Object data, long durationMs) {
        logTask(correlationId, "db", operation, table, data, durationMs, true, null);
    }

    public void logDbError(String correlationId, String operation, String table, 
                          Object data, long durationMs, Throwable error) {
        logTask(correlationId, "db", operation, table, data, durationMs, false, error);
    }

    /**
     * Log an email operation
     */
    public void logEmail(String correlationId, String operation, String recipient, 
                        Object data, long durationMs) {
        logTask(correlationId, "email", operation, recipient, data, durationMs, true, null);
    }

    public void logEmailError(String correlationId, String operation, String recipient, 
                             Object data, long durationMs, Throwable error) {
        logTask(correlationId, "email", operation, recipient, data, durationMs, false, error);
    }

    /**
     * Log a cache operation
     */
    public void logCache(String correlationId, String operation, String key, 
                        Object data, long durationMs) {
        logTask(correlationId, "cache", operation, key, data, durationMs, true, null);
    }

    /**
     * Log a queue/message operation
     */
    public void logQueue(String correlationId, String operation, String queue, 
                        Object data, long durationMs) {
        logTask(correlationId, "queue", operation, queue, data, durationMs, true, null);
    }

    /**
     * Log a file operation
     */
    public void logFile(String correlationId, String operation, String path, 
                       long durationMs) {
        logTask(correlationId, "file", operation, path, null, durationMs, true, null);
    }

    public void shutdown() {
        loggingScheduler.dispose();
    }
}
