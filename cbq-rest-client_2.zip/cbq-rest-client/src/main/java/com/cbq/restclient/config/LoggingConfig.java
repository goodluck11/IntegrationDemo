package com.cbq.restclient.config;

import java.net.InetAddress;
import java.util.*;

/**
 * Logging configuration with production safeguards.
 * 
 * <p>Log Formats:</p>
 * <ul>
 *   <li><b>PRETTY</b> - Human-readable box format (default)</li>
 *   <li><b>JSON</b> - Single-line JSON, Splunk-friendly (like Stripe)</li>
 * </ul>
 * 
 * <p>JSON Log Fields:</p>
 * <ul>
 *   <li><b>timestamp</b> - ISO 8601 timestamp</li>
 *   <li><b>level</b> - INFO, WARN, ERROR</li>
 *   <li><b>service</b> - Service name</li>
 *   <li><b>version</b> - Service version</li>
 *   <li><b>env</b> - Environment (dev, staging, production)</li>
 *   <li><b>host</b> - Hostname</li>
 *   <li><b>event</b> - Event type (http_request, http_response, task, etc.)</li>
 *   <li><b>span_kind</b> - client (outgoing) or server (incoming)</li>
 *   <li><b>trace_id</b> - Distributed trace ID</li>
 *   <li><b>correlation_id</b> - Request correlation ID</li>
 *   <li><b>request_id</b> - Unique request ID</li>
 * </ul>
 */
public class LoggingConfig {

    public enum LogFormat {
        PRETTY,  // Human-readable box format
        JSON     // Single-line JSON (Stripe-style, Splunk-friendly)
    }

    public enum Environment {
        DEV("dev"),
        STAGING("staging"),
        PRODUCTION("production"),
        TEST("test");
        
        private final String value;
        Environment(String value) { this.value = value; }
        public String getValue() { return value; }
    }

    private boolean enabled = false;
    private boolean logHeaders = false;
    private boolean logRequest = false;
    private boolean logResponse = false;
    private LogFormat format = LogFormat.PRETTY;
    
    // Service identity
    private String serviceName = "cbq-client";
    private String serviceVersion = "1.0.0";
    private Environment environment = Environment.DEV;
    private String host = resolveHostname();
    
    // Safety: Max body size to log (default 10KB)
    private int maxBodySize = 10_000;
    
    // Field masking - stored as lowercase for efficient lookup
    private Set<String> fieldsToMask = new HashSet<>(Arrays.asList(
            "password", "passwd", "pwd", "secret", "token", "apikey", "api_key",
            "authorization", "bearer", "credential", "credit_card", "creditcard",
            "cvv", "cvc", "ssn", "social_security", "pin", "iban", "accountiban"
    ));
    private Set<String> fieldsToExclude = new HashSet<>();
    private Map<String, Integer> fieldMaskLengths = new HashMap<>();
    private char maskSymbol = '*';
    private int defaultVisibleChars = 4;

    // Content types to never log (binary)
    private static final Set<String> NEVER_LOG_CONTENT_TYPES = Set.of(
            "multipart/form-data",
            "application/octet-stream",
            "application/pdf",
            "application/zip",
            "application/gzip",
            "application/x-tar"
    );
    
    private static final Set<String> NEVER_LOG_CONTENT_TYPE_PREFIXES = Set.of(
            "image/", "video/", "audio/", "application/x-binary"
    );

    private LoggingConfig() {}

    public static LoggingConfig disabled() {
        return new LoggingConfig();
    }

    public static LoggingConfig custom() {
        return new LoggingConfig().enabled(true);
    }

    public LoggingConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public LoggingConfig logHeaders() {
        this.logHeaders = true;
        this.enabled = true;
        return this;
    }

    public LoggingConfig logRequest() {
        this.logRequest = true;
        this.enabled = true;
        return this;
    }

    public LoggingConfig logResponse() {
        this.logResponse = true;
        this.enabled = true;
        return this;
    }

    public LoggingConfig logAll() {
        this.logHeaders = true;
        this.logRequest = true;
        this.logResponse = true;
        this.enabled = true;
        return this;
    }

    /**
     * Use JSON format (Stripe-style, Splunk-friendly)
     * Single-line JSON logs that can be easily searched by correlation_id
     */
    public LoggingConfig jsonFormat() {
        this.format = LogFormat.JSON;
        return this;
    }

    /**
     * Use pretty format (human-readable boxes)
     */
    public LoggingConfig prettyFormat() {
        this.format = LogFormat.PRETTY;
        return this;
    }

    /**
     * Set service name for JSON logs
     */
    public LoggingConfig serviceName(String serviceName) {
        this.serviceName = serviceName;
        return this;
    }

    /**
     * Set service version for JSON logs (e.g., "1.14.3")
     */
    public LoggingConfig serviceVersion(String version) {
        this.serviceVersion = version;
        return this;
    }

    /**
     * Set environment for JSON logs
     */
    public LoggingConfig environment(Environment env) {
        this.environment = env;
        return this;
    }

    /**
     * Set environment from string (dev, staging, production, test)
     */
    public LoggingConfig environment(String env) {
        if (env == null) return this;
        switch (env.toLowerCase()) {
            case "prod":
            case "production": this.environment = Environment.PRODUCTION; break;
            case "staging":
            case "stage": this.environment = Environment.STAGING; break;
            case "test": this.environment = Environment.TEST; break;
            default: this.environment = Environment.DEV;
        }
        return this;
    }

    /**
     * Override hostname (auto-detected by default)
     */
    public LoggingConfig host(String host) {
        this.host = host;
        return this;
    }

    public LoggingConfig maxBodySize(int maxBytes) {
        this.maxBodySize = maxBytes;
        return this;
    }

    public LoggingConfig maskFields(String... fields) {
        for (String field : fields) {
            this.fieldsToMask.add(field.toLowerCase());
        }
        return this;
    }

    public LoggingConfig maskField(String field, int visibleChars) {
        this.fieldsToMask.add(field.toLowerCase());
        this.fieldMaskLengths.put(field.toLowerCase(), visibleChars);
        return this;
    }

    public LoggingConfig excludeFields(String... fields) {
        for (String field : fields) {
            this.fieldsToExclude.add(field.toLowerCase());
        }
        return this;
    }

    public LoggingConfig maskSymbol(char symbol) {
        this.maskSymbol = symbol;
        return this;
    }

    public LoggingConfig defaultVisibleChars(int chars) {
        this.defaultVisibleChars = chars;
        return this;
    }

    // Getters
    public boolean isEnabled() { return enabled; }
    public boolean isLogHeaders() { return logHeaders; }
    public boolean isLogRequest() { return logRequest; }
    public boolean isLogResponse() { return logResponse; }
    public LogFormat getFormat() { return format; }
    public String getServiceName() { return serviceName; }
    public String getServiceVersion() { return serviceVersion; }
    public Environment getEnvironment() { return environment; }
    public String getHost() { return host; }
    public int getMaxBodySize() { return maxBodySize; }
    public Set<String> getFieldsToMask() { return fieldsToMask; }
    public Set<String> getFieldsToExclude() { return fieldsToExclude; }
    public Map<String, Integer> getFieldMaskLengths() { return fieldMaskLengths; }
    public char getMaskSymbol() { return maskSymbol; }
    public int getDefaultVisibleChars() { return defaultVisibleChars; }

    /**
     * Checks if a content type should be logged
     */
    public static boolean shouldLogContentType(String contentType) {
        if (contentType == null) return true;
        
        String ct = contentType.toLowerCase();
        
        // Check exact matches
        for (String blocked : NEVER_LOG_CONTENT_TYPES) {
            if (ct.startsWith(blocked)) return false;
        }
        
        // Check prefixes
        for (String prefix : NEVER_LOG_CONTENT_TYPE_PREFIXES) {
            if (ct.startsWith(prefix)) return false;
        }
        
        return true;
    }

    private static String resolveHostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            // Fallback to environment variable (common in K8s)
            String hostname = System.getenv("HOSTNAME");
            if (hostname != null && !hostname.isEmpty()) {
                return hostname;
            }
            return "unknown";
        }
    }
}
