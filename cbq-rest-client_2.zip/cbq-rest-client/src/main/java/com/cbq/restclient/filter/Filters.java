package com.cbq.restclient.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;

import java.util.function.Supplier;

/**
 * Common pre-built filter implementations.
 */
public final class Filters {
    
    private static final Logger log = LoggerFactory.getLogger(Filters.class);

    private Filters() {}

    // ═══════════════════════════════════════════════════════════════════════════
    // REQUEST FILTERS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Adds a Bearer token to requests.
     * Skips if Authorization header is already set (allows per-request override).
     */
    public static RequestFilter bearerToken(String token) {
        return context -> {
            if (!context.hasHeader("Authorization")) {
                context.addHeader("Authorization", "Bearer " + token);
            }
            return Mono.just(context);
        };
    }

    /**
     * Adds a Bearer token from a supplier (for dynamic tokens).
     * Skips if Authorization header is already set (allows per-request override).
     */
    public static RequestFilter bearerToken(Supplier<String> tokenSupplier) {
        return context -> {
            if (!context.hasHeader("Authorization")) {
                context.addHeader("Authorization", "Bearer " + tokenSupplier.get());
            }
            return Mono.just(context);
        };
    }

    /**
     * Adds Basic auth to requests.
     * Skips if Authorization header is already set (allows per-request override).
     */
    public static RequestFilter basicAuth(String username, String password) {
        String credentials = java.util.Base64.getEncoder()
                .encodeToString((username + ":" + password).getBytes());
        return context -> {
            if (!context.hasHeader("Authorization")) {
                context.addHeader("Authorization", "Basic " + credentials);
            }
            return Mono.just(context);
        };
    }

    /**
     * Adds an API key header.
     * Skips if the header is already set (allows per-request override).
     */
    public static RequestFilter apiKey(String headerName, String apiKey) {
        return context -> {
            if (!context.hasHeader(headerName)) {
                context.addHeader(headerName, apiKey);
            }
            return Mono.just(context);
        };
    }

    /**
     * Adds custom headers
     */
    public static RequestFilter headers(String... keyValuePairs) {
        if (keyValuePairs.length % 2 != 0) {
            throw new IllegalArgumentException("Headers must be key-value pairs");
        }
        return context -> {
            for (int i = 0; i < keyValuePairs.length; i += 2) {
                context.addHeader(keyValuePairs[i], keyValuePairs[i + 1]);
            }
            return Mono.just(context);
        };
    }

    /**
     * Adds a timestamp header
     */
    public static RequestFilter timestamp(String headerName) {
        return context -> {
            context.addHeader(headerName, String.valueOf(System.currentTimeMillis()));
            return Mono.just(context);
        };
    }

    /**
     * Request audit logging filter
     */
    public static RequestFilter auditLog(String appName) {
        return context -> {
            log.info("[AUDIT] {} {} {} - requestId={}", 
                    appName, context.getMethod(), context.getUri(), context.getRequestId());
            return Mono.just(context);
        };
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // RESPONSE FILTERS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Response audit logging filter
     */
    public static ResponseFilter responseAuditLog(String appName) {
        return context -> {
            log.info("[AUDIT] {} response status={} duration={}ms requestId={}",
                    appName, context.getStatusCode(), context.getDurationMs(), context.getRequestId());
            return Mono.just(context);
        };
    }

    /**
     * Logs slow responses
     */
    public static ResponseFilter slowResponseLog(long thresholdMs) {
        return context -> {
            if (context.getDurationMs() > thresholdMs) {
                log.warn("Slow response: {}ms (threshold: {}ms) requestId={}",
                        context.getDurationMs(), thresholdMs, context.getRequestId());
            }
            return Mono.just(context);
        };
    }

    /**
     * Logs error responses
     */
    public static ResponseFilter errorLog() {
        return context -> {
            if (context.isClientError() || context.isServerError()) {
                log.error("Error response: status={} requestId={}", 
                        context.getStatusCode(), context.getRequestId());
            }
            return Mono.just(context);
        };
    }

    /**
     * Validates response is successful, throws on error
     */
    public static ResponseFilter validateSuccess() {
        return context -> {
            if (!context.isSuccessful()) {
                return Mono.error(new RuntimeException(
                        "Unexpected status: " + context.getStatusCode()));
            }
            return Mono.just(context);
        };
    }
}
