package com.cbq.restclient.logging;

import org.slf4j.MDC;

import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.function.Supplier;

/**
 * Fast correlation context management.
 * 
 * <h2>Usage</h2>
 * <pre>{@code
 * // In controller/entry point
 * Ctx.start();  // Generates new correlation ID
 * 
 * // Or use existing (from header)
 * Ctx.set(request.getHeader("X-Correlation-ID"));
 * 
 * // Get current correlation ID
 * String cid = Ctx.cid();
 * 
 * // Run with context (auto-cleanup)
 * Ctx.run(() -> {
 *     // Your code here - correlation ID available
 *     orderService.process();
 * });
 * 
 * // Clear at end
 * Ctx.clear();
 * }</pre>
 * 
 * <h2>With async/threads</h2>
 * <pre>{@code
 * // Wrap runnable to propagate context
 * executor.submit(Ctx.wrap(() -> {
 *     // Correlation ID available in new thread
 *     processAsync();
 * }));
 * }</pre>
 */
public final class Ctx {
    
    public static final String CORRELATION_ID = "correlation_id";
    public static final String REQUEST_ID = "request_id";
    
    private Ctx() {}
    
    // ═══════════════════════════════════════════════════════════════════════════
    // CORRELATION ID
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Start new correlation - returns generated ID */
    public static String start() {
        String cid = newId("cid_");
        MDC.put(CORRELATION_ID, cid);
        return cid;
    }
    
    /** Set existing correlation ID */
    public static void set(String correlationId) {
        if (correlationId != null && !correlationId.isEmpty()) {
            MDC.put(CORRELATION_ID, correlationId);
        } else {
            start();
        }
    }
    
    /** Get current correlation ID */
    public static String cid() {
        return MDC.get(CORRELATION_ID);
    }
    
    /** Check if correlation exists */
    public static boolean hasCid() {
        return MDC.get(CORRELATION_ID) != null;
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // REQUEST ID (for individual operations within a correlation)
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Generate new request ID */
    public static String newReqId() {
        String rid = newId("req_");
        MDC.put(REQUEST_ID, rid);
        return rid;
    }
    
    /** Set request ID */
    public static void setReqId(String requestId) {
        MDC.put(REQUEST_ID, requestId);
    }
    
    /** Get current request ID */
    public static String rid() {
        return MDC.get(REQUEST_ID);
    }
    
    /** Clear request ID only */
    public static void clearReqId() {
        MDC.remove(REQUEST_ID);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // CLEANUP
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Clear all context */
    public static void clear() {
        MDC.clear();
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // RUN WITH CONTEXT (auto-cleanup)
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Run with new correlation context (auto-cleanup) */
    public static void run(Runnable task) {
        String cid = start();
        try {
            task.run();
        } finally {
            clear();
        }
    }
    
    /** Run with existing correlation context (auto-cleanup) */
    public static void run(String correlationId, Runnable task) {
        set(correlationId);
        try {
            task.run();
        } finally {
            clear();
        }
    }
    
    /** Call with new correlation context (auto-cleanup) */
    public static <T> T call(Supplier<T> task) {
        start();
        try {
            return task.get();
        } finally {
            clear();
        }
    }
    
    /** Call with existing correlation context (auto-cleanup) */
    public static <T> T call(String correlationId, Supplier<T> task) {
        set(correlationId);
        try {
            return task.get();
        } finally {
            clear();
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // ASYNC CONTEXT PROPAGATION
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Wrap runnable to propagate context to new thread */
    public static Runnable wrap(Runnable task) {
        String cid = cid();
        String rid = rid();
        return () -> {
            if (cid != null) MDC.put(CORRELATION_ID, cid);
            if (rid != null) MDC.put(REQUEST_ID, rid);
            try {
                task.run();
            } finally {
                clear();
            }
        };
    }
    
    /** Wrap callable to propagate context to new thread */
    public static <T> Callable<T> wrap(Callable<T> task) {
        String cid = cid();
        String rid = rid();
        return () -> {
            if (cid != null) MDC.put(CORRELATION_ID, cid);
            if (rid != null) MDC.put(REQUEST_ID, rid);
            try {
                return task.call();
            } finally {
                clear();
            }
        };
    }
    
    /** Wrap supplier to propagate context to new thread */
    public static <T> Supplier<T> wrapSupplier(Supplier<T> task) {
        String cid = cid();
        String rid = rid();
        return () -> {
            if (cid != null) MDC.put(CORRELATION_ID, cid);
            if (rid != null) MDC.put(REQUEST_ID, rid);
            try {
                return task.get();
            } finally {
                clear();
            }
        };
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // UTILITY
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Generate short unique ID */
    private static String newId(String prefix) {
        return prefix + UUID.randomUUID().toString().substring(0, 8);
    }
}
