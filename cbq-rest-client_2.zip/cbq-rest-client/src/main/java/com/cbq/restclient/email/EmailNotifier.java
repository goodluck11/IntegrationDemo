package com.cbq.restclient.email;

import com.cbq.restclient.config.EmailNotifierConfig;
import com.cbq.restclient.model.EmailNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.TaskExecutor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Event-driven, rate-limited email notifier with circuit breaker protection.
 * 
 * <p>Safety features:</p>
 * <ul>
 *   <li>Rate limiting - prevents email storms</li>
 *   <li>Circuit breaker - stops notifications during persistent failures</li>
 *   <li>Async execution - never blocks HTTP client threads</li>
 *   <li>Event-driven - decoupled from request flow</li>
 * </ul>
 */
public class EmailNotifier {
    private static final Logger log = LoggerFactory.getLogger(EmailNotifier.class);

    private final EmailNotifierConfig config;
    private final JavaMailSender mailSender;
    private final TaskExecutor taskExecutor;

    // Rate limiting state
    private final ConcurrentLinkedQueue<Instant> emailTimestamps = new ConcurrentLinkedQueue<>();
    
    // Circuit breaker state
    private final AtomicInteger consecutiveFailures = new AtomicInteger(0);
    private final AtomicLong circuitOpenedAt = new AtomicLong(0);
    
    private enum CircuitState { CLOSED, OPEN, HALF_OPEN }

    public EmailNotifier(EmailNotifierConfig config, 
                        JavaMailSender springMailSender,
                        TaskExecutor taskExecutor) {
        this.config = config;
        this.taskExecutor = taskExecutor;
        
        // Use Spring's mail sender if available, otherwise create from config
        if (springMailSender != null) {
            log.info("Using Spring-configured JavaMailSender for email notifications");
            this.mailSender = springMailSender;
        } else if (config.getHost() != null) {
            log.info("Creating JavaMailSender from EmailNotifierConfig");
            this.mailSender = createMailSender();
        } else {
            log.info("Email notifier disabled - no mail configuration");
            this.mailSender = null;
        }
    }

    /**
     * Notifies about an error event (async, non-blocking)
     */
    public void notify(ErrorEvent event, EmailNotification notification) {
        if (!config.isEnabled() || mailSender == null) {
            log.debug("Email notifications disabled, skipping");
            return;
        }

        // Check circuit breaker
        if (isCircuitOpen()) {
            log.warn("Email circuit breaker is open, skipping notification");
            return;
        }

        // Check rate limit
        if (isRateLimited()) {
            log.warn("Email rate limit exceeded, skipping notification for requestId={}", 
                    event.getRequestId());
            return;
        }

        // Execute async to never block HTTP threads
        if (config.isAsync()) {
            taskExecutor.execute(() -> sendNotification(event, notification));
        } else {
            sendNotification(event, notification);
        }
    }

    private void sendNotification(ErrorEvent event, EmailNotification notification) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            // Set from
            String from = notification.getFrom() != null 
                    ? notification.getFrom() 
                    : config.getDefaultFrom();
            if (from != null) helper.setFrom(from);

            // Set to
            List<String> to = notification.getTo().isEmpty() 
                    ? config.getDefaultTo() 
                    : notification.getTo();
            if (to.isEmpty()) {
                log.warn("No email recipients configured, skipping notification");
                return;
            }
            helper.setTo(to.toArray(new String[0]));

            // Set subject
            String subject = notification.getSubject() != null 
                    ? notification.getSubject() 
                    : config.getDefaultSubject();
            helper.setSubject(subject);

            // Set body
            String body = notification.getBody() != null 
                    ? notification.getBody() 
                    : formatErrorBody(event, notification.getContext());
            helper.setText(body, notification.isHtml());

            helper.setSentDate(new Date());

            // Send
            mailSender.send(message);
            
            // Record success for rate limiting
            recordEmailSent();
            
            // Reset circuit breaker on success
            consecutiveFailures.set(0);
            
            log.info("Error notification email sent for requestId={}", event.getRequestId());
            
        } catch (Exception e) {
            log.error("Failed to send error notification email: {}", e.getMessage());
            handleSendFailure();
        }
    }

    private boolean isRateLimited() {
        // Clean old timestamps
        Instant cutoff = Instant.now().minus(config.getRateLimitWindow());
        while (!emailTimestamps.isEmpty() && emailTimestamps.peek().isBefore(cutoff)) {
            emailTimestamps.poll();
        }
        
        return emailTimestamps.size() >= config.getMaxEmailsPerWindow();
    }

    private void recordEmailSent() {
        emailTimestamps.offer(Instant.now());
    }

    private boolean isCircuitOpen() {
        if (!config.isCircuitBreakerEnabled()) return false;
        
        long openedAt = circuitOpenedAt.get();
        if (openedAt == 0) return false; // Circuit is closed
        
        // Check if reset time has passed
        Duration sinceOpened = Duration.between(Instant.ofEpochMilli(openedAt), Instant.now());
        if (sinceOpened.compareTo(config.getCircuitBreakerResetTime()) > 0) {
            // Try to transition to half-open
            circuitOpenedAt.set(0);
            log.info("Email circuit breaker transitioning to half-open");
            return false;
        }
        
        return true;
    }

    private void handleSendFailure() {
        if (!config.isCircuitBreakerEnabled()) return;
        
        int failures = consecutiveFailures.incrementAndGet();
        if (failures >= config.getCircuitBreakerThreshold()) {
            circuitOpenedAt.set(System.currentTimeMillis());
            log.warn("Email circuit breaker opened after {} consecutive failures", failures);
        }
    }

    private String formatErrorBody(ErrorEvent event, Map<String, Object> context) {
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════════════════════════════════════════════════\n");
        sb.append("CBQ REST CLIENT ERROR NOTIFICATION\n");
        sb.append("═══════════════════════════════════════════════════════════════\n\n");
        
        sb.append("Request Details:\n");
        sb.append("───────────────────────────────────────────────────────────────\n");
        sb.append("Request ID: ").append(event.getRequestId()).append("\n");
        sb.append("Correlation ID: ").append(event.getCorrelationId()).append("\n");
        sb.append("Method: ").append(event.getMethod()).append("\n");
        sb.append("URI: ").append(event.getUri()).append("\n");
        sb.append("Timestamp: ").append(new Date()).append("\n\n");
        
        sb.append("Error Details:\n");
        sb.append("───────────────────────────────────────────────────────────────\n");
        sb.append("Exception: ").append(event.getError().getClass().getName()).append("\n");
        sb.append("Message: ").append(event.getError().getMessage()).append("\n\n");
        
        if (context != null && !context.isEmpty()) {
            sb.append("Context:\n");
            sb.append("───────────────────────────────────────────────────────────────\n");
            context.forEach((k, v) -> sb.append(k).append(": ").append(v).append("\n"));
        }
        
        return sb.toString();
    }

    private JavaMailSender createMailSender() {
        JavaMailSenderImpl sender = new JavaMailSenderImpl();
        sender.setHost(config.getHost());
        sender.setPort(config.getPort());
        sender.setUsername(config.getUsername());
        sender.setPassword(config.getPassword());

        Properties props = sender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.connectiontimeout", "5000");
        props.put("mail.smtp.timeout", "5000");
        
        if (config.isStartTls()) {
            props.put("mail.smtp.starttls.enable", "true");
        }
        if (config.isSsl()) {
            props.put("mail.smtp.ssl.enable", "true");
        }

        return sender;
    }

    /**
     * Error event for notification
     */
    public static class ErrorEvent {
        private final String requestId;
        private final String correlationId;
        private final String method;
        private final String uri;
        private final Throwable error;
        private final long durationMs;

        public ErrorEvent(String requestId, String correlationId, String method, 
                         String uri, Throwable error, long durationMs) {
            this.requestId = requestId;
            this.correlationId = correlationId;
            this.method = method;
            this.uri = uri;
            this.error = error;
            this.durationMs = durationMs;
        }

        public String getRequestId() { return requestId; }
        public String getCorrelationId() { return correlationId; }
        public String getMethod() { return method; }
        public String getUri() { return uri; }
        public Throwable getError() { return error; }
        public long getDurationMs() { return durationMs; }
    }
}
