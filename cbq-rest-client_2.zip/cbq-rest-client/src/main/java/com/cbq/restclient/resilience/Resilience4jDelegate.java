package com.cbq.restclient.resilience;

import com.cbq.restclient.config.ResilienceConfig;
import com.cbq.restclient.config.RequestOverride;
import com.cbq.restclient.exception.*;
import io.github.resilience4j.bulkhead.Bulkhead;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.ratelimiter.RateLimiterRegistry;
import io.github.resilience4j.reactor.bulkhead.operator.BulkheadOperator;
import io.github.resilience4j.reactor.circuitbreaker.operator.CircuitBreakerOperator;
import io.github.resilience4j.reactor.ratelimiter.operator.RateLimiterOperator;
import io.github.resilience4j.reactor.retry.RetryOperator;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;

import java.net.ConnectException;
import java.util.concurrent.TimeoutException;

/**
 * Delegate class that contains actual Resilience4j code.
 * This class is only loaded if Resilience4j is on the classpath.
 */
class Resilience4jDelegate {
    private static final Logger log = LoggerFactory.getLogger(Resilience4jDelegate.class);

    private final Retry retry;
    private final CircuitBreaker circuitBreaker;
    private final RateLimiter rateLimiter;
    private final Bulkhead bulkhead;

    Resilience4jDelegate(String name, ResilienceConfig config) {
        this.retry = createRetry(name, config.getRetryConfig());
        this.circuitBreaker = createCircuitBreaker(name, config.getCircuitBreakerConfig());
        this.rateLimiter = createRateLimiter(name, config.getRateLimiterConfig());
        this.bulkhead = createBulkhead(name, config.getBulkheadConfig());
        
        registerEventListeners(name);
    }

    Object getRetry() { return retry; }
    Object getCircuitBreaker() { return circuitBreaker; }
    Object getRateLimiter() { return rateLimiter; }
    Object getBulkhead() { return bulkhead; }

    static <T> Mono<T> applyResilience(Mono<T> mono, RequestOverride override, 
                                        ResilienceConfig config, String name,
                                        String requestId, String uri, String method,
                                        Object retryObj, Object cbObj, Object rlObj, Object bhObj) {
        
        Retry retry = (Retry) retryObj;
        CircuitBreaker circuitBreaker = (CircuitBreaker) cbObj;
        RateLimiter rateLimiter = (RateLimiter) rlObj;
        Bulkhead bulkhead = (Bulkhead) bhObj;

        // Apply in order: Bulkhead -> RateLimiter -> CircuitBreaker -> Retry
        
        // Retry (innermost)
        if (isRetryEnabled(override, config) && retry != null) {
            mono = mono.transformDeferred(RetryOperator.of(retry))
                    .onErrorMap(io.github.resilience4j.retry.MaxRetriesExceededException.class,
                            e -> new CBQRestClientException("Max retries exceeded", e, requestId, uri, method));
        }
        
        // Circuit Breaker
        if (isCircuitBreakerEnabled(override, config) && circuitBreaker != null) {
            mono = mono.transformDeferred(CircuitBreakerOperator.of(circuitBreaker))
                    .onErrorMap(io.github.resilience4j.circuitbreaker.CallNotPermittedException.class,
                            e -> new CircuitBreakerOpenException(name, requestId, uri, method));
        }
        
        // Rate Limiter
        if (isRateLimiterEnabled(override, config) && rateLimiter != null) {
            mono = mono.transformDeferred(RateLimiterOperator.of(rateLimiter))
                    .onErrorMap(io.github.resilience4j.ratelimiter.RequestNotPermitted.class,
                            e -> new RateLimitExceededException(name, requestId, uri, method));
        }
        
        // Bulkhead (outermost)
        if (isBulkheadEnabled(override, config) && bulkhead != null) {
            mono = mono.transformDeferred(BulkheadOperator.of(bulkhead))
                    .onErrorMap(io.github.resilience4j.bulkhead.BulkheadFullException.class,
                            e -> new BulkheadFullException(name, requestId, uri, method));
        }
        
        return mono;
    }

    private static boolean isRetryEnabled(RequestOverride override, ResilienceConfig config) {
        if (override != null && override.getRetryEnabled() != null) {
            return override.getRetryEnabled();
        }
        return config.getRetryConfig().isEnabled();
    }

    private static boolean isCircuitBreakerEnabled(RequestOverride override, ResilienceConfig config) {
        if (override != null && override.getCircuitBreakerEnabled() != null) {
            return override.getCircuitBreakerEnabled();
        }
        return config.getCircuitBreakerConfig().isEnabled();
    }

    private static boolean isRateLimiterEnabled(RequestOverride override, ResilienceConfig config) {
        if (override != null && override.getRateLimiterEnabled() != null) {
            return override.getRateLimiterEnabled();
        }
        return config.getRateLimiterConfig().isEnabled();
    }

    private static boolean isBulkheadEnabled(RequestOverride override, ResilienceConfig config) {
        if (override != null && override.getBulkheadEnabled() != null) {
            return override.getBulkheadEnabled();
        }
        return config.getBulkheadConfig().isEnabled();
    }

    private Retry createRetry(String name, ResilienceConfig.RetryConfig cfg) {
        if (!cfg.isEnabled()) return null;

        io.github.resilience4j.retry.RetryConfig.Builder builder = 
            io.github.resilience4j.retry.RetryConfig.custom()
                .maxAttempts(cfg.getMaxAttempts())
                .waitDuration(cfg.getWaitDuration());

        switch (cfg.getBackoffStrategy()) {
            case EXPONENTIAL:
                builder.intervalFunction(io.github.resilience4j.core.IntervalFunction
                        .ofExponentialBackoff(cfg.getWaitDuration(), cfg.getBackoffMultiplier()));
                break;
            case EXPONENTIAL_WITH_JITTER:
                builder.intervalFunction(io.github.resilience4j.core.IntervalFunction
                        .ofExponentialRandomBackoff(cfg.getWaitDuration(), cfg.getBackoffMultiplier()));
                break;
            case FIXED:
            default:
                break;
        }

        builder.retryOnException(ex -> {
            if (cfg.isRetryOnConnectionTimeout() && isConnectionTimeout(ex)) return true;
            if (cfg.isRetryOnReadTimeout() && isReadTimeout(ex)) return true;
            for (Class<? extends Throwable> retryEx : cfg.getRetryExceptions()) {
                if (retryEx.isInstance(ex)) return true;
            }
            return false;
        });

        if (!cfg.getIgnoreExceptions().isEmpty()) {
            builder.ignoreExceptions(cfg.getIgnoreExceptions().toArray(new Class[0]));
        }

        return RetryRegistry.of(builder.build()).retry(name);
    }

    private CircuitBreaker createCircuitBreaker(String name, ResilienceConfig.CircuitBreakerConfig cfg) {
        if (!cfg.isEnabled()) return null;

        io.github.resilience4j.circuitbreaker.CircuitBreakerConfig cbConfig = 
            io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.custom()
                .slidingWindowSize(cfg.getWindowSize())
                .minimumNumberOfCalls(cfg.getMinCalls())
                .permittedNumberOfCallsInHalfOpenState(cfg.getHalfOpenCalls())
                .failureRateThreshold(cfg.getFailureRate())
                .slowCallRateThreshold(cfg.getSlowCallRate())
                .slowCallDurationThreshold(cfg.getSlowCallDuration())
                .waitDurationInOpenState(cfg.getOpenStateWait())
                .automaticTransitionFromOpenToHalfOpenEnabled(cfg.isAutoTransition())
                .build();

        return CircuitBreakerRegistry.of(cbConfig).circuitBreaker(name);
    }

    private RateLimiter createRateLimiter(String name, ResilienceConfig.RateLimiterConfig cfg) {
        if (!cfg.isEnabled()) return null;

        io.github.resilience4j.ratelimiter.RateLimiterConfig rlConfig = 
            io.github.resilience4j.ratelimiter.RateLimiterConfig.custom()
                .limitForPeriod(cfg.getLimitForPeriod())
                .limitRefreshPeriod(cfg.getRefreshPeriod())
                .timeoutDuration(cfg.getTimeout())
                .build();

        return RateLimiterRegistry.of(rlConfig).rateLimiter(name);
    }

    private Bulkhead createBulkhead(String name, ResilienceConfig.BulkheadConfig cfg) {
        if (!cfg.isEnabled()) return null;

        io.github.resilience4j.bulkhead.BulkheadConfig bhConfig = 
            io.github.resilience4j.bulkhead.BulkheadConfig.custom()
                .maxConcurrentCalls(cfg.getMaxConcurrentCalls())
                .maxWaitDuration(cfg.getMaxWait())
                .build();

        return BulkheadRegistry.of(bhConfig).bulkhead(name);
    }

    private void registerEventListeners(String name) {
        if (circuitBreaker != null) {
            circuitBreaker.getEventPublisher()
                .onStateTransition(event -> 
                    log.info("Circuit breaker '{}' state changed: {} -> {}", 
                        name, event.getStateTransition().getFromState(), 
                        event.getStateTransition().getToState()));
        }
        
        if (retry != null) {
            retry.getEventPublisher()
                .onRetry(event -> 
                    log.debug("Retry attempt {} for '{}': {}", 
                        event.getNumberOfRetryAttempts(), name, event.getLastThrowable().getMessage()));
        }
    }

    private static boolean isConnectionTimeout(Throwable ex) {
        return ex instanceof ConnectException ||
               (ex.getCause() != null && ex.getCause() instanceof ConnectException) ||
               (ex.getMessage() != null && ex.getMessage().toLowerCase().contains("connection timed out"));
    }

    private static boolean isReadTimeout(Throwable ex) {
        return ex instanceof java.net.SocketTimeoutException ||
               ex instanceof TimeoutException ||
               (ex.getMessage() != null && ex.getMessage().toLowerCase().contains("read timed out"));
    }
}
