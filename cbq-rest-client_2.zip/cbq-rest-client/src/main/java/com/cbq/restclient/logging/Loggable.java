package com.cbq.restclient.logging;

/**
 * Mixin interface for easy structured logging access.
 * 
 * <h2>Usage</h2>
 * <pre>{@code
 * public class OrderService implements Loggable {
 *     
 *     public void process() {
 *         slog().db("INSERT", "orders", 45);
 *         slog().http("POST", "/payments", 200, 145);
 *         slog().email("user@test.com", "Confirmed", 230);
 *     }
 * }
 * }</pre>
 * 
 * <h2>Alternative: Static field (like Lombok)</h2>
 * <pre>{@code
 * public class OrderService {
 *     private static final SLog slog = SLog.forClass(OrderService.class);
 * }
 * }</pre>
 */
public interface Loggable {
    
    /**
     * Get structured logger for this class.
     * Cached per class, so no performance overhead.
     */
    default SLog slog() {
        return SLog.forClass(getClass());
    }
}
