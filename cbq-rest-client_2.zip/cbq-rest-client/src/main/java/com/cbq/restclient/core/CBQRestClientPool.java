package com.cbq.restclient.core;

import com.cbq.restclient.config.*;
import lombok.Builder;
import lombok.Getter;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Pool of pre-configured CBQRestClient instances with different timeout profiles.
 * 
 * <p>Since connection, read, and write timeouts are configured at the Netty level
 * and cannot be changed per-request, this pool allows you to maintain multiple
 * clients with different timeout configurations for different use cases.</p>
 * 
 * <h2>Usage Example:</h2>
 * <pre>{@code
 * // Create pool with base configuration
 * CBQRestClientPool pool = CBQRestClientPool.builder()
 *     .baseUrl("https://api.example.com")
 *     .resilience(ResilienceConfig.defaults())
 *     .logging(LoggingConfig.custom().logAll())
 *     .build();
 * 
 * // Get client for different use cases
 * CBQRestClient defaultClient = pool.getDefault();
 * CBQRestClient fastClient = pool.getFast();           // Short timeouts
 * CBQRestClient slowClient = pool.getSlow();           // Long timeouts
 * CBQRestClient customClient = pool.getOrCreate("batch", TimeoutProfile.builder()
 *     .connection(Duration.ofSeconds(10))
 *     .read(Duration.ofMinutes(5))
 *     .write(Duration.ofMinutes(5))
 *     .response(Duration.ofMinutes(10))
 *     .build());
 * 
 * // Use appropriate client
 * fastClient.get().uri("/health").retrieve(String.class).block();
 * slowClient.get().uri("/reports/generate").retrieve(String.class).block();
 * }</pre>
 */
public class CBQRestClientPool {

    private final String baseUrl;
    private final ResilienceConfig resilience;
    private final LoggingConfig logging;
    private final EmailNotifierConfig emailNotifier;
    private final TracingConfig tracing;
    private final MetricsConfig metrics;
    private final SslConfig ssl;
    private final Map<String, String> defaultHeaders;

    private final Map<String, CBQRestClient> clients = new ConcurrentHashMap<>();

    // Pre-defined timeout profiles
    public static final TimeoutProfile FAST_PROFILE = TimeoutProfile.builder()
            .connection(Duration.ofSeconds(2))
            .read(Duration.ofSeconds(5))
            .write(Duration.ofSeconds(5))
            .response(Duration.ofSeconds(10))
            .build();

    public static final TimeoutProfile DEFAULT_PROFILE = TimeoutProfile.builder()
            .connection(Duration.ofSeconds(5))
            .read(Duration.ofSeconds(30))
            .write(Duration.ofSeconds(30))
            .response(Duration.ofSeconds(60))
            .build();

    public static final TimeoutProfile SLOW_PROFILE = TimeoutProfile.builder()
            .connection(Duration.ofSeconds(10))
            .read(Duration.ofMinutes(2))
            .write(Duration.ofMinutes(2))
            .response(Duration.ofMinutes(5))
            .build();

    public static final TimeoutProfile BATCH_PROFILE = TimeoutProfile.builder()
            .connection(Duration.ofSeconds(10))
            .read(Duration.ofMinutes(10))
            .write(Duration.ofMinutes(10))
            .response(Duration.ofMinutes(30))
            .build();

    private CBQRestClientPool(Builder builder) {
        this.baseUrl = builder.baseUrl;
        this.resilience = builder.resilience;
        this.logging = builder.logging;
        this.emailNotifier = builder.emailNotifier;
        this.tracing = builder.tracing;
        this.metrics = builder.metrics;
        this.ssl = builder.ssl;
        this.defaultHeaders = builder.defaultHeaders;
    }

    /**
     * Get the default client (30s read, 60s response)
     */
    public CBQRestClient getDefault() {
        return getOrCreate("default", DEFAULT_PROFILE);
    }

    /**
     * Get the fast client for quick operations (5s read, 10s response)
     * Good for: health checks, simple lookups
     */
    public CBQRestClient getFast() {
        return getOrCreate("fast", FAST_PROFILE);
    }

    /**
     * Get the slow client for long operations (2min read, 5min response)
     * Good for: report generation, file downloads
     */
    public CBQRestClient getSlow() {
        return getOrCreate("slow", SLOW_PROFILE);
    }

    /**
     * Get the batch client for very long operations (10min read, 30min response)
     * Good for: batch processing, large data transfers
     */
    public CBQRestClient getBatch() {
        return getOrCreate("batch", BATCH_PROFILE);
    }

    /**
     * Get or create a client with a custom timeout profile
     */
    public CBQRestClient getOrCreate(String name, TimeoutProfile profile) {
        return clients.computeIfAbsent(name, n -> createClient(n, profile));
    }

    /**
     * Get a client by name (must have been created already)
     */
    public CBQRestClient get(String name) {
        CBQRestClient client = clients.get(name);
        if (client == null) {
            throw new IllegalArgumentException("No client with name: " + name + 
                    ". Use getOrCreate() to create it first.");
        }
        return client;
    }

    private CBQRestClient createClient(String name, TimeoutProfile profile) {
        CBQRestClientBuilder builder = CBQRestClientBuilder.builder(name)
                .baseUrl(baseUrl)
                .timeouts(TimeoutConfig.custom()
                        .connection(profile.getConnection())
                        .read(profile.getRead())
                        .write(profile.getWrite())
                        .response(profile.getResponse()));

        if (resilience != null) builder.resilience(resilience);
        if (logging != null) builder.logging(logging);
        if (emailNotifier != null) builder.emailNotifier(emailNotifier);
        if (tracing != null) builder.tracing(tracing);
        if (metrics != null) builder.metrics(metrics);
        if (ssl != null) builder.ssl(ssl);
        if (defaultHeaders != null) {
            builder.headers(h -> h.putAll(defaultHeaders));
        }

        return builder.build();
    }

    /**
     * Shutdown all clients in the pool
     */
    public void shutdown() {
        clients.values().forEach(CBQRestClient::shutdown);
        clients.clear();
    }

    public static Builder builder() {
        return new Builder();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // TIMEOUT PROFILE
    // ═══════════════════════════════════════════════════════════════════════════

    @Getter
    @Builder
    public static class TimeoutProfile {
        private final Duration connection;
        private final Duration read;
        private final Duration write;
        private final Duration response;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BUILDER
    // ═══════════════════════════════════════════════════════════════════════════

    public static class Builder {
        private String baseUrl;
        private ResilienceConfig resilience;
        private LoggingConfig logging;
        private EmailNotifierConfig emailNotifier;
        private TracingConfig tracing;
        private MetricsConfig metrics;
        private SslConfig ssl;
        private Map<String, String> defaultHeaders;

        public Builder baseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
            return this;
        }

        public Builder resilience(ResilienceConfig resilience) {
            this.resilience = resilience;
            return this;
        }

        public Builder logging(LoggingConfig logging) {
            this.logging = logging;
            return this;
        }

        public Builder emailNotifier(EmailNotifierConfig emailNotifier) {
            this.emailNotifier = emailNotifier;
            return this;
        }

        public Builder tracing(TracingConfig tracing) {
            this.tracing = tracing;
            return this;
        }

        public Builder metrics(MetricsConfig metrics) {
            this.metrics = metrics;
            return this;
        }

        public Builder ssl(SslConfig ssl) {
            this.ssl = ssl;
            return this;
        }

        public Builder defaultHeaders(Map<String, String> headers) {
            this.defaultHeaders = headers;
            return this;
        }

        public CBQRestClientPool build() {
            return new CBQRestClientPool(this);
        }
    }
}
