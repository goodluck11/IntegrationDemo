package com.cbq.restclient.examples;

import com.cbq.restclient.config.*;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQRestClientBuilder;
import com.cbq.restclient.core.CBQRestClientPool;
import com.cbq.restclient.exception.*;
import com.cbq.restclient.filter.*;
import com.cbq.restclient.model.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

import java.time.Duration;
import java.util.List;
import java.util.Map;

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * CBQ REST CLIENT v2.0 - COMPREHENSIVE EXAMPLES (ALL FEATURES)
 * ═══════════════════════════════════════════════════════════════════════════════
 */
public class ComprehensiveExamples {

    // ═══════════════════════════════════════════════════════════════════════════
    // MODELS (Using Lombok)
    // ═══════════════════════════════════════════════════════════════════════════

    @Data @NoArgsConstructor @AllArgsConstructor
    static class User {
        private Long id;
        private String name;
        private String email;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    static class Order {
        private Long id;
        private Long userId;
        private String status;
        private Double amount;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    static class Product {
        private Long id;
        private String name;
        private Double price;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    static class PaymentRequest {
        private Long orderId;
        private Double amount;
        private String currency;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    static class PaymentResult {
        private String transactionId;
        private String status;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    static class CreateUserRequest {
        private String name;
        private String email;
    }

    // Custom Exceptions
    static class UserNotFoundException extends RuntimeException {
        public UserNotFoundException(String message) { super(message); }
    }

    static class OrderNotFoundException extends RuntimeException {
        public OrderNotFoundException(String message) { super(message); }
    }

    static class ServiceUnavailableException extends RuntimeException {
        public ServiceUnavailableException(String message) { super(message); }
    }

    static class UnauthorizedException extends RuntimeException {
        public UnauthorizedException(String message) { super(message); }
    }

    static class RateLimitException extends RuntimeException {
        public RateLimitException(String message) { super(message); }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 1. FULL CLIENT CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Production-ready client with all features enabled
     */
    public static CBQRestClient createFullyConfiguredClient() {
        return CBQRestClientBuilder.builder("user-service")
                .baseUrl("https://api.example.com/v1")

                // ─────────────────────────────────────────────────────────────────
                // TIMEOUTS (All 4 types)
                // ─────────────────────────────────────────────────────────────────
                .timeouts(TimeoutConfig.custom()
                        .connection(Duration.ofSeconds(3))   // TCP connection
                        .read(Duration.ofSeconds(10))        // Between data packets
                        .write(Duration.ofSeconds(10))       // Write operation
                        .response(Duration.ofSeconds(30)))   // Total response time

                // ─────────────────────────────────────────────────────────────────
                // DEFAULT HEADERS
                // ─────────────────────────────────────────────────────────────────
                .headers(h -> {
                    h.put("X-Application", "my-app");
                    h.put("X-Environment", "production");
                    h.put("Accept-Language", "en-US");
                })

                // ─────────────────────────────────────────────────────────────────
                // SSL CONFIGURATION
                // ─────────────────────────────────────────────────────────────────
                .ssl(SslConfig.custom()
                        .certificatePath("/etc/ssl/certs/api-cert.pem")
                        .handshakeTimeout(Duration.ofSeconds(10)))

                // ─────────────────────────────────────────────────────────────────
                // RESILIENCE (Retry, Circuit Breaker, Rate Limiter, Bulkhead)
                // ─────────────────────────────────────────────────────────────────
                .resilience(ResilienceConfig.custom()
                        // Retry Configuration
                        .retry(ResilienceConfig.RetryConfig.custom()
                                .maxAttempts(3)
                                .waitDuration(Duration.ofMillis(500))
                                .backoff(ResilienceConfig.BackoffStrategy.EXPONENTIAL_WITH_JITTER)
                                .backoffMultiplier(2.0)
                                .maxBackoff(Duration.ofSeconds(10))
                                .retryOnConnectionTimeout(true)
                                .retryOnReadTimeout(true)
                                .retryOnExceptions(java.io.IOException.class))

                        // Circuit Breaker Configuration
                        .circuitBreaker(ResilienceConfig.CircuitBreakerConfig.custom()
                                .windowSize(100)
                                .minCalls(10)
                                .failureRate(50)
                                .slowCallRate(80)
                                .slowCallDuration(Duration.ofSeconds(2))
                                .openStateWait(Duration.ofSeconds(60))
                                .halfOpenCalls(5)
                                .autoTransition(true))

                        // Rate Limiter Configuration
                        .rateLimiter(ResilienceConfig.RateLimiterConfig.custom()
                                .limitForPeriod(100)           // 100 requests
                                .refreshPeriod(Duration.ofSeconds(1))  // per second
                                .timeout(Duration.ofMillis(500)))      // wait up to 500ms

                        // Bulkhead Configuration (Thread Isolation)
                        .bulkhead(ResilienceConfig.BulkheadConfig.custom()
                                .maxConcurrentCalls(25)        // Max 25 concurrent calls
                                .maxWait(Duration.ofMillis(100))))  // Wait up to 100ms

                // ─────────────────────────────────────────────────────────────────
                // LOGGING (Safe: max body size, async, content-type aware)
                // ─────────────────────────────────────────────────────────────────
                .logging(LoggingConfig.custom()
                        .logAll()                              // Log request + response + headers
                        .maskFields("password", "token", "apiKey", "secret", "authorization")
                        .maskField("creditCard", 4)            // Show last 4 chars
                        .excludeFields("internalId")           // Never log this field
                        .maskSymbol('*')
                        .maxBodySize(10_000))                  // Max 10KB body logged

                // ─────────────────────────────────────────────────────────────────
                // EMAIL NOTIFICATIONS (Rate limited, Circuit Breaker protected)
                // ─────────────────────────────────────────────────────────────────
                .emailNotifier(EmailNotifierConfig.custom()
                        .async(true)                           // Never block HTTP threads
                        .rateLimit(5, Duration.ofMinutes(1))   // Max 5 emails per minute
                        .circuitBreaker(true)
                        .circuitBreakerThreshold(3)            // Open after 3 failures
                        .circuitBreakerResetTime(Duration.ofMinutes(5))
                        .host("smtp.company.com")
                        .port(587)
                        .credentials("alerts@company.com", "password")
                        .startTls(true)
                        .defaultFrom("noreply@company.com")
                        .defaultTo("ops-team@company.com", "dev-team@company.com")
                        .defaultSubject("API Error Alert"))

                // ─────────────────────────────────────────────────────────────────
                // TRACING (Correlation ID, OpenTelemetry)
                // ─────────────────────────────────────────────────────────────────
                .tracing(TracingConfig.custom()
                        .correlationId(true)
                        .correlationIdHeader("X-Correlation-Id")
                        .generateCorrelationIdIfMissing(true)
                        .openTelemetry(true)
                        .propagateHeaders("X-Request-Id", "X-Session-Id"))

                // ─────────────────────────────────────────────────────────────────
                // METRICS (Micrometer)
                // ─────────────────────────────────────────────────────────────────
                .metrics(MetricsConfig.custom()
                        .metricPrefix("cbq.http.client")
                        .commonTag("service", "user-service")
                        .normalizeUri(true)                    // Prevent high cardinality
                        .maxUriSegments(5))

                // ─────────────────────────────────────────────────────────────────
                // REQUEST FILTERS
                // ─────────────────────────────────────────────────────────────────
                .addRequestFilter(Filters.bearerToken(() -> getAuthToken()))
                .addRequestFilter(Filters.timestamp("X-Request-Timestamp"))
                .addRequestFilter(Filters.auditLog("user-service"))

                // ─────────────────────────────────────────────────────────────────
                // RESPONSE FILTERS
                // ─────────────────────────────────────────────────────────────────
                .addResponseFilter(Filters.slowResponseLog(2000))  // Log if > 2s
                .addResponseFilter(Filters.errorLog())

                // ─────────────────────────────────────────────────────────────────
                // GLOBAL ERROR MAPPERS
                // ─────────────────────────────────────────────────────────────────
                .addErrorMapper(ErrorMapper.on401(ctx -> 
                        new UnauthorizedException("Auth failed: " + ctx.getUri())))
                .addErrorMapper(ErrorMapper.on429(ctx -> 
                        new RateLimitException("Rate limited: " + ctx.getUri())))

                .build();
    }

    private static String getAuthToken() {
        // In real app, get from auth service or cache
        return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 2. ERROR HANDLING (onStatus THROWS exceptions via Mono.error)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * onStatus() THROWS the exception - it's converted to Mono.error()
     */
    public static void errorHandlingExamples(CBQRestClient client) {

        // ─────────────────────────────────────────────────────────────────
        // Example 2.1: Basic error mapping - THROWS UserNotFoundException
        // ─────────────────────────────────────────────────────────────────
        try {
            User user = client.get()
                    .uri("/users/999")  // Non-existent user
                    .onStatus(
                            status -> status.value() == 404,
                            ctx -> new UserNotFoundException("User not found: " + ctx.getUri())
                    )
                    .retrieve(User.class)
                    .block();
        } catch (UserNotFoundException e) {
            System.err.println("Caught: " + e.getMessage());
            // Output: Caught: User not found: /users/999
        }

        // ─────────────────────────────────────────────────────────────────
        // Example 2.2: Multiple error mappers
        // ─────────────────────────────────────────────────────────────────
        try {
            User user = client.get()
                    .uri("/users/123")
                    .onStatus(status -> status.value() == 404,
                            ctx -> new UserNotFoundException("User " + extractId(ctx.getUri()) + " not found"))
                    .onStatus(status -> status.value() == 401,
                            ctx -> new UnauthorizedException("Not authorized to access user"))
                    .onStatus(status -> status.value() == 403,
                            ctx -> new SecurityException("Forbidden: " + ctx.getResponseBody()))
                    .onStatus(HttpStatus::is5xxServerError,
                            ctx -> new ServiceUnavailableException("Service error: " + ctx.getStatusCode()))
                    .retrieve(User.class)
                    .block();
        } catch (UserNotFoundException | UnauthorizedException | ServiceUnavailableException e) {
            System.err.println("Error: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }

        // ─────────────────────────────────────────────────────────────────
        // Example 2.3: Using ErrorMapper helpers
        // ─────────────────────────────────────────────────────────────────
        try {
            Order order = client.get()
                    .uri("/orders/456")
                    .onStatus(status -> status.value() == 404,
                            ctx -> new OrderNotFoundException("Order not found"))
                    .onStatus(status -> status.value() == 400,
                            ErrorMapper.ErrorContext::toException)  // Uses built-in exception
                    .retrieve(Order.class)
                    .block();
        } catch (OrderNotFoundException e) {
            // Handle not found
        } catch (CBQRestClientException e) {
            // Handle other errors
            System.err.println("Request failed: " + e.getRequestId());
        }

        // ─────────────────────────────────────────────────────────────────
        // Example 2.4: Reactive error handling (non-blocking)
        // ─────────────────────────────────────────────────────────────────
        client.get()
                .uri("/users/123")
                .onStatus(status -> status.value() == 404,
                        ctx -> new UserNotFoundException("Not found"))
                .retrieve(User.class)
                .doOnNext(user -> System.out.println("Got user: " + user.getName()))
                .doOnError(UserNotFoundException.class, e -> 
                        System.err.println("User not found!"))
                .doOnError(CBQRestClientException.class, e -> 
                        System.err.println("Request error: " + e.getMessage()))
                .onErrorResume(UserNotFoundException.class, e -> {
                    // Return default user
                    return reactor.core.publisher.Mono.just(new User(0L, "Unknown", "unknown@example.com"));
                })
                .subscribe(
                        user -> System.out.println("Final user: " + user.getName()),
                        error -> System.err.println("Unhandled error: " + error.getMessage())
                );
    }

    private static String extractId(String uri) {
        String[] parts = uri.split("/");
        return parts[parts.length - 1];
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 3. ALL OVERRIDE EXAMPLES
    // ═══════════════════════════════════════════════════════════════════════════

    public static void allOverrideExamples(CBQRestClient client) {

        // ─────────────────────────────────────────────────────────────────
        // Example 3.1: Response Timeout Override (ONLY timeout that can be overridden per-request)
        // ─────────────────────────────────────────────────────────────────
        // Connection, read, and write timeouts are set at Netty level and 
        // CANNOT be changed per-request. Use CBQRestClientPool for different 
        // timeout profiles (see section 14).
        
        CBQResponse<String> slowEndpoint = client.get()
                .uri("/reports/generate")
                .override(o -> o.responseTimeout(Duration.ofMinutes(5)))  // Only response timeout!
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 3.2: Disable Retry Only
        // ─────────────────────────────────────────────────────────────────
        // Use for non-idempotent operations like payments
        CBQResponse<PaymentResult> payment = client.post()
                .uri("/payments/process")
                .bodyValue(new PaymentRequest(123L, 99.99, "USD"))
                .override(o -> o.disableRetry())  // Don't retry payments!
                .retrieve(PaymentResult.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 3.3: Disable Circuit Breaker Only
        // ─────────────────────────────────────────────────────────────────
        // For critical health checks that should always attempt
        CBQResponse<String> health = client.get()
                .uri("/health")
                .override(o -> o.disableCircuitBreaker())
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 3.4: Disable Rate Limiter Only
        // ─────────────────────────────────────────────────────────────────
        // For admin/priority operations
        CBQResponse<String> adminOp = client.post()
                .uri("/admin/critical-operation")
                .override(o -> o.disableRateLimiter())
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 3.5: Disable Bulkhead Only
        // ─────────────────────────────────────────────────────────────────
        CBQResponse<String> urgent = client.get()
                .uri("/urgent/request")
                .override(o -> o.disableBulkhead())
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 3.6: Disable ALL Resilience
        // ─────────────────────────────────────────────────────────────────
        // For testing or when you need raw behavior
        CBQResponse<String> raw = client.get()
                .uri("/test/endpoint")
                .override(RequestOverride::disableAllResilience)
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 3.7: Custom Retry Settings
        // ─────────────────────────────────────────────────────────────────
        CBQResponse<String> customRetry = client.get()
                .uri("/flaky/endpoint")
                .override(o -> o
                        .maxAttempts(5)
                        .waitDuration(Duration.ofSeconds(2)))
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 3.8: Combined Overrides
        // ─────────────────────────────────────────────────────────────────
        CBQResponse<String> combined = client.post()
                .uri("/complex/operation")
                .bodyValue(Map.of("key", "value"))
                .override(o -> o
                        .disableRetry()                      // Non-idempotent
                        .disableCircuitBreaker()             // Critical operation
                        .responseTimeout(Duration.ofMinutes(2)))  // Long response timeout
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 3.9: Response Timeout with Resilience Disabled
        // ─────────────────────────────────────────────────────────────────
        CBQResponse<String> longRunning = client.post()
                .uri("/batch/process")
                .bodyValue(List.of(1, 2, 3, 4, 5))
                .override(o -> o
                        .disableRetry()                           // Don't retry batch
                        .disableCircuitBreaker()                  // Batch is expected to be slow
                        .responseTimeout(Duration.ofMinutes(10))) // Long response timeout
                .retrieve(String.class)
                .block();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 14. CLIENT POOL FOR DIFFERENT TIMEOUT PROFILES (Connection/Read/Write)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Since connection, read, and write timeouts are configured at Netty level
     * and CANNOT be changed per-request, use CBQRestClientPool to maintain
     * multiple clients with different timeout profiles.
     */
    public static void clientPoolExamples() {
        
        // ─────────────────────────────────────────────────────────────────
        // Example 14.1: Create pool with shared configuration
        // ─────────────────────────────────────────────────────────────────
        CBQRestClientPool pool = CBQRestClientPool.builder()
                .baseUrl("https://api.example.com")
                .resilience(ResilienceConfig.defaults())
                .logging(LoggingConfig.custom().logAll().maskFields("password", "token"))
                .tracing(TracingConfig.defaults())
                .ssl(SslConfig.custom().certificatePath("/certs/api.pem"))
                .build();

        // ─────────────────────────────────────────────────────────────────
        // Example 14.2: Use pre-defined profiles
        // ─────────────────────────────────────────────────────────────────
        
        // FAST: 2s connection, 5s read, 10s response
        // Good for: health checks, simple lookups
        CBQRestClient fastClient = pool.getFast();
        fastClient.get()
                .uri("/health")
                .retrieve(String.class)
                .block();

        // DEFAULT: 5s connection, 30s read, 60s response
        // Good for: most API calls
        CBQRestClient defaultClient = pool.getDefault();
        defaultClient.get()
                .uri("/users/123")
                .retrieve(User.class)
                .block();

        // SLOW: 10s connection, 2min read, 5min response
        // Good for: report generation, file downloads
        CBQRestClient slowClient = pool.getSlow();
        slowClient.get()
                .uri("/reports/monthly")
                .retrieve(String.class)
                .block();

        // BATCH: 10s connection, 10min read, 30min response
        // Good for: batch processing, large data transfers
        CBQRestClient batchClient = pool.getBatch();
        batchClient.post()
                .uri("/batch/import")
                .bodyValue(List.of(/* large dataset */))
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 14.3: Create custom timeout profile
        // ─────────────────────────────────────────────────────────────────
        CBQRestClient customClient = pool.getOrCreate("file-upload",
                CBQRestClientPool.TimeoutProfile.builder()
                        .connection(Duration.ofSeconds(5))
                        .read(Duration.ofSeconds(30))
                        .write(Duration.ofMinutes(5))   // Long write for uploads
                        .response(Duration.ofMinutes(10))
                        .build());

        customClient.post()
                .uri("/files/upload")
                .bodyValue(new byte[1024 * 1024])  // 1MB file
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 14.4: Retrieve existing client by name
        // ─────────────────────────────────────────────────────────────────
        CBQRestClient existingClient = pool.get("file-upload");  // Must exist
        
        // ─────────────────────────────────────────────────────────────────
        // Example 14.5: Real-world usage pattern
        // ─────────────────────────────────────────────────────────────────
        
        // In a service class:
        // @Autowired CBQRestClientPool apiPool;
        
        // Health check endpoint - use fast client
        String healthCheck() {
            return pool.getFast().get()
                    .uri("/health")
                    .retrieve(String.class)
                    .block();
        }
        
        // Normal API call - use default client
        User getUser(Long id) {
            return pool.getDefault().get()
                    .uri("/users/" + id)
                    .retrieve(User.class)
                    .map(CBQResponse::getBody)
                    .block();
        }
        
        // Report generation - use slow client
        String generateReport(String reportType) {
            return pool.getSlow().get()
                    .uri("/reports/" + reportType)
                    .override(o -> o.disableRetry())  // Don't retry expensive operation
                    .retrieve(String.class)
                    .map(CBQResponse::getBody)
                    .block();
        }
        
        // Batch import - use batch client with response timeout override
        String importData(List<Object> data) {
            return pool.getBatch().post()
                    .uri("/batch/import")
                    .bodyValue(data)
                    .override(o -> o
                            .disableRetry()
                            .disableCircuitBreaker()
                            .responseTimeout(Duration.ofMinutes(45)))  // Extra long
                    .retrieve(String.class)
                    .map(CBQResponse::getBody)
                    .block();
        }

        // ─────────────────────────────────────────────────────────────────
        // Example 14.6: Shutdown pool
        // ─────────────────────────────────────────────────────────────────
        pool.shutdown();  // Shuts down all clients
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 4. PARALLEL CALLS - WAIT FOR ALL
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Parallel execution with waitAll() - uses Mono.zip under the hood
     * All requests must succeed, or the entire operation fails
     */
    public static void parallelWaitForAll(CBQRestClient client) {

        // Execute 3 requests in parallel
        CBQParallelResult<Object> result = client.parallel(
                client.get().uri("/users/1").retrieve(User.class),
                client.get().uri("/orders/100").retrieve(Order.class),
                client.get().uri("/products/50").retrieve(Product.class)
        ).waitAll().execute().block();

        // ─────────────────────────────────────────────────────────────────
        // How the response looks and is used:
        // ─────────────────────────────────────────────────────────────────

        // Check overall result
        System.out.println("All successful: " + result.allSuccessful());  // true
        System.out.println("Total duration: " + result.getTotalDurationMs() + "ms");
        System.out.println("Response count: " + result.size());  // 3
        System.out.println("Success count: " + result.successCount());  // 3
        System.out.println("Error count: " + result.errorCount());  // 0

        // Get individual responses by index
        CBQResponse<Object> userResponse = result.getResponse(0);
        CBQResponse<Object> orderResponse = result.getResponse(1);
        CBQResponse<Object> productResponse = result.getResponse(2);

        // Access bodies (need to cast)
        User user = (User) userResponse.getBody();
        Order order = (Order) orderResponse.getBody();
        Product product = (Product) productResponse.getBody();

        System.out.println("User: " + user.getName());
        System.out.println("Order: " + order.getStatus());
        System.out.println("Product: " + product.getName());

        // Access response metadata
        System.out.println("User request ID: " + userResponse.getRequestId());
        System.out.println("User status: " + userResponse.getStatusCode());
        System.out.println("User duration: " + userResponse.getDurationMs() + "ms");
        System.out.println("User correlation ID: " + userResponse.getCorrelationId());

        // Get all bodies as list
        List<Object> allBodies = result.getBodies();
        System.out.println("All bodies: " + allBodies.size());

        // Get all successful responses
        List<CBQResponse<Object>> successfulResponses = result.getSuccessfulResponses();

        // ─────────────────────────────────────────────────────────────────
        // Type-safe parallel (same type)
        // ─────────────────────────────────────────────────────────────────
        CBQParallelResult<User> usersResult = client.parallel(
                client.get().uri("/users/1").retrieve(User.class),
                client.get().uri("/users/2").retrieve(User.class),
                client.get().uri("/users/3").retrieve(User.class)
        ).waitAll().execute().block();

        // Direct access without casting
        List<User> users = usersResult.getBodies();
        users.forEach(u -> System.out.println("User: " + u.getName()));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 5. PARALLEL CALLS - FAIL FAST
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Parallel execution with failFast() - uses Flux.merge
     * Fails immediately on first error, cancels remaining requests
     */
    public static void parallelFailFast(CBQRestClient client) {

        try {
            CBQParallelResult<Object> result = client.parallel(
                    client.get().uri("/users/1").retrieve(User.class),
                    client.get().uri("/users/999").retrieve(User.class),  // This will 404
                    client.get().uri("/users/3").retrieve(User.class)
            ).failFast().execute().block();

            // This won't be reached if any request fails
            System.out.println("All succeeded: " + result.successCount());

        } catch (CBQRestClientException e) {
            // Catch the first failure
            System.err.println("Fail fast triggered!");
            System.err.println("Error: " + e.getMessage());
            System.err.println("Request ID: " + e.getRequestId());
            System.err.println("URI: " + e.getUri());
        }

        // ─────────────────────────────────────────────────────────────────
        // With error mapping
        // ─────────────────────────────────────────────────────────────────
        try {
            client.parallel(
                    client.get().uri("/users/1")
                            .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException("User 1 not found"))
                            .retrieve(User.class),
                    client.get().uri("/users/999")
                            .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException("User 999 not found"))
                            .retrieve(User.class)
            ).failFast().execute().block();

        } catch (UserNotFoundException e) {
            System.err.println("User not found: " + e.getMessage());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 6. PARALLEL CALLS - PARTIAL SUCCESS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Parallel execution with partialSuccess() - continues on errors
     * Collects all successful responses and all errors separately
     */
    public static void parallelPartialSuccess(CBQRestClient client) {

        CBQParallelResult<User> result = client.parallel(
                client.get().uri("/users/1").retrieve(User.class),      // OK
                client.get().uri("/users/999").retrieve(User.class),    // 404
                client.get().uri("/users/3").retrieve(User.class),      // OK
                client.get().uri("/users/888").retrieve(User.class)     // 404
        ).partialSuccess().execute().block();

        // ─────────────────────────────────────────────────────────────────
        // How to use the response:
        // ─────────────────────────────────────────────────────────────────

        System.out.println("Has errors: " + result.hasErrors());     // true
        System.out.println("Success count: " + result.successCount());  // 2
        System.out.println("Error count: " + result.errorCount());      // 2
        System.out.println("Total: " + result.size());                  // 4

        // Get successful responses
        List<CBQResponse<User>> successful = result.getSuccessfulResponses();
        System.out.println("Successful users:");
        for (CBQResponse<User> resp : successful) {
            System.out.println("  - " + resp.getBody().getName() + " (id=" + resp.getBody().getId() + ")");
        }

        // Get errors by index
        Map<Integer, Throwable> errors = result.getErrors();
        System.out.println("Errors:");
        errors.forEach((index, error) -> {
            System.out.println("  - Index " + index + ": " + error.getMessage());
        });

        // Check specific index
        if (result.getError(1) != null) {
            System.out.println("Request at index 1 failed: " + result.getError(1).getMessage());
        }

        // Get all bodies (only from successful)
        List<User> users = result.getBodies();
        System.out.println("Got " + users.size() + " users successfully");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 7. SEQUENTIAL CALLS - DEPENDENT CHAIN
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Sequential chaining - each step depends on previous result
     */
    public static void sequentialChainExamples(CBQRestClient client) {

        // ─────────────────────────────────────────────────────────────────
        // Example 7.1: Basic chain WITHOUT overrides
        // ─────────────────────────────────────────────────────────────────
        // Get user -> Get user's orders -> Get first order's product
        Product product = client.sequence()
                // Step 1: Get user
                .then(() -> client.get()
                        .uri("/users/123")
                        .retrieve(User.class))
                // Step 2: Use user ID to get their orders
                .then((User user) -> client.get()
                        .uri("/orders?userId=" + user.getId())
                        .retrieve(Order[].class))
                // Step 3: Use first order to get product
                .then((Order[] orders) -> client.get()
                        .uri("/products/" + orders[0].getId())
                        .retrieve(Product.class))
                .<Product>execute()
                .block();

        System.out.println("Final product: " + product.getName());

        // ─────────────────────────────────────────────────────────────────
        // Example 7.2: Chain WITH overrides at each step
        // ─────────────────────────────────────────────────────────────────
        PaymentResult paymentResult = client.sequence()
                // Step 1: Get user (with custom timeout)
                .then(() -> client.get()
                        .uri("/users/123")
                        .override(o -> o.timeouts(t -> t.read(Duration.ofSeconds(5))))
                        .retrieve(User.class))
                // Step 2: Create order (disable retry - not idempotent)
                .then((User user) -> client.post()
                        .uri("/orders")
                        .bodyValue(Map.of("userId", user.getId(), "items", List.of(1, 2, 3)))
                        .override(o -> o.disableRetry())
                        .retrieve(Order.class))
                // Step 3: Process payment (disable all resilience - critical)
                .then((Order order) -> client.post()
                        .uri("/payments/process")
                        .bodyValue(new PaymentRequest(order.getId(), order.getAmount(), "USD"))
                        .override(o -> o
                                .disableRetry()
                                .disableCircuitBreaker()
                                .timeouts(t -> t.response(Duration.ofMinutes(1))))
                        .onErrorNotify(mail -> mail
                                .subject("Payment Failed!")
                                .addContext("orderId", order.getId()))
                        .retrieve(PaymentResult.class))
                .<PaymentResult>execute()
                .block();

        System.out.println("Payment transaction: " + paymentResult.getTransactionId());

        // ─────────────────────────────────────────────────────────────────
        // Example 7.3: Chain with error handling at each step
        // ─────────────────────────────────────────────────────────────────
        try {
            String result = client.sequence()
                    .then(() -> client.get()
                            .uri("/users/123")
                            .onStatus(s -> s.value() == 404, 
                                    ctx -> new UserNotFoundException("User not found"))
                            .retrieve(User.class))
                    .then((User user) -> client.get()
                            .uri("/orders?userId=" + user.getId())
                            .onStatus(s -> s.value() == 404,
                                    ctx -> new OrderNotFoundException("No orders for user"))
                            .retrieve(Order[].class))
                    .<Order[]>execute()
                    .map(orders -> "Found " + orders.length + " orders")
                    .block();

            System.out.println(result);

        } catch (UserNotFoundException e) {
            System.err.println("User error: " + e.getMessage());
        } catch (OrderNotFoundException e) {
            System.err.println("Order error: " + e.getMessage());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 8. DISABLE LOGGING + METRICS FOR ONE CALL
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Note: Logging and metrics are client-level, but you can create 
     * a separate client for specific calls, or filter in your logging config
     */
    public static void disableLoggingAndMetrics() {

        // ─────────────────────────────────────────────────────────────────
        // Option 1: Create a separate "silent" client
        // ─────────────────────────────────────────────────────────────────
        CBQRestClient silentClient = CBQRestClientBuilder.builder("silent-client")
                .baseUrl("https://api.example.com")
                .logging(LoggingConfig.disabled())      // No logging
                .metrics(MetricsConfig.disabled())      // No metrics
                .tracing(TracingConfig.disabled())      // No tracing
                .resilience(ResilienceConfig.disabled()) // No resilience
                .build();

        // Use for health checks, internal calls, etc.
        silentClient.get()
                .uri("/internal/health")
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Option 2: Minimal client for specific use case
        // ─────────────────────────────────────────────────────────────────
        CBQRestClient minimalClient = CBQRestClientBuilder.builder("minimal")
                .baseUrl("https://api.example.com")
                .timeouts(TimeoutConfig.defaults()
                        .connection(Duration.ofSeconds(2))
                        .response(Duration.ofSeconds(5)))
                // Everything else disabled by default
                .build();

        minimalClient.get()
                .uri("/quick/check")
                .retrieve(String.class)
                .block();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 9. CORRELATION ID PROPAGATION
    // ═══════════════════════════════════════════════════════════════════════════

    public static void correlationIdExamples(CBQRestClient client) {

        // ─────────────────────────────────────────────────────────────────
        // Example 9.1: Auto-generated correlation ID
        // ─────────────────────────────────────────────────────────────────
        // If no X-Correlation-Id is passed, one is generated automatically
        CBQResponse<User> response = client.get()
                .uri("/users/123")
                .retrieve(User.class)
                .block();

        // Access the correlation ID from response
        System.out.println("Correlation ID: " + response.getCorrelationId());
        System.out.println("Request ID: " + response.getRequestId());

        // ─────────────────────────────────────────────────────────────────
        // Example 9.2: Pass existing correlation ID
        // ─────────────────────────────────────────────────────────────────
        String incomingCorrelationId = "abc-123-def-456";  // From incoming request

        CBQResponse<User> response2 = client.get()
                .uri("/users/123")
                .header("X-Correlation-Id", incomingCorrelationId)  // Propagate
                .retrieve(User.class)
                .block();

        // Same correlation ID is used
        System.out.println("Propagated ID: " + response2.getCorrelationId());

        // ─────────────────────────────────────────────────────────────────
        // Example 9.3: Chain with correlation ID
        // ─────────────────────────────────────────────────────────────────
        // Correlation ID is automatically propagated through the chain
        client.sequence()
                .then(() -> client.get().uri("/users/1").retrieve(User.class))
                .then((User user) -> client.get()
                        .uri("/orders?userId=" + user.getId())
                        .retrieve(Order[].class))
                .execute()
                .block();
        // All requests in the chain share the same correlation ID

        // ─────────────────────────────────────────────────────────────────
        // Example 9.4: Parallel with correlation ID
        // ─────────────────────────────────────────────────────────────────
        CBQParallelResult<Object> parallelResult = client.parallel(
                client.get().uri("/users/1").retrieve(User.class),
                client.get().uri("/orders/1").retrieve(Order.class)
        ).waitAll().execute().block();

        // Each parallel request may have its own correlation ID
        String userId1CorrelationId = parallelResult.getResponse(0).getCorrelationId();
        String orderId1CorrelationId = parallelResult.getResponse(1).getCorrelationId();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 10. RATE LIMITING REJECTION HANDLING
    // ═══════════════════════════════════════════════════════════════════════════

    public static void rateLimitingExamples(CBQRestClient client) {

        // ─────────────────────────────────────────────────────────────────
        // Example 10.1: Handle rate limit exception
        // ─────────────────────────────────────────────────────────────────
        try {
            // If rate limit is exceeded, RateLimitExceededException is thrown
            for (int i = 0; i < 200; i++) {
                client.get()
                        .uri("/users/" + i)
                        .retrieve(User.class)
                        .block();
            }
        } catch (RateLimitExceededException e) {
            System.err.println("Rate limit exceeded!");
            System.err.println("Rate limiter: " + e.getRateLimiterName());
            System.err.println("Request ID: " + e.getRequestId());
            System.err.println("URI: " + e.getUri());

            // Implement backoff
            try {
                Thread.sleep(1000);  // Wait 1 second
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            }
        }

        // ─────────────────────────────────────────────────────────────────
        // Example 10.2: Reactive rate limit handling
        // ─────────────────────────────────────────────────────────────────
        client.get()
                .uri("/users/123")
                .retrieve(User.class)
                .doOnError(RateLimitExceededException.class, e -> {
                    System.err.println("Rate limited! Will retry after delay...");
                })
                .retryWhen(reactor.util.retry.Retry.backoff(3, Duration.ofSeconds(1))
                        .filter(ex -> ex instanceof RateLimitExceededException))
                .subscribe(
                        user -> System.out.println("Got user: " + user.getName()),
                        error -> System.err.println("Failed after retries: " + error.getMessage())
                );

        // ─────────────────────────────────────────────────────────────────
        // Example 10.3: Bypass rate limiter for specific request
        // ─────────────────────────────────────────────────────────────────
        // For admin/priority operations
        client.get()
                .uri("/admin/critical")
                .override(o -> o.disableRateLimiter())
                .retrieve(String.class)
                .block();

        // ─────────────────────────────────────────────────────────────────
        // Example 10.4: Handle server-side 429 response
        // ─────────────────────────────────────────────────────────────────
        try {
            client.get()
                    .uri("/external-api/data")
                    .onStatus(status -> status.value() == 429, ctx -> {
                        // Extract retry-after header if present
                        String retryAfter = ctx.getHeaders().getFirst("Retry-After");
                        return new RateLimitException(
                                "Server rate limit. Retry after: " + retryAfter);
                    })
                    .retrieve(String.class)
                    .block();
        } catch (RateLimitException e) {
            System.err.println(e.getMessage());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 11. EMAIL USE CASES - ALL
    // ═══════════════════════════════════════════════════════════════════════════

    public static void emailUseCases(CBQRestClient client) {

        // ─────────────────────────────────────────────────────────────────
        // Example 11.1: Basic email notification on error
        // ─────────────────────────────────────────────────────────────────
        client.post()
                .uri("/payments/process")
                .bodyValue(new PaymentRequest(100L, 99.99, "USD"))
                .onErrorNotify(mail -> mail
                        .to("payments@company.com")
                        .subject("Payment Processing Failed"))
                .retrieve(PaymentResult.class)
                .subscribe();  // Email sent async if error occurs

        // ─────────────────────────────────────────────────────────────────
        // Example 11.2: Email with full context
        // ─────────────────────────────────────────────────────────────────
        PaymentRequest paymentRequest = new PaymentRequest(200L, 149.99, "EUR");

        client.post()
                .uri("/payments/process")
                .bodyValue(paymentRequest)
                .onErrorNotify(mail -> mail
                        .from("alerts@company.com")
                        .to("payments@company.com", "oncall@company.com")
                        .subject("CRITICAL: Payment Failed - Order #" + paymentRequest.getOrderId())
                        .addContext("orderId", paymentRequest.getOrderId())
                        .addContext("amount", paymentRequest.getAmount())
                        .addContext("currency", paymentRequest.getCurrency())
                        .addContext("timestamp", System.currentTimeMillis())
                        .addContext("environment", "production")
                        .html(false))  // Plain text email
                .retrieve(PaymentResult.class)
                .subscribe();

        // ─────────────────────────────────────────────────────────────────
        // Example 11.3: HTML email
        // ─────────────────────────────────────────────────────────────────
        client.post()
                .uri("/orders/create")
                .bodyValue(Map.of("items", List.of(1, 2, 3)))
                .onErrorNotify(mail -> mail
                        .to("orders@company.com")
                        .subject("Order Creation Failed")
                        .body("<html><body>" +
                                "<h1>Order Creation Failed</h1>" +
                                "<p>Please check the order service.</p>" +
                                "</body></html>")
                        .html(true))
                .retrieve(Order.class)
                .subscribe();

        // ─────────────────────────────────────────────────────────────────
        // Example 11.4: Email with dynamic recipients
        // ─────────────────────────────────────────────────────────────────
        String serviceOwner = getServiceOwner("payment-service");
        String oncallEngineer = getOncallEngineer();

        client.post()
                .uri("/payments/process")
                .bodyValue(paymentRequest)
                .onErrorNotify(mail -> mail
                        .to(serviceOwner, oncallEngineer)
                        .subject("Payment Service Error"))
                .retrieve(PaymentResult.class)
                .subscribe();

        // ─────────────────────────────────────────────────────────────────
        // Example 11.5: Email in sequential chain
        // ─────────────────────────────────────────────────────────────────
        client.sequence()
                .then(() -> client.get()
                        .uri("/users/123")
                        .onErrorNotify(mail -> mail
                                .to("user-service@company.com")
                                .subject("User Lookup Failed"))
                        .retrieve(User.class))
                .then((User user) -> client.post()
                        .uri("/notifications/send")
                        .bodyValue(Map.of("userId", user.getId(), "message", "Welcome!"))
                        .onErrorNotify(mail -> mail
                                .to("notification-service@company.com")
                                .subject("Notification Send Failed")
                                .addContext("userId", user.getId()))
                        .retrieve(String.class))
                .execute()
                .subscribe();

        // ─────────────────────────────────────────────────────────────────
        // Example 11.6: Email only for specific errors
        // ─────────────────────────────────────────────────────────────────
        client.post()
                .uri("/orders/process")
                .bodyValue(Map.of("id", 123))
                .retrieve(Order.class)
                .doOnError(error -> {
                    // Only send email for 5xx errors
                    if (error instanceof CBQRestClientException) {
                        CBQRestClientException e = (CBQRestClientException) error;
                        if (e.getStatusCode() != null && e.getStatusCode() >= 500) {
                            // Manually trigger email (via your email service)
                            sendCriticalAlert(e);
                        }
                    }
                })
                .subscribe();

        // ─────────────────────────────────────────────────────────────────
        // Example 11.7: Rate limiting prevents email storms
        // ─────────────────────────────────────────────────────────────────
        // The email notifier is configured with rate limiting:
        // .rateLimit(5, Duration.ofMinutes(1))
        // 
        // This means:
        // - Max 5 emails per minute
        // - After 5 emails, subsequent errors won't trigger emails
        // - After 1 minute, the window resets
        //
        // Also circuit breaker protected:
        // .circuitBreakerThreshold(3)
        // - After 3 consecutive email send failures, stops trying
        // - Prevents blocking on SMTP issues

        // ─────────────────────────────────────────────────────────────────
        // Example 11.8: Conditional email (in chain)
        // ─────────────────────────────────────────────────────────────────
        client.post()
                .uri("/critical/operation")
                .bodyValue(Map.of("important", true))
                .override(o -> o.disableRetry())  // Critical, non-idempotent
                .onErrorNotify(mail -> mail
                        .to("critical-alerts@company.com")
                        .subject("URGENT: Critical Operation Failed")
                        .addContext("severity", "HIGH")
                        .addContext("requiresImmediate", true))
                .retrieve(String.class)
                .subscribe();
    }

    private static String getServiceOwner(String service) {
        return "owner-" + service + "@company.com";
    }

    private static String getOncallEngineer() {
        return "oncall@company.com";
    }

    private static void sendCriticalAlert(CBQRestClientException e) {
        System.err.println("Sending critical alert for: " + e.getMessage());
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 12. BULKHEAD REJECTION HANDLING
    // ═══════════════════════════════════════════════════════════════════════════

    public static void bulkheadExamples(CBQRestClient client) {

        // ─────────────────────────────────────────────────────────────────
        // Example 12.1: Handle bulkhead full exception
        // ─────────────────────────────────────────────────────────────────
        try {
            client.get()
                    .uri("/users/123")
                    .retrieve(User.class)
                    .block();
        } catch (BulkheadFullException e) {
            System.err.println("Bulkhead is full!");
            System.err.println("Bulkhead: " + e.getBulkheadName());
            System.err.println("Max concurrent calls reached");
        }

        // ─────────────────────────────────────────────────────────────────
        // Example 12.2: Bypass bulkhead for priority requests
        // ─────────────────────────────────────────────────────────────────
        client.get()
                .uri("/priority/request")
                .override(o -> o.disableBulkhead())
                .retrieve(String.class)
                .block();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 13. CIRCUIT BREAKER HANDLING
    // ═══════════════════════════════════════════════════════════════════════════

    public static void circuitBreakerExamples(CBQRestClient client) {

        // ─────────────────────────────────────────────────────────────────
        // Example 13.1: Handle circuit breaker open
        // ─────────────────────────────────────────────────────────────────
        try {
            client.get()
                    .uri("/flaky/service")
                    .retrieve(String.class)
                    .block();
        } catch (CircuitBreakerOpenException e) {
            System.err.println("Circuit breaker is OPEN!");
            System.err.println("Circuit breaker: " + e.getCircuitBreakerName());
            System.err.println("Service is temporarily unavailable");

            // Return fallback or cached data
            // return cachedData;
        }

        // ─────────────────────────────────────────────────────────────────
        // Example 13.2: Bypass circuit breaker for health checks
        // ─────────────────────────────────────────────────────────────────
        client.get()
                .uri("/health")
                .override(o -> o.disableCircuitBreaker())
                .retrieve(String.class)
                .block();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // MAIN
    // ═══════════════════════════════════════════════════════════════════════════

    public static void main(String[] args) {
        CBQRestClient client = createFullyConfiguredClient();

        System.out.println("=== CBQ REST Client v2.0 Examples ===\n");

        // Run examples (uncomment as needed)
        // errorHandlingExamples(client);
        // allOverrideExamples(client);
        // parallelWaitForAll(client);
        // parallelFailFast(client);
        // parallelPartialSuccess(client);
        // sequentialChainExamples(client);
        // correlationIdExamples(client);
        // rateLimitingExamples(client);
        // emailUseCases(client);

        client.shutdown();
    }
}
