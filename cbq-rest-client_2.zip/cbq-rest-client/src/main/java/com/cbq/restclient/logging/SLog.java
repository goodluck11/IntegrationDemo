package com.cbq.restclient.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Fast, efficient structured JSON logger - Lombok @Slf4j style.
 * 
 * <h2>Usage (like Lombok)</h2>
 * <pre>{@code
 * public class OrderService {
 *     private static final SLog slog = SLog.forClass(OrderService.class);
 *     
 *     public void process() {
 *         slog.http("POST", "/payments", 200, 145);
 *         slog.db("INSERT", "orders", 45);
 *         slog.email("user@test.com", "Order Confirmed", 230);
 *         slog.cache("HIT", "users", "user_123");
 *         slog.queue("PUBLISH", "order-events", "msg_123");
 *         slog.task("process_order", 450);
 *         slog.error("payment_failed", "Insufficient funds", "INS_001");
 *     }
 * }
 * }</pre>
 * 
 * <h2>Output (Single-line JSON, Splunk-friendly)</h2>
 * <pre>
 * {"ts":"2024-01-15T10:30:00Z","type":"http","cid":"corr_abc","rid":"req_001","c":"OrderService","method":"POST","uri":"/payments","status":200,"ms":145}
 * {"ts":"2024-01-15T10:30:00Z","type":"db","cid":"corr_abc","c":"OrderService","op":"INSERT","table":"orders","ms":45}
 * {"ts":"2024-01-15T10:30:00Z","type":"email","cid":"corr_abc","c":"OrderService","to":"us**@test.com","subject":"Order Confirmed","ms":230}
 * </pre>
 * 
 * <h2>Performance</h2>
 * <ul>
 *   <li>No object allocation per log (reuses StringBuilder)</li>
 *   <li>No reflection</li>
 *   <li>No JSON library overhead</li>
 *   <li>Thread-safe with ThreadLocal StringBuilder</li>
 * </ul>
 */
public final class SLog {
    
    private static final Map<Class<?>, SLog> CACHE = new ConcurrentHashMap<>();
    private static final ThreadLocal<StringBuilder> SB = ThreadLocal.withInitial(() -> new StringBuilder(512));
    
    private final Logger log;
    private final String component;
    
    private SLog(Class<?> clazz) {
        this.log = LoggerFactory.getLogger(clazz);
        this.component = clazz.getSimpleName();
    }
    
    private SLog(Class<?> clazz, String component) {
        this.log = LoggerFactory.getLogger(clazz);
        this.component = component != null && !component.isEmpty() ? component : clazz.getSimpleName();
    }
    
    /**
     * Get logger for class (cached, like Lombok)
     */
    public static SLog forClass(Class<?> clazz) {
        return CACHE.computeIfAbsent(clazz, SLog::new);
    }
    
    /**
     * Get logger with custom component name
     */
    public static SLog forClass(Class<?> clazz, String component) {
        return new SLog(clazz, component);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // HTTP LOGGING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Log HTTP request/response */
    public void http(String method, String uri, int status, long ms) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("http");
        kv(sb, "method", method);
        kv(sb, "uri", uri);
        kvInt(sb, "status", status);
        kvLong(sb, "ms", ms);
        end(sb);
    }
    
    /** Log HTTP request */
    public void httpReq(String method, String uri, String requestId) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("http_req");
        kv(sb, "rid", requestId);
        kv(sb, "method", method);
        kv(sb, "uri", uri);
        end(sb);
    }
    
    /** Log HTTP response */
    public void httpRes(String requestId, int status, long ms) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("http_res");
        kv(sb, "rid", requestId);
        kvInt(sb, "status", status);
        kvLong(sb, "ms", ms);
        end(sb);
    }
    
    /** Log HTTP error */
    public void httpErr(String method, String uri, String error, long ms) {
        if (!log.isErrorEnabled()) return;
        StringBuilder sb = begin("http_err");
        kv(sb, "method", method);
        kv(sb, "uri", uri);
        kv(sb, "err", error);
        kvLong(sb, "ms", ms);
        endErr(sb);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // DATABASE LOGGING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Log DB operation */
    public void db(String op, String table, long ms) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("db");
        kv(sb, "op", op);
        kv(sb, "table", table);
        kvLong(sb, "ms", ms);
        end(sb);
    }
    
    /** Log DB operation with row count */
    public void db(String op, String table, int rows, long ms) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("db");
        kv(sb, "op", op);
        kv(sb, "table", table);
        kvInt(sb, "rows", rows);
        kvLong(sb, "ms", ms);
        end(sb);
    }
    
    /** Log DB error */
    public void dbErr(String op, String table, String error, long ms) {
        if (!log.isErrorEnabled()) return;
        StringBuilder sb = begin("db_err");
        kv(sb, "op", op);
        kv(sb, "table", table);
        kv(sb, "err", error);
        kvLong(sb, "ms", ms);
        endErr(sb);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // EMAIL LOGGING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Log email sent */
    public void email(String to, String subject, long ms) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("email");
        kv(sb, "to", maskEmail(to));
        kv(sb, "subject", subject);
        kvLong(sb, "ms", ms);
        end(sb);
    }
    
    /** Log email error */
    public void emailErr(String to, String subject, String error) {
        if (!log.isErrorEnabled()) return;
        StringBuilder sb = begin("email_err");
        kv(sb, "to", maskEmail(to));
        kv(sb, "subject", subject);
        kv(sb, "err", error);
        endErr(sb);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // CACHE LOGGING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Log cache hit/miss */
    public void cache(String result, String cacheName, String key) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("cache");
        kv(sb, "result", result);  // HIT or MISS
        kv(sb, "cache", cacheName);
        kv(sb, "key", key);
        end(sb);
    }
    
    /** Log cache hit */
    public void cacheHit(String cacheName, String key) {
        cache("HIT", cacheName, key);
    }
    
    /** Log cache miss */
    public void cacheMiss(String cacheName, String key) {
        cache("MISS", cacheName, key);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // QUEUE / MESSAGING LOGGING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Log queue operation */
    public void queue(String op, String queueName, String messageId) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("queue");
        kv(sb, "op", op);  // PUBLISH, CONSUME, ACK, NACK
        kv(sb, "queue", queueName);
        kv(sb, "mid", messageId);
        end(sb);
    }
    
    /** Log queue operation with duration */
    public void queue(String op, String queueName, String messageId, long ms) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("queue");
        kv(sb, "op", op);
        kv(sb, "queue", queueName);
        kv(sb, "mid", messageId);
        kvLong(sb, "ms", ms);
        end(sb);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // TASK / GENERIC LOGGING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Log task completion */
    public void task(String taskName, long ms) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("task");
        kv(sb, "task", taskName);
        kvLong(sb, "ms", ms);
        end(sb);
    }
    
    /** Log task with result */
    public void task(String taskName, String result, long ms) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("task");
        kv(sb, "task", taskName);
        kv(sb, "result", result);
        kvLong(sb, "ms", ms);
        end(sb);
    }
    
    /** Log task start */
    public void taskStart(String taskName) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin("task_start");
        kv(sb, "task", taskName);
        end(sb);
    }
    
    /** Log task error */
    public void taskErr(String taskName, String error, long ms) {
        if (!log.isErrorEnabled()) return;
        StringBuilder sb = begin("task_err");
        kv(sb, "task", taskName);
        kv(sb, "err", error);
        kvLong(sb, "ms", ms);
        endErr(sb);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // GENERIC ERROR LOGGING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Log error with code */
    public void error(String type, String message, String code) {
        if (!log.isErrorEnabled()) return;
        StringBuilder sb = begin("error");
        kv(sb, "error_type", type);
        kv(sb, "msg", message);
        kv(sb, "code", code);
        endErr(sb);
    }
    
    /** Log error with exception */
    public void error(String type, Throwable t) {
        if (!log.isErrorEnabled()) return;
        StringBuilder sb = begin("error");
        kv(sb, "error_type", type);
        kv(sb, "ex", t.getClass().getSimpleName());
        kv(sb, "msg", t.getMessage() != null ? t.getMessage() : "null");
        endErr(sb);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // CUSTOM / FLEXIBLE LOGGING
    // ═══════════════════════════════════════════════════════════════════════════
    
    /** Log custom event with key-value pairs */
    public void event(String type, Object... kvPairs) {
        if (!log.isInfoEnabled()) return;
        StringBuilder sb = begin(type);
        for (int i = 0; i < kvPairs.length - 1; i += 2) {
            String key = String.valueOf(kvPairs[i]);
            Object val = kvPairs[i + 1];
            if (val instanceof Number) {
                if (val instanceof Long) {
                    kvLong(sb, key, (Long) val);
                } else if (val instanceof Integer) {
                    kvInt(sb, key, (Integer) val);
                } else {
                    kv(sb, key, val.toString());
                }
            } else {
                kv(sb, key, val != null ? val.toString() : "null");
            }
        }
        end(sb);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // INTERNAL - FAST JSON BUILDING (NO ALLOCATION)
    // ═══════════════════════════════════════════════════════════════════════════
    
    private StringBuilder begin(String type) {
        StringBuilder sb = SB.get();
        sb.setLength(0);  // Reset without allocation
        
        sb.append("{\"ts\":\"").append(java.time.Instant.now()).append('"');
        sb.append(",\"type\":\"").append(type).append('"');
        
        // Add correlation ID from MDC (if present)
        String cid = MDC.get("correlation_id");
        if (cid != null) {
            sb.append(",\"cid\":\"").append(cid).append('"');
        }
        
        // Add request ID from MDC (if present)
        String rid = MDC.get("request_id");
        if (rid != null) {
            sb.append(",\"rid\":\"").append(rid).append('"');
        }
        
        sb.append(",\"c\":\"").append(component).append('"');
        
        return sb;
    }
    
    private void kv(StringBuilder sb, String key, String value) {
        sb.append(",\"").append(key).append("\":\"");
        escapeJson(sb, value);
        sb.append('"');
    }
    
    private void kvInt(StringBuilder sb, String key, int value) {
        sb.append(",\"").append(key).append("\":").append(value);
    }
    
    private void kvLong(StringBuilder sb, String key, long value) {
        sb.append(",\"").append(key).append("\":").append(value);
    }
    
    private void end(StringBuilder sb) {
        sb.append('}');
        log.info(sb.toString());
    }
    
    private void endErr(StringBuilder sb) {
        sb.append('}');
        log.error(sb.toString());
    }
    
    /** Escape JSON special characters (fast, no allocation) */
    private void escapeJson(StringBuilder sb, String s) {
        if (s == null) {
            sb.append("null");
            return;
        }
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 32) {
                        sb.append("\\u00").append(String.format("%02x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
    }
    
    /** Mask email (fast) */
    private String maskEmail(String email) {
        if (email == null) return "****";
        int at = email.indexOf('@');
        if (at <= 0) return "****";
        if (at <= 2) return "**" + email.substring(at);
        return email.substring(0, 2) + "**" + email.substring(at);
    }
}
