package com.cbq.restclient.logging.annotation;

import javax.annotation.processing.*;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.*;
import javax.tools.Diagnostic;
import javax.tools.JavaFileObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;

/**
 * Annotation processor for @StructuredLog.
 * 
 * NOTE: This generates a companion class, not field injection like Lombok.
 * For true Lombok-style, just use the manual approach:
 * 
 * <pre>{@code
 * private static final SLog slog = SLog.forClass(MyClass.class);
 * }</pre>
 * 
 * This processor is provided for completeness but the manual approach is simpler.
 */
@SupportedAnnotationTypes("com.cbq.restclient.logging.annotation.StructuredLog")
@SupportedSourceVersion(SourceVersion.RELEASE_17)
public class StructuredLogProcessor extends AbstractProcessor {

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        for (Element element : roundEnv.getElementsAnnotatedWith(StructuredLog.class)) {
            if (element.getKind() != ElementKind.CLASS) {
                processingEnv.getMessager().printMessage(
                    Diagnostic.Kind.ERROR,
                    "@StructuredLog can only be applied to classes",
                    element
                );
                continue;
            }
            
            TypeElement classElement = (TypeElement) element;
            String className = classElement.getSimpleName().toString();
            String packageName = processingEnv.getElementUtils()
                .getPackageOf(classElement).getQualifiedName().toString();
            
            StructuredLog annotation = element.getAnnotation(StructuredLog.class);
            String component = annotation.component().isEmpty() ? className : annotation.component();
            
            // Just print a note - we can't inject fields like Lombok
            processingEnv.getMessager().printMessage(
                Diagnostic.Kind.NOTE,
                "Add this field to " + className + ": private static final SLog slog = SLog.forClass(" + className + ".class);",
                element
            );
        }
        return true;
    }
}
