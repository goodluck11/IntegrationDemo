# CBQ REST Client - Slim Dependency Usage

## Minimal Setup (HTTP Client Only)

Just add the core dependency - no Resilience4j, no metrics, no email:

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-rest-client</artifactId>
    <version>2.0.0</version>
</dependency>
```

**What you get:**
- ✅ WebClient wrapper with fluent API
- ✅ Timeout configuration (connection, read, write, response)
- ✅ SSL/TLS support
- ✅ Request/Response logging with masking
- ✅ Request/Response filters
- ✅ Error mapping
- ✅ Parallel & Sequential execution
- ✅ CBQWorkflow for complex flows
- ❌ No Retry (pass-through)
- ❌ No Circuit Breaker (pass-through)
- ❌ No Rate Limiter (pass-through)
- ❌ No Bulkhead (pass-through)
- ❌ No Metrics
- ❌ No Email notifications

```java
// Works without any optional dependencies
CBQRestClient client = CBQRestClientBuilder.builder()
    .baseUrl("https://api.example.com")
    .timeouts(TimeoutConfig.custom()
        .connection(Duration.ofSeconds(5))
        .response(Duration.ofSeconds(30)))
    .logging(LoggingConfig.custom().logAll())
    .build();

client.get().uri("/users/1").retrieve(User.class).block();
```

---

## Add Resilience (Retry, Circuit Breaker, Rate Limiter, Bulkhead)

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-rest-client</artifactId>
    <version>2.0.0</version>
</dependency>

<!-- Add Resilience4j -->
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-reactor</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-retry</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-circuitbreaker</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-ratelimiter</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-bulkhead</artifactId>
    <version>1.7.1</version>
</dependency>
```

```java
// Now resilience features work
CBQRestClient client = CBQRestClientBuilder.builder()
    .baseUrl("https://api.example.com")
    .resilience(ResilienceConfig.custom()
        .retry(RetryConfig.custom().maxAttempts(3))
        .circuitBreaker(CircuitBreakerConfig.custom().failureRate(50))
        .rateLimiter(RateLimiterConfig.custom().limitForPeriod(100))
        .bulkhead(BulkheadConfig.custom().maxConcurrentCalls(25)))
    .build();
```

---

## Add Metrics (Micrometer)

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-rest-client</artifactId>
    <version>2.0.0</version>
</dependency>

<!-- Add Micrometer -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-core</artifactId>
    <version>1.9.17</version>
</dependency>
```

```java
CBQRestClient client = CBQRestClientBuilder.builder()
    .baseUrl("https://api.example.com")
    .metricsEnabled(true)
    .metrics(MetricsConfig.custom()
        .metricPrefix("myapp.http")
        .normalizeUri(true))
    .build();
```

---

## Add Email Notifications

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-rest-client</artifactId>
    <version>2.0.0</version>
</dependency>

<!-- Add Spring Mail -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-mail</artifactId>
</dependency>
```

```java
CBQRestClient client = CBQRestClientBuilder.builder()
    .baseUrl("https://api.example.com")
    .emailNotifier(EmailNotifierConfig.custom()
        .host("smtp.company.com")
        .port(587)
        .defaultTo("alerts@company.com"))
    .build();

client.post()
    .uri("/payments")
    .onErrorNotify(mail -> mail.subject("Payment Failed"))
    .retrieve(Result.class)
    .block();
```

---

## Full Production Setup (All Features)

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-rest-client</artifactId>
    <version>2.0.0</version>
</dependency>

<!-- Resilience4j -->
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-reactor</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-retry</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-circuitbreaker</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-ratelimiter</artifactId>
    <version>1.7.1</version>
</dependency>
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-bulkhead</artifactId>
    <version>1.7.1</version>
</dependency>

<!-- Micrometer -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-core</artifactId>
    <version>1.9.17</version>
</dependency>

<!-- Spring Mail -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-mail</artifactId>
</dependency>
```

---

## Dependency Size Comparison

| Configuration | Approx. Added Size |
|--------------|-------------------|
| Core only | ~0 (uses existing Spring WebFlux) |
| + Resilience4j | ~1.5 MB |
| + Micrometer | ~500 KB |
| + Spring Mail | ~300 KB |
| Full | ~2.3 MB |

---

## Feature Detection

The library automatically detects available dependencies:

```java
// Logs at startup:
// "Resilience4j not on classpath - resilience features disabled"
// OR
// "Resilience4j detected - resilience features enabled"
```

When optional dependencies are missing:
- **Resilience**: Requests pass through without retry/circuit breaker/etc.
- **Metrics**: No metrics recorded
- **Email**: `onErrorNotify()` is silently ignored
