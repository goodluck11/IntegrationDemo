
### Enable Scanning

```java
@SpringBootApplication
@EnableCBQClient(basePackages = "com.myapp.clients")
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

### Define a Client

```java
@CBQClient(
    name = "user-service",
    url = "${user.service.url}",
    retryEnabled = true,
    maxAttempts = 3,
    circuitBreakerEnabled = true
)
public interface UserClient {

    @CBQGet("/users/{id}")
    Mono<User> getUser(@CBQPath("id") String userId);

    @CBQPost("/users")
    Mono<User> createUser(@CBQBody CreateUserRequest request);

    @CBQGet("/users")
    Flux<User> searchUsers(@CBQParam("q") String query, @CBQParam("page") int page);
}
```

### Inject and Use

```java
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserClient userClient;

    public Mono<User> findUser(String id) {
        return userClient.getUser(id);
    }
}
```

### application.yml

```yaml
user:
  service:
    url: https://api.users.example.com
```

---

## 2. Annotation Reference

### Client Declaration

| Annotation | Target | Description |
|------------|--------|-------------|
| `@CBQClient` | Interface | Declares a declarative HTTP client |
| `@EnableCBQClient` | Class | Enables component scanning for @CBQClient interfaces |

### HTTP Methods

| Annotation | HTTP Method | Example |
|------------|-------------|---------|
| `@CBQGet` | GET | `@CBQGet("/users/{id}")` |
| `@CBQPost` | POST | `@CBQPost("/users")` |
| `@CBQPut` | PUT | `@CBQPut("/users/{id}")` |
| `@CBQDelete` | DELETE | `@CBQDelete("/users/{id}")` |
| `@CBQPatch` | PATCH | `@CBQPatch("/users/{id}")` |
| `@CBQRequest` | Any | `@CBQRequest(method = "OPTIONS", path = "/config")` |

### Parameter Binding

| Annotation | Target | Description |
|------------|--------|-------------|
| `@CBQPath("id")` | Parameter | Binds to URI path variable `{id}` |
| `@CBQParam("page")` | Parameter | Binds to query parameter `?page=` |
| `@CBQBody` | Parameter | Marks as request body (one per method) |
| `@CBQHeader("Authorization")` | Parameter | Binds to a dynamic request header |
| `@CBQHeaders({"X-Api: v2"})` | Class/Method | Static headers |

### Resilience & Behavior

| Annotation | Target | Description |
|------------|--------|-------------|
| `@CBQRetryOn` | Method | Fine-grained retry control per method |
| `@CBQFallback("methodName")` | Method | Fallback to a default method on failure |
| `@CBQErrorMapping(status, exception)` | Method | Map HTTP status → custom exception |
| `@CBQLog(LogLevel.FULL)` | Method | Override log level per method |
| `@CBQExchange` | Method | Return `CBQResponse<T>` with headers/status |
| `@CBQInterceptor(MyInterceptor.class)` | Class/Method | Bind request interceptors |

---

## 3. Tri-State Override (Per-Method Resilience)

Every HTTP method annotation has `retryEnabled`, `circuitBreakerEnabled`, `rateLimiterEnabled`, and `bulkheadEnabled` fields using `CBQOverride`:

- `INHERIT` — use the @CBQClient setting (default)
- `ENABLED` — force enable for this method
- `DISABLED` — force disable for this method

```java
@CBQClient(
    name = "notification-service",
    url = "${notification.url}",
    retryEnabled = true,
    circuitBreakerEnabled = true
)
public interface NotificationClient {

    // Inherits client-level retry + circuit breaker
    @CBQPost("/notifications/email")
    Mono<Void> sendEmail(@CBQBody EmailRequest request);

    // Force DISABLE retry for SMS (idempotency risk)
    @CBQPost(value = "/notifications/sms", retryEnabled = CBQOverride.DISABLED)
    Mono<Void> sendSms(@CBQBody SmsRequest request);

    // Force ENABLE bulkhead even though client doesn't have it
    @CBQPost(value = "/notifications/push", bulkheadEnabled = CBQOverride.ENABLED)
    Mono<Void> sendPush(@CBQBody PushRequest request);
}
```

---

## 4. Full-Featured Client Example

```java
@CBQClient(
    name = "payment-service",
    url = "${payment.service.url}",
    path = "/api/v1",
    connectionTimeout = 3000,
    readTimeout = 10000,
    writeTimeout = 5000,
    responseTimeout = 15000,
    retryEnabled = true,
    maxAttempts = 3,
    waitDuration = 2000,
    circuitBreakerEnabled = true,
    failureRateThreshold = 50,
    slidingWindowSize = 100,
    openStateWaitDuration = 30000,
    rateLimiterEnabled = true,
    limitForPeriod = 100,
    limitRefreshPeriod = 1000,
    bulkheadEnabled = true,
    maxConcurrentCalls = 25,
    logLevel = CBQClient.LogLevel.FULL,
    maskFields = {"cardNumber", "cvv", "pin"},
    fallbackFactory = PaymentFallbackFactory.class,
    configurer = "paymentConfigurer"
)
@CBQHeaders({
    "X-Api-Version: 2",
    "X-Client-Id: erikka-pos"
})
@CBQInterceptor(AuthTokenInterceptor.class)
public interface PaymentClient {

    @CBQPost("/payments/charge")
    @CBQRetryOn(
        maxAttempts = 5,
        waitDuration = 3000,
        backoffMultiplier = 2.0,
        retryOnStatus = {502, 503, 504},
        ignoreExceptions = {BadRequestException.class}
    )
    @CBQErrorMapping(status = 400, exception = InvalidPaymentException.class, message = "Bad payment data")
    @CBQErrorMapping(status = 409, exception = DuplicatePaymentException.class)
    @CBQErrorMapping(status = 422, exception = InsufficientFundsException.class)
    Mono<PaymentResult> chargePayment(@CBQBody ChargeRequest request);

    @CBQGet("/payments/{id}")
    Mono<Payment> getPayment(@CBQPath("id") String paymentId);

    @CBQGet("/payments/{id}")
    @CBQExchange
    Mono<CBQResponse<Payment>> getPaymentWithMetadata(@CBQPath("id") String paymentId);

    @CBQGet("/payments")
    Flux<Payment> searchPayments(
        @CBQParam("status") String status,
        @CBQParam("from") String fromDate,
        @CBQParam("to") String toDate,
        @CBQParam(value = "limit", defaultValue = "50") int limit
    );

    @CBQPost("/payments/{id}/refund")
    @CBQLog(CBQClient.LogLevel.FULL)
    Mono<RefundResult> refundPayment(
        @CBQPath("id") String paymentId,
        @CBQBody RefundRequest request,
        @CBQHeader("X-Idempotency-Key") String idempotencyKey
    );

    @CBQDelete("/payments/{id}")
    @CBQGet(retryEnabled = CBQOverride.DISABLED)
    Mono<Void> cancelPayment(@CBQPath("id") String paymentId);

    @CBQRequest(method = "HEAD", path = "/health")
    Mono<Void> healthCheck();
}
```

---

## 5. Request Interceptors

Interceptors allow you to modify requests before they are sent.

### Auth Token Interceptor

```java
@Component
@RequiredArgsConstructor
public class AuthTokenInterceptor implements CBQRequestInterceptor {

    private final TokenService tokenService;

    @Override
    public void apply(CBQRequestContext context) {
        String token = tokenService.getAccessToken();
        context.setHeader("Authorization", "Bearer " + token);
        context.addHeader("X-Correlation-Id", UUID.randomUUID().toString());
    }

    @Override
    public int order() {
        return 100;
    }
}
```

### Multiple Interceptors with Ordering

```java
@Component
public class CorrelationIdInterceptor implements CBQRequestInterceptor {
    @Override
    public void apply(CBQRequestContext ctx) {
        ctx.addHeader("X-Correlation-Id", MDC.get("correlationId"));
    }

    @Override
    public int order() { return 10; }  // runs first
}

@Component
public class AuditInterceptor implements CBQRequestInterceptor {
    private final AuditService auditService;

    @Override
    public void apply(CBQRequestContext ctx) {
        auditService.log(ctx.getClientName(), ctx.getHttpMethod(), ctx.getUri());
    }

    @Override
    public int order() { return 200; }  // runs last
}

@CBQClient(name = "secure-api", url = "https://api.secure.com")
@CBQInterceptor({CorrelationIdInterceptor.class, AuthTokenInterceptor.class})
public interface SecureApiClient {

    @CBQGet("/data")
    @CBQInterceptor(AuditInterceptor.class)  // added on top of class-level interceptors
    Mono<Data> getData();
}
```

---

## 6. Fallback Strategies

### Fallback Factory

```java
@Component
@Slf4j
public class PaymentFallbackFactory implements CBQFallbackFactory<PaymentClient> {

    @Override
    public PaymentClient create(Throwable cause) {
        log.warn("Payment service fallback triggered: {}", cause.getMessage());

        return new PaymentClient() {
            @Override
            public Mono<PaymentResult> chargePayment(ChargeRequest request) {
                return Mono.just(PaymentResult.queued("Service temporarily unavailable"));
            }

            @Override
            public Mono<Payment> getPayment(String paymentId) {
                return Mono.empty();
            }

            @Override
            public Mono<CBQResponse<Payment>> getPaymentWithMetadata(String paymentId) {
                return Mono.empty();
            }

            @Override
            public Flux<Payment> searchPayments(String s, String s1, String s2, int i) {
                return Flux.empty();
            }

            @Override
            public Mono<RefundResult> refundPayment(String id, RefundRequest req, String key) {
                return Mono.error(new ServiceUnavailableException("Refunds temporarily unavailable"));
            }

            @Override
            public Mono<Void> cancelPayment(String paymentId) {
                return Mono.empty();
            }

            @Override
            public Mono<Void> healthCheck() {
                return Mono.error(cause);
            }
        };
    }
}
```

### Method-Level Fallback (Default Methods)

```java
@CBQClient(name = "inventory-service", url = "${inventory.service.url}")
public interface InventoryClient {

    @CBQGet("/products/{id}/stock")
    @CBQFallback("getStockFallback")
    Mono<StockInfo> getStock(@CBQPath("id") String productId);

    default Mono<StockInfo> getStockFallback(String productId, Throwable cause) {
        log.warn("Inventory service unavailable for product {}: {}", productId, cause.getMessage());
        return Mono.just(StockInfo.unknown(productId));
    }

    @CBQPost("/products/{id}/reserve")
    @CBQFallback("reserveStockFallback")
    Mono<ReservationResult> reserveStock(@CBQPath("id") String productId,
                                         @CBQBody ReservationRequest request);

    default Mono<ReservationResult> reserveStockFallback(String productId,
                                                          ReservationRequest request,
                                                          Throwable cause) {
        return Mono.just(ReservationResult.pending("Queued for processing"));
    }
}
```

---

## 7. Programmatic Configurer (Escape Hatch)

For advanced configuration not covered by annotations:

```java
@Configuration
public class PaymentClientConfig {

    @Bean("paymentConfigurer")
    public CBQClientConfigurer paymentConfigurer(TokenService tokenService) {
        return builder -> builder
            .ssl(SslConfig.custom()
                .certificatePath("/certs/payment-service.pem")
                .handshakeTimeout(Duration.ofSeconds(10)))
            .addRequestFilter(Filters.bearerToken(tokenService::getAccessToken))
            .addErrorMapper(ErrorMapper.onStatus(
                status -> status == HttpStatus.UNAUTHORIZED,
                ctx -> new AuthExpiredException("Token expired")));
    }
}
```

---

## 8. Using @CBQExchange for Full Response

```java
@CBQClient(name = "api", url = "${api.url}")
public interface ApiClient {

    @CBQGet("/resources/{id}")
    @CBQExchange
    Mono<CBQResponse<Resource>> getResource(@CBQPath("id") String id);
}

// Usage
apiClient.getResource("123")
    .subscribe(response -> {
        int status = response.getStatusCode();
        HttpHeaders headers = response.getHeaders();
        String correlationId = response.getCorrelationId();
        Resource body = response.getBody();
        long duration = response.getDurationMs();
    });
```

---

## 9. Collection Query Parameters

```java
@CBQClient(name = "order-service", url = "${order.service.url}")
public interface OrderClient {

    // Produces: /orders?status=ACTIVE&status=PENDING&sort=createdAt
    @CBQGet("/orders")
    Flux<Order> findOrders(
        @CBQParam("status") List<String> statuses,
        @CBQParam("sort") String sortBy,
        @CBQParam(value = "page", defaultValue = "0") int page,
        @CBQParam(value = "size", defaultValue = "20") int size
    );
}
```

---

## 10. Minimal Client (Simple Use Case)

```java
@CBQClient(name = "weather-api", url = "https://api.weather.com")
public interface WeatherClient {

    @CBQGet("/current")
    Mono<Weather> getCurrentWeather(@CBQParam("city") String city);
}
```

---
Key design decisions:

1. **Zero reflection at invocation** — all annotations are parsed once into `CBQMethodMetadata` at startup
2. **CBQRestClient under the hood** — gets you WebClient + Resilience4j + correlation IDs + structured logging for free
3. **Fail fast** — invalid annotations throw `CBQClientDefinitionException` at startup, not at first call
4. **Full CBQRestClient power** — the `configurer` escape hatch lets you apply SSL, custom filters, error mappers, etc.

---

## 12. Annotation Quick Reference

```java
// CLIENT
@CBQClient(name, url, path, retryEnabled, circuitBreakerEnabled, ...)
@EnableCBQClient(basePackages)

// HTTP METHODS
@CBQGet("/path")    @CBQPost("/path")    @CBQPut("/path")
@CBQDelete("/path") @CBQPatch("/path")   @CBQRequest(method, path)

// PARAMETERS
@CBQPath("name")    @CBQParam("name")    @CBQBody    @CBQHeader("name")

// HEADERS
@CBQHeaders({"Name: Value", "Name2: Value2"})

// RESILIENCE
@CBQRetryOn(maxAttempts, waitDuration, backoffMultiplier, retryOnStatus, retryExceptions)

// BEHAVIOR
@CBQExchange                           // returns CBQResponse<T>
@CBQLog(LogLevel.FULL)                 // per-method log level
@CBQFallback("fallbackMethodName")     // method-level fallback
@CBQInterceptor(MyInterceptor.class)   // request interceptor

// ERROR HANDLING
@CBQErrorMapping(status = 404, exception = NotFoundException.class)

// PER-METHOD RESILIENCE TOGGLE
@CBQGet(retryEnabled = CBQOverride.DISABLED)
@CBQPost(bulkheadEnabled = CBQOverride.ENABLED)
```

---

## 13. Comparison with Feign

| Feature | Feign | CBQ Declarative |
|---------|-------|-----------------|
| HTTP engine | Blocking (default) | Non-blocking (WebClient/Netty) |
| Reactive support | Limited (via modules) | Native (Mono/Flux) |
| Circuit breaker | Via Hystrix/Resilience4j | Built-in via CBQRestClient |
| Retry | Basic | `@CBQRetryOn` with exponential backoff |
| Rate limiting | External | `@CBQClient(rateLimiterEnabled)` |
| Bulkhead | External | `@CBQClient(bulkheadEnabled)` |
| Error mapping | ErrorDecoder | `@CBQErrorMapping(status, exception)` |
| Per-method override | No | `CBQOverride.ENABLED/DISABLED` |
| Correlation tracing | Manual | Automatic (CBQRestClient) |
| Log level override | No | `@CBQLog(LogLevel.FULL)` |
| Interceptors | RequestInterceptor | `@CBQInterceptor` + ordering |
| Fallback | Class only | Class + Factory + Default methods |
