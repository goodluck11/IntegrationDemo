package com.cbq.restclient.annotation.autoconfig;

import com.cbq.restclient.annotation.proxy.CBQClientProxyFactory;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.env.Environment;

/*
 * @created by 02/02/2026  - 23:22
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Slf4j
public class CBQClientFactoryBean implements FactoryBean<Object>, ApplicationContextAware {

   @Setter
   private String clientInterface;

   private ApplicationContext applicationContext;

   private volatile Object proxyInstance;

   @Override
   public Object getObject() throws Exception {
      if (proxyInstance == null) {
         synchronized (this) {
            if (proxyInstance == null) {
               proxyInstance = createProxy();
            }
         }
      }
      return proxyInstance;
   }

   @Override
   public Class<?> getObjectType() {
      try {
         return clientInterface != null
                 ? Class.forName(clientInterface)
                 : null;
      } catch (ClassNotFoundException e) {
         log.warn("Cannot resolve client interface class: {}", clientInterface);
         return null;
      }
   }

   @Override
   public boolean isSingleton() {
      return true;
   }

   @Override
   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
      this.applicationContext = applicationContext;
   }

   private Object createProxy() throws Exception {
      Class<?> interfaceClass = Class.forName(clientInterface);
      Environment environment = applicationContext.getEnvironment();

      CBQClientProxyFactory proxyFactory = new CBQClientProxyFactory(
              applicationContext, environment);

      return proxyFactory.createProxy(interfaceClass);
   }
}