package com.cbq.restclient.annotation.model;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026 - 21:39
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CBQClient {
   String name();
   String url() default "";
   String path() default "";
   long connectionTimeout() default 5000L;
   long readTimeout() default 30000L;
   long writeTimeout() default 10000L;
   long responseTimeout() default 30000L;
   boolean retryEnabled() default false;
   int maxAttempts() default 3;
   long waitDuration() default 1000L;
   boolean circuitBreakerEnabled() default false;
   int failureRateThreshold() default 50;
   int slidingWindowSize() default 100;
   long openStateWaitDuration() default 60000L;
   boolean rateLimiterEnabled() default false;
   int limitForPeriod() default 50;
   long limitRefreshPeriod() default 1000L;
   boolean bulkheadEnabled() default false;
   int maxConcurrentCalls() default 25;
   long maxWaitDuration() default 0L;
   LogLevel logLevel() default LogLevel.FULL;
   String[] maskFields() default {};
   String configurer() default "";
   Class<?> fallback() default void.class;
   Class<?> fallbackFactory() default void.class;


   enum LogLevel {
      NONE, REQUEST, RESPONSE, HEADERS, FULL
   }

}
