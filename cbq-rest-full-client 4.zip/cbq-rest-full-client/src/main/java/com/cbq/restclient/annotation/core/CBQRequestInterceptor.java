package com.cbq.restclient.annotation.core;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import java.util.Map;

/*
 * @created by 02/02/2026  - 21:55
 * @project cbq-rest-full-client
 * @author Goodluck
 */
public interface CBQRequestInterceptor {

   void apply(CBQRequestContext context);

   default int order() {
      return 0;
   }

   @Getter
   @Builder(toBuilder = true)
   class CBQRequestContext {
      private final String clientName;
      private final String methodName;
      private final HttpMethod httpMethod;
      @Setter
      private String uri;
      private final HttpHeaders headers;
      @Setter
      private Object body;
      private final Map<String, Object> attributes;

      public void addHeader(String name, String value) {
         this.headers.add(name, value);
      }

      public void setHeader(String name, String value) {
         this.headers.set(name, value);
      }

      public void setAttribute(String key, Object value) {
         this.attributes.put(key, value);
      }

      @SuppressWarnings("unchecked")
      public <T> T getAttribute(String key) {
         return (T) this.attributes.get(key);
      }
   }
}

