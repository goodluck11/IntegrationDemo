package com.cbq.restclient.annotation.model;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026  - 21:53
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(CBQErrorMappings.class)
@Documented
public @interface CBQErrorMapping {
   int status();
   Class<? extends RuntimeException> exception();
   String message() default "";
}
