package com.cbq.restclient.annotation.autoconfig;

/*
 * @created by 02/02/2026  - 23:21
 * @project cbq-rest-full-client
 * @author Goodluck
 */

import com.cbq.restclient.annotation.model.CBQClient;
import com.cbq.restclient.annotation.model.EnableCBQClient;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Slf4j
public class CBQClientRegistrar implements ImportBeanDefinitionRegistrar {

   @Override
   public void registerBeanDefinitions(@NonNull AnnotationMetadata importingClassMetadata,
                                       @NonNull BeanDefinitionRegistry registry) {
      Set<String> basePackages = getBasePackages(importingClassMetadata);

      ClassPathScanningCandidateComponentProvider scanner = createScanner();

      for (String basePackage : basePackages) {
         scanner.findCandidateComponents(basePackage).forEach(beanDef -> {
            if (beanDef instanceof AnnotatedBeanDefinition) {
               AnnotatedBeanDefinition annotatedDef = (AnnotatedBeanDefinition) beanDef;
               AnnotationMetadata annotationMetadata = annotatedDef.getMetadata();

               if (!annotationMetadata.isInterface()) {
                  log.warn("@CBQClient can only be applied to interfaces. Skipping: {}",
                          beanDef.getBeanClassName());
                  return;
               }

               Map<String, Object> attrs = annotationMetadata.getAnnotationAttributes(
                       CBQClient.class.getName());
               if (attrs == null) return;

               String clientName = (String) attrs.get("name");

               registerClientBean(registry, beanDef.getBeanClassName(), clientName);
            }
         });
      }
   }

   private void registerClientBean(BeanDefinitionRegistry registry,
                                   String className, String clientName) {
      BeanDefinitionBuilder definition = BeanDefinitionBuilder
              .genericBeanDefinition(CBQClientFactoryBean.class);

      definition.addPropertyValue("clientInterface", className);
      definition.setAutowireMode(AbstractBeanDefinition.AUTOWIRE_BY_TYPE);
      definition.setLazyInit(false); // Fail fast at startup

      // Register with both class name and client name
      String beanName = StringUtils.uncapitalize(
              className.substring(className.lastIndexOf('.') + 1));

      AbstractBeanDefinition beanDefinition = definition.getBeanDefinition();
      beanDefinition.setPrimary(true);

      BeanDefinitionHolder holder = new BeanDefinitionHolder(beanDefinition, beanName);
      registry.registerBeanDefinition(holder.getBeanName(), holder.getBeanDefinition());

      // Also register under the client name if different
      if (clientName != null && !clientName.equals(beanName)) {
         registry.registerAlias(beanName, clientName);
      }

      log.info("[CBQ] Registered client bean: {} → {}", beanName, className);
   }

   private ClassPathScanningCandidateComponentProvider createScanner() {
      ClassPathScanningCandidateComponentProvider scanner =
              new ClassPathScanningCandidateComponentProvider(false) {
                 @Override
                 protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {
                    // Allow interfaces (not just concrete classes)
                    return beanDefinition.getMetadata().isInterface()
                            && beanDefinition.getMetadata().isIndependent();
                 }
              };
      scanner.addIncludeFilter(new AnnotationTypeFilter(CBQClient.class));
      return scanner;
   }

   private Set<String> getBasePackages(AnnotationMetadata importingClassMetadata) {
      Map<String, Object> attrs = importingClassMetadata.getAnnotationAttributes(
              EnableCBQClient.class.getName());

      Set<String> basePackages = new HashSet<>();

      if (attrs != null) {
         String[] packages = (String[]) attrs.get("basePackages");
         if (packages != null) {
            for (String pkg : packages) {
               if (StringUtils.hasText(pkg)) {
                  basePackages.add(pkg);
               }
            }
         }

         Class<?>[] classes = (Class<?>[]) attrs.get("basePackageClasses");
         if (classes != null) {
            for (Class<?> clazz : classes) {
               basePackages.add(ClassUtils.getPackageName(clazz));
            }
         }
      }

      // Default: scan from the package of the annotated class
      if (basePackages.isEmpty()) {
         basePackages.add(ClassUtils.getPackageName(importingClassMetadata.getClassName()));
      }

      return basePackages;
   }
}
