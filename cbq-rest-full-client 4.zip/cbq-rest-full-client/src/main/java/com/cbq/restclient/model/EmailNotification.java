package com.cbq.restclient.model;

import lombok.Getter;

import java.util.*;

@Getter
public class EmailNotification {

    private String from;
    private final List<String> to = new ArrayList<>();
    private String subject;
    private String body;
    private boolean html;
    private final Map<String, Object> context = new HashMap<>();

    private EmailNotification() {}

    public static EmailNotification create() {
        return new EmailNotification();
    }

    public EmailNotification from(String from) {
        this.from = from;
        return this;
    }

    public EmailNotification to(String... recipients) {
        this.to.addAll(Arrays.asList(recipients));
        return this;
    }

    public EmailNotification to(List<String> recipients) {
        this.to.addAll(recipients);
        return this;
    }

    public EmailNotification subject(String subject) {
        this.subject = subject;
        return this;
    }

    public EmailNotification body(String body) {
        this.body = body;
        return this;
    }

    public EmailNotification html(boolean html) {
        this.html = html;
        return this;
    }

    public EmailNotification context(Map<String, Object> context) {
        this.context.putAll(context);
        return this;
    }

    public EmailNotification addContext(String key, Object value) {
        this.context.put(key, value);
        return this;
    }

}
