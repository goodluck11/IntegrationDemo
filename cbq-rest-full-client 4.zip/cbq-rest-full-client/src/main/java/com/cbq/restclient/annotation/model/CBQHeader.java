package com.cbq.restclient.annotation.model;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026  - 21:49
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CBQHeader {
   String value();
}
