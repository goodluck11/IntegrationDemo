package com.cbq.restclient.v2;

public class ServerErrorExceptionV2 extends CBQHttpExceptionV2 {
   public ServerErrorExceptionV2(int status, String msg) {
      super(status, msg);
   }
}
