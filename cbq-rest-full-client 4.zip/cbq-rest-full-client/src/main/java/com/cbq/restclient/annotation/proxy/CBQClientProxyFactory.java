package com.cbq.restclient.annotation.proxy;

/*
 * @created by 02/02/2026  - 22:28
 * @project cbq-rest-full-client
 * @author Goodluck
 */

import com.cbq.restclient.annotation.core.CBQClientConfigurer;
import com.cbq.restclient.annotation.exception.CBQClientDefinitionException;
import com.cbq.restclient.annotation.handler.CBQClientInvocationHandler;
import com.cbq.restclient.annotation.metadata.CBQClientMetadata;
import com.cbq.restclient.annotation.resolver.CBQMetadataResolver;
import com.cbq.restclient.config.LoggingConfig;
import com.cbq.restclient.config.ResilienceConfig;
import com.cbq.restclient.config.SslConfig;
import com.cbq.restclient.config.TimeoutConfig;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQRestClientBuilder;
import com.cbq.restclient.filter.ErrorMapper;
import com.cbq.restclient.filter.RequestFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;

import java.lang.reflect.Proxy;
import java.time.Duration;

/**
 * Factory that:
 * 1. Resolves annotation metadata from a @CBQClient interface
 * 2. Builds a configured CBQRestClient using the annotation values
 * 3. Creates a JDK dynamic proxy that delegates to CBQClientInvocationHandler
 *
 * <p>Called once per @CBQClient bean at application startup.</p>
 */
@Slf4j
public class CBQClientProxyFactory {

   private final ApplicationContext applicationContext;
   private final Environment environment;

   public CBQClientProxyFactory(ApplicationContext applicationContext, Environment environment) {
      this.applicationContext = applicationContext;
      this.environment = environment;
   }

   /**
    * Create a proxy instance for a @CBQClient interface.
    *
    * @param clientInterface the annotated interface class
    * @param <T>             the interface type
    * @return a proxy implementing the interface
    */
   @SuppressWarnings("unchecked")
   public <T> T createProxy(Class<T> clientInterface) {
      CBQClientMetadata clientMeta = CBQMetadataResolver.resolve(clientInterface);
      log.info("[CBQ] Creating client proxy: {} → {} ({} methods)",
              clientMeta.getName(), resolveUrl(clientMeta), clientMeta.getMethods().size());

      // 2. Validate
      validate(clientMeta);

      // 3. Build CBQRestClient from annotation metadata
      CBQRestClient restClient = buildRestClient(clientMeta);

      CBQClientInvocationHandler handler = new CBQClientInvocationHandler(
              restClient, clientMeta, applicationContext);

      return (T) Proxy.newProxyInstance(
              clientInterface.getClassLoader(),
              new Class<?>[]{clientInterface},
              handler);
   }

   /**
    * Build a CBQRestClient from annotation metadata + optional programmatic configurer.
    */
   private CBQRestClient buildRestClient(CBQClientMetadata meta) {
      String resolvedUrl = resolveUrl(meta);

      // Use the builder API from cbq-rest-client core
      // This maps annotation values → builder calls
      CBQRestClientBuilder builder = CBQRestClientBuilder.builder(meta.getName());

      if (!resolvedUrl.isEmpty()) {
         builder.baseUrl(resolvedUrl);
      }

      // Timeouts
      builder.timeouts(TimeoutConfig.custom()
              .connection(Duration.ofMillis(meta.getConnectionTimeout()))
              .read(Duration.ofMillis(meta.getReadTimeout()))
              .response(Duration.ofMillis(meta.getResponseTimeout()))
              .write(Duration.ofMillis(meta.getWriteTimeout()))
      );

      // Resilience
      ResilienceConfig resilienceConfig = ResilienceConfig.custom();

      // Retry
      if (meta.isRetryEnabled()) {
         resilienceConfig.retry(ResilienceConfig.RetryConfig.defaults()
                 .maxAttempts(meta.getMaxAttempts())
                 .waitDuration(Duration.ofMillis(meta.getWaitDuration())));
      }

      // Circuit Breaker
      if (meta.isCircuitBreakerEnabled()) {
         resilienceConfig.circuitBreaker(ResilienceConfig.CircuitBreakerConfig.defaults()
                 .windowSize(meta.getSlidingWindowSize())
                 .failureRate(meta.getFailureRateThreshold())
                 .openStateWait(Duration.ofMillis(meta.getOpenStateWaitDuration())));
      }

      // Rate Limiter
      if (meta.isRateLimiterEnabled()) {
         resilienceConfig.rateLimiter(ResilienceConfig.RateLimiterConfig.defaults()
                 .limitForPeriod(meta.getLimitForPeriod())
                 .refreshPeriod(Duration.ofMillis(meta.getLimitRefreshPeriod())));
      }

      // Bulkhead
      if (meta.isBulkheadEnabled()) {
         resilienceConfig.bulkhead(ResilienceConfig.BulkheadConfig.defaults()
                 .maxConcurrentCalls(meta.getMaxConcurrentCalls())
                 .maxWait(Duration.ofMillis(meta.getMaxWaitDuration())));
      }

      builder.resilience(resilienceConfig);

      // Logging
      LoggingConfig loggingConfig;
      switch (meta.getLogLevel()) {
         case HEADERS:
            loggingConfig = LoggingConfig.custom().logHeaders();
            break;
         case REQUEST:
            loggingConfig = LoggingConfig.custom().logRequest();
            break;
         case RESPONSE:
            loggingConfig = LoggingConfig.custom().logResponse();
            break;
         case FULL:
            loggingConfig = LoggingConfig.custom().logAll();
            break;
         case NONE:
         default:
            loggingConfig = LoggingConfig.disabled();
      }

      if (meta.getMaskFields() != null && meta.getMaskFields().length > 0) {
         loggingConfig.maskFields(meta.getMaskFields());
      }

      if (meta.getFieldsToExclude() != null && meta.getFieldsToExclude().length > 0) {
         loggingConfig.excludeFields(meta.getFieldsToExclude());
      }

      builder.logging(loggingConfig);


      // Apply programmatic configurer (escape hatch)
      if (meta.getConfigurerBeanName() != null) {
         try {
            CBQClientConfigurer configurer = applicationContext.getBean(
                    meta.getConfigurerBeanName(), CBQClientConfigurer.class);
            configurer.configure(new BuilderAccessAdapter(builder));
            log.debug("[{}] Applied programmatic configurer: {}",
                    meta.getName(), meta.getConfigurerBeanName());
         } catch (Exception e) {
            throw new CBQClientDefinitionException(
                    "Configurer bean '" + meta.getConfigurerBeanName() + "' not found or invalid",
                    meta.getClientInterface(), e);
         }
      }

      return builder.build();
   }

   /**
    * Resolve property placeholders in URLs: ${payment.service.url} → https://...
    */
   private String resolveUrl(CBQClientMetadata meta) {
      String url = meta.getUrl();
      if (url == null || url.isEmpty()) return "";
      return environment.resolvePlaceholders(url);
   }

   /**
    * Validate metadata at startup. Fail fast on misconfiguration.
    */
   private void validate(CBQClientMetadata meta) {
      if (meta.getName() == null || meta.getName().isEmpty()) {
         throw new CBQClientDefinitionException("@CBQClient name is required",
                 meta.getClientInterface());
      }

      if (meta.getMethods().isEmpty()) {
         log.warn("[{}] No HTTP-mapped methods found in {}",
                 meta.getName(), meta.getClientInterface().getSimpleName());
      }

      // Validate fallback class implements the interface
      if (meta.getFallbackClass() != null && !meta.getClientInterface().isAssignableFrom(meta.getFallbackClass())) {
         throw new CBQClientDefinitionException(
                 "Fallback class " + meta.getFallbackClass().getSimpleName()
                         + " must implement " + meta.getClientInterface().getSimpleName(),
                 meta.getClientInterface());
      }


      meta.getMethods().forEach((key, method) -> {
         // Validate return type is reactive
         if (!method.isReturnsMono() && !method.isReturnsFlux()) {
            throw new CBQClientDefinitionException(
                    "Method '" + method.getMethodName()
                            + "' must return Mono<T> or Flux<T>. Got: "
                            + method.getReturnType().getTypeName(),
                    meta.getClientInterface());
         }
      });
   }

   /**
    * Adapter to expose builder in a safe way for programmatic configurers.
    */
   private static class BuilderAccessAdapter implements CBQClientConfigurer.CBQRestClientBuilderAccess {

      private final CBQRestClientBuilder builder;

      BuilderAccessAdapter(CBQRestClientBuilder builder) {
         this.builder = builder;
      }

      @Override
      public CBQClientConfigurer.CBQRestClientBuilderAccess addRequestFilter(RequestFilter filter) {
         builder.addRequestFilter(filter);
         return this;
      }

      @Override
      public CBQClientConfigurer.CBQRestClientBuilderAccess addErrorMapper(ErrorMapper errorMapper) {
         builder.addErrorMapper(errorMapper);
         return this;
      }

      @Override
      public CBQClientConfigurer.CBQRestClientBuilderAccess ssl(SslConfig sslConfig) {
         builder.ssl(sslConfig);
         return this;
      }

      @Override
      public CBQClientConfigurer.CBQRestClientBuilderAccess header(String name, String value) {
         builder.header(name, value);
         return this;
      }

      @Override
      public Object rawBuilder() {
         return builder;
      }
   }
}

