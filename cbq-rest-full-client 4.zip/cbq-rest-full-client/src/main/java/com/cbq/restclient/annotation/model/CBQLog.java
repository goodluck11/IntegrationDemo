package com.cbq.restclient.annotation.model;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026  - 22:10
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CBQLog {
   CBQClient.LogLevel value();
}
