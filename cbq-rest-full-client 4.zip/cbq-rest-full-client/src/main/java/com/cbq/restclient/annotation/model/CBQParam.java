package com.cbq.restclient.annotation.model;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026  - 21:48
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CBQParam {
   String value();
   String defaultValue() default "";
   boolean omitNull() default true;
   boolean encoded() default true;
}

