package com.cbq.restclient.annotation.model;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026  - 21:50
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CBQRetryOn {
   int maxAttempts() default 3;
   long waitDuration() default 1000L;
   double backoffMultiplier() default 1.5;
   long maxWaitDuration() default 30000L;
   Class<? extends Throwable>[] retryExceptions() default {};
   Class<? extends Throwable>[] ignoreExceptions() default {};
   int[] retryOnStatus() default {};
}
