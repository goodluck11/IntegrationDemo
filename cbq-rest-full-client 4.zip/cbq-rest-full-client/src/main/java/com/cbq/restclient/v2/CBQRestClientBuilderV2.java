package com.cbq.restclient.v2;

import lombok.Setter;
import org.springframework.web.reactive.function.client.WebClient;

@Setter
public class CBQRestClientBuilderV2 {
   private String baseUrl;
   private TimeoutConfigV2 timeoutConfig = TimeoutConfigV2.defaults();
   private SslConfigV2 sslConfig = SslConfigV2.disabled();
   private ResilienceConfigV2 resilienceConfig = ResilienceConfigV2.disabled();
   private LoggingConfigV2 loggingConfig = LoggingConfigV2.disabled();
   private EmailConfigV2 emailConfig = EmailConfigV2.disabled();
   private ObservabilityConfigV2 observabilityConfig = ObservabilityConfigV2.disabled();

   public CBQRestClientBuilderV2 timeouts(TimeoutConfigV2 config) {
      this.timeoutConfig = config; return this;
   }

   public CBQRestClientBuilderV2 ssl(SslConfigV2 config) {
      this.sslConfig = config; return this;
   }

   public CBQRestClientBuilderV2 resilience(ResilienceConfigV2 config) {
      this.resilienceConfig = config; return this;
   }

   public CBQRestClientBuilderV2 logging(LoggingConfigV2 config) {
      this.loggingConfig = config; return this;
   }

   public CBQRestClientBuilderV2 emailNotifier(EmailConfigV2 config) {
      this.emailConfig = config; return this;
   }

   public CBQRestClientBuilderV2 observability(ObservabilityConfigV2 config) {
      this.observabilityConfig = config; return this;
   }

   public CBQRestClientBuilderV2 baseUrl(String baseUrl) {
      this.baseUrl = baseUrl;
      return this;
   }

   public CBQRestClientV2 build() {
      WebClient client = WebClientFactoryV2.create(
              baseUrl,
              timeoutConfig,
              sslConfig,
              loggingConfig,
              observabilityConfig
      );

      return new CBQRestClientV2(
              client,
              timeoutConfig,
              resilienceConfig,
              loggingConfig,
              emailConfig,
              observabilityConfig
      );
   }
}
