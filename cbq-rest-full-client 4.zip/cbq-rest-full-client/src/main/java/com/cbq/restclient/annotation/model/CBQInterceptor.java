package com.cbq.restclient.annotation.model;

import com.cbq.restclient.annotation.core.CBQRequestInterceptor;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026  - 21:52
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CBQInterceptor {
   Class<? extends CBQRequestInterceptor>[] value();
}