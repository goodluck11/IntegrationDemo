package com.cbq.restclient.filter;

import com.cbq.restclient.exception.CBQRestClientException;
import org.springframework.http.HttpStatus;

import java.util.function.Function;
import java.util.function.Predicate;

public class ErrorMapper {

    private final Predicate<HttpStatus> statusPredicate;
    private final Function<ErrorContext, Throwable> exceptionMapper;

    private ErrorMapper(Predicate<HttpStatus> statusPredicate,
                       Function<ErrorContext, Throwable> exceptionMapper) {
        this.statusPredicate = statusPredicate;
        this.exceptionMapper = exceptionMapper;
    }

    public static ErrorMapper onStatus(Predicate<HttpStatus> statusPredicate,
                                       Function<ErrorContext, Throwable> exceptionMapper) {
        return new ErrorMapper(statusPredicate, exceptionMapper);
    }

    public static ErrorMapper on4xx(Function<ErrorContext, Throwable> exceptionMapper) {
        return new ErrorMapper(HttpStatus::is4xxClientError, exceptionMapper);
    }

    public static ErrorMapper on5xx(Function<ErrorContext, Throwable> exceptionMapper) {
        return new ErrorMapper(HttpStatus::is5xxServerError, exceptionMapper);
    }

    public static ErrorMapper onStatusCode(int code, Function<ErrorContext, Throwable> exceptionMapper) {
        return new ErrorMapper(status -> status.value() == code, exceptionMapper);
    }

    public static ErrorMapper on404(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(404, exceptionMapper);
    }

    public static ErrorMapper on401(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(401, exceptionMapper);
    }

    public static ErrorMapper on403(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(403, exceptionMapper);
    }

    public static ErrorMapper on429(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(429, exceptionMapper);
    }

    public static ErrorMapper on503(Function<ErrorContext, Throwable> exceptionMapper) {
        return onStatusCode(503, exceptionMapper);
    }

    public boolean matches(HttpStatus status) {
        return statusPredicate.test(status);
    }

    public Throwable mapError(ErrorContext context) {
        return exceptionMapper.apply(context);
    }

    public static class ErrorContext {
        private final String requestId;
        private final HttpStatus status;
        private final String method;
        private final String uri;
        private final String responseBody;
        private final org.springframework.http.HttpHeaders headers;

        public ErrorContext(String requestId, HttpStatus status, String method, String uri,
                          String responseBody, org.springframework.http.HttpHeaders headers) {
            this.requestId = requestId;
            this.status = status;
            this.method = method;
            this.uri = uri;
            this.responseBody = responseBody;
            this.headers = headers;
        }

        public String getRequestId() { return requestId; }
        public HttpStatus getStatus() { return status; }
        public int getStatusCode() { return status.value(); }
        public String getMethod() { return method; }
        public String getUri() { return uri; }
        public String getResponseBody() { return responseBody; }
        public org.springframework.http.HttpHeaders getHeaders() { return headers; }

        public CBQRestClientException toException() {
            return new CBQRestClientException(
                    "HTTP " + status.value() + " " + status.getReasonPhrase(),
                    requestId, uri, method, status.value()
            );
        }

        public CBQRestClientException toException(String message) {
            return new CBQRestClientException(message, requestId, uri, method, status.value());
        }
    }
}
