package com.cbq.restclient.clients;

import com.cbq.restclient.annotation.model.*;
import com.cbq.restclient.model.CBQResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/*
 * @created by 02/02/2026  - 23:40
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@CBQClient(name = "api", url = "${user.service.url}")
@CBQHeaders({
        "X-Api-Version: 2",
        "X-Client-Id: flux-client-pos"
})
public interface AnnotationClientExample {
   @CBQGet("/users")
   @CBQExchange
   Mono<CBQResponse<Object>> getUsers();

   @CBQGet("/posts/{id}")
   Mono<Object> getPost(@CBQPath("id") Long id);

   @CBQGet("/comments")
   Mono<Object> getComments(@CBQParam("postId") Long postId);

   @CBQGet("/users")
   Flux<Object> getUsersData(@CBQHeader("X-Idempotency-Key") String idempotencyKey);
}
