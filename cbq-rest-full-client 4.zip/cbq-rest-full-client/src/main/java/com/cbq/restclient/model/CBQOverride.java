package com.cbq.restclient.model;

/*
 * @created by 02/02/2026  - 21:42
 * @project cbq-rest-full-client
 * @author Goodluck
 */
public enum CBQOverride {
   INHERIT,
   ENABLED,
   DISABLED;

   public boolean resolve(boolean clientDefault) {
      switch (this) {
         case ENABLED:
            return true;
         case DISABLED:
            return false;
         default:
            return clientDefault;
      }
   }
}
