package com.cbq.restclient.annotation.metadata;

import com.cbq.restclient.annotation.model.CBQClient;
import lombok.Builder;
import lombok.Getter;

import java.util.Map;
import java.util.Set;

/*
 * @created by 02/02/2026  - 22:04
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Getter
@Builder
public class CBQClientMetadata {
   private final Class<?> clientInterface;
   private final String name;
   private final String url;
   private final String pathPrefix;

   // Timeouts
   private final long connectionTimeout;
   private final long readTimeout;
   private final long writeTimeout;
   private final long responseTimeout;

   // Resilience defaults
   private final boolean retryEnabled;
   private final int maxAttempts;
   private final long waitDuration;
   private final boolean circuitBreakerEnabled;
   private final int failureRateThreshold;
   private final int slidingWindowSize;
   private final long openStateWaitDuration;
   private final boolean rateLimiterEnabled;
   private final int limitForPeriod;
   private final long limitRefreshPeriod;
   private final boolean bulkheadEnabled;
   private final int maxConcurrentCalls;
   private final long maxWaitDuration;

   // Logging
   private final CBQClient.LogLevel logLevel;
   private final String[] maskFields;
   private final String[] fieldsToExclude;
   private final Map<String, Integer> fieldMaskLengths;

   // Advanced
   private final String configurerBeanName;
   private final Class<?> fallbackClass;
   private final Class<?> fallbackFactoryClass;

   // Per-method metadata (keyed by method name + descriptor for overloads)
   private final Map<String, CBQMethodMetadata> methods;
}
