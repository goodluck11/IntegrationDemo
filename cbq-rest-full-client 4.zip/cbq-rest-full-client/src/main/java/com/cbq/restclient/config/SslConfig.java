package com.cbq.restclient.config;

import lombok.Getter;

import java.time.Duration;

@Getter
public class SslConfig {

    private boolean enabled = false;
    private boolean insecure = false;
    private String certificatePath;
    private String keystorePath;
    private String keystorePassword;
    private String keystoreType = "PKCS12";
    private Duration handshakeTimeout = Duration.ofSeconds(10);

    private SslConfig() {}

    public static SslConfig defaultInsecure() {
        SslConfig config = new SslConfig();
        config.enabled = true;
        config.insecure = true;
        return config;
    }

    public static SslConfig custom() {
        return new SslConfig();
    }

    public static SslConfig disabled() {
        return new SslConfig();
    }

    public SslConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public SslConfig certificatePath(String path) {
        this.certificatePath = path;
        this.enabled = true;
        return this;
    }

    public SslConfig keystore(String path, String password) {
        this.keystorePath = path;
        this.keystorePassword = password;
        this.enabled = true;
        return this;
    }

    public SslConfig keystoreType(String type) {
        this.keystoreType = type;
        return this;
    }

    public SslConfig handshakeTimeout(Duration timeout) {
        this.handshakeTimeout = timeout;
        return this;
    }

}
