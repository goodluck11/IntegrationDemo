package com.cbq.restclient.annotation.autoconfig;

import com.cbq.restclient.annotation.proxy.CBQClientProxyFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/*
 * @created by 02/02/2026  - 23:23
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Configuration
@ConditionalOnClass(name = "com.cbq.restclient.core.CBQRestClient")
public class CBQDeclarativeAutoConfiguration {

   @Bean
   @ConditionalOnMissingBean
   public CBQClientProxyFactory cbqClientProxyFactory(ApplicationContext applicationContext,
                                                      Environment environment) {
      return new CBQClientProxyFactory(applicationContext, environment);
   }
}
