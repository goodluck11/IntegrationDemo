package com.cbq.restclient.annotation.model;

import com.cbq.restclient.model.CBQOverride;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026  - 21:46
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CBQRequest {
   /** HTTP method: GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS */
   String method();
   String path() default "";

   long responseTimeout() default -1L;
   CBQOverride retryEnabled() default CBQOverride.INHERIT;
   CBQOverride circuitBreakerEnabled() default CBQOverride.INHERIT;
   CBQOverride rateLimiterEnabled() default CBQOverride.INHERIT;
   CBQOverride bulkheadEnabled() default CBQOverride.INHERIT;
   String[] headers() default {};
   String consumes() default "";
   String produces() default "";
}
