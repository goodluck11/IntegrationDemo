package com.cbq.restclient.annotation.exception;

/*
 * @created by 02/02/2026  - 22:14
 * @project cbq-rest-full-client
 * @author Goodluck
 */

import lombok.Getter;

/**
 * Thrown during proxy method invocation when an unexpected error occurs.
 */
@Getter
public class CBQClientInvocationException extends RuntimeException {

   private final String clientName;
   private final String methodName;
   private final String uri;

   public CBQClientInvocationException(String clientName, String methodName, String uri,
                                       String message) {
      super(String.format("[%s.%s] %s → %s", clientName, methodName, uri, message));
      this.clientName = clientName;
      this.methodName = methodName;
      this.uri = uri;
   }

   public CBQClientInvocationException(String clientName, String methodName, String uri,
                                       String message, Throwable cause) {
      super(String.format("[%s.%s] %s → %s", clientName, methodName, uri, message), cause);
      this.clientName = clientName;
      this.methodName = methodName;
      this.uri = uri;
   }
}
