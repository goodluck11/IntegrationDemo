package com.cbq.restclient.controller;

import com.cbq.restclient.clients.AnnotationClientExample;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQWorkflow;
import com.cbq.restclient.model.CBQParallelResult;
import com.cbq.restclient.model.CBQResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
public class DemoController {

   private final CBQRestClient client;
   private final AnnotationClientExample annotationClientExample;

   @GetMapping("/users")
   public Flux<Object> users() {
      return annotationClientExample.getUsersData(UUID.randomUUID().toString());
   }

   @GetMapping("/comments/{id}")
   public Mono<Object> getComments(@PathVariable Long id) {
      return annotationClientExample.getComments(id);
   }

   @GetMapping("/post/{id}")
   public Mono<Object> post(@PathVariable Long id) {
      return annotationClientExample.getPost(id);
   }

   @GetMapping("/simple")
   public Mono<CBQResponse<Object>> simpleRequest() {
      return client.get()
              .uri("https://3dbf7a6d982b.ngrok-free.app/api/v1/parties")
              .retrieve(Object.class);
   }

   @GetMapping("/sequence")
   public Mono<Object> sequenceRequest() {
      String url = "http://localhost:1200/api/v1/parties";
      return client.sequence()
              .then(() -> client.get().uri(url).retrieve())
              .then((String user) -> client.get().uri(url).retrieve())
              .then((String user) -> client.get().uri(url).retrieve())
              .then((String user) -> client.get().uri(url).retrieve())
              .then((String user) -> client.get().uri(url).retrieve())
              .execute();
   }

   @GetMapping("/parallel")
   public Mono<List<Object>> parallelRequest() {
      String url = "https://3dbf7a6d982b.ngrok-free.app/api/v1/parties";
      return client.parallel(
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class),
                      client.get().uri(url).retrieve(Object.class)
              ).waitAll().execute()
              .map(CBQParallelResult::getBodies);
   }

   @GetMapping("/workflow")
   public Mono<CBQResponse<Object>> workflowExample(@RequestParam(required = false) String correlationId) {
      String cid = correlationId != null ? correlationId : UUID.randomUUID().toString();

      log.info("availableProcessors: {}", Runtime.getRuntime().availableProcessors());
      log.info("MDC correlationId: {}", MDC.get("cid"));

      return CBQWorkflow
              .startWith(() -> client.get().uri("/get").retrieve(Object.class))
              .step(() -> client.get().uri("/uuid").retrieve(Object.class))
              .step(() -> client.get().uri("/headers").retrieve(Object.class))
              .stepSync(() -> client.get().uri("/headers").retrieve(Object.class))
              .stepMono(res -> res)
              .executeAsync();
//              .contextWrite(Context.of("cid", cid));
   }

   @GetMapping("/workflow-with-fire-and-forget")
   public Mono<String> workflowWithFireAndForget(@RequestParam(required = false) String correlationId) {
      String cid = correlationId != null ? correlationId : UUID.randomUUID().toString();

      return CBQWorkflow
              .startWith(() -> client.get()
                      .uri("/get")
                      .header("X-Correlation-ID", cid)
                      .retrieve(String.class))
              .step(() -> client.get()
                      .uri("/uuid")
                      .retrieve(String.class))
              .fireAndForget(
                      () -> client.get().uri("/delay/1").retrieve(String.class),
                      () -> client.get().uri("/delay/1").retrieve(String.class)
              )
              .executeAsync()
              .map(result -> "Workflow with fire-and-forget completed. Correlation ID: " + cid);
   }

   @GetMapping("/health")
   public String health() {
      return "CBQ Rest Client Demo Application is running!";
   }
}
