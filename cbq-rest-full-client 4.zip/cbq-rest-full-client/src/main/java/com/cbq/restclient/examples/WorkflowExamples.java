package com.cbq.restclient.examples;

import com.cbq.restclient.config.RequestOverride;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQRestClientBuilder;
import com.cbq.restclient.core.CBQWorkflow;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Slf4j
public class WorkflowExamples {

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class Status {
      String status;
      boolean active;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class CardDetails {
      String cardNumber;
      String holderName;
      Double limit;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class Balance {
      Double available;
      Double pending;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class PostingRequest {
      String cardNumber;
      Double amount;
      String reference;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class PostingResult {
      String transactionId;
      String status;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class ReversalRequest {
      String transactionId;
      String reason;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class ReversalResult {
      boolean success;
   }

   interface TransactionRepository {
      void save(Object transaction);

      void incrementFailureCount(String cardNumber);

      Mono<Void> saveAsync(Object transaction);

      Mono<Void> incrementFailureCountAsync(String cardNumber);
   }

   public static void sequentialThenFireAndForget(CBQRestClient client) {

      PostingResult result = CBQWorkflow

              .startWith(() -> client.get()
                      .uri("/status")
                      .retrieve(Status.class))

              .step(status -> client.post()
                      .uri("/payments/process")
                      .bodyValue(new PostingRequest("1234", 100.0, "REF001"))
                      .retrieve(PostingResult.class))

              .fireAndForget(
                      () -> client.post().uri("/notify/email").bodyValue("Payment done").retrieve(Void.class),
                      () -> client.post().uri("/notify/sms").bodyValue("Payment done").retrieve(Void.class),
                      () -> client.post().uri("/audit/log").bodyValue("Payment logged").retrieve(Void.class)
              )
              .execute();

      System.out.println("Payment done: " + result.getTransactionId());

      CBQWorkflow
              .startWith(() -> client.post()
                      .uri("/orders/create")
                      .bodyValue(new Object())
                      .retrieve(PostingResult.class))

              .fireAndForgetWith(result2 -> client.post()
                      .uri("/analytics/track")
                      .bodyValue("Order created: " + result2.getTransactionId())
                      .retrieve(Void.class)
                      .then())
              .execute();
   }

   public static void dbCallsInWorkflow(CBQRestClient client, TransactionRepository repository) {

      CBQWorkflow
              .startWith(() -> client.post()
                      .uri("/payments/process")
                      .bodyValue(new PostingRequest("1234", 100.0, "REF001"))
                      .retrieve(PostingResult.class))

              .stepSync(result -> {
                 repository.save(result);
                 return result;
              })
              .execute();

      CBQWorkflow
              .startWith(() -> client.post()
                      .uri("/payments/process")
                      .bodyValue(new PostingRequest("1234", 100.0, "REF001"))
                      .retrieve(PostingResult.class))

              .stepMono(result -> repository.saveAsync(result).thenReturn(result))
              .execute();

      CBQWorkflow
              .startWith(() -> client.post()
                      .uri("/payments/process")
                      .bodyValue(new PostingRequest("1234", 100.0, "REF001"))
                      .retrieve(PostingResult.class))

              .fireAndForgetSync(
                      () -> repository.save("audit log entry"),
                      () -> repository.save("analytics entry")
              )
              .execute();

      CBQWorkflow
              .startWith(() -> client.post()
                      .uri("/payments/process")
                      .bodyValue(new PostingRequest("1234", 100.0, "REF001"))
                      .retrieve(PostingResult.class))

              .fireAndForgetMono(
                      () -> repository.saveAsync("audit entry"),
                      () -> repository.saveAsync("metrics entry")
              )
              .execute();

      CBQWorkflow

              .startWith(() -> client.get()
                      .uri("/users/123")
                      .retrieve(Status.class))

              .stepSync(status -> {

                 return status;
              })

              .step(enrichedStatus -> client.post()
                      .uri("/process")
                      .bodyValue(enrichedStatus)
                      .retrieve(PostingResult.class))

              .stepMono(result -> repository.saveAsync(result).thenReturn(result))

              .fireAndForget(
                      () -> client.post().uri("/notify").retrieve(Void.class)
              )
              .execute();
   }

   public static PostingResult cardPaymentWithReversal(
           CBQRestClient client,
           String cardNumber,
           Double amount,
           TransactionRepository repository) {

      final String[] transactionIdHolder = new String[1];

      return CBQWorkflow

              .startWith(() -> client.get()
                      .uri("/card/status/" + cardNumber)
                      .retrieve(Status.class))

              .step(status -> {
                 if (!status.isActive()) {
                    return Mono.error(new RuntimeException("Card is not active"));
                 }
                 return client.post()
                         .uri("/card/details")
                         .bodyValue(new CardDetailsRequest(cardNumber))
                         .retrieve(CardDetails.class);
              })

              .step(cardDetails -> {
                 if (cardDetails.getLimit() < amount) {
                    return Mono.error(new RuntimeException("Insufficient limit"));
                 }
                 return client.post()
                         .uri("/card/balance")
                         .bodyValue(new BalanceRequest(cardNumber))
                         .retrieve(Balance.class);
              })

              .step(balance -> {
                 if (balance.getAvailable() < amount) {
                    return Mono.error(new RuntimeException("Insufficient balance"));
                 }
                 return client.post()
                         .uri("/card/posting")
                         .bodyValue(new PostingRequest(cardNumber, amount, "TXN-" + System.currentTimeMillis()))
                         .override(RequestOverride::disableRetry)
                         .retrieve(PostingResult.class);
              })

              .stepMono(result -> {
                 transactionIdHolder[0] = result.getTransactionId();
                 return Mono.just(result);
              })

              .onFailure(error -> {
                 log.error("Payment failed: {}", error.getMessage());

                 if (transactionIdHolder[0] != null) {
                    return client.post()
                            .uri("/card/reversal")
                            .bodyValue(new ReversalRequest(transactionIdHolder[0], error.getMessage()))
                            .override(o -> o.disableRetry())
                            .retrieve(ReversalResult.class)
                            .doOnNext(r -> log.info("Reversal result: {}", r.isSuccessful()))
                            .then();
                 }
                 return Mono.empty();
              })

              .fireAndForget(
                      () -> client.post().uri("/audit/payment").retrieve(Void.class),
                      () -> client.post().uri("/notify/customer").retrieve(Void.class)
              )

              .execute();
   }

   @Data
   @AllArgsConstructor
   static class CardDetailsRequest {
      String cardNumber;
   }

   @Data
   @AllArgsConstructor
   static class BalanceRequest {
      String cardNumber;
   }

   public static PostingResult postingWithSecondaryCall(
           CBQRestClient client,
           PostingRequest request,
           TransactionRepository repository) {

      return CBQWorkflow

              .startWith(() -> client.post()
                      .uri("/posting/create")
                      .bodyValue(request)
                      .override(o -> o.disableRetry())
                      .retrieve(PostingResult.class))

              .stepContinueOnError(
                      result -> client.post()
                              .uri("/secondary/process")
                              .bodyValue(result)
                              .retrieve(Void.class),

                      error -> {
                         log.warn("Secondary call failed: {}", error.getMessage());

                         repository.incrementFailureCountAsync(request.getCardNumber())
                                 .subscribeOn(Schedulers.boundedElastic())
                                 .subscribe();
                      }
              )

              .execute();
   }

   public static PostingResult postingWithSecondaryCallSyncDb(
           CBQRestClient client,
           PostingRequest request,
           TransactionRepository repository) {

      return CBQWorkflow

              .startWith(() -> client.post()
                      .uri("/posting/create")
                      .bodyValue(request)
                      .retrieve(PostingResult.class))

              .stepContinueOnError(
                      result -> client.post()
                              .uri("/secondary/process")
                              .bodyValue(result)
                              .retrieve(Void.class),

                      error -> {
                         log.warn("Secondary call failed, updating DB: {}", error.getMessage());
                         repository.incrementFailureCount(request.getCardNumber());
                      }
              )

              .fireAndForget(
                      () -> client.post().uri("/notify").retrieve(Void.class)
              )

              .execute();
   }

   public static void multipleSequentialThenParallel(CBQRestClient client) {

      CBQWorkflow
              .startWith(() -> client.get().uri("/step1").retrieve(String.class))
              .step(r1 -> client.get().uri("/step2").retrieve(String.class))
              .step(r2 -> client.get().uri("/step3").retrieve(String.class))
              .step(r3 -> client.post().uri("/final").bodyValue(r3).retrieve(String.class))

              .fireAndForget(
                      () -> client.post().uri("/notify/a").retrieve(Void.class),
                      () -> client.post().uri("/notify/b").retrieve(Void.class),
                      () -> client.post().uri("/notify/c").retrieve(Void.class),
                      () -> client.post().uri("/audit").retrieve(Void.class),
                      () -> client.post().uri("/analytics").retrieve(Void.class)
              )
              .execute();
   }

   public static void conditionalFireAndForget(CBQRestClient client) {
      CBQWorkflow
              .startWith(() -> client.post()
                      .uri("/orders/create")
                      .retrieve(PostingResult.class))
              .fireAndForgetWith(result -> {

                 if ("HIGH_VALUE".equals(result.getStatus())) {
                    return client.post()
                            .uri("/notify/vip")
                            .bodyValue(result)
                            .retrieve(Void.class).then();
                 } else {
                    return client.post()
                            .uri("/notify/standard")
                            .bodyValue(result)
                            .retrieve(Void.class).then();
                 }
              })
              .execute();
   }

   public static void fullWorkflowWithErrorHandling(
           CBQRestClient client,
           TransactionRepository repository) {

      CBQWorkflow

              .startWith(() -> client.get().uri("/validate").retrieve(Status.class))
              .step(status -> client.post().uri("/process").retrieve(PostingResult.class))

              .stepContinueOnError(
                      result -> client.post().uri("/enrich").retrieve(PostingResult.class),
                      error -> log.warn("Enrichment failed: {}", error.getMessage())
              )

              .fireAndForget(
                      () -> client.post().uri("/notify").retrieve(Void.class)
              )
              .fireAndForgetMono(
                      () -> repository.saveAsync("audit")
              )

              .onFailure(error -> {
                 log.error("Workflow failed: {}", error.getMessage());
                 return client.post()
                         .uri("/rollback")
                         .bodyValue(error.getMessage())
                         .retrieve(Void.class).then();
              })

              .onFireAndForgetError(error ->
                      log.error("Background task failed: {}", error.getMessage()))

              .execute();
   }

   public static void asyncWorkflow(CBQRestClient client) {

      CBQWorkflow
              .startWith(() -> client.post().uri("/process").retrieve(PostingResult.class))
              .fireAndForget(
                      () -> client.post().uri("/notify").retrieve(Void.class)
              )
              .executeAsync()
              .subscribe(
                      result -> log.info("Async workflow completed: {}", result),
                      error -> log.error("Async workflow failed: {}", error.getMessage())
              );
   }

   public static void backgroundJob(CBQRestClient client) {

      CBQWorkflow
              .startWith(() -> client.post().uri("/batch/process").retrieve(Void.class))
              .fireAndForget(
                      () -> client.post().uri("/notify/complete").retrieve(Void.class)
              )
              .onFailure(error -> client.post().uri("/notify/failed").retrieve(Void.class).then())
              .executeAndForget();
   }

   public static void main(String[] args) {
      CBQRestClient client = CBQRestClientBuilder.builder("workflow-client")
              .baseUrl("https://api.example.com")
              .build();

      client.shutdown();
      CBQWorkflow.shutdown();
   }
}
