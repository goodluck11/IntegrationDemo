package com.cbq.restclient.config;

import lombok.Getter;

import java.util.*;

@Getter
public class TracingConfig {

   private boolean enabled = false;

    private boolean correlationIdEnabled = true;
    private String correlationIdHeader = "X-Correlation-Id";
    private boolean generateIfMissing = true;

    private boolean openTelemetryEnabled = false;
    private String traceIdHeader = "X-B3-TraceId";
    private String spanIdHeader = "X-B3-SpanId";
    private String parentSpanIdHeader = "X-B3-ParentSpanId";
    private String sampledHeader = "X-B3-Sampled";

    private boolean w3cTraceContextEnabled = false;
    private final String traceParentHeader = "traceparent";
    private final String traceStateHeader = "tracestate";

    private final Set<String> propagateHeaders = new HashSet<>();

    private TracingConfig() {}

    public static TracingConfig disabled() {
        return new TracingConfig();
    }

    public static TracingConfig defaults() {
        return new TracingConfig().enabled(true);
    }

    public static TracingConfig custom() {
        return new TracingConfig().enabled(true);
    }

    public TracingConfig enabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public TracingConfig correlationId(boolean enabled) {
        this.correlationIdEnabled = enabled;
        return this;
    }

    public TracingConfig correlationIdHeader(String header) {
        this.correlationIdHeader = header;
        return this;
    }

    public TracingConfig generateCorrelationIdIfMissing(boolean generate) {
        this.generateIfMissing = generate;
        return this;
    }

    public TracingConfig openTelemetry(boolean enabled) {
        this.openTelemetryEnabled = enabled;
        return this;
    }

    public TracingConfig b3Headers(String traceId, String spanId, String parentSpanId, String sampled) {
        this.traceIdHeader = traceId;
        this.spanIdHeader = spanId;
        this.parentSpanIdHeader = parentSpanId;
        this.sampledHeader = sampled;
        return this;
    }

    public TracingConfig w3cTraceContext(boolean enabled) {
        this.w3cTraceContextEnabled = enabled;
        return this;
    }

    public TracingConfig propagateHeaders(String... headers) {
        this.propagateHeaders.addAll(Arrays.asList(headers));
        return this;
    }

    public Set<String> getAllPropagationHeaders() {
        Set<String> headers = new HashSet<>(propagateHeaders);

        if (correlationIdEnabled) {
            headers.add(correlationIdHeader);
        }

        if (openTelemetryEnabled) {
            headers.add(traceIdHeader);
            headers.add(spanIdHeader);
            headers.add(parentSpanIdHeader);
            headers.add(sampledHeader);
        }

        if (w3cTraceContextEnabled) {
            headers.add(traceParentHeader);
            headers.add(traceStateHeader);
        }

        return headers;
    }
}
