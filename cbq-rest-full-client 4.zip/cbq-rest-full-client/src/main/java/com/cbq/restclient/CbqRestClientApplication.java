package com.cbq.restclient;

import com.cbq.restclient.annotation.model.EnableCBQClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableCBQClient(basePackages = "com.cbq.restclient.clients")
public class CbqRestClientApplication {

   public static void main(String[] args) {
      SpringApplication.run(CbqRestClientApplication.class, args);
   }
}
