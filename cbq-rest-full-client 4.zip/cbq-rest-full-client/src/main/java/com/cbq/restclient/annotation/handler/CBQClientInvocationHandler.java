package com.cbq.restclient.annotation.handler;

/*
 * @created by 02/02/2026  - 22:15
 * @project cbq-rest-full-client
 * @author Goodluck
 */

import com.cbq.restclient.annotation.core.CBQFallbackFactory;
import com.cbq.restclient.annotation.core.CBQRequestInterceptor;
import com.cbq.restclient.annotation.exception.CBQClientInvocationException;
import com.cbq.restclient.annotation.metadata.CBQClientMetadata;
import com.cbq.restclient.annotation.metadata.CBQMethodMetadata;
import com.cbq.restclient.annotation.model.CBQErrorMapping;
import com.cbq.restclient.annotation.resolver.CBQMetadataResolver;
import com.cbq.restclient.core.CBQRestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static com.cbq.restclient.annotation.core.CBQRequestInterceptor.CBQRequestContext;
import static com.cbq.restclient.annotation.metadata.CBQMethodMetadata.ParamMeta;

/**
 * JDK dynamic proxy InvocationHandler that translates interface method calls
 * into CBQRestClient HTTP operations.
 *
 * <p>All annotation parsing happens once at creation via {@code CBQMetadataResolver}.
 * Invocation is zero-reflection for hot path — only map lookups and string substitution.</p>
 */
@Slf4j
public class CBQClientInvocationHandler implements InvocationHandler {

   private final CBQRestClient restClient;
   private final CBQClientMetadata clientMeta;
   private final ApplicationContext applicationContext;

   // Fallback instances (lazy-initialized)
   private volatile Object fallbackInstance;
   private volatile CBQFallbackFactory<?> fallbackFactory;

   // Interceptors resolved from Spring context (lazy per class)
   private final ConcurrentHashMap<Class<?>, CBQRequestInterceptor> interceptorCache = new ConcurrentHashMap<>();

   public CBQClientInvocationHandler(CBQRestClient restClient,
                                     CBQClientMetadata clientMeta,
                                     ApplicationContext applicationContext) {
      this.restClient = restClient;
      this.clientMeta = clientMeta;
      this.applicationContext = applicationContext;
   }

   @Override
   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
      // Handle Object methods (toString, equals, hashCode)
      if (method.getDeclaringClass() == Object.class) {
         return handleObjectMethod(method, args);
      }

      // Handle default interface methods
      if (method.isDefault()) {
         return invokeDefaultMethod(proxy, method, args);
      }

      // Look up pre-parsed metadata
      String key = CBQMetadataResolver.methodKey(method);
      CBQMethodMetadata meta = clientMeta.getMethods().get(key);
      if (meta == null) {
         throw new CBQClientInvocationException(clientMeta.getName(), method.getName(),
                 "", "No HTTP mapping found for this method");
      }

      try {
         return executeRequest(meta, args);
      } catch (Exception e) {
         // This shouldn't normally be reached because errors are handled in the reactive chain
         // but covers edge cases during request construction.
         log.error("[{}] Failed to build request for {}: {}",
                 clientMeta.getName(), meta.getMethodName(), e.getMessage());
         throw new CBQClientInvocationException(clientMeta.getName(), meta.getMethodName(),
                 meta.getPathTemplate(), "Request construction failed", e);
      }
   }

   /**
    * Build and execute the HTTP request using CBQRestClient.
    */
   @SuppressWarnings({"unchecked", "rawtypes"})
   private Object executeRequest(CBQMethodMetadata meta, Object[] args) {
      // 1. Resolve URI with path variables
      String uri = resolveUri(meta, args);

      // 2. Append query parameters
      uri = appendQueryParams(uri, meta, args);

      // 3. Build headers (static + dynamic)
      HttpHeaders headers = buildHeaders(meta, args);

      // 4. Resolve body
      Object body = meta.getBodyParamIndex() >= 0 ? args[meta.getBodyParamIndex()] : null;

      // 5. Apply interceptors
      applyInterceptors(meta, uri, headers, body, args);

      // 7. Build CBQRestClient request spec
      CBQRestClient.RequestSpec spec = buildRequestSpec(meta, uri, headers, body);

      // 8. Execute and map response
      Mono<?> responseMono;
      if (meta.isReturnsCBQResponse()) {
         responseMono = spec.retrieve((Class) resolveRawClass(meta.getBodyType()));
      } else if (meta.isReturnsVoid()) {
         responseMono = spec.retrieve(Void.class).then(Mono.empty());
      } else {
         responseMono = spec.retrieveBody((Class) resolveRawClass(meta.getBodyType()));
      }

      // 9. Apply error mappings
      responseMono = applyErrorMappings(responseMono, meta);

      // 11. Apply fallback
      responseMono = applyFallback(responseMono, meta, args);

      // 12. Wrap return type (Mono vs Flux)
      return wrapReturn(meta, responseMono);
   }

   // ═══════════════════════════════════════════════════════════════════
   // URI RESOLUTION
   // ═══════════════════════════════════════════════════════════════════

   private String resolveUri(CBQMethodMetadata meta, Object[] args) {
      String path = meta.getPathTemplate();

      // Substitute path variables: /users/{id} → /users/123
      for (ParamMeta param : meta.getPathParams()) {
         Object value = args[param.getIndex()];
         if (value == null) {
            throw new CBQClientInvocationException(clientMeta.getName(), meta.getMethodName(),
                    path, "Path variable '" + param.getName() + "' cannot be null");
         }
         String strValue = String.valueOf(value);
         if (param.isEncoded()) {
            strValue = URLEncoder.encode(strValue, StandardCharsets.UTF_8);
         }
         path = path.replace("{" + param.getName() + "}", strValue);
      }

      // Prepend client path prefix
      String prefix = clientMeta.getPathPrefix();
      if (prefix != null && !prefix.isEmpty()) {
         if (!prefix.startsWith("/")) prefix = "/" + prefix;
         if (prefix.endsWith("/")) prefix = prefix.substring(0, prefix.length() - 1);
         if (!path.startsWith("/")) path = String.format("/%s", path);
         path = prefix + path;
      }

      return path;
   }

   private String appendQueryParams(String uri, CBQMethodMetadata meta, Object[] args) {
      if (meta.getQueryParams().isEmpty()) return uri;

      UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uri);

      for (ParamMeta param : meta.getQueryParams()) {
         Object value = args[param.getIndex()];

         if (value == null) {
            if (param.isOmitNull()) continue;
            String defaultVal = param.getDefaultValue();
            if (defaultVal != null && !defaultVal.isEmpty()) {
               value = defaultVal;
            } else {
               continue;
            }
         }

         // Handle collections (expand to multiple params)
         if (value instanceof Collection) {
            for (Object item : (Collection<?>) value) {
               builder.queryParam(param.getName(), String.valueOf(item));
            }
         } else if (value.getClass().isArray()) {
            int length = Array.getLength(value);
            for (int i = 0; i < length; i++) {
               builder.queryParam(param.getName(), String.valueOf(Array.get(value, i)));
            }
         } else {
            builder.queryParam(param.getName(), String.valueOf(value));
         }
      }

      return builder.build().toUriString();
   }

   private HttpHeaders buildHeaders(CBQMethodMetadata meta, Object[] args) {
      HttpHeaders headers = new HttpHeaders();

      // Static headers from @CBQHeaders
      meta.getStaticHeaders().forEach(headers::set);

      // Content-Type
      if (meta.getConsumes() != null && !meta.getConsumes().isEmpty()) {
         headers.set(HttpHeaders.CONTENT_TYPE, meta.getConsumes());
      }
      if (meta.getProduces() != null && !meta.getProduces().isEmpty()) {
         headers.set(HttpHeaders.ACCEPT, meta.getProduces());
      }

      // Dynamic headers from @CBQHeader parameters
      for (ParamMeta param : meta.getHeaderParams()) {
         Object value = args[param.getIndex()];
         if (value != null) {
            headers.set(param.getName(), String.valueOf(value));
         }
      }

      return headers;
   }

   // ═══════════════════════════════════════════════════════════════════
   // INTERCEPTORS
   // ═══════════════════════════════════════════════════════════════════

   private void applyInterceptors(CBQMethodMetadata meta, String uri,
                                  HttpHeaders headers, Object body, Object[] args) {
      if (meta.getInterceptorClasses().isEmpty()) return;

      CBQRequestContext context = CBQRequestContext.builder()
              .clientName(clientMeta.getName())
              .methodName(meta.getMethodName())
              .httpMethod(meta.getHttpMethod())
              .uri(uri)
              .headers(headers)
              .body(body)
              .attributes(new HashMap<>())
              .build();

      // Resolve interceptors from Spring context, sorted by order
      List<CBQRequestInterceptor> interceptors = meta.getInterceptorClasses().stream()
              .map(cls -> interceptorCache.computeIfAbsent(cls,
                      k -> (CBQRequestInterceptor) applicationContext.getBean(k)))
              .sorted(Comparator.comparingInt(CBQRequestInterceptor::order))
              .collect(java.util.stream.Collectors.toList());

      for (CBQRequestInterceptor interceptor : interceptors) {
         try {
            interceptor.apply(context);
         } catch (Exception e) {
            log.error("[{}] Interceptor {} failed: {}", clientMeta.getName(),
                    interceptor.getClass().getSimpleName(), e.getMessage());
            throw new CBQClientInvocationException(clientMeta.getName(), meta.getMethodName(),
                    uri, "Interceptor failed: " + interceptor.getClass().getSimpleName(), e);
         }
      }
   }

   // ═══════════════════════════════════════════════════════════════════
   // REQUEST SPEC BUILDING
   // ═══════════════════════════════════════════════════════════════════

   private CBQRestClient.RequestSpec buildRequestSpec(CBQMethodMetadata meta, String uri,
                                                      HttpHeaders headers, Object body) {
      CBQRestClient.RequestSpec spec;

      switch (meta.getHttpMethod().name()) {
         case "GET":
            spec = restClient.get();
            break;
         case "POST":
            spec = restClient.post();
            break;
         case "PUT":
            spec = restClient.put();
            break;
         case "DELETE":
            spec = restClient.delete();
            break;
         case "PATCH":
            spec = restClient.patch();
            break;
         default:
            spec = restClient.method(meta.getHttpMethod());
            break;
      }

      spec.uri(uri);

      // Apply headers
      headers.forEach((name, values) -> values.
              forEach(value -> spec.header(name, value)));

      if (body != null) spec.bodyValue(body);

      if (meta.getResponseTimeout() > 0) {
         spec.override(o -> o
                 .responseTimeout(Duration.ofMillis(meta.getResponseTimeout())));
      }

      return spec;
   }

   // ═══════════════════════════════════════════════════════════════════
   // ERROR MAPPING
   // ═══════════════════════════════════════════════════════════════════

   @SuppressWarnings("unchecked")
   private <T> Mono<T> applyErrorMappings(Mono<T> mono, CBQMethodMetadata meta) {
      if (meta.getErrorMappings().isEmpty()) return mono;

      return mono.onErrorMap(throwable -> {
         // Check if the error has a status code we can map
         Integer statusCode = extractStatusCode(throwable);
         if (statusCode == null) return throwable;

         for (CBQErrorMapping mapping : meta.getErrorMappings()) {
            if (mapping.status() == statusCode) {
               return createMappedException(mapping, throwable, statusCode);
            }
         }
         return throwable;
      });
   }

   private Integer extractStatusCode(Throwable throwable) {
      // Try CBQRestClientException first
      try {
         Method getStatusCode = throwable.getClass().getMethod("getStatusCode");
         Object result = getStatusCode.invoke(throwable);
         if (result instanceof Integer) return (Integer) result;
      } catch (Exception ignored) {
      }

      // Check message for a status pattern
      String msg = throwable.getMessage();
      if (msg != null && msg.contains("status:")) {
         try {
            int idx = msg.indexOf("status:") + 7;
            return Integer.parseInt(msg.substring(idx, idx + 3).trim());
         } catch (Exception ignored) {
         }
      }
      return null;
   }

   private RuntimeException createMappedException(CBQErrorMapping mapping, Throwable cause,
                                                  int statusCode) {
      String message = mapping.message().isEmpty()
              ? "HTTP " + statusCode + " error"
              : mapping.message()
              .replace("{status}", String.valueOf(statusCode))
              .replace("{uri}", cause.getMessage() != null ? cause.getMessage() : "");

      try {
         // Try (String, Throwable) constructor
         Constructor<? extends RuntimeException> ctor =
                 mapping.exception().getConstructor(String.class, Throwable.class);
         return ctor.newInstance(message, cause);
      } catch (NoSuchMethodException e) {
         try {
            // Fallback to (String) constructor
            Constructor<? extends RuntimeException> ctor =
                    mapping.exception().getConstructor(String.class);
            return ctor.newInstance(message);
         } catch (Exception ex) {
            log.warn("Cannot instantiate exception {}: {}",
                    mapping.exception().getSimpleName(), ex.getMessage());
            return new RuntimeException(message, cause);
         }
      } catch (Exception e) {
         return new RuntimeException(message, cause);
      }
   }

   // ═══════════════════════════════════════════════════════════════════
   // FALLBACK
   // ═══════════════════════════════════════════════════════════════════

   @SuppressWarnings({"unchecked", "rawtypes"})
   private <T> Mono<T> applyFallback(Mono<T> mono, CBQMethodMetadata meta, Object[] args) {
      // Method-level @CBQFallback (default method in interface)
      if (meta.getFallbackMethod() != null) {
         return mono.onErrorResume(throwable -> {
            try {
               Object[] fallbackArgs;
               Method fm = meta.getFallbackMethod();
               if (fm.getParameterCount() > (args != null ? args.length : 0)) {
                  // Includes Throwable as the last param
                  fallbackArgs = new Object[(args != null ? args.length : 0) + 1];
                  if (args != null) System.arraycopy(args, 0, fallbackArgs, 0, args.length);
                  fallbackArgs[fallbackArgs.length - 1] = throwable;
               } else {
                  fallbackArgs = args;
               }

               // Invoke the default method on fallback class or interface
               Object result = fm.invoke(resolveFallbackTarget(), fallbackArgs);
               if (result instanceof Mono) return (Mono<T>) result;
               return Mono.justOrEmpty((T) result);
            } catch (Exception e) {
               log.error("[{}] Fallback method {} failed: {}",
                       clientMeta.getName(), meta.getFallbackMethodName(), e.getMessage());
               return Mono.error(throwable);
            }
         });
      }

      // Client-level fallbackFactory
      if (clientMeta.getFallbackFactoryClass() != null) {
         return mono.onErrorResume(throwable -> {
            try {
               if (fallbackFactory == null) {
                  synchronized (this) {
                     if (fallbackFactory == null) {
                        fallbackFactory = (CBQFallbackFactory<?>)
                                applicationContext.getBean(clientMeta.getFallbackFactoryClass());
                     }
                  }
               }
               Object fallbackProxy = fallbackFactory.create(throwable);
               Object result = meta.getMethod().invoke(fallbackProxy, args);
               if (result instanceof Mono) return (Mono<T>) result;
               return Mono.justOrEmpty((T) result);
            } catch (Exception e) {
               log.error("[{}] FallbackFactory failed: {}",
                       clientMeta.getName(), e.getMessage());
               return Mono.error(throwable);
            }
         });
      }

      // Client-level static fallback class
      if (clientMeta.getFallbackClass() != null) {
         return mono.onErrorResume(throwable -> {
            try {
               if (fallbackInstance == null) {
                  synchronized (this) {
                     if (fallbackInstance == null) {
                        fallbackInstance = applicationContext.getBean(clientMeta.getFallbackClass());
                     }
                  }
               }
               Object result = meta.getMethod().invoke(fallbackInstance, args);
               if (result instanceof Mono) return (Mono<T>) result;
               return Mono.justOrEmpty((T) result);
            } catch (Exception e) {
               log.error("[{}] Fallback class failed: {}",
                       clientMeta.getName(), e.getMessage());
               return Mono.error(throwable);
            }
         });
      }

      return mono;
   }

   private Object resolveFallbackTarget() {
      if (clientMeta.getFallbackClass() != null) {
         if (fallbackInstance == null) {
            synchronized (this) {
               if (fallbackInstance == null) {
                  fallbackInstance = applicationContext.getBean(clientMeta.getFallbackClass());
               }
            }
         }
         return fallbackInstance;
      }
      return null;
   }

   // ═══════════════════════════════════════════════════════════════════
   // RETURN TYPE WRAPPING
   // ═══════════════════════════════════════════════════════════════════

   @SuppressWarnings({"unchecked", "rawtypes"})
   private Object wrapReturn(CBQMethodMetadata meta, Mono<?> mono) {
      if (meta.isReturnsFlux()) {
         return mono.flatMapMany(result -> {
            if (result instanceof Iterable) {
               return Flux.fromIterable((Iterable) result);
            }
            return Flux.just(result);
         });
      }
      return mono; // Already Mono
   }

   // ═══════════════════════════════════════════════════════════════════
   // UTILITY
   // ═══════════════════════════════════════════════════════════════════

   private Object handleObjectMethod(Method method, Object[] args) {
      switch (method.getName()) {
         case "toString":
            return "CBQClient[" + clientMeta.getName() + "]<"
                    + clientMeta.getClientInterface().getSimpleName() + ">";
         case "hashCode":
            return System.identityHashCode(this);
         case "equals":
            return this == args[0];
         default:
            throw new UnsupportedOperationException(method.getName());
      }
   }

   private Object invokeDefaultMethod(Object proxy, Method method, Object[] args) throws Throwable {
      MethodHandle handle = MethodHandles.lookup()
              .findSpecial(
                      method.getDeclaringClass(),
                      method.getName(),
                      MethodType.methodType(method.getReturnType(), method.getParameterTypes()),
                      method.getDeclaringClass()
              ).bindTo(proxy);
      return args != null ? handle.invokeWithArguments(args) : handle.invoke();
   }

   private Class<?> resolveRawClass(Type type) {
      if (type instanceof Class) return (Class<?>) type;
      if (type instanceof ParameterizedType) {
         Type raw = ((ParameterizedType) type).getRawType();
         if (raw instanceof Class) return (Class<?>) raw;
      }
      return Object.class;
   }
}
