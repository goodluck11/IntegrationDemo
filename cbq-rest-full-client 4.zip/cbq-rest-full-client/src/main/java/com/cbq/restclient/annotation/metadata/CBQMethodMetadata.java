package com.cbq.restclient.annotation.metadata;

import com.cbq.restclient.annotation.model.CBQClient;
import com.cbq.restclient.annotation.model.CBQErrorMapping;
import com.cbq.restclient.annotation.model.CBQRetryOn;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import org.springframework.http.HttpMethod;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

/*
 * @created by 02/02/2026  - 22:02
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Getter
@Builder
@ToString(exclude = {"method", "fallbackMethod"})
public class CBQMethodMetadata {
   // ── Identity ──
   private final Method method;
   private final String methodName;

   // ── HTTP ──
   private final HttpMethod httpMethod;
   private final String pathTemplate;
   private final String consumes;
   private final String produces;

   // ── Headers ──
   private final Map<String, String> staticHeaders;

   // ── Parameters ──
   private final List<ParamMeta> pathParams;
   private final List<ParamMeta> queryParams;
   private final List<ParamMeta> headerParams;
   private final int bodyParamIndex; // -1 = no body

   private final Type returnType;
   private final Type bodyType;
   private final boolean returnsMono;
   private final boolean returnsFlux;
   private final boolean returnsVoid;
   private final boolean returnsCBQResponse; // @CBQExchange

   private final boolean retryEnabled;
   private final boolean circuitBreakerEnabled;
   private final boolean rateLimiterEnabled;
   private final boolean bulkheadEnabled;
   private final long responseTimeout; // -1 = use client default

   private final CBQRetryOn retryOverride; // null = use client default

   // ── Error mappings ──
   private final List<CBQErrorMapping> errorMappings;

   // ── Logging ──
   private final CBQClient.LogLevel logLevel; // null = use client default

   // ── Fallback ──
   private final String fallbackMethodName; // null = no method-level fallback
   private final Method fallbackMethod;     // resolved fallback method

   // ── Interceptors ──
   private final List<Class<?>> interceptorClasses;

   @Getter
   @Builder
   public static class ParamMeta {
      private final int index;
      private final String name;
      private final String defaultValue;
      private final boolean omitNull;
      private final boolean encoded;
      private final Type type;
   }
}
