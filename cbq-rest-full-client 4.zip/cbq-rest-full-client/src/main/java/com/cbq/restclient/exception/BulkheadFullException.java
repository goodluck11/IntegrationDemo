package com.cbq.restclient.exception;

public class BulkheadFullException extends CBQRestClientException {
    private final String bulkheadName;

    public BulkheadFullException(String bulkheadName, String requestId, String uri, String method) {
        super("Bulkhead '" + bulkheadName + "' is full - max concurrent calls reached", requestId, uri, method);
        this.bulkheadName = bulkheadName;
    }

    public String getBulkheadName() { return bulkheadName; }
}
