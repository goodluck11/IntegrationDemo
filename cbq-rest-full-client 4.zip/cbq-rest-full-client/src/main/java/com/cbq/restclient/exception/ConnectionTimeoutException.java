package com.cbq.restclient.exception;

public class ConnectionTimeoutException extends CBQRestClientException {
    public ConnectionTimeoutException(String message, String requestId, String uri, String method) {
        super(message, requestId, uri, method);
    }
    public ConnectionTimeoutException(String message, Throwable cause, String requestId, String uri, String method) {
        super(message, cause, requestId, uri, method);
    }
}
