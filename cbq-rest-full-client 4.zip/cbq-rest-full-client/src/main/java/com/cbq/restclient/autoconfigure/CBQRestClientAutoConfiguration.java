package com.cbq.restclient.autoconfigure;

import com.cbq.restclient.config.LoggingConfig;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQRestClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CBQRestClientAutoConfiguration {

   @Bean(destroyMethod = "shutdown")
//    @ConditionalOnMissingBean
   public CBQRestClient client() {
      return CBQRestClientBuilder.builder("demo-client")
              .baseUrl("https://httpbin.org")
              .logging(LoggingConfig.custom()
                      .logAll()
              )
              .tracingEnabled(true)
              .metricsEnabled(false)
              .build();
   }
}
