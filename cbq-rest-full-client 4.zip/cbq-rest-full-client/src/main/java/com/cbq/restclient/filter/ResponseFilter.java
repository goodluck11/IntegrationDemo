package com.cbq.restclient.filter;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.util.Map;

@FunctionalInterface
public interface ResponseFilter {

    Mono<ResponseContext> filter(ResponseContext context);

    @Getter
    class ResponseContext {
        private final String requestId;
        private final HttpStatus status;
        private final HttpHeaders headers;
        @Setter
        private Object body;
        private final long durationMs;
        private final Map<String, Object> requestAttributes;

        public ResponseContext(String requestId, HttpStatus status, HttpHeaders headers,
                             Object body, long durationMs, Map<String, Object> requestAttributes) {
            this.requestId = requestId;
            this.status = status;
            this.headers = headers;
            this.body = body;
            this.durationMs = durationMs;
            this.requestAttributes = requestAttributes;
        }

       public int getStatusCode() { return status.value(); }

       @SuppressWarnings("unchecked")
        public <T> T getRequestAttribute(String key) {
            return (T) requestAttributes.get(key);
        }

        public boolean isSuccessful() {
            return status.is2xxSuccessful();
        }

        public boolean isClientError() {
            return status.is4xxClientError();
        }

        public boolean isServerError() {
            return status.is5xxServerError();
        }
    }
}
