package com.cbq.restclient.annotation.core;

/*
 * @created by 02/02/2026  - 21:57
 * @project cbq-rest-full-client
 * @author Goodluck
 */
public interface CBQFallbackFactory<T> {

   /**
    * Create a fallback instance given the cause of the failure.
    *
    * @param cause the exception that triggered the fallback
    * @return a fallback implementation of the client interface
    */
   T create(Throwable cause);
}
