package com.cbq.restclient.filter;

import org.slf4j.MDC;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.UUID;

import static com.cbq.restclient.config.ClientConstants.CID_KEY;
import static com.cbq.restclient.config.ClientConstants.REQUEST_ID_HEADER;

/*
 * @created by 31/01/2026  - 08:23
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Component
public class RequestIdWebFilter implements WebFilter {


   @Override
   public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
      String requestId = exchange.getRequest().getHeaders().getFirst(REQUEST_ID_HEADER);
      if (requestId == null) {
         requestId = UUID.randomUUID().toString();
      }

      ServerHttpRequest mutatedRequest = exchange.getRequest().mutate()
              .header(REQUEST_ID_HEADER, requestId)
              .build();

      ServerWebExchange mutatedExchange = exchange.mutate()
              .request(mutatedRequest)
              .build();

      String finalRequestId = requestId;
      mutatedExchange.getResponse().beforeCommit(() -> {
         mutatedExchange.getResponse().getHeaders()
                 .add(REQUEST_ID_HEADER, finalRequestId);
         return Mono.empty();
      });

      return chain.filter(mutatedExchange)
              .contextWrite(Context.of(CID_KEY, finalRequestId))
              .doFirst(() -> MDC.put(CID_KEY, finalRequestId))
              .doFinally(signal -> MDC.remove(CID_KEY));

   }
}
