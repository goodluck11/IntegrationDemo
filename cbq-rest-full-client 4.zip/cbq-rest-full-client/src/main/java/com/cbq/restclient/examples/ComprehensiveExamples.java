package com.cbq.restclient.examples;

import com.cbq.restclient.config.*;
import com.cbq.restclient.core.CBQRestClient;
import com.cbq.restclient.core.CBQRestClientBuilder;
import com.cbq.restclient.core.CBQRestClientPool;
import com.cbq.restclient.exception.BulkheadFullException;
import com.cbq.restclient.exception.CBQRestClientException;
import com.cbq.restclient.exception.CircuitBreakerOpenException;
import com.cbq.restclient.exception.RateLimitExceededException;
import com.cbq.restclient.filter.ErrorMapper;
import com.cbq.restclient.filter.Filters;
import com.cbq.restclient.model.CBQParallelResult;
import com.cbq.restclient.model.CBQResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static java.lang.System.err;
import static java.lang.System.out;

public class ComprehensiveExamples {

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class User {
      private Long id;
      private String name;
      private String email;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class Order {
      private Long id;
      private Long userId;
      private String status;
      private Double amount;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class Product {
      private Long id;
      private String name;
      private Double price;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class PaymentRequest {
      private Long orderId;
      private Double amount;
      private String currency;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class PaymentResult {
      private String transactionId;
      private String status;
   }

   @Data
   @NoArgsConstructor
   @AllArgsConstructor
   static class CreateUserRequest {
      private String name;
      private String email;
   }

   static class UserNotFoundException extends RuntimeException {
      public UserNotFoundException(String message) {
         super(message);
      }
   }

   static class OrderNotFoundException extends RuntimeException {
      public OrderNotFoundException(String message) {
         super(message);
      }
   }

   static class ServiceUnavailableException extends RuntimeException {
      public ServiceUnavailableException(String message) {
         super(message);
      }
   }

   static class UnauthorizedException extends RuntimeException {
      public UnauthorizedException(String message) {
         super(message);
      }
   }

   static class RateLimitException extends RuntimeException {
      public RateLimitException(String message) {
         super(message);
      }
   }

   public static CBQRestClient createFullyConfiguredClient() {
      return CBQRestClientBuilder.builder("user-service")
              .baseUrl("https://api.example.com/v1")

              .timeouts(TimeoutConfig.custom()
                      .connection(Duration.ofSeconds(3))
                      .read(Duration.ofSeconds(10))
                      .write(Duration.ofSeconds(10))
                      .response(Duration.ofSeconds(30)))

              .headers(h -> {
                 h.put("X-Application", "my-app");
                 h.put("X-Environment", "production");
                 h.put("Accept-Language", "en-US");
              })

              .ssl(SslConfig.custom()
                      .certificatePath("/etc/ssl/certs/api-cert.pem")
                      .handshakeTimeout(Duration.ofSeconds(10)))

              .resilience(ResilienceConfig.custom()

                      .retry(ResilienceConfig.RetryConfig.custom()
                              .maxAttempts(3)
                              .waitDuration(Duration.ofMillis(500))
                              .backoff(ResilienceConfig.BackoffStrategy.EXPONENTIAL_WITH_JITTER)
                              .backoffMultiplier(2.0)
                              .maxBackoff(Duration.ofSeconds(10))
                              .retryOnConnectionTimeout(true)
                              .retryOnReadTimeout(true)
                              .retryOnExceptions(IOException.class))

                      .circuitBreaker(ResilienceConfig.CircuitBreakerConfig.custom()
                              .windowSize(100)
                              .minCalls(10)
                              .failureRate(50)
                              .slowCallRate(80)
                              .slowCallDuration(Duration.ofSeconds(2))
                              .openStateWait(Duration.ofSeconds(60))
                              .halfOpenCalls(5)
                              .autoTransition(true))

                      .rateLimiter(ResilienceConfig.RateLimiterConfig.custom()
                              .limitForPeriod(100)
                              .refreshPeriod(Duration.ofSeconds(1))
                              .timeout(Duration.ofMillis(500)))

                      .bulkhead(ResilienceConfig.BulkheadConfig.custom()
                              .maxConcurrentCalls(25)
                              .maxWait(Duration.ofMillis(100))))

              .logging(LoggingConfig.custom()
                      .logAll()
                      .maskFields("password", "token", "apiKey", "secret", "authorization")
                      .maskField("creditCard", 4)
                      .excludeFields("internalId")
                      .maskSymbol('*')
                      .maxBodySize(10_000))

              .emailNotifier(EmailNotifierConfig.custom()
                      .async(true)
                      .rateLimit(5, Duration.ofMinutes(1))
                      .circuitBreaker(true)
                      .circuitBreakerThreshold(3)
                      .circuitBreakerResetTime(Duration.ofMinutes(5))
                      .host("smtp.company.com")
                      .port(587)
                      .credentials("alerts@company.com", "password")
                      .startTls(true)
                      .defaultFrom("noreply@company.com")
                      .defaultTo("ops-team@company.com", "dev-team@company.com")
                      .defaultSubject("API Error Alert"))

              .tracing(TracingConfig.custom()
                      .correlationId(true)
                      .correlationIdHeader("X-Correlation-Id")
                      .generateCorrelationIdIfMissing(true)
                      .openTelemetry(true)
                      .propagateHeaders("X-Request-Id", "X-Session-Id"))

              .metrics(MetricsConfig.custom()
                      .metricPrefix("cbq.http.client")
                      .commonTag("service", "user-service")
                      .normalizeUri(true)
                      .maxUriSegments(5))

              .addRequestFilter(Filters.bearerToken(() -> getAuthToken()))
              .addRequestFilter(Filters.timestamp("X-Request-Timestamp"))
              .addRequestFilter(Filters.auditLog("user-service"))

              .addResponseFilter(Filters.slowResponseLog(2000))
              .addResponseFilter(Filters.errorLog())

              .addErrorMapper(ErrorMapper.on401(ctx ->
                      new UnauthorizedException("Auth failed: " + ctx.getUri())))
              .addErrorMapper(ErrorMapper.on429(ctx ->
                      new RateLimitException("Rate limited: " + ctx.getUri())))

              .build();
   }

   private static String getAuthToken() {

      return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";
   }

   public static void errorHandlingExamples(CBQRestClient client) {

      try {
         CBQResponse<User> block = client.get()
                 .uri("/users/999")
                 .onStatus(
                         status -> status.value() == 404,
                         ctx -> new UserNotFoundException("User not found: " + ctx.getUri())
                 )
                 .retrieve(User.class)
                 .block();
      } catch (UserNotFoundException e) {
         err.println("Caught: " + e.getMessage());

      }

      try {
         CBQResponse<User> block = client.get()
                 .uri("/users/123")
                 .onStatus(status -> status.value() == 404,
                         ctx -> new UserNotFoundException("User " + extractId(ctx.getUri()) + " not found"))
                 .onStatus(status -> status.value() == 401,
                         ctx -> new UnauthorizedException("Not authorized to access user"))
                 .onStatus(status -> status.value() == 403,
                         ctx -> new SecurityException("Forbidden: " + ctx.getResponseBody()))
                 .onStatus(HttpStatus::is5xxServerError,
                         ctx -> new ServiceUnavailableException("Service error: " + ctx.getStatusCode()))
                 .retrieve(User.class)
                 .block();
      } catch (UserNotFoundException | UnauthorizedException | ServiceUnavailableException e) {
         err.println("Error: " + e.getClass().getSimpleName() + " - " + e.getMessage());
      }

      try {
         CBQResponse<Order> orderNotFound = client.get()
                 .uri("/orders/456")
                 .onStatus(status -> status.value() == 404,
                         ctx -> new OrderNotFoundException("Order not found"))
                 .onStatus(status -> status.value() == 400,
                         ErrorMapper.ErrorContext::toException)
                 .retrieve(Order.class)
                 .block();
      } catch (OrderNotFoundException e) {

      } catch (CBQRestClientException e) {

         err.println("Request failed: " + e.getRequestId());
      }

      client.get()
              .uri("/users/123")
              .onStatus(status -> status.value() == 404,
                      ctx -> new UserNotFoundException("Not found"))
              .retrieve(User.class)
              .doOnNext(user -> out.println("Got user: " + user.getBody().getName()))
              .doOnError(UserNotFoundException.class, e ->
                      err.println("User not found!"))
              .doOnError(CBQRestClientException.class, e ->
                      err.println("Request error: " + e.getMessage()))
              .onErrorResume(UserNotFoundException.class, e ->
                      Mono.just(CBQResponse.<User>builder()
                              .body(new User(0L, "Unknown", "unknown@example.com"))
                              .build())
              )
              .subscribe(
                      user -> out.println("Final user: " + user.getBody().getName()),
                      error -> err.println("Unhandled error: " + error.getMessage())
              );
   }

   private static String extractId(String uri) {
      String[] parts = uri.split("/");
      return parts[parts.length - 1];
   }

   public static void allOverrideExamples(CBQRestClient client) {

      CBQResponse<byte[]> largeFile = client.get()
              .uri("/files/large-report.pdf")
              .override(o -> o.responseTimeout(Duration.ofMinutes(5)))
              .retrieve(byte[].class)
              .block();

      CBQResponse<String> slowEndpoint = client.get()
              .uri("/reports/generate")
              .override(o -> o.responseTimeout(Duration.ofMinutes(3)))
              .retrieve(String.class)
              .block();

      CBQResponse<PaymentResult> payment = client.post()
              .uri("/payments/process")
              .bodyValue(new PaymentRequest(123L, 99.99, "USD"))
              .override(o -> o.disableRetry())
              .retrieve(PaymentResult.class)
              .block();

      CBQResponse<String> health = client.get()
              .uri("/health")
              .override(o -> o.disableCircuitBreaker())
              .retrieve(String.class)
              .block();

      CBQResponse<String> adminOp = client.post()
              .uri("/admin/critical-operation")
              .override(o -> o.disableRateLimiter())
              .retrieve(String.class)
              .block();

      CBQResponse<String> urgent = client.get()
              .uri("/urgent/request")
              .override(o -> o.disableBulkhead())
              .retrieve(String.class)
              .block();

      CBQResponse<String> raw = client.get()
              .uri("/test/endpoint")
              .override(RequestOverride::disableAllResilience)
              .retrieve()
              .block();

      CBQResponse<String> customRetry = client.get()
              .uri("/flaky/endpoint")
              .override(o -> o
                      .maxAttempts(5)
                      .waitDuration(Duration.ofSeconds(2)))
              .retrieve(String.class)
              .block();

      CBQResponse<String> combined = client.post()
              .uri("/complex/operation")
              .bodyValue(Map.of("key", "value"))
              .override(o -> o
                      .disableRetry()
                      .disableCircuitBreaker()
                      .responseTimeout(Duration.ofMinutes(2)))
              .retrieve(String.class)
              .block();

      CBQResponse<String> longRunning = client.post()
              .uri("/batch/process")
              .bodyValue(List.of(1, 2, 3, 4, 5))
              .override(o -> o
                      .disableRetry()
                      .disableCircuitBreaker()
                      .responseTimeout(Duration.ofMinutes(10))
              )
              .retrieve(String.class)
              .block();
   }

   public static void clientPoolExamples() {

      CBQRestClientPool pool = CBQRestClientPool.builder()
              .baseUrl("https://api.example.com")
              .resilience(ResilienceConfig.defaults())
              .logging(LoggingConfig.custom().logAll().maskFields("password", "token"))
              .tracing(TracingConfig.defaults())
              .ssl(SslConfig.custom().certificatePath("/certs/api.pem"))
              .build();

      CBQRestClient fastClient = pool.getFast();
      fastClient.get()
              .uri("/health")
              .retrieve(String.class)
              .block();

      CBQRestClient defaultClient = pool.getDefault();
      defaultClient.get()
              .uri("/users/123")
              .retrieve(User.class)
              .block();

      CBQRestClient slowClient = pool.getSlow();
      slowClient.get()
              .uri("/reports/monthly")
              .retrieve(String.class)
              .block();

      CBQRestClient batchClient = pool.getBatch();
      batchClient.post()
              .uri("/batch/import")
              .bodyValue(List.of())
              .retrieve(String.class)
              .block();

      CBQRestClient customClient = pool.getOrCreate("file-upload",
              CBQRestClientPool.TimeoutProfile.builder()
                      .connection(Duration.ofSeconds(5))
                      .read(Duration.ofSeconds(30))
                      .write(Duration.ofMinutes(5))
                      .response(Duration.ofMinutes(10))
                      .build());

      customClient.post()
              .uri("/files/upload")
              .bodyValue(new byte[1024 * 1024])
              .retrieve(String.class)
              .block();

      CBQRestClient existingClient = pool.get("file-upload");

      pool.getFast().get()
              .uri("/health")
              .retrieve(String.class)
              .block();

      pool.getDefault().get()
              .uri("/users/" + "id")
              .retrieve(User.class)
              .map(CBQResponse::getBody)
              .block();

      pool.getSlow().get()
              .uri("/reports/" + "reportType")
              .override(o -> o.disableRetry())
              .retrieve(String.class)
              .map(CBQResponse::getBody)
              .block();

      List<Object> data = new ArrayList<>();
      pool.getBatch().post()
              .uri("/batch/import")
              .bodyValue(data)
              .override(o -> o
                      .disableRetry()
                      .disableCircuitBreaker()
                      .responseTimeout(Duration.ofMinutes(45)))
              .retrieve(String.class)
              .map(CBQResponse::getBody)
              .block();

      pool.shutdown();
   }

   public static void parallelWaitForAll(CBQRestClient client) {

      CBQParallelResult<Object> result = client.parallel(
              client.get().uri("/users/1").retrieve(Object.class),
              client.get().uri("/orders/100").retrieve(Object.class),
              client.get().uri("/products/50").retrieve(Object.class)
      ).waitAll().execute().block();

      if (result != null) {

         out.println("All successful: " + result.allSuccessful());
         out.println("Total duration: " + result.getTotalDurationMs() + "ms");
         out.println("Response count: " + result.size());
         out.println("Success count: " + result.successCount());
         out.println("Error count: " + result.errorCount());

         CBQResponse<Object> userResponse = result.getResponse(0);
         CBQResponse<Object> orderResponse = result.getResponse(1);
         CBQResponse<Object> productResponse = result.getResponse(2);

         User user = userResponse.bodyAs(User.class);
         Order order = orderResponse.bodyAs(Order.class);
         Product product = productResponse.bodyAs(Product.class);

         out.println("User: " + user.getName());
         out.println("Order: " + order.getStatus());
         out.println("Product: " + product.getName());

         out.println("User request ID: " + userResponse.getRequestId());
         out.println("User status: " + userResponse.getStatusCode());
         out.println("User duration: " + userResponse.getDurationMs() + "ms");
         out.println("User correlation ID: " + userResponse.getCorrelationId());

         List<Object> allBodies = result.getBodies();
         out.println("All bodies: " + allBodies.size());

         List<CBQResponse<Object>> successfulResponses = result.getSuccessfulResponses();
      }

      CBQParallelResult<User> usersResult = client.parallel(
              client.get().uri("/users/1").retrieve(User.class),
              client.get().uri("/users/2").retrieve(User.class),
              client.get().uri("/users/3").retrieve(User.class)
      ).waitAll().execute().block();

      List<User> users = usersResult.getBodies();
      users.forEach(u -> out.println("User: " + u.getName()));
   }

   public static void parallelFailFast(CBQRestClient client) {

      try {
         CBQParallelResult<User> result = client.parallel(
                 client.get().uri("/users/1").retrieve(User.class),
                 client.get().uri("/users/999").retrieve(User.class),
                 client.get().uri("/users/3").retrieve(User.class)
         ).failFast().execute().block();

         out.println("All succeeded: " + result.successCount());

      } catch (CBQRestClientException e) {

         err.println("Fail fast triggered!");
         err.println("Error: " + e.getMessage());
         err.println("Request ID: " + e.getRequestId());
         err.println("URI: " + e.getUri());
      }

      try {
         client.parallel(
                 client.get().uri("/users/1")
                         .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException("User 1 not found"))
                         .retrieve(User.class),
                 client.get().uri("/users/999")
                         .onStatus(s -> s.value() == 404, ctx -> new UserNotFoundException("User 999 not found"))
                         .retrieve(User.class)
         ).failFast().execute().block();

      } catch (UserNotFoundException e) {
         err.println("User not found: " + e.getMessage());
      }
   }

   public static void parallelPartialSuccess(CBQRestClient client) {

      CBQParallelResult<User> result = client.parallel(
              client.get().uri("/users/1").retrieve(User.class),
              client.get().uri("/users/999").retrieve(User.class),
              client.get().uri("/users/3").retrieve(User.class),
              client.get().uri("/users/888").retrieve(User.class)
      ).partialSuccess().execute().block();

      out.println("Has errors: " + result.hasErrors());
      out.println("Success count: " + result.successCount());
      out.println("Error count: " + result.errorCount());
      out.println("Total: " + result.size());

      List<CBQResponse<User>> successful = result.getSuccessfulResponses();
      out.println("Successful users:");
      for (CBQResponse<User> resp : successful) {
         out.println("  - " + resp.getBody().getName() + " (id=" + resp.getBody().getId() + ")");
      }

      Map<Integer, Throwable> errors = result.getErrors();
      out.println("Errors:");
      errors.forEach((index, error) -> {
         out.println("  - Index " + index + ": " + error.getMessage());
      });

      if (result.getError(1) != null) {
         out.println("Request at index 1 failed: " + result.getError(1).getMessage());
      }

      List<User> users = result.getBodies();
      out.println("Got " + users.size() + " users successfully");
   }

   public static void sequentialChainExamples(CBQRestClient client) {

      Product product = client.sequence()
              .then(() -> client.get()
                      .uri("/users/123")
                      .retrieve(User.class))
              .then((User user) -> client.get()
                      .uri("/orders?userId=" + user.getId())
                      .retrieve(Order[].class))
              .then((Order[] orders) -> client.get()
                      .uri("/products/" + orders[0].getId())
                      .retrieve(Product.class))
              .<Product>execute()
              .block();

      out.println("Final product: " + product.getName());

      PaymentResult paymentResult = client.sequence()

              .then(() -> client.get()
                      .uri("/users/123")
                      .override(o -> o.responseTimeout(Duration.ofSeconds(5)))
                      .retrieve(User.class))

              .then((User user) -> client.post()
                      .uri("/orders")
                      .bodyValue(Map.of("userId", user.getId(), "items", List.of(1, 2, 3)))
                      .override(o -> o.disableRetry())
                      .retrieve(Order.class))

              .then((Order order) -> client.post()
                      .uri("/payments/process")
                      .bodyValue(new PaymentRequest(order.getId(), order.getAmount(), "USD"))
                      .override(o -> o
                              .disableRetry()
                              .disableCircuitBreaker()
                              .responseTimeout(Duration.ofMinutes(1)))
                      .onErrorNotify(mail -> mail
                              .subject("Payment Failed!")
                              .addContext("orderId", order.getId()))
                      .retrieve(PaymentResult.class))
              .<PaymentResult>execute()
              .block();

      out.println("Payment transaction: " + paymentResult.getTransactionId());

      try {
         String result = client.sequence()
                 .then(() -> client.get()
                         .uri("/users/123")
                         .onStatus(s -> s.value() == 404,
                                 ctx -> new UserNotFoundException("User not found"))
                         .retrieve(User.class))
                 .then((User user) -> client.get()
                         .uri("/orders?userId=" + user.getId())
                         .onStatus(s -> s.value() == 404,
                                 ctx -> new OrderNotFoundException("No orders for user"))
                         .retrieve(Order[].class))
                 .<Order[]>execute()
                 .map(orders -> "Found " + orders.length + " orders")
                 .block();

         out.println(result);

      } catch (UserNotFoundException e) {
         err.println("User error: " + e.getMessage());
      } catch (OrderNotFoundException e) {
         err.println("Order error: " + e.getMessage());
      }
   }

   public static void disableLoggingAndMetrics() {

      CBQRestClient silentClient = CBQRestClientBuilder.builder("silent-client")
              .baseUrl("https://api.example.com")
              .logging(LoggingConfig.disabled())
              .metrics(MetricsConfig.disabled())
              .tracing(TracingConfig.disabled())
              .resilience(ResilienceConfig.disabled())
              .build();

      silentClient.get()
              .uri("/internal/health")
              .retrieve(String.class)
              .block();

      CBQRestClient minimalClient = CBQRestClientBuilder.builder("minimal")
              .baseUrl("https://api.example.com")
              .timeouts(TimeoutConfig.defaults()
                      .connection(Duration.ofSeconds(2))
                      .response(Duration.ofSeconds(5)))

              .build();

      minimalClient.get()
              .uri("/quick/check")
              .retrieve(String.class)
              .block();
   }

   public static void correlationIdExamples(CBQRestClient client) {

      CBQResponse<User> response = client.get()
              .uri("/users/123")
              .retrieve(User.class)
              .block();

      if (response != null) {
         out.println("Correlation ID: " + response.getCorrelationId());
      }
      out.println("Request ID: " + (response != null ? response.getRequestId() : null));

      String incomingCorrelationId = "abc-123-def-456";

      CBQResponse<User> response2 = client.get()
              .uri("/users/123")
              .header("X-Correlation-Id", incomingCorrelationId)
              .retrieve(User.class)
              .block();

      if (response2 != null) {
         out.println("Propagated ID: " + response2.getCorrelationId());
      }

      client.sequence()
              .then(() -> client.get().uri("/users/1").retrieve(User.class))
              .then((User user) -> client.get()
                      .uri("/orders?userId=" + user.getId())
                      .retrieve(Order[].class))
              .execute()
              .block();

      CBQParallelResult<Object> parallelResult = client.parallel(
              client.get().uri("/users/1").retrieve(Object.class),
              client.get().uri("/orders/1").retrieve(Object.class)
      ).waitAll().execute().block();

      String userId1CorrelationId = parallelResult.getResponse(0).getCorrelationId();
      String orderId1CorrelationId = parallelResult.getResponse(1).getCorrelationId();
   }

   public static void rateLimitingExamples(CBQRestClient client) {

      try {

         for (int i = 0; i < 200; i++) {
            client.get()
                    .uri("/users/" + i)
                    .retrieve(User.class)
                    .block();
         }
      } catch (RateLimitExceededException e) {
         err.println("Rate limit exceeded!");
         err.println("Rate limiter: " + e.getRateLimiterName());
         err.println("Request ID: " + e.getRequestId());
         err.println("URI: " + e.getUri());

         try {
            Thread.sleep(1000);
         } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
         }
      }

      client.get()
              .uri("/users/123")
              .retrieve(User.class)
              .doOnError(RateLimitExceededException.class, e -> err.println("Rate limited! Will retry after delay..."))
              .retryWhen(Retry.backoff(3, Duration.ofSeconds(1))
                      .filter(RateLimitExceededException.class::isInstance))
              .subscribe(
                      user -> out.println("Got user: " + user.getBody().getName()),
                      error -> err.println("Failed after retries: " + error.getMessage())
              );

      client.get()
              .uri("/admin/critical")
              .override(RequestOverride::disableRateLimiter)
              .retrieve(String.class)
              .block();

      try {
         client.get()
                 .uri("/external-api/data")
                 .onStatus(status -> status.value() == 429, ctx -> {

                    String retryAfter = ctx.getHeaders().getFirst("Retry-After");
                    return new RateLimitException(
                            "Server rate limit. Retry after: " + retryAfter);
                 })
                 .retrieve(String.class)
                 .block();
      } catch (RateLimitException e) {
         err.println(e.getMessage());
      }
   }

   public static void emailUseCases(CBQRestClient client) {

      client.post()
              .uri("/payments/process")
              .bodyValue(new PaymentRequest(100L, 99.99, "USD"))
              .onErrorNotify(mail -> mail
                      .to("payments@company.com")
                      .subject("Payment Processing Failed"))
              .retrieve(PaymentResult.class)
              .subscribe();

      PaymentRequest paymentRequest = new PaymentRequest(200L, 149.99, "EUR");

      client.post()
              .uri("/payments/process")
              .bodyValue(paymentRequest)
              .onErrorNotify(mail -> mail
                      .from("alerts@company.com")
                      .to("payments@company.com", "oncall@company.com")
                      .subject("CRITICAL: Payment Failed - Order #" + paymentRequest.getOrderId())
                      .addContext("orderId", paymentRequest.getOrderId())
                      .addContext("amount", paymentRequest.getAmount())
                      .addContext("currency", paymentRequest.getCurrency())
                      .addContext("timestamp", System.currentTimeMillis())
                      .addContext("environment", "production")
                      .html(false))
              .retrieve(PaymentResult.class)
              .subscribe();

      client.post()
              .uri("/orders/create")
              .bodyValue(Map.of("items", List.of(1, 2, 3)))
              .onErrorNotify(mail -> mail
                      .to("orders@company.com")
                      .subject("Order Creation Failed")
                      .body("<html><body>" +
                              "<h1>Order Creation Failed</h1>" +
                              "<p>Please check the order service.</p>" +
                              "</body></html>")
                      .html(true))
              .retrieve(Order.class)
              .subscribe();

      String serviceOwner = getServiceOwner("payment-service");
      String oncallEngineer = getOncallEngineer();

      client.post()
              .uri("/payments/process")
              .bodyValue(paymentRequest)
              .onErrorNotify(mail -> mail
                      .to(serviceOwner, oncallEngineer)
                      .subject("Payment Service Error"))
              .retrieve(PaymentResult.class)
              .subscribe();

      client.sequence()
              .then(() -> client.get()
                      .uri("/users/123")
                      .onErrorNotify(mail -> mail
                              .to("user-service@company.com")
                              .subject("User Lookup Failed"))
                      .retrieve(User.class))
              .then((User user) -> client.post()
                      .uri("/notifications/send")
                      .bodyValue(Map.of("userId", user.getId(), "message", "Welcome!"))
                      .onErrorNotify(mail -> mail
                              .to("notification-service@company.com")
                              .subject("Notification Send Failed")
                              .addContext("userId", user.getId()))
                      .retrieve(String.class))
              .execute()
              .subscribe();

      client.post()
              .uri("/orders/process")
              .bodyValue(Map.of("id", 123))
              .retrieve(Order.class)
              .doOnError(error -> {

                 if (error instanceof CBQRestClientException) {
                    CBQRestClientException e = (CBQRestClientException) error;
                    if (e.getStatusCode() != null && e.getStatusCode() >= 500) {

                       sendCriticalAlert(e);
                    }
                 }
              })
              .subscribe();

      client.post()
              .uri("/critical/operation")
              .bodyValue(Map.of("important", true))
              .override(o -> o.disableRetry())
              .onErrorNotify(mail -> mail
                      .to("critical-alerts@company.com")
                      .subject("URGENT: Critical Operation Failed")
                      .addContext("severity", "HIGH")
                      .addContext("requiresImmediate", true))
              .retrieve(String.class)
              .subscribe();
   }

   private static String getServiceOwner(String service) {
      return "owner-" + service + "@company.com";
   }

   private static String getOncallEngineer() {
      return "oncall@company.com";
   }

   private static void sendCriticalAlert(CBQRestClientException e) {
      err.println("Sending critical alert for: " + e.getMessage());
   }

   public static void bulkheadExamples(CBQRestClient client) {

      try {
         client.get()
                 .uri("/users/123")
                 .retrieve(User.class)
                 .block();
      } catch (BulkheadFullException e) {
         err.println("Bulkhead is full!");
         err.println("Bulkhead: " + e.getBulkheadName());
         err.println("Max concurrent calls reached");
      }

      client.get()
              .uri("/priority/request")
              .override(RequestOverride::disableBulkhead)
              .retrieve(String.class)
              .block();
   }

   public static void circuitBreakerExamples(CBQRestClient client) {

      try {
         client.get()
                 .uri("/flaky/service")
                 .retrieve(String.class)
                 .block();
      } catch (CircuitBreakerOpenException e) {
         err.println("Circuit breaker is OPEN!");
         err.println("Circuit breaker: " + e.getCircuitBreakerName());
         err.println("Service is temporarily unavailable");

      }

      client.get()
              .uri("/health")
              .override(RequestOverride::disableCircuitBreaker)
              .retrieve(String.class)
              .block();
   }

   public static void main(String[] args) {
      CBQRestClient client = createFullyConfiguredClient();

      out.println("=== CBQ REST Client v2.0 Examples ===\n");

      client.shutdown();
   }
}
