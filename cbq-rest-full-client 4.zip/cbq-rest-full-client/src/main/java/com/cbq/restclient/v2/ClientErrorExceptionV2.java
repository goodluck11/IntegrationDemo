package com.cbq.restclient.v2;

public class ClientErrorExceptionV2 extends CBQHttpExceptionV2 {
   public ClientErrorExceptionV2(int status, String msg) {
      super(status, msg);
   }
}
