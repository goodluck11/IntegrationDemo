package com.cbq.restclient.annotation.model;

import com.cbq.restclient.annotation.autoconfig.CBQClientRegistrar;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/*
 * @created by 02/02/2026  - 21:53
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(CBQClientRegistrar.class)
public @interface EnableCBQClient {
   String[] basePackages() default {};
   Class<?>[] basePackageClasses() default {};
}
