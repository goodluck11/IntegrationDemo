package com.cbq.restclient.logging;

import com.cbq.restclient.config.LoggingConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.cbq.restclient.config.ClientConstants.CID_KEY;
import static com.cbq.restclient.config.ClientConstants.RID_KEY;

public class LoggingService {
   private static final Logger log = LoggerFactory.getLogger(LoggingService.class);

   private final LoggingConfig config;
   private final ObjectMapper objectMapper;
   private final Scheduler loggingScheduler;

   private final Map<String, Pattern> maskPatterns = new HashMap<>();

   public LoggingService(LoggingConfig config) {
      this.config = config;
      this.objectMapper = new ObjectMapper();

      this.loggingScheduler = Schedulers.newBoundedElastic(2, 100, "cbq-logging");

      for (String field : config.getFieldsToMask()) {
         String pattern = String.format("(?i)(\"%s\"\\s*:\\s*\")[^\"]*(\"|$)", field);
         maskPatterns.put(field, Pattern.compile(pattern));
      }
   }

   public Mono<Void> logRequestAsync(String requestId, String cid, String method, String uri,
                                     HttpHeaders headers, Object body, String contentType) {
      if (!config.isEnabled() || !config.isLogRequest()) {
         return Mono.empty();
      }

      return Mono.fromRunnable(() -> withMdc(cid, requestId, () ->
                      logRequest(requestId, cid, method, uri, headers, body, contentType)
              ))
              .subscribeOn(loggingScheduler)
              .onErrorResume(throwable -> Mono.empty())
              .then();
   }

   public Mono<Void> logResponseAsync(String requestId, String cid, String uri, int status, HttpHeaders headers,
                                      String body, long durationMs, String contentType) {
      if (!config.isEnabled() || !config.isLogResponse()) {
         return Mono.empty();
      }

      return Mono.fromRunnable(() ->
                      withMdc(cid, requestId, () ->
                              logResponseJson(requestId, cid, uri, status, headers, body, durationMs, contentType)))
              .subscribeOn(loggingScheduler)
              .onErrorResume(throwable -> Mono.empty())
              .then();
   }

   private void logRequest(String requestId, String cid, String method, String uri,
                           HttpHeaders headers, Object body, String contentType) {
      StringBuilder sb = new StringBuilder();
      sb.append("\n╔══════════════════════════════════════════════════════════════════╗\n");
      sb.append("║ CBQ HTTP REQUEST\n");
      sb.append("╠══════════════════════════════════════════════════════════════════╣\n");
      sb.append("║ Request ID: ").append(requestId).append("\n");
      if (cid != null) sb.append("║ CID: ").append(cid).append("\n");
      sb.append("║ Method: ").append(method).append("\n");
      sb.append("║ URI: ").append(uri).append("\n");

      if (config.isLogHeaders() && headers != null) {
         sb.append("║ Headers:\n");
         headers.forEach((name, values) -> {
            if (!config.getFieldsToExclude().contains(name.toLowerCase())) {
               String value = String.join(", ", values);
               value = maskHeaderValue(name, value);
               sb.append("║   ").append(name).append(": ").append(value).append("\n");
            }
         });
      }

      if (body != null && shouldLogBody(contentType)) {
         String bodyStr = formatBody(body);
         sb.append("║ Body:\n").append(bodyStr).append("\n");
      } else if (body != null) {
         sb.append("║ Body: [").append(contentType).append(" - not logged]\n");
      }

      sb.append("╚══════════════════════════════════════════════════════════════════╝");

      log.info("{}", sb);
   }

   private void logResponse(String requestId, String cid, int status, HttpHeaders headers,
                            String body, long durationMs, String contentType) {
      StringBuilder sb = new StringBuilder();
      sb.append("\n╔══════════════════════════════════════════════════════════════════╗\n");
      sb.append("║ CBQ HTTP RESPONSE\n");
      sb.append("╠══════════════════════════════════════════════════════════════════╣\n");
      sb.append("║ Request ID: ").append(requestId).append("\n");
      sb.append("║ Status: ").append(status).append("\n");
      if (cid != null) sb.append("║ CID: ").append(cid).append("\n");
      sb.append("║ Duration: ").append(durationMs).append("ms\n");

      if (config.isLogHeaders() && headers != null) {
         sb.append("║ Headers:\n");
         headers.forEach((name, values) -> {
            if (!config.getFieldsToExclude().contains(name.toLowerCase())) {
               String value = String.join(", ", values);
               sb.append("║   ").append(name).append(": ").append(value).append("\n");
            }
         });
      }

      if (body != null && shouldLogBody(contentType)) {
         String maskedBody = maskBody(body);
         String truncatedBody = truncateBody(maskedBody);
         sb.append("║ Body:\n").append(truncatedBody).append("\n");
      } else if (body != null) {
         sb.append("║ Body: [").append(contentType).append(" - not logged]\n");
      }

      sb.append("╚══════════════════════════════════════════════════════════════════╝");

      log.info("{}", sb);
   }

   private void logResponseJson(String requestId, String cid, String uri, int status, HttpHeaders headers, String body, long durationMs,
                                String contentType) {

      StringBuilder sb = new StringBuilder();
      sb.append("\n╔══════════════════════════════════════════════════════════════════╗\n");
      sb.append(String.format("║ CBQ HTTP RESPONSE FOR: %s%n", uri));
      sb.append("╠══════════════════════════════════════════════════════════════════╣\n");

      try {
         Map<String, Object> logNode = new LinkedHashMap<>(12);

         // Standard fields
         logNode.put("timestamp", Instant.now().toString());
         logNode.put("level", status >= 400 ? (status >= 500 ? "ERROR" : "WARN") : "INFO");

         // Event classification
         logNode.put("event", "http_response");

         // Identifiers
         logNode.put(RID_KEY, requestId);
         logNode.put(CID_KEY, cid);

         logNode.put("status", status);
         logNode.put("duration_ms", durationMs);

         if (config.isLogHeaders() && headers != null) {
            ObjectNode headersNode = objectMapper.createObjectNode();
            headers.forEach((name, values) -> {
               if (!config.getFieldsToExclude().contains(name.toLowerCase())) {
                  headersNode.put(name, String.join(", ", values));
               }
            });
            logNode.put("headers", headersNode);
         }

         if (body != null && shouldLogBody(contentType)) {
            logNode.put("response", truncateBody(maskBody(body)));
         }

         sb.append("║ Payload:\n").append(objectMapper.writeValueAsString(logNode)).append("\n");
         sb.append("╚══════════════════════════════════════════════════════════════════╝");

         log.info("{}", sb);
      } catch (Exception e) {
         log.warn("Failed to create JSON log: {}", e.getMessage());
      }
   }

   private boolean shouldLogBody(String contentType) {
      return LoggingConfig.shouldLogContentType(contentType);
   }

   private String formatBody(Object body) {
      if (body == null) return "";

      String bodyStr;
      if (body instanceof String) {
         bodyStr = (String) body;
      } else {
         try {
            bodyStr = objectMapper.writeValueAsString(body);
         } catch (JsonProcessingException e) {
            bodyStr = body.toString();
         }
      }

      return truncateBody(maskBody(bodyStr));
   }

   private String maskBody(String body) {
      if (body == null || body.isEmpty()) return body;

      if (body.trim().startsWith("{") || body.trim().startsWith("[")) {
         try {
            JsonNode node = objectMapper.readTree(body);
            maskJsonNode(node);
            return objectMapper.writeValueAsString(node);
         } catch (Exception e) {
            log.debug("JSON MASKING FAILED: BODY: {}", e.getMessage());
         }
      }

      String masked = body;
      for (Map.Entry<String, Pattern> entry : maskPatterns.entrySet()) {
         Matcher matcher = entry.getValue().matcher(masked);
         int visibleChars = config.getFieldMaskLengths().getOrDefault(
                 entry.getKey().toLowerCase(), config.getDefaultVisibleChars());
         masked = matcher.replaceAll("$1" + generateMask(visibleChars) + "$2");
      }

      return masked;
   }

   private void maskJsonNode(JsonNode node) {
      if (node == null) return;

      if (node.isObject()) {
         ObjectNode objNode = (ObjectNode) node;
         Iterator<String> fieldNames = objNode.fieldNames();
         List<String> names = new ArrayList<>();
         fieldNames.forEachRemaining(names::add);

         for (String fieldName : names) {
            if (config.getFieldsToExclude().contains(fieldName.toLowerCase())) {
               objNode.remove(fieldName);
            } else if (config.getFieldsToMask().contains(fieldName.toLowerCase())) {
               int visibleChars = config.getFieldMaskLengths().getOrDefault(
                       fieldName.toLowerCase(), config.getDefaultVisibleChars());
               JsonNode valueNode = objNode.get(fieldName);
               if (valueNode != null && valueNode.isTextual()) {
                  String value = valueNode.asText();
                  objNode.put(fieldName, maskValue(value, visibleChars));
               } else {
                  objNode.put(fieldName, generateMask(0));
               }
            } else {
               maskJsonNode(objNode.get(fieldName));
            }
         }
      } else if (node.isArray()) {
         for (JsonNode element : node) {
            maskJsonNode(element);
         }
      }
   }

   private String maskValue(String value, int visibleChars) {
      if (value == null || value.length() <= visibleChars * 2) {
         return generateMask(0);
      }

      String mask = String.valueOf(config.getMaskSymbol()).repeat(
              Math.min(8, value.length() - visibleChars * 2));

      if (visibleChars > 0) {
         return value.substring(0, visibleChars) + mask +
                 value.substring(value.length() - visibleChars);
      }
      return mask;
   }

   private String generateMask(int visibleChars) {
      return String.valueOf(config.getMaskSymbol()).repeat(8);
   }

   private String maskHeaderValue(String headerName, String value) {
      String lowerName = headerName.toLowerCase();
      if (config.getFieldsToMask().contains(lowerName) ||
              lowerName.contains("authorization") ||
              lowerName.contains("token") ||
              lowerName.contains("api-key") ||
              lowerName.contains("apikey")) {
         int visibleChars = config.getFieldMaskLengths().getOrDefault(
                 lowerName, config.getDefaultVisibleChars());
         return maskValue(value, visibleChars);
      }
      return value;
   }

   private String truncateBody(String body) {
      if (body == null) return "";

      int maxSize = config.getMaxBodySize();
      if (body.length() <= maxSize) {
         return body;
      }

      return body.substring(0, maxSize) + "\n... [TRUNCATED - " +
              (body.length() - maxSize) + " more bytes]";
   }

   public void logError(String requestId, String method, String uri,
                        Throwable error, long durationMs) {
      log.error("Request {} {} failed after {}ms: {}",
              method, uri, durationMs, error.getMessage(), error);
   }

   private void withMdc(String cid, String rid, Runnable r) {
      try {
         MDC.put(CID_KEY, cid);
         MDC.put(RID_KEY, rid);
         r.run();
      } finally {
         MDC.clear();
      }
   }


   public void shutdown() {
      loggingScheduler.dispose();
   }
}
