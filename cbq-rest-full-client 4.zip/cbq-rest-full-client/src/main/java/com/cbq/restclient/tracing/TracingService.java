package com.cbq.restclient.tracing;

import com.cbq.restclient.config.TracingConfig;
import org.springframework.http.HttpHeaders;
import reactor.util.context.Context;
import reactor.util.context.ContextView;

import java.util.UUID;

public class TracingService {

   private final TracingConfig config;

   public TracingService(TracingConfig config) {
      this.config = config;
   }

   public String getOrCreateCId(HttpHeaders headers, ContextView ctx) {
      if (!config.isEnabled() || !config.isCorrelationIdEnabled()) {
         return null;
      }

      var cid = headers.getFirst(config.getCorrelationIdHeader());
      if (cid == null && ctx != null) {
         cid = ctx.<String>getOrEmpty("cid").orElse(null);
      }

      if (cid == null && config.isGenerateIfMissing()) {
         cid = generateCorrelationId();
      }

      return cid;
   }

   public void addTracingHeaders(HttpHeaders headers, String correlationId) {
      if (!config.isEnabled()) return;

      if (config.isCorrelationIdEnabled() && correlationId != null) {
         headers.set(config.getCorrelationIdHeader(), correlationId);
      }

      if (config.isOpenTelemetryEnabled()) {

      }
   }

   public void propagateHeaders(HttpHeaders source, HttpHeaders target) {
      if (!config.isEnabled()) return;

      for (String header : config.getAllPropagationHeaders()) {
         String value = source.getFirst(header);
         if (value != null) {
            target.set(header, value);
         }
      }
   }

   public Context createTracingContext(String correlationId, String requestId) {
      Context ctx = Context.empty();

      if (correlationId != null) {
         ctx = ctx.put("cid", correlationId);
      }
      if (requestId != null) {
         ctx = ctx.put("requestId", requestId);
      }

      return ctx;
   }

   public String generateCorrelationId() {
      return UUID.randomUUID().toString();
   }

   public String generateRequestId() {
      return UUID.randomUUID().toString().substring(0, 8);
   }
}
