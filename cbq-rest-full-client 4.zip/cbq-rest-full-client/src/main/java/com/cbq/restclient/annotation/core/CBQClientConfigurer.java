package com.cbq.restclient.annotation.core;

import com.cbq.restclient.config.SslConfig;
import com.cbq.restclient.filter.ErrorMapper;
import com.cbq.restclient.filter.RequestFilter;

/*
 * @created by 02/02/2026  - 21:58
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@FunctionalInterface
public interface CBQClientConfigurer {

   /**
    * Apply additional configuration to the CBQRestClient builder.
    * Called after annotation-based configuration is applied.
    *
    * @param builder the partially-configured builder
    */
   void configure(CBQRestClientBuilderAccess builder);

   interface CBQRestClientBuilderAccess {
      CBQRestClientBuilderAccess addRequestFilter(RequestFilter filter);
      CBQRestClientBuilderAccess addErrorMapper(ErrorMapper errorMapper);
      CBQRestClientBuilderAccess ssl(SslConfig sslConfig);
      CBQRestClientBuilderAccess header(String name, String value);
      Object rawBuilder();
   }
}
