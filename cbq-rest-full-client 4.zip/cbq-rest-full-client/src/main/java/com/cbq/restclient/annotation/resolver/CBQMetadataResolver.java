package com.cbq.restclient.annotation.resolver;

import com.cbq.restclient.annotation.metadata.CBQClientMetadata;
import com.cbq.restclient.annotation.metadata.CBQMethodMetadata;
import com.cbq.restclient.annotation.model.*;
import com.cbq.restclient.model.CBQOverride;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;

import java.lang.annotation.Annotation;
import java.lang.reflect.*;
import java.util.*;

import static com.cbq.restclient.annotation.metadata.CBQMethodMetadata.ParamMeta;

/*
 * @created by 02/02/2026  - 22:05
 * @project cbq-rest-full-client
 * @author Goodluck
 */
@Slf4j
public final class CBQMetadataResolver {

   private CBQMetadataResolver() {
   }

   public static CBQClientMetadata resolve(Class<?> clientInterface) {
      CBQClient clientAnn = clientInterface.getAnnotation(CBQClient.class);
      if (clientAnn == null) {
         throw new IllegalArgumentException(
                 clientInterface.getName() + " is not annotated with @CBQClient");
      }

      Map<String, CBQMethodMetadata> methods = new LinkedHashMap<>();
      for (Method method : clientInterface.getMethods()) {
         if (method.isDefault() || Modifier.isStatic(method.getModifiers())) {
            continue; // skip default and static methods
         }

         CBQMethodMetadata meta = resolveMethod(method, clientAnn);
         if (meta != null) methods.put(methodKey(method), meta);
      }

      return CBQClientMetadata.builder()
              .clientInterface(clientInterface)
              .name(clientAnn.name())
              .url(clientAnn.url())
              .pathPrefix(clientAnn.path())
              .connectionTimeout(clientAnn.connectionTimeout())
              .readTimeout(clientAnn.readTimeout())
              .writeTimeout(clientAnn.writeTimeout())
              .responseTimeout(clientAnn.responseTimeout())
              .retryEnabled(clientAnn.retryEnabled())
              .maxAttempts(clientAnn.maxAttempts())
              .waitDuration(clientAnn.waitDuration())
              .circuitBreakerEnabled(clientAnn.circuitBreakerEnabled())
              .failureRateThreshold(clientAnn.failureRateThreshold())
              .slidingWindowSize(clientAnn.slidingWindowSize())
              .openStateWaitDuration(clientAnn.openStateWaitDuration())
              .rateLimiterEnabled(clientAnn.rateLimiterEnabled())
              .limitForPeriod(clientAnn.limitForPeriod())
              .limitRefreshPeriod(clientAnn.limitRefreshPeriod())
              .bulkheadEnabled(clientAnn.bulkheadEnabled())
              .maxConcurrentCalls(clientAnn.maxConcurrentCalls())
              .maxWaitDuration(clientAnn.maxWaitDuration())
              .logLevel(clientAnn.logLevel())
              .maskFields(clientAnn.maskFields())
              .configurerBeanName(clientAnn.configurer().isEmpty() ? null : clientAnn.configurer())
              .fallbackClass(clientAnn.fallback() == void.class ? null : clientAnn.fallback())
              .fallbackFactoryClass(clientAnn.fallbackFactory() == void.class ? null : clientAnn.fallbackFactory())
              .methods(methods)
              .build();
   }

   /**
    * Parse a single method's annotations into metadata.
    */
   private static CBQMethodMetadata resolveMethod(Method method, CBQClient clientAnn) {
      HttpMethod httpMethod;
      String path;
      long methodTimeout;
      CBQOverride retryOvr;
      CBQOverride cbOvr;
      CBQOverride rlOvr;
      CBQOverride bhOvr;
      String[] methodHeaders;
      String consumes = "";
      String produces;

      if (method.isAnnotationPresent(CBQGet.class)) {
         CBQGet a = method.getAnnotation(CBQGet.class);
         httpMethod = HttpMethod.GET;
         path = a.value();
         methodTimeout = a.responseTimeout();
         retryOvr = a.retryEnabled();
         cbOvr = a.circuitBreakerEnabled();
         rlOvr = a.rateLimiterEnabled();
         bhOvr = a.bulkheadEnabled();
         methodHeaders = a.headers();
         consumes = a.consumes();
         produces = a.produces();

      } else if (method.isAnnotationPresent(CBQPost.class)) {
         CBQPost a = method.getAnnotation(CBQPost.class);
         httpMethod = HttpMethod.POST;
         path = a.value();
         methodTimeout = a.responseTimeout();
         retryOvr = a.retryEnabled();
         cbOvr = a.circuitBreakerEnabled();
         rlOvr = a.rateLimiterEnabled();
         bhOvr = a.bulkheadEnabled();
         methodHeaders = a.headers();
         consumes = a.consumes();
         produces = a.produces();

      } else if (method.isAnnotationPresent(CBQPut.class)) {
         CBQPut a = method.getAnnotation(CBQPut.class);
         httpMethod = HttpMethod.PUT;
         path = a.value();
         methodTimeout = a.responseTimeout();
         retryOvr = a.retryEnabled();
         cbOvr = a.circuitBreakerEnabled();
         rlOvr = a.rateLimiterEnabled();
         bhOvr = a.bulkheadEnabled();
         methodHeaders = a.headers();
         consumes = a.consumes();
         produces = a.produces();

      } else if (method.isAnnotationPresent(CBQDelete.class)) {
         CBQDelete a = method.getAnnotation(CBQDelete.class);
         httpMethod = HttpMethod.DELETE;
         path = a.value();
         methodTimeout = a.responseTimeout();
         retryOvr = a.retryEnabled();
         cbOvr = a.circuitBreakerEnabled();
         rlOvr = a.rateLimiterEnabled();
         bhOvr = a.bulkheadEnabled();
         methodHeaders = a.headers();
         produces = a.produces();

      } else if (method.isAnnotationPresent(CBQPatch.class)) {
         CBQPatch a = method.getAnnotation(CBQPatch.class);
         httpMethod = HttpMethod.PATCH;
         path = a.value();
         methodTimeout = a.responseTimeout();
         retryOvr = a.retryEnabled();
         cbOvr = a.circuitBreakerEnabled();
         rlOvr = a.rateLimiterEnabled();
         bhOvr = a.bulkheadEnabled();
         methodHeaders = a.headers();
         consumes = a.consumes();
         produces = a.produces();

      } else if (method.isAnnotationPresent(CBQRequest.class)) {
         CBQRequest a = method.getAnnotation(CBQRequest.class);
         httpMethod = HttpMethod.valueOf(a.method().toUpperCase());
         path = a.path();
         methodTimeout = a.responseTimeout();
         retryOvr = a.retryEnabled();
         cbOvr = a.circuitBreakerEnabled();
         rlOvr = a.rateLimiterEnabled();
         bhOvr = a.bulkheadEnabled();
         methodHeaders = a.headers();
         consumes = a.consumes();
         produces = a.produces();
      } else {
         log.warn("Method {} has no HTTP mapping annotation — skipping", method.getName());
         return null;
      }

      // ── Parse parameters ──
      List<ParamMeta> pathParams = new ArrayList<>();
      List<ParamMeta> queryParams = new ArrayList<>();
      List<ParamMeta> headerParams = new ArrayList<>();
      int bodyIndex = -1;

      Parameter[] params = method.getParameters();
      Annotation[][] paramAnnotations = method.getParameterAnnotations();

      for (int i = 0; i < params.length; i++) {
         for (Annotation ann : paramAnnotations[i]) {
            if (ann instanceof CBQPath) {
               CBQPath p = (CBQPath) ann;
               pathParams.add(ParamMeta.builder()
                       .index(i).name(p.value()).encoded(p.encoded())
                       .type(params[i].getParameterizedType()).build());

            } else if (ann instanceof CBQParam) {
               CBQParam p = (CBQParam) ann;
               queryParams.add(ParamMeta.builder()
                       .index(i).name(p.value()).defaultValue(p.defaultValue())
                       .omitNull(p.omitNull()).encoded(p.encoded())
                       .type(params[i].getParameterizedType()).build());

            } else if (ann instanceof CBQHeader) {
               CBQHeader h = (CBQHeader) ann;
               headerParams.add(ParamMeta.builder()
                       .index(i).name(h.value())
                       .type(params[i].getParameterizedType()).build());

            } else if (ann instanceof CBQBody) {
               if (bodyIndex != -1) {
                  throw new IllegalStateException("Method " + method.getName()
                          + " has multiple @CBQBody parameters — only one is allowed");
               }
               bodyIndex = i;
            }
         }
      }

      // ── Resolve return type ──
      Type returnType = method.getGenericReturnType();
      Type bodyType = resolveBodyType(returnType);
      boolean returnsMono = isReactiveType(returnType, "Mono");
      boolean returnsFlux = isReactiveType(returnType, "Flux");
      boolean returnsVoid = bodyType == Void.class || bodyType == void.class;
      boolean returnsCBQResponse = method.isAnnotationPresent(CBQExchange.class);

      // ── Merge static headers (class-level + method-level + inline) ──
      Map<String, String> mergedHeaders = new LinkedHashMap<>();
      CBQHeaders classHeaders = method.getDeclaringClass().getAnnotation(CBQHeaders.class);
      if (classHeaders != null) {
         parseStaticHeaders(classHeaders.value(), mergedHeaders);
      }

      CBQHeaders methodHeadersAnn = method.getAnnotation(CBQHeaders.class);
      if (methodHeadersAnn != null) {
         parseStaticHeaders(methodHeadersAnn.value(), mergedHeaders);
      }

      parseStaticHeaders(methodHeaders, mergedHeaders);

      // ── Resolve resilience (method overrides client) ──
      boolean retryResolved = retryOvr.resolve(clientAnn.retryEnabled());
      boolean cbResolved = cbOvr.resolve(clientAnn.circuitBreakerEnabled());
      boolean rlResolved = rlOvr.resolve(clientAnn.rateLimiterEnabled());
      boolean bhResolved = bhOvr.resolve(clientAnn.bulkheadEnabled());

      // ── Resolve @CBQRetryOn override ──
      CBQRetryOn retryOverride = method.getAnnotation(CBQRetryOn.class);

      // ── Resolve @CBQErrorMapping ──
      List<CBQErrorMapping> errorMappings = new ArrayList<>();
      CBQErrorMappings mappingsContainer = method.getAnnotation(CBQErrorMappings.class);
      if (mappingsContainer != null) {
         Collections.addAll(errorMappings, mappingsContainer.value());
      }
      CBQErrorMapping singleMapping = method.getAnnotation(CBQErrorMapping.class);
      if (singleMapping != null && mappingsContainer == null) {
         errorMappings.add(singleMapping);
      }

      // ── Resolve @CBQLog ──
      CBQLog logOverride = method.getAnnotation(CBQLog.class);
      CBQClient.LogLevel logLevel = logOverride != null ? logOverride.value() : null;

      // ── Resolve @CBQFallback ──
      CBQFallback fallbackAnn = method.getAnnotation(CBQFallback.class);
      String fallbackMethodName = fallbackAnn != null ? fallbackAnn.value() : null;
      Method fallbackMethod = null;
      if (fallbackMethodName != null) {
         fallbackMethod = resolveFallbackMethod(method, fallbackMethodName);
      }

      // ── Resolve @CBQInterceptor ──
      List<Class<?>> interceptorClasses = new ArrayList<>();
      CBQInterceptor classInterceptors = method.getDeclaringClass().getAnnotation(CBQInterceptor.class);
      if (classInterceptors != null) {
         Collections.addAll(interceptorClasses, classInterceptors.value());
      }
      CBQInterceptor methodInterceptors = method.getAnnotation(CBQInterceptor.class);
      if (methodInterceptors != null) {
         Collections.addAll(interceptorClasses, methodInterceptors.value());
      }

      return CBQMethodMetadata.builder()
              .method(method)
              .methodName(method.getName())
              .httpMethod(httpMethod)
              .pathTemplate(path)
              .consumes(consumes.isEmpty() ? "application/json" : consumes)
              .produces(produces.isEmpty() ? "application/json" : produces)
              .staticHeaders(mergedHeaders)
              .pathParams(pathParams)
              .queryParams(queryParams)
              .headerParams(headerParams)
              .bodyParamIndex(bodyIndex)
              .returnType(returnType)
              .bodyType(bodyType)
              .returnsMono(returnsMono)
              .returnsFlux(returnsFlux)
              .returnsVoid(returnsVoid)
              .returnsCBQResponse(returnsCBQResponse)
              .retryEnabled(retryResolved)
              .circuitBreakerEnabled(cbResolved)
              .rateLimiterEnabled(rlResolved)
              .bulkheadEnabled(bhResolved)
              .responseTimeout(methodTimeout)
              .retryOverride(retryOverride)
              .errorMappings(errorMappings)
              .logLevel(logLevel)
              .fallbackMethodName(fallbackMethodName)
              .fallbackMethod(fallbackMethod)
              .interceptorClasses(interceptorClasses)
              .build();
   }

   // ═══════════════════════════════════════════════════════════════════
   // UTILITIES
   // ═══════════════════════════════════════════════════════════════════

   /**
    * Unique key for a method (handles overloads).
    */
   public static String methodKey(Method method) {
      StringBuilder sb = new StringBuilder(method.getName());
      for (Class<?> paramType : method.getParameterTypes()) {
         sb.append('_').append(paramType.getSimpleName());
      }
      return sb.toString();
   }

   /**
    * Unwrap generic: Mono<User> → User, Flux<Order> → Order, CBQResponse<User> → User
    */
   private static Type resolveBodyType(Type returnType) {
      if (returnType instanceof ParameterizedType) {
         ParameterizedType pt = (ParameterizedType) returnType;
         Type[] args = pt.getActualTypeArguments();
         if (args.length > 0) {
            Type inner = args[0];
            // Handle CBQResponse<User> → User
            if (inner instanceof ParameterizedType) {
               ParameterizedType innerPt = (ParameterizedType) inner;
               String rawName = innerPt.getRawType().getTypeName();
               if (rawName.contains("CBQResponse")) {
                  Type[] innerArgs = innerPt.getActualTypeArguments();
                  return innerArgs.length > 0 ? innerArgs[0] : inner;
               }
            }
            return inner;
         }
      }
      return returnType;
   }

   private static boolean isReactiveType(Type type, String simpleName) {
      if (type instanceof ParameterizedType) {
         Type raw = ((ParameterizedType) type).getRawType();
         return raw.getTypeName().endsWith("." + simpleName);
      }
      if (type instanceof Class) {
         return ((Class<?>) type).getSimpleName().equals(simpleName);
      }
      return false;
   }

   private static void parseStaticHeaders(String[] entries, Map<String, String> target) {
      for (String entry : entries) {
         if (entry == null || entry.isEmpty()) continue;
         int colonIdx = entry.indexOf(':');
         if (colonIdx <= 0) {
            throw new IllegalArgumentException("Invalid header format '" + entry
                    + "'. Expected 'Name: Value'");
         }
         String name = entry.substring(0, colonIdx).trim();
         String value = entry.substring(colonIdx + 1).trim();
         target.put(name, value);
      }
   }

   private static Method resolveFallbackMethod(Method original, String fallbackName) {
      Class<?> declaringClass = original.getDeclaringClass();

      // Try with the same params + Throwable at end
      try {
         Class<?>[] originalParams = original.getParameterTypes();
         Class<?>[] fallbackParams = new Class[originalParams.length + 1];
         System.arraycopy(originalParams, 0, fallbackParams, 0, originalParams.length);
         fallbackParams[originalParams.length] = Throwable.class;
         return declaringClass.getMethod(fallbackName, fallbackParams);
      } catch (NoSuchMethodException ignored) {
      }

      // Try with the same params (no Throwable)
      try {
         return declaringClass.getMethod(fallbackName, original.getParameterTypes());
      } catch (NoSuchMethodException ignored) {
      }

      log.warn("Fallback method '{}' not found on {} — will check fallback class at runtime",
              fallbackName, declaringClass.getSimpleName());
      return null;
   }
}

