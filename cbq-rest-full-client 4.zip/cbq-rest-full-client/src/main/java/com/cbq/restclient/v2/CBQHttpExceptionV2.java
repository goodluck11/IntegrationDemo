package com.cbq.restclient.v2;

import lombok.Getter;

@Getter
public class CBQHttpExceptionV2 extends RuntimeException {
   private final int status;

   protected CBQHttpExceptionV2(int status, String msg) {
      super(msg);
      this.status = status;
   }
}
