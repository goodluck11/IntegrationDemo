package com.cbq.restclient.annotation.exception;

/*
 * @created by 02/02/2026  - 22:14
 * @project cbq-rest-full-client
 * @author Goodluck
 */

import lombok.Getter;

/**
 * Thrown when a @CBQClient interface has invalid annotation configuration.
 * Occurs at startup during metadata resolution — fail fast.
 */
@Getter
public class CBQClientDefinitionException extends RuntimeException {

   private final Class<?> clientInterface;

   public CBQClientDefinitionException(String message, Class<?> clientInterface) {
      super("[" + clientInterface.getSimpleName() + "] " + message);
      this.clientInterface = clientInterface;
   }

   public CBQClientDefinitionException(String message, Class<?> clientInterface, Throwable cause) {
      super("[" + clientInterface.getSimpleName() + "] " + message, cause);
      this.clientInterface = clientInterface;
   }
}
