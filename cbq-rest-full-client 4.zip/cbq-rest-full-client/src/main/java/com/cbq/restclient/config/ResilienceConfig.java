package com.cbq.restclient.config;

import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Duration;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
public class ResilienceConfig {

    private RetryConfig retryConfig = RetryConfig.disabled();
    private CircuitBreakerConfig circuitBreakerConfig = CircuitBreakerConfig.disabled();
    private RateLimiterConfig rateLimiterConfig = RateLimiterConfig.disabled();
    private BulkheadConfig bulkheadConfig = BulkheadConfig.disabled();

    public static ResilienceConfig defaults() {
        return new ResilienceConfig()
                .retry(RetryConfig.defaults())
                .circuitBreaker(CircuitBreakerConfig.defaults())
                .rateLimiter(RateLimiterConfig.defaults())
                .bulkhead(BulkheadConfig.defaults());
    }

    public static ResilienceConfig custom() {
        return new ResilienceConfig();
    }

    public static ResilienceConfig disabled() {
        return new ResilienceConfig();
    }

    public ResilienceConfig retry(RetryConfig config) {
        this.retryConfig = config;
        return this;
    }

    public ResilienceConfig circuitBreaker(CircuitBreakerConfig config) {
        this.circuitBreakerConfig = config;
        return this;
    }

    public ResilienceConfig rateLimiter(RateLimiterConfig config) {
        this.rateLimiterConfig = config;
        return this;
    }

    public ResilienceConfig bulkhead(BulkheadConfig config) {
        this.bulkheadConfig = config;
        return this;
    }

    @Getter
    public static class RetryConfig {
        private boolean enabled = false;
        private int maxAttempts = 3;
        private Duration waitDuration = Duration.ofMillis(500);
        private BackoffStrategy backoffStrategy = BackoffStrategy.EXPONENTIAL_WITH_JITTER;
        private double backoffMultiplier = 2.0;
        private Duration maxBackoff = Duration.ofSeconds(30);
        private final Set<Class<? extends Throwable>> retryExceptions = new HashSet<>();
        private final Set<Class<? extends Throwable>> ignoreExceptions = new HashSet<>();
        private boolean retryOnConnectionTimeout = true;
        private boolean retryOnReadTimeout = true;

        private RetryConfig() {}

        public static RetryConfig defaults() {
            return new RetryConfig().enabled(true);
        }

        public static RetryConfig custom() {
            return new RetryConfig().enabled(true);
        }

        public static RetryConfig disabled() {
            return new RetryConfig();
        }

        public RetryConfig enabled(boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public RetryConfig maxAttempts(int attempts) {
            this.maxAttempts = attempts;
            return this;
        }

        public RetryConfig waitDuration(Duration duration) {
            this.waitDuration = duration;
            return this;
        }

        public RetryConfig backoff(BackoffStrategy strategy) {
            this.backoffStrategy = strategy;
            return this;
        }

        public RetryConfig backoffMultiplier(double multiplier) {
            this.backoffMultiplier = multiplier;
            return this;
        }

        public RetryConfig maxBackoff(Duration max) {
            this.maxBackoff = max;
            return this;
        }

        @SafeVarargs
        public final RetryConfig retryOnExceptions(Class<? extends Throwable>... exceptions) {
            this.retryExceptions.addAll(Arrays.asList(exceptions));
            return this;
        }

        @SafeVarargs
        public final RetryConfig ignoreExceptions(Class<? extends Throwable>... exceptions) {
            this.ignoreExceptions.addAll(Arrays.asList(exceptions));
            return this;
        }

        public RetryConfig retryOnConnectionTimeout(boolean retry) {
            this.retryOnConnectionTimeout = retry;
            return this;
        }

        public RetryConfig retryOnReadTimeout(boolean retry) {
            this.retryOnReadTimeout = retry;
            return this;
        }

    }

    public enum BackoffStrategy {
        FIXED,
        EXPONENTIAL,
        EXPONENTIAL_WITH_JITTER
    }

    @Getter
    public static class CircuitBreakerConfig {
        private boolean enabled = false;
        private int windowSize = 100;
        private int minCalls = 10;
        private int halfOpenCalls = 10;
        private float failureRate = 50;
        private float slowCallRate = 100;
        private Duration slowCallDuration = Duration.ofSeconds(2);
        private Duration openStateWait = Duration.ofSeconds(60);
        private boolean autoTransition = true;

        private CircuitBreakerConfig() {}

        public static CircuitBreakerConfig defaults() {
            return new CircuitBreakerConfig().enabled(true);
        }

        public static CircuitBreakerConfig custom() {
            return new CircuitBreakerConfig().enabled(true);
        }

        public static CircuitBreakerConfig disabled() {
            return new CircuitBreakerConfig();
        }

        public CircuitBreakerConfig enabled(boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public CircuitBreakerConfig windowSize(int size) {
            this.windowSize = size;
            return this;
        }

        public CircuitBreakerConfig minCalls(int calls) {
            this.minCalls = calls;
            return this;
        }

        public CircuitBreakerConfig halfOpenCalls(int calls) {
            this.halfOpenCalls = calls;
            return this;
        }

        public CircuitBreakerConfig failureRate(float rate) {
            this.failureRate = rate;
            return this;
        }

        public CircuitBreakerConfig slowCallRate(float rate) {
            this.slowCallRate = rate;
            return this;
        }

        public CircuitBreakerConfig slowCallDuration(Duration duration) {
            this.slowCallDuration = duration;
            return this;
        }

        public CircuitBreakerConfig openStateWait(Duration duration) {
            this.openStateWait = duration;
            return this;
        }

        public CircuitBreakerConfig autoTransition(boolean auto) {
            this.autoTransition = auto;
            return this;
        }

    }

    @Getter
    public static class RateLimiterConfig {
        private boolean enabled = false;
        private int limitForPeriod = 100;
        private Duration refreshPeriod = Duration.ofSeconds(1);
        private Duration timeout = Duration.ofMillis(0);

        private RateLimiterConfig() {}

        public static RateLimiterConfig defaults() {
            return new RateLimiterConfig().enabled(true);
        }

        public static RateLimiterConfig custom() {
            return new RateLimiterConfig().enabled(true);
        }

        public static RateLimiterConfig disabled() {
            return new RateLimiterConfig();
        }

        public RateLimiterConfig enabled(boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public RateLimiterConfig limitForPeriod(int limit) {
            this.limitForPeriod = limit;
            return this;
        }

        public RateLimiterConfig refreshPeriod(Duration period) {
            this.refreshPeriod = period;
            return this;
        }

        public RateLimiterConfig timeout(Duration timeout) {
            this.timeout = timeout;
            return this;
        }

    }

    @Getter
    public static class BulkheadConfig {
        private boolean enabled = false;
        private int maxConcurrentCalls = 25;
        private Duration maxWait = Duration.ZERO;

        private BulkheadConfig() {}

        public static BulkheadConfig defaults() {
            return new BulkheadConfig().enabled(true);
        }

        public static BulkheadConfig custom() {
            return new BulkheadConfig().enabled(true);
        }

        public static BulkheadConfig disabled() {
            return new BulkheadConfig();
        }

        public BulkheadConfig enabled(boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public BulkheadConfig maxConcurrentCalls(int max) {
            this.maxConcurrentCalls = max;
            return this;
        }

        public BulkheadConfig maxWait(Duration duration) {
            this.maxWait = duration;
            return this;
        }

    }
}
