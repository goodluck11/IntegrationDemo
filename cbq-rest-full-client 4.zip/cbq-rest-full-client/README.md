# CBQ Rest Client

A production-ready, robust HTTP client wrapper for Spring Boot 2.7.x that combines WebClient with Resilience4j patterns.

## Features

- ✅ WebClient-based non-blocking HTTP client
- ✅ SSL Support (default insecure or custom certificate)
- ✅ Retry with timeout-specific options
- ✅ Circuit Breaker to prevent cascade failures
- ✅ Rate Limiter for throughput control
- ✅ Request/Response logging with field masking
- ✅ Async email notifications on errors
- ✅ Parallel & Sequential execution
- ✅ Per-request resilience overrides
- ✅ Fluent Builder API

## Quick Start

```java
// Create client
CBQRestClient client = CBQRestClientBuilder.create()
    .baseUrl("https://api.example.com")
    .withRetry(3).allTimeout().and()
    .withCircuitBreaker().failureRate(50).and()
    .logAll().maskFields("password", "token").and()
    .build();

// GET request
CBQResponse<User> response = client.get()
    .uri("/users/123")
    .execute(User.class)
    .block();

// POST request
CBQResponse<User> created = client.post()
    .uri("/users")
    .bodyValue(newUser)
    .execute(User.class)
    .block();

// Disable retry for non-idempotent operations
client.post()
    .uri("/payments")
    .bodyValue(payment)
    .withoutRetry()
    .execute(PaymentResult.class);

// Parallel execution
ParallelResult<User> results = client.parallel(
    client.get().uri("/users/1"),
    client.get().uri("/users/2"),
    client.get().uri("/users/3")
).execute(User.class).block();

// Email on error
client.post()
    .uri("/critical/operation")
    .sendEmailOnError()
        .to("alerts@company.com")
        .subject("API Error")
        .done()
    .execute(Result.class);
```

## Full Configuration Example

```java
CBQRestClient client = CBQRestClientBuilder.create("payment-service")
    .baseUrl("https://api.payment.com/v1")
    .connectionTimeout(Duration.ofSeconds(5))
    .readTimeout(Duration.ofSeconds(30))
    .header("X-Api-Key", "your-key")
    
    .withSsl()
        .certificatePath("/path/to/cert.pem")
        .and()
    
    .withRetry(3)
        .waitDuration(Duration.ofMillis(500))
        .allTimeout()
        .and()
    
    .withRateLimiter()
        .limitForPeriod(100)
        .limitRefreshPeriod(Duration.ofSeconds(1))
        .and()
    
    .withCircuitBreaker()
        .windowSize(100)
        .minCalls(10)
        .failureRate(50)
        .waitDuration(Duration.ofSeconds(60))
        .and()
    
    .logAll()
        .maskFields("password", "token", "apiKey")
        .maskSymbol('*')
        .and()
    
    .withEmail()
        .host("smtp.gmail.com")
        .port(587)
        .username("alerts@company.com")
        .password("app-password")
        .defaultTo("team@company.com")
        .and()
    
    .build();
```

## Spring Boot Integration

```java
@Configuration
public class RestClientConfig {
    
    @Bean
    public CBQRestClient apiClient() {
        return CBQRestClientBuilder.create("api-client")
            .baseUrl("${api.base-url}")
            .withRetry(3).allTimeout().and()
            .build();
    }
}

@Service
public class UserService {
    private final CBQRestClient client;
    
    public UserService(CBQRestClient client) {
        this.client = client;
    }
    
    public Mono<User> getUser(Long id) {
        return client.get()
            .uri("/users/{}", id)
            .bodyToMono(User.class);
    }
}
```

See `CBQRestClientExamples.java` for comprehensive usage examples.
