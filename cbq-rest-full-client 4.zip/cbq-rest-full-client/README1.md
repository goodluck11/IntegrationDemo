# CBQ Flux Client

A production-ready HTTP client library for Java/Spring applications with built-in resilience, observability, and workflow capabilities.

---

## 📦 Maven Dependency

```xml
<dependency>
    <groupId>com.cbq.flux</groupId>
    <artifactId>cbq-flux-client</artifactId>
    <version>2.0.0</version>
</dependency>
```

### Optional Dependencies (add only what you need)

```xml
<!-- Spring Mail - for email notifications -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-mail</artifactId>
</dependency>
```

---

## 🚀 Quick Start

### Simplest Setup

```java
FluxHttpClient client = FluxHttpClientBuilder.builder()
    .baseUrl("https://api.example.com")
    .build();

// GET request
User user = client.get()
    .uri("/users/1")
    .retrieveBody(User.class)
    .block();

// POST request
Order order = client.post()
    .uri("/orders")
    .bodyValue(new CreateOrderRequest("item-1", 2))
    .retrieveBody(Order.class)
    .block();

// Don't forget to shutdown
client.shutdown();
```

### Production Setup

```java
FluxHttpClient client = FluxHttpClientBuilder.builder("payment-service")
    .baseUrl("https://api.payment.com")
    
    // Timeouts
    .timeouts(TimeoutConfig.custom()
        .connection(Duration.ofSeconds(5))
        .read(Duration.ofSeconds(30))
        .response(Duration.ofSeconds(60)))
    
    // Resilience (retry, circuit breaker)
    .resilience(ResilienceConfig.custom()
        .retry(RetryConfig.custom()
            .maxAttempts(3)
            .waitDuration(Duration.ofMillis(500)))
        .circuitBreaker(CircuitBreakerConfig.custom()
            .failureRate(50)
            .openStateWait(Duration.ofSeconds(30))))
    
    // Logging (JSON format for Splunk)
    .logging(LoggingConfig.custom()
        .logAll()
        .jsonFormat()
        .serviceName("payment-service")
        .maskFields("cardNumber", "cvv", "password"))
    
    // Default headers
    .header("X-API-Version", "2.0")
    
    // Auth filter
    .addRequestFilter(Filters.bearerToken(() -> tokenService.getToken()))
    
    .build();
```

---

## 📖 Table of Contents

1. [HTTP Methods](#1-http-methods)
2. [Request Options](#2-request-options)
3. [Response Handling](#3-response-handling)
4. [Parallel Execution](#4-parallel-execution)
5. [Sequential Execution](#5-sequential-execution)
6. [FluxHttpWorkflow - Advanced Workflows](#6-fluxhttpworkflow---advanced-workflows)
7. [Resilience (Retry, Circuit Breaker)](#7-resilience)
8. [Logging & Masking](#8-logging--masking)
9. [Error Handling](#9-error-handling)
10. [Filters](#10-filters)
11. [Real-World Examples](#11-real-world-examples)

---

## 1. HTTP Methods

```java
// GET
client.get().uri("/users").retrieve(UserList.class);

// POST
client.post().uri("/users").bodyValue(newUser).retrieve(User.class);

// PUT
client.put().uri("/users/1").bodyValue(updateUser).retrieve(User.class);

// PATCH
client.patch().uri("/users/1").bodyValue(partialUpdate).retrieve(User.class);

// DELETE
client.delete().uri("/users/1").retrieve(Void.class);

// HEAD
client.head().uri("/users/1").retrieve(Void.class);

// OPTIONS
client.options().uri("/users").retrieve(String.class);
```

### URI with Variables

```java
// Single variable
client.get().uri("/users/{}", userId).retrieve(User.class);

// Multiple variables
client.get().uri("/users/{}/orders/{}", userId, orderId).retrieve(Order.class);
```

---

## 2. Request Options

### Headers

```java
client.post()
    .uri("/orders")
    .header("X-Idempotency-Key", UUID.randomUUID().toString())
    .header("X-Request-Source", "mobile-app")
    .headers(h -> {
        h.add("X-Custom-1", "value1");
        h.add("X-Custom-2", "value2");
    })
    .bodyValue(order)
    .retrieve(Order.class);
```

### Content Type

```java
// JSON (default)
client.post().uri("/api").bodyValue(obj).retrieve(Result.class);

// Form data
client.post()
    .uri("/login")
    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
    .bodyValue("username=john&password=secret")
    .retrieve(LoginResult.class);
```

### Per-Request Timeout Override

```java
// Override timeout for slow endpoint
client.post()
    .uri("/reports/generate")
    .bodyValue(request)
    .override(o -> o
        .responseTimeout(Duration.ofMinutes(5))
        .retryEnabled(false)
        .circuitBreakerEnabled(false))
    .retrieve(Report.class);
```

---

## 3. Response Handling

### Full Response (with metadata)

```java
FluxResponse<User> response = client.get()
    .uri("/users/1")
    .retrieve(User.class)
    .block();

User user = response.getBody();
int status = response.getStatus().value();
HttpHeaders headers = response.getHeaders();
long duration = response.getDurationMs();
String requestId = response.getRequestId();
```

### Body Only (simpler)

```java
User user = client.get()
    .uri("/users/1")
    .retrieveBody(User.class)
    .block();
```

### Blocking vs Reactive

```java
// Blocking (traditional code)
User user = client.get().uri("/users/1").retrieveBody(User.class).block();

// Blocking with timeout
User user = client.get().uri("/users/1").retrieveBody(User.class)
    .block(Duration.ofSeconds(10));

// Reactive (WebFlux)
Mono<User> userMono = client.get().uri("/users/1").retrieveBody(User.class);

// Subscribe
client.get().uri("/users/1").retrieveBody(User.class)
    .subscribe(
        user -> log.info("Got user: {}", user.getName()),
        error -> log.error("Failed: {}", error.getMessage())
    );
```

### Streaming (Flux)

```java
Flux<Event> events = client.get()
    .uri("/events/stream")
    .retrieveFlux(Event.class);

events.subscribe(event -> processEvent(event));
```

---

## 4. Parallel Execution

Execute multiple requests at the same time.

### Basic Parallel

```java
FluxParallelResult<Object> result = client.parallel(
    client.get().uri("/users/1").retrieve(User.class),
    client.get().uri("/orders/recent").retrieve(OrderList.class),
    client.get().uri("/notifications").retrieve(NotificationList.class)
).execute().block();

// Get results by index
User user = (User) result.getResponses().get(0).getBody();
OrderList orders = (OrderList) result.getResponses().get(1).getBody();
```

### Parallel Strategies

| Strategy | Behavior |
|----------|----------|
| `waitAll()` | Wait for ALL requests (default) |
| `failFast()` | Stop on FIRST failure |
| `partialSuccess()` | Continue even if some fail |

```java
// WAIT_ALL - Wait for all, fail if any fails
client.parallel(req1, req2, req3)
    .waitAll()
    .execute();

// FAIL_FAST - Stop immediately on first failure
client.parallel(req1, req2, req3)
    .failFast()
    .execute();

// PARTIAL_SUCCESS - Get what you can
FluxParallelResult<User> result = client.parallel(req1, req2, req3)
    .partialSuccess()
    .execute()
    .block();

// Check for errors
if (result.hasErrors()) {
    result.getErrors().forEach((index, error) -> 
        log.warn("Request {} failed: {}", index, error.getMessage()));
}
```

---

## 5. Sequential Execution

Execute requests in order, passing data from one to the next.

```java
// Step 1 result feeds into Step 2
Order order = client.sequence()
    .then(() -> client.get().uri("/users/1").retrieve(User.class))
    .then((User user) -> client.post()
        .uri("/orders")
        .bodyValue(new CreateOrderRequest(user.getId(), items))
        .retrieve(Order.class))
    .<Order>execute()
    .block();
```

---

## 6. FluxHttpWorkflow - Advanced Workflows

The most powerful feature for complex operations.

### Quick Reference

| Method | Waits? | Has Result? | Use For |
|--------|--------|-------------|---------|
| `step()` | ✅ Yes | ✅ Yes | HTTP calls |
| `stepMono()` | ✅ Yes | ✅ Yes | Reactive DB (R2DBC) |
| `stepSync()` | ✅ Yes | ✅ Yes | Blocking DB (JPA/JDBC) |
| `stepContinueOnError()` | ✅ Yes | ✅ Yes | Non-critical steps |
| `fireAndForget()` | ❌ No | ❌ No | Background HTTP |
| `fireAndForgetMono()` | ❌ No | ❌ No | Background reactive |
| `fireAndForgetSync()` | ❌ No | ❌ No | Background blocking |
| `fireAndForgetWith()` | ❌ No | ✅ Yes | Background with result |
| `onFailure()` | - | ❌ No | HTTP rollback |
| `onFailureSync()` | - | ✅ Yes | Blocking rollback |

### 6.1 Basic Workflow

```java
Order order = FluxHttpWorkflow
    // Step 1: Validate
    .startWith(() -> client.post()
        .uri("/validate")
        .bodyValue(request)
        .retrieve(ValidationResult.class))
    
    // Step 2: Create order (uses validation result)
    .step(validation -> client.post()
        .uri("/orders")
        .bodyValue(new OrderRequest(validation.getAccountId()))
        .retrieve(Order.class))
    
    .execute();
```

### 6.2 With Database Calls

```java
// Reactive DB (R2DBC)
Order order = FluxHttpWorkflow
    .startWith(() -> client.post().uri("/orders").retrieve(Order.class))
    .stepMono(order -> reactiveOrderRepo.save(order))  // Reactive DB
    .execute();

// Blocking DB (JPA/JDBC)
Order order = FluxHttpWorkflow
    .startWith(() -> client.post().uri("/orders").retrieve(Order.class))
    .stepSync(order -> jpaOrderRepo.save(order))  // Blocking DB
    .execute();
```

### 6.3 Fire-and-Forget (Background Tasks)

```java
Order order = FluxHttpWorkflow
    // Main: Create order (waits)
    .startWith(() -> client.post()
        .uri("/orders")
        .bodyValue(request)
        .retrieve(Order.class))
    
    // Background: These don't block the response
    .fireAndForget(
        () -> client.post().uri("/audit").bodyValue(audit).retrieve(Void.class),
        () -> client.post().uri("/analytics").bodyValue(event).retrieve(Void.class)
    )
    
    // Background with result access
    .fireAndForgetWith(order -> client.post()
        .uri("/email/send")
        .bodyValue(new EmailRequest(order.getCustomerEmail(), "Order confirmed"))
        .retrieve(Void.class))
    
    // Background DB save
    .fireAndForgetSync(() -> auditRepo.save(new AuditLog("order_created")))
    
    .execute();  // Returns immediately after order created
```

### 6.4 Continue on Error (Non-Critical Steps)

**Use Case:** Step 2 fails but you still want Step 1's result.

```java
TransferResult result = FluxHttpWorkflow
    // Step 1: Main transfer (critical)
    .startWith(() -> client.post()
        .uri("/transfers")
        .bodyValue(request)
        .retrieve(TransferResult.class))
    
    // Step 2: Partner notification (non-critical)
    // If fails → logs error, continues with Step 1 result
    .stepContinueOnError(transfer -> client.post()
        .uri("/partners/notify")
        .bodyValue(new PartnerNotification(transfer.getId()))
        .retrieve(NotificationResult.class))
    
    // Step 3: Update status (runs even if Step 2 failed)
    .step(transfer -> client.post()
        .uri("/transfers/complete")
        .bodyValue(new CompleteRequest(transfer.getId()))
        .retrieve(TransferResult.class))
    
    .execute();
```

### More stepContinueOnError Examples

#### Example 1: HTTP Call with Inline Result Capture

Create order, then create notification. If notification fails, continue with empty ID.
```java
public OrderResponse createOrder(CreateOrderRequest request) {
    
    AtomicReference<String> notificationId = new AtomicReference<>("");
    
    Order order = FluxHttpWorkflow
        .startWith(() -> client.post()
            .uri("/orders")
            .bodyValue(request)
            .retrieve(Order.class))
        
        .stepContinueOnError(o -> 
            client.post()
                .uri("/notifications")
                .bodyValue(new NotificationRequest(o.getId()))
                .retrieve(Notification.class)
                .doOnNext(resp -> notificationId.set(resp.getBody().getId()))
        )
        .execute();
    
    return new OrderResponse(order.getId(), order.getAmount(), notificationId.get());
}
```

---

#### Example 2: DB Call with Success/Error Callbacks

Create order, then save notification to DB. If DB fails, continue with empty ID.
```java
public OrderResponse createOrder(CreateOrderRequest request) {
    
    AtomicReference<String> notificationId = new AtomicReference<>("");
    
    Order order = FluxHttpWorkflow
        .startWith(() -> client.post()
            .uri("/orders")
            .bodyValue(request)
            .retrieve(Order.class))
        
        .stepContinueOnError(
            o -> notificationRepository.save(new Notification(o.getId())),
            notification -> notificationId.set(notification.getId()),
            error -> log.warn("Notification failed: {}", error.getMessage())
        )
        .execute();
    
    return new OrderResponse(order.getId(), order.getAmount(), notificationId.get());
}
```

---

#### Example 3: Continue to Next Step After Optional Step

Create transfer, try to generate receipt, then complete transfer regardless of receipt result.
```java
public TransferResponse processTransfer(TransferRequest request) {
    
    AtomicReference<String> receiptId = new AtomicReference<>("");
    
    TransferResult result = FluxHttpWorkflow
        .startWith(() -> client.post()
            .uri("/transfers")
            .bodyValue(request)
            .retrieve(TransferResult.class))
        
        .stepContinueOnError(
            transfer -> client.post()
                .uri("/receipts")
                .bodyValue(new ReceiptRequest(transfer.getId()))
                .retrieveBody(Receipt.class),
            receipt -> receiptId.set(receipt.getId()),
            error -> log.warn("Receipt generation failed: {}", error.getMessage())
        )
        
        // This runs regardless of receipt success/failure
        .step(transfer -> client.post()
            .uri("/transfers/complete")
            .bodyValue(new CompleteRequest(transfer.getId()))
            .retrieve(TransferResult.class))
        
        .execute();
    
    return new TransferResponse(result.getId(), result.getAmount(), receiptId.get());
}
```

**With custom error handler:**

```java
.stepContinueOnError(
    transfer -> client.post().uri("/notify").retrieve(Void.class),
    error -> log.warn("Notification failed: {}", error.getMessage())
)
```

### 6.5 Rollback on Failure

```java
PaymentResult result = FluxHttpWorkflow
    // Step 1: Reserve funds
    .startWith(() -> client.post()
        .uri("/accounts/reserve")
        .bodyValue(new ReserveRequest(accountId, amount))
        .retrieve(ReservationResult.class))
    
    // Step 2: Process payment
    .step(reservation -> client.post()
        .uri("/payments/execute")
        .bodyValue(new ExecuteRequest(reservation.getId()))
        .retrieve(PaymentResult.class))
    
    // If ANY step fails: Release funds
    .onFailure(() -> client.post()
        .uri("/accounts/release")
        .bodyValue(new ReleaseRequest(accountId))
        .retrieve(Void.class))
    
    .execute();
```

### 6.6 Deep Chain with Partial Results

**Scenario:** Chain of 5 calls. Return results of successful calls even if later ones fail.

```java
public ChainResult processChain(Request request) {
    ChainResult result = new ChainResult();
    
    try {
        // Step 1: First API call
        FirstResult first = FluxHttpWorkflow
            .startWith(() -> client.post()
                .uri("/step1")
                .bodyValue(request)
                .retrieve(FirstResult.class))
            .execute();
        result.setFirst(first);  // Save result
        
        // Step 2: Second API call (uses first result)
        // If fails, we still have first result
        SecondResult second = FluxHttpWorkflow
            .startWith(first)
            .step(f -> client.post()
                .uri("/step2")
                .bodyValue(new Step2Request(f.getId()))
                .retrieve(SecondResult.class))
            .stepContinueOnError(s -> client.post()
                .uri("/step2-optional")
                .retrieve(Void.class))
            .execute();
        result.setSecond(second);
        
        // Step 3: Third API call
        ThirdResult third = FluxHttpWorkflow
            .startWith(second)
            .step(s -> client.post()
                .uri("/step3")
                .bodyValue(new Step3Request(s.getId()))
                .retrieve(ThirdResult.class))
            .execute();
        result.setThird(third);
        
    } catch (Exception e) {
        result.setError(e.getMessage());
        // Result contains whatever succeeded before failure
    }
    
    return result;
}
```

### 6.7 Combined: HTTP + DB + Continue on Error

```java
public OrderResult createOrder(CreateOrderRequest request, String correlationId) {
    
    return FluxHttpWorkflow
        // Step 1: Validate with external API
        .startWith(() -> client.post()
            .uri("/validation/check")
            .header("X-Correlation-Id", correlationId)
            .bodyValue(request)
            .retrieve(ValidationResult.class))
        
        // Step 2: Save to DB (blocking)
        .stepSync(validation -> {
            Order order = new Order();
            order.setAccountId(validation.getAccountId());
            order.setAmount(request.getAmount());
            order.setStatus("PENDING");
            return orderRepository.save(order);
        })
        
        // Step 3: Process payment
        .step(order -> client.post()
            .uri("/payments/charge")
            .header("X-Correlation-Id", correlationId)
            .bodyValue(new ChargeRequest(order.getId(), order.getAmount()))
            .retrieve(PaymentResult.class))
        
        // Step 4: Update order status (DB)
        .stepSync(payment -> {
            Order order = orderRepository.findById(payment.getOrderId()).get();
            order.setStatus("PAID");
            order.setPaymentId(payment.getId());
            return orderRepository.save(order);
        })
        
        // Step 5: Notify partner (non-critical - continue if fails)
        .stepContinueOnError(
            order -> client.post()
                .uri("/partners/notify")
                .bodyValue(new PartnerNotification(order.getId()))
                .retrieve(Void.class),
            error -> log.warn("Partner notification failed: {}", error.getMessage())
        )
        
        // Background: Send email, update analytics
        .fireAndForgetWith(order -> client.post()
            .uri("/email/confirmation")
            .bodyValue(new EmailRequest(request.getEmail(), order.getId()))
            .retrieve(Void.class))
        
        .fireAndForgetSync(() -> 
            analyticsRepository.trackEvent("order_created", request.getAmount()))
        
        // Rollback: If payment fails, mark order as failed
        .onFailureSync(error -> {
            log.error("Order creation failed: {}", error.getMessage());
            // Update order status to FAILED
        })
        
        .execute();
}
```

### 6.8 Async Execution

```java
// Non-blocking - returns Mono
Mono<Order> orderMono = FluxHttpWorkflow
    .startWith(() -> client.post().uri("/orders").retrieve(Order.class))
    .executeAsync();

// Subscribe to result
orderMono.subscribe(
    order -> log.info("Order created: {}", order.getId()),
    error -> log.error("Failed: {}", error.getMessage())
);

// Fire completely in background (no result tracking)
FluxHttpWorkflow
    .startWith(() -> client.post().uri("/background/job").retrieve(Void.class))
    .executeAndForget();  // Returns immediately
```

---

## 7. Resilience

### Retry

```java
ResilienceConfig.custom()
    .retry(RetryConfig.custom()
        .enabled(true)
        .maxAttempts(3)
        .waitDuration(Duration.ofMillis(500))
        .backoffStrategy(BackoffStrategy.EXPONENTIAL_WITH_JITTER)
        .retryOnConnectionTimeout(true)
        .retryOnReadTimeout(true))
```

### Circuit Breaker

```java
ResilienceConfig.custom()
    .circuitBreaker(CircuitBreakerConfig.custom()
        .enabled(true)
        .failureRate(50)           // Open at 50% failures
        .slowCallRate(80)          // Open at 80% slow calls
        .slowCallDuration(Duration.ofSeconds(5))
        .windowSize(10)
        .openStateWait(Duration.ofSeconds(30)))
```

### Rate Limiter

```java
ResilienceConfig.custom()
    .rateLimiter(RateLimiterConfig.custom()
        .enabled(true)
        .limitForPeriod(100)       // 100 calls per second
        .refreshPeriod(Duration.ofSeconds(1)))
```

### Disable Per-Request

```java
client.post()
    .uri("/payments/charge")
    .override(o -> o
        .retryEnabled(false)
        .circuitBreakerEnabled(false))
    .retrieve(Result.class);
```

---

## 8. Logging & Masking

### JSON Format (Splunk-Friendly)

```java
LoggingConfig.custom()
    .logAll()
    .jsonFormat()                    // Single-line JSON
    .serviceName("order-service")
    .maskFields("password", "cardNumber", "cvv", "token")
    .maskField("iban", 4)            // Show first/last 4 chars
    .maxBodySize(10_000)             // Truncate large bodies
```

### JSON Log Output

```json
{"timestamp":"2024-01-15T10:30:00Z","service":"order-service","type":"request","request_id":"req_001","correlation_id":"corr_abc123","method":"POST","uri":"/orders","body":{"amount":100,"cardNumber":"4111********1111"}}

{"timestamp":"2024-01-15T10:30:01Z","service":"order-service","type":"response","request_id":"req_001","correlation_id":"corr_abc123","status":200,"duration_ms":245}
```

### Pretty Format (Human-Readable)

```java
LoggingConfig.custom()
    .logAll()
    .prettyFormat()  // Box format
```

```
╔══════════════════════════════════════════════════════════════════╗
║ FLUX HTTP REQUEST
╠══════════════════════════════════════════════════════════════════╣
║ Request ID: req_001
║ Correlation ID: corr_abc123
║ Method: POST
║ URI: /orders
║ Body:
{
  "amount": 100,
  "cardNumber": "4111********1111"
}
╚══════════════════════════════════════════════════════════════════╝
```

### Log Other Tasks (DB, Email, etc.)

```java
LoggingService logger = client.getLoggingService();
String correlationId = "corr_abc123";

// DB operation
logger.logDb(correlationId, "save", "orders", order, durationMs);

// Email
logger.logEmail(correlationId, "send", "john@example.com", data, durationMs);

// Cache
logger.logCache(correlationId, "set", "order:123", null, durationMs);

// Queue
logger.logQueue(correlationId, "publish", "order-events", event, durationMs);
```

---

## 9. Error Handling

### Global Error Mappers

```java
FluxHttpClientBuilder.builder()
    .addErrorMapper(ErrorMapper.onStatus(
        status -> status == HttpStatus.NOT_FOUND,
        ctx -> new ResourceNotFoundException("Not found: " + ctx.getUri())))
    
    .addErrorMapper(ErrorMapper.onStatus(
        status -> status == HttpStatus.UNAUTHORIZED,
        ctx -> new AuthException("Authentication failed")))
    
    .addErrorMapper(ErrorMapper.onStatus(
        HttpStatus::is5xxServerError,
        ctx -> new ServiceException("Service error: " + ctx.getBody())))
    
    .build();
```

### Per-Request Error Handling

```java
User user = client.get()
    .uri("/users/{}", userId)
    .onStatus(
        status -> status == HttpStatus.NOT_FOUND,
        ctx -> new UserNotFoundException("User not found: " + userId))
    .retrieveBody(User.class)
    .block();
```

### Try-Catch Pattern

```java
try {
    Order order = FluxHttpWorkflow
        .startWith(() -> client.post().uri("/orders").retrieve(Order.class))
        .execute();
    return ApiResponse.success(order);
    
} catch (ResourceNotFoundException e) {
    return ApiResponse.error("NOT_FOUND", e.getMessage());
    
} catch (FluxHttpClientException e) {
    log.error("HTTP error - requestId: {}", e.getRequestId(), e);
    return ApiResponse.error("SERVICE_ERROR", "Please try again");
    
} catch (Exception e) {
    return ApiResponse.error("INTERNAL_ERROR", "Unexpected error");
}
```

---

## 10. Filters

### Built-in Filters

```java
// Bearer token (dynamic)
Filters.bearerToken(() -> tokenService.getAccessToken())

// Basic auth
Filters.basicAuth("username", "password")

// API key
Filters.apiKey("X-API-Key", "my-api-key")

// Custom headers
Filters.headers("X-Client", "my-app", "X-Version", "1.0")
```

### Custom Filter

```java
RequestFilter correlationFilter = context -> {
    String correlationId = MDC.get("correlationId");
    if (correlationId != null) {
        context.addHeader("X-Correlation-Id", correlationId);
    }
    return Mono.just(context);
};

FluxHttpClientBuilder.builder()
    .addRequestFilter(correlationFilter)
    .build();
```

---

## 11. Real-World Examples

### Payment Service

```java
@Service
public class PaymentService {
    
    private final FluxHttpClient client;
    private final PaymentRepository repository;
    
    public PaymentResult processPayment(PaymentRequest request) {
        String correlationId = UUID.randomUUID().toString();
        
        return FluxHttpWorkflow
            // 1. Fraud check
            .startWith(() -> client.post()
                .uri("/fraud/check")
                .header("X-Correlation-Id", correlationId)
                .bodyValue(request)
                .retrieve(FraudResult.class))
            
            // 2. Validate
            .step(fraud -> {
                if (fraud.getRiskScore() > 80) {
                    throw new FraudException("High risk transaction");
                }
                return client.post()
                    .uri("/validation")
                    .bodyValue(request)
                    .retrieve(ValidationResult.class);
            })
            
            // 3. Charge
            .step(validation -> client.post()
                .uri("/charge")
                .bodyValue(new ChargeRequest(validation.getToken(), request.getAmount()))
                .retrieve(PaymentResult.class))
            
            // 4. Save to DB
            .stepSync(payment -> {
                repository.save(Payment.from(payment));
                return payment;
            })
            
            // Background tasks
            .fireAndForgetWith(payment -> client.post()
                .uri("/notifications/email")
                .bodyValue(new EmailRequest(request.getEmail(), payment.getId()))
                .retrieve(Void.class))
            
            // Rollback on failure
            .onFailure(() -> client.post()
                .uri("/payments/rollback")
                .bodyValue(new RollbackRequest(request.getTransactionId()))
                .retrieve(Void.class))
            
            .execute(Duration.ofSeconds(30));
    }
}
```

### Dashboard Aggregation (Parallel)

```java
@Service
public class DashboardService {
    
    private final FluxHttpClient client;
    
    public DashboardData getDashboard(String userId) {
        FluxParallelResult<Object> result = client.parallel(
            client.get().uri("/users/{}", userId).retrieve(User.class),
            client.get().uri("/orders/recent?userId={}", userId).retrieve(OrderList.class),
            client.get().uri("/notifications?userId={}", userId).retrieve(NotificationList.class),
            client.get().uri("/recommendations?userId={}", userId).retrieve(RecommendationList.class)
        )
        .partialSuccess()  // Don't fail if recommendations is down
        .execute()
        .block();
        
        DashboardData dashboard = new DashboardData();
        dashboard.setUser((User) getResult(result, 0));
        dashboard.setOrders((OrderList) getResult(result, 1));
        dashboard.setNotifications((NotificationList) getResult(result, 2));
        dashboard.setRecommendations((RecommendationList) getResult(result, 3));
        
        return dashboard;
    }
    
    private Object getResult(FluxParallelResult<?> result, int index) {
        return result.getErrors().containsKey(index) 
            ? null 
            : result.getResponses().get(index).getBody();
    }
}
```

---

## 💡 Tips

1. **Always call `shutdown()`** when your application stops
2. **Use `correlationId`** to trace requests across services
3. **Use `stepContinueOnError()`** for non-critical steps
4. **Use `fireAndForget*()`** for background tasks that shouldn't block response
5. **Use `partialSuccess()`** for parallel calls where some can fail
6. **Mask sensitive fields** in logs (passwords, tokens, card numbers)
7. **Set appropriate timeouts** per endpoint type

